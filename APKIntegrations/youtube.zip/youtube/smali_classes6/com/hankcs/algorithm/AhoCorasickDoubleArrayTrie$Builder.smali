.class Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;
.super Ljava/lang/Object;
.source "AhoCorasickDoubleArrayTrie.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "Builder"
.end annotation


# instance fields
.field private allocSize:I

.field private keySize:I

.field private nextCheckPos:I

.field private progress:I

.field private rootState:Lcom/hankcs/algorithm/State;

.field final synthetic this$0:Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;

.field private used:[Z


# direct methods
.method private constructor <init>(Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;)V
    .locals 0

    .line 682
    .local p0, "this":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<TV;>.Builder;"
    iput-object p1, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->this$0:Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 687
    new-instance p1, Lcom/hankcs/algorithm/State;

    invoke-direct {p1}, Lcom/hankcs/algorithm/State;-><init>()V

    iput-object p1, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->rootState:Lcom/hankcs/algorithm/State;

    return-void
.end method

.method synthetic constructor <init>(Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$1;)V
    .locals 0
    .param p1, "x0"    # Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;
    .param p2, "x1"    # Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$1;

    .line 682
    .local p0, "this":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<TV;>.Builder;"
    invoke-direct {p0, p1}, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;-><init>(Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;)V

    return-void
.end method

.method private addAllKeyword(Ljava/util/Collection;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Collection<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 778
    .local p0, "this":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<TV;>.Builder;"
    .local p1, "keywordSet":Ljava/util/Collection;, "Ljava/util/Collection<Ljava/lang/String;>;"
    const/4 v0, 0x0

    .line 779
    .local v0, "i":I
    invoke-interface {p1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    .line 781
    .local v2, "keyword":Ljava/lang/String;
    add-int/lit8 v3, v0, 0x1

    .end local v0    # "i":I
    .local v3, "i":I
    invoke-direct {p0, v2, v0}, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->addKeyword(Ljava/lang/String;I)V

    .line 782
    .end local v2    # "keyword":Ljava/lang/String;
    move v0, v3

    goto :goto_0

    .line 783
    .end local v3    # "i":I
    .restart local v0    # "i":I
    :cond_0
    return-void
.end method

.method private addKeyword(Ljava/lang/String;I)V
    .locals 5
    .param p1, "keyword"    # Ljava/lang/String;
    .param p2, "index"    # I

    .line 762
    .local p0, "this":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<TV;>.Builder;"
    iget-object v0, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->rootState:Lcom/hankcs/algorithm/State;

    .line 763
    .local v0, "currentState":Lcom/hankcs/algorithm/State;
    invoke-virtual {p1}, Ljava/lang/String;->toCharArray()[C

    move-result-object v1

    array-length v2, v1

    const/4 v3, 0x0

    :goto_0
    if-ge v3, v2, :cond_0

    aget-char v4, v1, v3

    invoke-static {v4}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v4

    .line 765
    .local v4, "character":Ljava/lang/Character;
    invoke-virtual {v0, v4}, Lcom/hankcs/algorithm/State;->addState(Ljava/lang/Character;)Lcom/hankcs/algorithm/State;

    move-result-object v0

    .line 763
    .end local v4    # "character":Ljava/lang/Character;
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    .line 767
    :cond_0
    invoke-virtual {v0, p2}, Lcom/hankcs/algorithm/State;->addEmit(I)V

    .line 768
    iget-object v1, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->this$0:Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;

    iget-object v1, v1, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->l:[I

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v2

    aput v2, v1, p2

    .line 769
    return-void
.end method

.method private buildDoubleArrayTrie(I)V
    .locals 4
    .param p1, "keySize"    # I

    .line 843
    .local p0, "this":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<TV;>.Builder;"
    const/4 v0, 0x0

    iput v0, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->progress:I

    .line 844
    iput p1, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->keySize:I

    .line 845
    const/high16 v1, 0x200000

    invoke-direct {p0, v1}, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->resize(I)I

    .line 847
    iget-object v1, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->this$0:Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;

    iget-object v1, v1, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->base:[I

    const/4 v2, 0x1

    aput v2, v1, v0

    .line 848
    iput v0, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->nextCheckPos:I

    .line 850
    iget-object v0, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->rootState:Lcom/hankcs/algorithm/State;

    .line 852
    .local v0, "root_node":Lcom/hankcs/algorithm/State;
    new-instance v1, Ljava/util/ArrayList;

    invoke-virtual {v0}, Lcom/hankcs/algorithm/State;->getSuccess()Ljava/util/Map;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Set;->size()I

    move-result v2

    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(I)V

    .line 853
    .local v1, "siblings":Ljava/util/List;, "Ljava/util/List<Ljava/util/Map$Entry<Ljava/lang/Integer;Lcom/hankcs/algorithm/State;>;>;"
    invoke-direct {p0, v0, v1}, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->fetch(Lcom/hankcs/algorithm/State;Ljava/util/List;)I

    .line 854
    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_0

    .line 855
    iget-object v2, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->this$0:Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;

    iget-object v2, v2, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->check:[I

    const/4 v3, -0x1

    invoke-static {v2, v3}, Ljava/util/Arrays;->fill([II)V

    goto :goto_0

    .line 857
    :cond_0
    invoke-direct {p0, v1}, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->insert(Ljava/util/List;)V

    .line 858
    :goto_0
    return-void
.end method

.method private constructFailureStates()V
    .locals 8

    .line 790
    .local p0, "this":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<TV;>.Builder;"
    iget-object v0, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->this$0:Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;

    iget-object v1, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->this$0:Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;

    iget v1, v1, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->size:I

    add-int/lit8 v1, v1, 0x1

    new-array v1, v1, [I

    iput-object v1, v0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->fail:[I

    .line 791
    iget-object v0, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->this$0:Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;

    iget-object v1, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->this$0:Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;

    iget v1, v1, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->size:I

    add-int/lit8 v1, v1, 0x1

    new-array v1, v1, [[I

    iput-object v1, v0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->output:[[I

    .line 792
    new-instance v0, Ljava/util/ArrayDeque;

    invoke-direct {v0}, Ljava/util/ArrayDeque;-><init>()V

    .line 795
    .local v0, "queue":Ljava/util/Queue;, "Ljava/util/Queue<Lcom/hankcs/algorithm/State;>;"
    iget-object v1, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->rootState:Lcom/hankcs/algorithm/State;

    invoke-virtual {v1}, Lcom/hankcs/algorithm/State;->getStates()Ljava/util/Collection;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/hankcs/algorithm/State;

    .line 797
    .local v2, "depthOneState":Lcom/hankcs/algorithm/State;
    iget-object v3, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->rootState:Lcom/hankcs/algorithm/State;

    iget-object v4, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->this$0:Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;

    iget-object v4, v4, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->fail:[I

    invoke-virtual {v2, v3, v4}, Lcom/hankcs/algorithm/State;->setFailure(Lcom/hankcs/algorithm/State;[I)V

    .line 798
    invoke-interface {v0, v2}, Ljava/util/Queue;->add(Ljava/lang/Object;)Z

    .line 799
    invoke-direct {p0, v2}, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->constructOutput(Lcom/hankcs/algorithm/State;)V

    .line 800
    .end local v2    # "depthOneState":Lcom/hankcs/algorithm/State;
    goto :goto_0

    .line 803
    :cond_0
    :goto_1
    invoke-interface {v0}, Ljava/util/Queue;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_3

    .line 805
    invoke-interface {v0}, Ljava/util/Queue;->remove()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/hankcs/algorithm/State;

    .line 807
    .local v1, "currentState":Lcom/hankcs/algorithm/State;
    invoke-virtual {v1}, Lcom/hankcs/algorithm/State;->getTransitions()Ljava/util/Collection;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_2
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_2

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Character;

    .line 809
    .local v3, "transition":Ljava/lang/Character;
    invoke-virtual {v1, v3}, Lcom/hankcs/algorithm/State;->nextState(Ljava/lang/Character;)Lcom/hankcs/algorithm/State;

    move-result-object v4

    .line 810
    .local v4, "targetState":Lcom/hankcs/algorithm/State;
    invoke-interface {v0, v4}, Ljava/util/Queue;->add(Ljava/lang/Object;)Z

    .line 812
    invoke-virtual {v1}, Lcom/hankcs/algorithm/State;->failure()Lcom/hankcs/algorithm/State;

    move-result-object v5

    .line 813
    .local v5, "traceFailureState":Lcom/hankcs/algorithm/State;
    :goto_3
    invoke-virtual {v5, v3}, Lcom/hankcs/algorithm/State;->nextState(Ljava/lang/Character;)Lcom/hankcs/algorithm/State;

    move-result-object v6

    if-nez v6, :cond_1

    .line 815
    invoke-virtual {v5}, Lcom/hankcs/algorithm/State;->failure()Lcom/hankcs/algorithm/State;

    move-result-object v5

    goto :goto_3

    .line 817
    :cond_1
    invoke-virtual {v5, v3}, Lcom/hankcs/algorithm/State;->nextState(Ljava/lang/Character;)Lcom/hankcs/algorithm/State;

    move-result-object v6

    .line 818
    .local v6, "newFailureState":Lcom/hankcs/algorithm/State;
    iget-object v7, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->this$0:Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;

    iget-object v7, v7, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->fail:[I

    invoke-virtual {v4, v6, v7}, Lcom/hankcs/algorithm/State;->setFailure(Lcom/hankcs/algorithm/State;[I)V

    .line 819
    invoke-virtual {v6}, Lcom/hankcs/algorithm/State;->emit()Ljava/util/Collection;

    move-result-object v7

    invoke-virtual {v4, v7}, Lcom/hankcs/algorithm/State;->addEmit(Ljava/util/Collection;)V

    .line 820
    invoke-direct {p0, v4}, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->constructOutput(Lcom/hankcs/algorithm/State;)V

    .line 821
    .end local v3    # "transition":Ljava/lang/Character;
    .end local v4    # "targetState":Lcom/hankcs/algorithm/State;
    .end local v5    # "traceFailureState":Lcom/hankcs/algorithm/State;
    .end local v6    # "newFailureState":Lcom/hankcs/algorithm/State;
    goto :goto_2

    .line 822
    .end local v1    # "currentState":Lcom/hankcs/algorithm/State;
    :cond_2
    goto :goto_1

    .line 823
    :cond_3
    return-void
.end method

.method private constructOutput(Lcom/hankcs/algorithm/State;)V
    .locals 5
    .param p1, "targetState"    # Lcom/hankcs/algorithm/State;

    .line 830
    .local p0, "this":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<TV;>.Builder;"
    invoke-virtual {p1}, Lcom/hankcs/algorithm/State;->emit()Ljava/util/Collection;

    move-result-object v0

    .line 831
    .local v0, "emit":Ljava/util/Collection;, "Ljava/util/Collection<Ljava/lang/Integer;>;"
    if-eqz v0, :cond_2

    invoke-interface {v0}, Ljava/util/Collection;->size()I

    move-result v1

    if-nez v1, :cond_0

    goto :goto_1

    .line 832
    :cond_0
    invoke-interface {v0}, Ljava/util/Collection;->size()I

    move-result v1

    new-array v1, v1, [I

    .line 833
    .local v1, "output":[I
    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v2

    .line 834
    .local v2, "it":Ljava/util/Iterator;, "Ljava/util/Iterator<Ljava/lang/Integer;>;"
    const/4 v3, 0x0

    .local v3, "i":I
    :goto_0
    array-length v4, v1

    if-ge v3, v4, :cond_1

    .line 836
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Integer;

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v4

    aput v4, v1, v3

    .line 834
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    .line 838
    .end local v3    # "i":I
    :cond_1
    iget-object v3, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->this$0:Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;

    iget-object v3, v3, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->output:[[I

    invoke-virtual {p1}, Lcom/hankcs/algorithm/State;->getIndex()I

    move-result v4

    aput-object v1, v3, v4

    .line 839
    return-void

    .line 831
    .end local v1    # "output":[I
    .end local v2    # "it":Ljava/util/Iterator;, "Ljava/util/Iterator<Ljava/lang/Integer;>;"
    :cond_2
    :goto_1
    return-void
.end method

.method private fetch(Lcom/hankcs/algorithm/State;Ljava/util/List;)I
    .locals 5
    .param p1, "parent"    # Lcom/hankcs/algorithm/State;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/hankcs/algorithm/State;",
            "Ljava/util/List<",
            "Ljava/util/Map$Entry<",
            "Ljava/lang/Integer;",
            "Lcom/hankcs/algorithm/State;",
            ">;>;)I"
        }
    .end annotation

    .line 741
    .local p0, "this":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<TV;>.Builder;"
    .local p2, "siblings":Ljava/util/List;, "Ljava/util/List<Ljava/util/Map$Entry<Ljava/lang/Integer;Lcom/hankcs/algorithm/State;>;>;"
    invoke-virtual {p1}, Lcom/hankcs/algorithm/State;->isAcceptable()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 743
    new-instance v0, Lcom/hankcs/algorithm/State;

    invoke-virtual {p1}, Lcom/hankcs/algorithm/State;->getDepth()I

    move-result v1

    add-int/lit8 v1, v1, 0x1

    neg-int v1, v1

    invoke-direct {v0, v1}, Lcom/hankcs/algorithm/State;-><init>(I)V

    .line 744
    .local v0, "fakeNode":Lcom/hankcs/algorithm/State;
    invoke-virtual {p1}, Lcom/hankcs/algorithm/State;->getLargestValueId()Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    invoke-virtual {v0, v1}, Lcom/hankcs/algorithm/State;->addEmit(I)V

    .line 745
    new-instance v1, Ljava/util/AbstractMap$SimpleEntry;

    const/4 v2, 0x0

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-direct {v1, v2, v0}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-interface {p2, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 747
    .end local v0    # "fakeNode":Lcom/hankcs/algorithm/State;
    :cond_0
    invoke-virtual {p1}, Lcom/hankcs/algorithm/State;->getSuccess()Ljava/util/Map;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map$Entry;

    .line 749
    .local v1, "entry":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Ljava/lang/Character;Lcom/hankcs/algorithm/State;>;"
    new-instance v2, Ljava/util/AbstractMap$SimpleEntry;

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Character;

    invoke-virtual {v3}, Ljava/lang/Character;->charValue()C

    move-result v3

    add-int/lit8 v3, v3, 0x1

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v4

    invoke-direct {v2, v3, v4}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-interface {p2, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 750
    .end local v1    # "entry":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Ljava/lang/Character;Lcom/hankcs/algorithm/State;>;"
    goto :goto_0

    .line 751
    :cond_1
    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result v0

    return v0
.end method

.method private insert(Ljava/util/List;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/util/Map$Entry<",
            "Ljava/lang/Integer;",
            "Lcom/hankcs/algorithm/State;",
            ">;>;)V"
        }
    .end annotation

    .line 892
    .local p0, "this":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<TV;>.Builder;"
    .local p1, "firstSiblings":Ljava/util/List;, "Ljava/util/List<Ljava/util/Map$Entry<Ljava/lang/Integer;Lcom/hankcs/algorithm/State;>;>;"
    new-instance v0, Ljava/util/ArrayDeque;

    invoke-direct {v0}, Ljava/util/ArrayDeque;-><init>()V

    .line 893
    .local v0, "siblingQueue":Ljava/util/Queue;, "Ljava/util/Queue<Ljava/util/Map$Entry<Ljava/lang/Integer;Ljava/util/List<Ljava/util/Map$Entry<Ljava/lang/Integer;Lcom/hankcs/algorithm/State;>;>;>;>;"
    new-instance v1, Ljava/util/AbstractMap$SimpleEntry;

    const/4 v2, 0x0

    invoke-direct {v1, v2, p1}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-interface {v0, v1}, Ljava/util/Queue;->add(Ljava/lang/Object;)Z

    .line 895
    :goto_0
    invoke-interface {v0}, Ljava/util/Queue;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_0

    .line 897
    invoke-direct {p0, v0}, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->insert(Ljava/util/Queue;)V

    goto :goto_0

    .line 899
    :cond_0
    return-void
.end method

.method private insert(Ljava/util/Queue;)V
    .locals 16
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Queue<",
            "Ljava/util/Map$Entry<",
            "Ljava/lang/Integer;",
            "Ljava/util/List<",
            "Ljava/util/Map$Entry<",
            "Ljava/lang/Integer;",
            "Lcom/hankcs/algorithm/State;",
            ">;>;>;>;)V"
        }
    .end annotation

    .line 908
    .local p0, "this":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<TV;>.Builder;"
    .local p1, "siblingQueue":Ljava/util/Queue;, "Ljava/util/Queue<Ljava/util/Map$Entry<Ljava/lang/Integer;Ljava/util/List<Ljava/util/Map$Entry<Ljava/lang/Integer;Lcom/hankcs/algorithm/State;>;>;>;>;"
    move-object/from16 v0, p0

    invoke-interface/range {p1 .. p1}, Ljava/util/Queue;->remove()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map$Entry;

    .line 909
    .local v1, "tCurrent":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Ljava/lang/Integer;Ljava/util/List<Ljava/util/Map$Entry<Ljava/lang/Integer;Lcom/hankcs/algorithm/State;>;>;>;"
    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/List;

    .line 911
    .local v2, "siblings":Ljava/util/List;, "Ljava/util/List<Ljava/util/Map$Entry<Ljava/lang/Integer;Lcom/hankcs/algorithm/State;>;>;"
    const/4 v3, 0x0

    .line 912
    .local v3, "begin":I
    const/4 v4, 0x0

    invoke-interface {v2, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/Map$Entry;

    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Integer;

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v5

    const/4 v6, 0x1

    add-int/2addr v5, v6

    iget v7, v0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->nextCheckPos:I

    invoke-static {v5, v7}, Ljava/lang/Math;->max(II)I

    move-result v5

    sub-int/2addr v5, v6

    .line 913
    .local v5, "pos":I
    const/4 v7, 0x0

    .line 914
    .local v7, "nonzero_num":I
    const/4 v8, 0x0

    .line 916
    .local v8, "first":I
    iget v9, v0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->allocSize:I

    if-gt v9, v5, :cond_0

    .line 917
    add-int/lit8 v9, v5, 0x1

    invoke-direct {v0, v9}, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->resize(I)I

    .line 923
    :cond_0
    :goto_0
    add-int/2addr v5, v6

    .line 925
    iget v9, v0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->allocSize:I

    if-gt v9, v5, :cond_1

    .line 926
    add-int/lit8 v9, v5, 0x1

    invoke-direct {v0, v9}, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->resize(I)I

    .line 928
    :cond_1
    iget-object v9, v0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->this$0:Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;

    iget-object v9, v9, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->check:[I

    aget v9, v9, v5

    if-eqz v9, :cond_2

    .line 930
    add-int/lit8 v7, v7, 0x1

    .line 931
    goto :goto_0

    .line 933
    :cond_2
    if-nez v8, :cond_3

    .line 935
    iput v5, v0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->nextCheckPos:I

    .line 936
    const/4 v8, 0x1

    .line 939
    :cond_3
    invoke-interface {v2, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/util/Map$Entry;

    invoke-interface {v9}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/Integer;

    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    move-result v9

    sub-int v3, v5, v9

    .line 940
    iget v9, v0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->allocSize:I

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v10

    sub-int/2addr v10, v6

    invoke-interface {v2, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/Map$Entry;

    invoke-interface {v10}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/Integer;

    invoke-virtual {v10}, Ljava/lang/Integer;->intValue()I

    move-result v10

    add-int/2addr v10, v3

    const-wide/high16 v11, 0x3ff0000000000000L    # 1.0

    if-gt v9, v10, :cond_5

    .line 943
    iget v9, v0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->keySize:I

    int-to-double v9, v9

    mul-double/2addr v9, v11

    iget v13, v0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->progress:I

    add-int/2addr v13, v6

    int-to-double v13, v13

    div-double/2addr v9, v13

    const-wide v13, 0x3ff0cccccccccccdL    # 1.05

    invoke-static {v13, v14, v9, v10}, Ljava/lang/Math;->max(DD)D

    move-result-wide v9

    iget v13, v0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->allocSize:I

    int-to-double v13, v13

    mul-double/2addr v9, v13

    .line 944
    .local v9, "toSize":D
    const v13, 0x79999998

    .line 945
    .local v13, "maxSize":I
    iget v14, v0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->allocSize:I

    if-ge v14, v13, :cond_4

    .line 946
    int-to-double v14, v13

    invoke-static {v9, v10, v14, v15}, Ljava/lang/Math;->min(DD)D

    move-result-wide v14

    double-to-int v14, v14

    invoke-direct {v0, v14}, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->resize(I)I

    goto :goto_1

    .line 945
    :cond_4
    new-instance v4, Ljava/lang/RuntimeException;

    const-string v6, "Double array trie is too big."

    invoke-direct {v4, v6}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v4

    .line 949
    .end local v9    # "toSize":D
    .end local v13    # "maxSize":I
    :cond_5
    :goto_1
    iget-object v9, v0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->used:[Z

    aget-boolean v9, v9, v3

    if-eqz v9, :cond_6

    .line 950
    goto :goto_0

    .line 952
    :cond_6
    const/4 v9, 0x1

    .local v9, "i":I
    :goto_2
    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v10

    if-ge v9, v10, :cond_8

    .line 953
    iget-object v10, v0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->this$0:Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;

    iget-object v10, v10, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->check:[I

    invoke-interface {v2, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/util/Map$Entry;

    invoke-interface {v13}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/lang/Integer;

    invoke-virtual {v13}, Ljava/lang/Integer;->intValue()I

    move-result v13

    add-int/2addr v13, v3

    aget v10, v10, v13

    if-eqz v10, :cond_7

    .line 954
    goto/16 :goto_0

    .line 952
    :cond_7
    add-int/lit8 v9, v9, 0x1

    goto :goto_2

    .line 956
    .end local v9    # "i":I
    :cond_8
    nop

    .line 965
    int-to-double v9, v7

    mul-double/2addr v9, v11

    iget v4, v0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->nextCheckPos:I

    sub-int v4, v5, v4

    add-int/2addr v4, v6

    int-to-double v11, v4

    div-double/2addr v9, v11

    const-wide v11, 0x3fee666666666666L    # 0.95

    cmpl-double v4, v9, v11

    if-ltz v4, :cond_9

    .line 966
    iput v5, v0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->nextCheckPos:I

    .line 967
    :cond_9
    iget-object v4, v0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->used:[Z

    aput-boolean v6, v4, v3

    .line 969
    iget-object v4, v0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->this$0:Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;

    iget-object v9, v0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->this$0:Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;

    iget v9, v9, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->size:I

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v10

    sub-int/2addr v10, v6

    invoke-interface {v2, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/Map$Entry;

    invoke-interface {v10}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/Integer;

    invoke-virtual {v10}, Ljava/lang/Integer;->intValue()I

    move-result v10

    add-int/2addr v10, v3

    add-int/2addr v10, v6

    if-le v9, v10, :cond_a

    iget-object v9, v0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->this$0:Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;

    iget v9, v9, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->size:I

    goto :goto_3

    :cond_a
    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v9

    sub-int/2addr v9, v6

    invoke-interface {v2, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/util/Map$Entry;

    invoke-interface {v9}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/Integer;

    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    move-result v9

    add-int/2addr v9, v3

    add-int/2addr v9, v6

    :goto_3
    iput v9, v4, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->size:I

    .line 971
    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_4
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_b

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/util/Map$Entry;

    .line 973
    .local v9, "sibling":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Ljava/lang/Integer;Lcom/hankcs/algorithm/State;>;"
    iget-object v10, v0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->this$0:Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;

    iget-object v10, v10, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->check:[I

    invoke-interface {v9}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/lang/Integer;

    invoke-virtual {v11}, Ljava/lang/Integer;->intValue()I

    move-result v11

    add-int/2addr v11, v3

    aput v3, v10, v11

    .line 974
    .end local v9    # "sibling":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Ljava/lang/Integer;Lcom/hankcs/algorithm/State;>;"
    goto :goto_4

    .line 976
    :cond_b
    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_5
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_d

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/util/Map$Entry;

    .line 978
    .restart local v9    # "sibling":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Ljava/lang/Integer;Lcom/hankcs/algorithm/State;>;"
    new-instance v10, Ljava/util/ArrayList;

    invoke-interface {v9}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Lcom/hankcs/algorithm/State;

    invoke-virtual {v11}, Lcom/hankcs/algorithm/State;->getSuccess()Ljava/util/Map;

    move-result-object v11

    invoke-interface {v11}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v11

    invoke-interface {v11}, Ljava/util/Set;->size()I

    move-result v11

    add-int/2addr v11, v6

    invoke-direct {v10, v11}, Ljava/util/ArrayList;-><init>(I)V

    .line 980
    .local v10, "new_siblings":Ljava/util/List;, "Ljava/util/List<Ljava/util/Map$Entry<Ljava/lang/Integer;Lcom/hankcs/algorithm/State;>;>;"
    invoke-interface {v9}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Lcom/hankcs/algorithm/State;

    invoke-direct {v0, v11, v10}, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->fetch(Lcom/hankcs/algorithm/State;Ljava/util/List;)I

    move-result v11

    if-nez v11, :cond_c

    .line 982
    iget-object v11, v0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->this$0:Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;

    iget-object v11, v11, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->base:[I

    invoke-interface {v9}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/lang/Integer;

    invoke-virtual {v12}, Ljava/lang/Integer;->intValue()I

    move-result v12

    add-int/2addr v12, v3

    invoke-interface {v9}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Lcom/hankcs/algorithm/State;

    invoke-virtual {v13}, Lcom/hankcs/algorithm/State;->getLargestValueId()Ljava/lang/Integer;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/Integer;->intValue()I

    move-result v13

    neg-int v13, v13

    sub-int/2addr v13, v6

    aput v13, v11, v12

    .line 983
    iget v11, v0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->progress:I

    add-int/2addr v11, v6

    iput v11, v0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->progress:I

    move-object/from16 v12, p1

    goto :goto_6

    .line 987
    :cond_c
    new-instance v11, Ljava/util/AbstractMap$SimpleEntry;

    invoke-interface {v9}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/lang/Integer;

    invoke-virtual {v12}, Ljava/lang/Integer;->intValue()I

    move-result v12

    add-int/2addr v12, v3

    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    invoke-direct {v11, v12, v10}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    move-object/from16 v12, p1

    invoke-interface {v12, v11}, Ljava/util/Queue;->add(Ljava/lang/Object;)Z

    .line 989
    :goto_6
    invoke-interface {v9}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Lcom/hankcs/algorithm/State;

    invoke-interface {v9}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/lang/Integer;

    invoke-virtual {v13}, Ljava/lang/Integer;->intValue()I

    move-result v13

    add-int/2addr v13, v3

    invoke-virtual {v11, v13}, Lcom/hankcs/algorithm/State;->setIndex(I)V

    .line 990
    .end local v9    # "sibling":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Ljava/lang/Integer;Lcom/hankcs/algorithm/State;>;"
    .end local v10    # "new_siblings":Ljava/util/List;, "Ljava/util/List<Ljava/util/Map$Entry<Ljava/lang/Integer;Lcom/hankcs/algorithm/State;>;>;"
    goto/16 :goto_5

    .line 993
    :cond_d
    move-object/from16 v12, p1

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Integer;

    .line 994
    .local v4, "parentBaseIndex":Ljava/lang/Integer;
    if-eqz v4, :cond_e

    .line 996
    iget-object v6, v0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->this$0:Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;

    iget-object v6, v6, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->base:[I

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v9

    aput v3, v6, v9

    .line 998
    :cond_e
    return-void
.end method

.method private loseWeight()V
    .locals 6

    .line 1005
    .local p0, "this":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<TV;>.Builder;"
    iget-object v0, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->this$0:Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;

    iget v0, v0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->size:I

    const v1, 0xffff

    add-int/2addr v0, v1

    new-array v0, v0, [I

    .line 1006
    .local v0, "nbase":[I
    iget-object v2, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->this$0:Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;

    iget-object v2, v2, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->base:[I

    iget-object v3, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->this$0:Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;

    iget v3, v3, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->size:I

    const/4 v4, 0x0

    invoke-static {v2, v4, v0, v4, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 1007
    iget-object v2, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->this$0:Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;

    iput-object v0, v2, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->base:[I

    .line 1009
    iget-object v2, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->this$0:Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;

    iget v2, v2, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->size:I

    add-int/2addr v2, v1

    new-array v1, v2, [I

    .line 1010
    .local v1, "ncheck":[I
    iget-object v2, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->this$0:Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;

    iget-object v2, v2, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->check:[I

    iget-object v3, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->this$0:Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;

    iget-object v3, v3, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->check:[I

    array-length v3, v3

    array-length v5, v1

    invoke-static {v3, v5}, Ljava/lang/Math;->min(II)I

    move-result v3

    invoke-static {v2, v4, v1, v4, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 1011
    iget-object v2, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->this$0:Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;

    iput-object v1, v2, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->check:[I

    .line 1012
    return-void
.end method

.method private resize(I)I
    .locals 6
    .param p1, "newSize"    # I

    .line 868
    .local p0, "this":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<TV;>.Builder;"
    new-array v0, p1, [I

    .line 869
    .local v0, "base2":[I
    new-array v1, p1, [I

    .line 870
    .local v1, "check2":[I
    new-array v2, p1, [Z

    .line 871
    .local v2, "used2":[Z
    iget v3, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->allocSize:I

    if-lez v3, :cond_0

    .line 873
    iget-object v3, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->this$0:Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;

    iget-object v3, v3, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->base:[I

    iget v4, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->allocSize:I

    const/4 v5, 0x0

    invoke-static {v3, v5, v0, v5, v4}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 874
    iget-object v3, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->this$0:Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;

    iget-object v3, v3, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->check:[I

    iget v4, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->allocSize:I

    invoke-static {v3, v5, v1, v5, v4}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 875
    iget-object v3, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->used:[Z

    iget v4, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->allocSize:I

    invoke-static {v3, v5, v2, v5, v4}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 878
    :cond_0
    iget-object v3, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->this$0:Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;

    iput-object v0, v3, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->base:[I

    .line 879
    iget-object v3, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->this$0:Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;

    iput-object v1, v3, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->check:[I

    .line 880
    iput-object v2, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->used:[Z

    .line 882
    iput p1, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->allocSize:I

    return p1
.end method


# virtual methods
.method public build(Ljava/util/Map;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "TV;>;)V"
        }
    .end annotation

    .line 718
    .local p0, "this":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<TV;>.Builder;"
    .local p1, "map":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;TV;>;"
    iget-object v0, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->this$0:Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;

    invoke-interface {p1}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Collection;->toArray()[Ljava/lang/Object;

    move-result-object v1

    check-cast v1, [Ljava/lang/Object;

    iput-object v1, v0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->v:[Ljava/lang/Object;

    .line 719
    iget-object v0, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->this$0:Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;

    iget-object v1, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->this$0:Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;

    iget-object v1, v1, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->v:[Ljava/lang/Object;

    array-length v1, v1

    new-array v1, v1, [I

    iput-object v1, v0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->l:[I

    .line 720
    invoke-interface {p1}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v0

    .line 722
    .local v0, "keySet":Ljava/util/Set;, "Ljava/util/Set<Ljava/lang/String;>;"
    invoke-direct {p0, v0}, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->addAllKeyword(Ljava/util/Collection;)V

    .line 724
    invoke-interface {v0}, Ljava/util/Set;->size()I

    move-result v1

    invoke-direct {p0, v1}, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->buildDoubleArrayTrie(I)V

    .line 725
    const/4 v1, 0x0

    iput-object v1, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->used:[Z

    .line 727
    invoke-direct {p0}, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->constructFailureStates()V

    .line 728
    iput-object v1, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->rootState:Lcom/hankcs/algorithm/State;

    .line 729
    invoke-direct {p0}, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->loseWeight()V

    .line 730
    return-void
.end method
