.class public Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;
.super Ljava/lang/Object;
.source "AhoCorasickDoubleArrayTrie.java"

# interfaces
.implements Ljava/io/Serializable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;,
        Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Hit;,
        Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$IHitCancellable;,
        Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$IHitFull;,
        Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$IHit;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<V:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Ljava/io/Serializable;"
    }
.end annotation


# instance fields
.field protected base:[I

.field protected check:[I

.field protected fail:[I

.field protected l:[I

.field protected output:[[I

.field protected size:I

.field protected v:[Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[TV;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 34
    .local p0, "this":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<TV;>;"
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private exactMatchSearch(Ljava/lang/String;III)I
    .locals 6
    .param p1, "key"    # Ljava/lang/String;
    .param p2, "pos"    # I
    .param p3, "len"    # I
    .param p4, "nodePos"    # I

    .line 514
    .local p0, "this":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<TV;>;"
    if-gtz p3, :cond_0

    .line 515
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result p3

    move v2, p3

    goto :goto_0

    .line 514
    :cond_0
    move v2, p3

    .line 516
    .end local p3    # "len":I
    .local v2, "len":I
    :goto_0
    if-gtz p4, :cond_1

    .line 517
    const/4 p4, 0x0

    .line 519
    :cond_1
    const/4 v3, -0x1

    .line 521
    .local v3, "result":I
    invoke-virtual {p1}, Ljava/lang/String;->toCharArray()[C

    move-result-object v4

    .line 523
    .local v4, "keyChars":[C
    iget-object p3, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->base:[I

    aget v5, p3, p4

    move-object v0, p0

    move v1, p2

    .end local p2    # "pos":I
    .local v1, "pos":I
    invoke-direct/range {v0 .. v5}, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->getMatched(III[CI)I

    move-result p2

    return p2
.end method

.method private exactMatchSearch([CIII)I
    .locals 6
    .param p1, "keyChars"    # [C
    .param p2, "pos"    # I
    .param p3, "len"    # I
    .param p4, "nodePos"    # I

    .line 560
    .local p0, "this":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<TV;>;"
    const/4 v3, -0x1

    .line 562
    .local v3, "result":I
    iget-object v0, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->base:[I

    aget v5, v0, p4

    move-object v0, p0

    move-object v4, p1

    move v1, p2

    move v2, p3

    .end local p1    # "keyChars":[C
    .end local p2    # "pos":I
    .end local p3    # "len":I
    .local v1, "pos":I
    .local v2, "len":I
    .local v4, "keyChars":[C
    invoke-direct/range {v0 .. v5}, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->getMatched(III[CI)I

    move-result p1

    return p1
.end method

.method private getMatched(III[CI)I
    .locals 4
    .param p1, "pos"    # I
    .param p2, "len"    # I
    .param p3, "result"    # I
    .param p4, "keyChars"    # [C
    .param p5, "b1"    # I

    .line 528
    .local p0, "this":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<TV;>;"
    move v0, p5

    .line 531
    .local v0, "b":I
    move v1, p1

    .local v1, "i":I
    :goto_0
    if-ge v1, p2, :cond_1

    .line 533
    aget-char v2, p4, v1

    add-int/2addr v2, v0

    add-int/lit8 v2, v2, 0x1

    .line 534
    .local v2, "p":I
    iget-object v3, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->check:[I

    aget v3, v3, v2

    if-ne v0, v3, :cond_0

    .line 535
    iget-object v3, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->base:[I

    aget v0, v3, v2

    .line 531
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 537
    :cond_0
    return p3

    .line 540
    .end local v1    # "i":I
    .end local v2    # "p":I
    :cond_1
    move v1, v0

    .line 541
    .local v1, "p":I
    iget-object v2, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->base:[I

    aget v2, v2, v1

    .line 542
    .local v2, "n":I
    iget-object v3, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->check:[I

    aget v3, v3, v1

    if-ne v0, v3, :cond_2

    .line 544
    neg-int v3, v2

    add-int/lit8 p3, v3, -0x1

    .line 546
    :cond_2
    return p3
.end method

.method private getState(IC)I
    .locals 2
    .param p1, "currentState"    # I
    .param p2, "character"    # C

    .line 408
    .local p0, "this":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<TV;>;"
    invoke-virtual {p0, p1, p2}, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->transitionWithRoot(IC)I

    move-result v0

    .line 409
    .local v0, "newCurrentState":I
    :goto_0
    const/4 v1, -0x1

    if-ne v0, v1, :cond_0

    .line 411
    iget-object v1, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->fail:[I

    aget p1, v1, p1

    .line 412
    invoke-virtual {p0, p1, p2}, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->transitionWithRoot(IC)I

    move-result v0

    goto :goto_0

    .line 414
    :cond_0
    return v0
.end method

.method private storeEmits(IILjava/util/List;)V
    .locals 7
    .param p1, "position"    # I
    .param p2, "currentState"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(II",
            "Ljava/util/List<",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Hit<",
            "TV;>;>;)V"
        }
    .end annotation

    .line 426
    .local p0, "this":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<TV;>;"
    .local p3, "collectedEmits":Ljava/util/List;, "Ljava/util/List<Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Hit<TV;>;>;"
    iget-object v0, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->output:[[I

    aget-object v0, v0, p2

    .line 427
    .local v0, "hitArray":[I
    if-eqz v0, :cond_0

    .line 429
    array-length v1, v0

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v1, :cond_0

    aget v3, v0, v2

    .line 431
    .local v3, "hit":I
    new-instance v4, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Hit;

    iget-object v5, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->l:[I

    aget v5, v5, v3

    sub-int v5, p1, v5

    iget-object v6, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->v:[Ljava/lang/Object;

    aget-object v6, v6, v3

    invoke-direct {v4, v5, p1, v6}, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Hit;-><init>(IILjava/lang/Object;)V

    invoke-interface {p3, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 429
    .end local v3    # "hit":I
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    .line 434
    :cond_0
    return-void
.end method


# virtual methods
.method public build(Ljava/util/Map;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "TV;>;)V"
        }
    .end annotation

    .line 488
    .local p0, "this":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<TV;>;"
    .local p1, "map":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;TV;>;"
    new-instance v0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;-><init>(Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$1;)V

    invoke-virtual {v0, p1}, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Builder;->build(Ljava/util/Map;)V

    .line 489
    return-void
.end method

.method public exactMatchSearch(Ljava/lang/String;)I
    .locals 1
    .param p1, "key"    # Ljava/lang/String;

    .line 500
    .local p0, "this":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<TV;>;"
    const/4 v0, 0x0

    invoke-direct {p0, p1, v0, v0, v0}, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->exactMatchSearch(Ljava/lang/String;III)I

    move-result v0

    return v0
.end method

.method public findFirst(Ljava/lang/String;)Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Hit;
    .locals 8
    .param p1, "text"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Hit<",
            "TV;>;"
        }
    .end annotation

    .line 220
    .local p0, "this":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<TV;>;"
    const/4 v0, 0x1

    .line 221
    .local v0, "position":I
    const/4 v1, 0x0

    .line 222
    .local v1, "currentState":I
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_0
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v3

    if-ge v2, v3, :cond_1

    .line 224
    invoke-virtual {p1, v2}, Ljava/lang/String;->charAt(I)C

    move-result v3

    invoke-direct {p0, v1, v3}, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->getState(IC)I

    move-result v1

    .line 225
    iget-object v3, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->output:[[I

    aget-object v3, v3, v1

    .line 226
    .local v3, "hitArray":[I
    if-eqz v3, :cond_0

    .line 228
    const/4 v4, 0x0

    aget v4, v3, v4

    .line 229
    .local v4, "hitIndex":I
    new-instance v5, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Hit;

    iget-object v6, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->l:[I

    aget v6, v6, v4

    sub-int v6, v0, v6

    iget-object v7, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->v:[Ljava/lang/Object;

    aget-object v7, v7, v4

    invoke-direct {v5, v6, v0, v7}, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Hit;-><init>(IILjava/lang/Object;)V

    return-object v5

    .line 231
    .end local v4    # "hitIndex":I
    :cond_0
    nop

    .end local v3    # "hitArray":[I
    add-int/lit8 v0, v0, 0x1

    .line 222
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    .line 233
    .end local v2    # "i":I
    :cond_1
    const/4 v2, 0x0

    return-object v2
.end method

.method public get(I)Ljava/lang/Object;
    .locals 1
    .param p1, "index"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)TV;"
        }
    .end annotation

    .line 315
    .local p0, "this":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<TV;>;"
    iget-object v0, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->v:[Ljava/lang/Object;

    aget-object v0, v0, p1

    return-object v0
.end method

.method public get(Ljava/lang/String;)Ljava/lang/Object;
    .locals 2
    .param p1, "key"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")TV;"
        }
    .end annotation

    .line 278
    .local p0, "this":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<TV;>;"
    invoke-virtual {p0, p1}, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->exactMatchSearch(Ljava/lang/String;)I

    move-result v0

    .line 279
    .local v0, "index":I
    if-ltz v0, :cond_0

    .line 281
    iget-object v1, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->v:[Ljava/lang/Object;

    aget-object v1, v1, v0

    return-object v1

    .line 284
    :cond_0
    const/4 v1, 0x0

    return-object v1
.end method

.method public load(Ljava/io/ObjectInputStream;)V
    .locals 1
    .param p1, "in"    # Ljava/io/ObjectInputStream;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;,
            Ljava/lang/ClassNotFoundException;
        }
    .end annotation

    .line 262
    .local p0, "this":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<TV;>;"
    invoke-virtual {p1}, Ljava/io/ObjectInputStream;->readObject()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [I

    check-cast v0, [I

    iput-object v0, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->base:[I

    .line 263
    invoke-virtual {p1}, Ljava/io/ObjectInputStream;->readObject()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [I

    check-cast v0, [I

    iput-object v0, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->check:[I

    .line 264
    invoke-virtual {p1}, Ljava/io/ObjectInputStream;->readObject()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [I

    check-cast v0, [I

    iput-object v0, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->fail:[I

    .line 265
    invoke-virtual {p1}, Ljava/io/ObjectInputStream;->readObject()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [[I

    check-cast v0, [[I

    iput-object v0, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->output:[[I

    .line 266
    invoke-virtual {p1}, Ljava/io/ObjectInputStream;->readObject()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [I

    check-cast v0, [I

    iput-object v0, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->l:[I

    .line 267
    invoke-virtual {p1}, Ljava/io/ObjectInputStream;->readObject()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Ljava/lang/Object;

    check-cast v0, [Ljava/lang/Object;

    iput-object v0, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->v:[Ljava/lang/Object;

    .line 268
    return-void
.end method

.method public matches(Ljava/lang/String;)Z
    .locals 4
    .param p1, "text"    # Ljava/lang/String;

    .line 199
    .local p0, "this":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<TV;>;"
    const/4 v0, 0x0

    .line 200
    .local v0, "currentState":I
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_0
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v2

    if-ge v1, v2, :cond_1

    .line 202
    invoke-virtual {p1, v1}, Ljava/lang/String;->charAt(I)C

    move-result v2

    invoke-direct {p0, v0, v2}, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->getState(IC)I

    move-result v0

    .line 203
    iget-object v2, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->output:[[I

    aget-object v2, v2, v0

    .line 204
    .local v2, "hitArray":[I
    if-eqz v2, :cond_0

    .line 206
    const/4 v3, 0x1

    return v3

    .line 200
    .end local v2    # "hitArray":[I
    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 209
    .end local v1    # "i":I
    :cond_1
    const/4 v1, 0x0

    return v1
.end method

.method public parseText(Ljava/lang/CharSequence;)Ljava/util/List;
    .locals 5
    .param p1, "text"    # Ljava/lang/CharSequence;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/CharSequence;",
            ")",
            "Ljava/util/List<",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Hit<",
            "TV;>;>;"
        }
    .end annotation

    .line 75
    .local p0, "this":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<TV;>;"
    const/4 v0, 0x1

    .line 76
    .local v0, "position":I
    const/4 v1, 0x0

    .line 77
    .local v1, "currentState":I
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 78
    .local v2, "collectedEmits":Ljava/util/List;, "Ljava/util/List<Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Hit<TV;>;>;"
    const/4 v3, 0x0

    .local v3, "i":I
    :goto_0
    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    move-result v4

    if-ge v3, v4, :cond_0

    .line 80
    invoke-interface {p1, v3}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v4

    invoke-direct {p0, v1, v4}, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->getState(IC)I

    move-result v1

    .line 81
    invoke-direct {p0, v0, v1, v2}, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->storeEmits(IILjava/util/List;)V

    .line 82
    add-int/lit8 v0, v0, 0x1

    .line 78
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    .line 85
    .end local v3    # "i":I
    :cond_0
    return-object v2
.end method

.method public parseText(Ljava/lang/CharSequence;Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$IHit;)V
    .locals 9
    .param p1, "text"    # Ljava/lang/CharSequence;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/CharSequence;",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$IHit<",
            "TV;>;)V"
        }
    .end annotation

    .line 96
    .local p0, "this":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<TV;>;"
    .local p2, "processor":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$IHit;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$IHit<TV;>;"
    const/4 v0, 0x1

    .line 97
    .local v0, "position":I
    const/4 v1, 0x0

    .line 98
    .local v1, "currentState":I
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_0
    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    move-result v3

    if-ge v2, v3, :cond_1

    .line 100
    invoke-interface {p1, v2}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v3

    invoke-direct {p0, v1, v3}, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->getState(IC)I

    move-result v1

    .line 101
    iget-object v3, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->output:[[I

    aget-object v3, v3, v1

    .line 102
    .local v3, "hitArray":[I
    if-eqz v3, :cond_0

    .line 104
    array-length v4, v3

    const/4 v5, 0x0

    :goto_1
    if-ge v5, v4, :cond_0

    aget v6, v3, v5

    .line 106
    .local v6, "hit":I
    iget-object v7, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->l:[I

    aget v7, v7, v6

    sub-int v7, v0, v7

    iget-object v8, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->v:[Ljava/lang/Object;

    aget-object v8, v8, v6

    invoke-interface {p2, v7, v0, v8}, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$IHit;->hit(IILjava/lang/Object;)V

    .line 104
    .end local v6    # "hit":I
    add-int/lit8 v5, v5, 0x1

    goto :goto_1

    .line 109
    :cond_0
    nop

    .end local v3    # "hitArray":[I
    add-int/lit8 v0, v0, 0x1

    .line 98
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    .line 111
    .end local v2    # "i":I
    :cond_1
    return-void
.end method

.method public parseText(Ljava/lang/CharSequence;Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$IHitCancellable;)V
    .locals 9
    .param p1, "text"    # Ljava/lang/CharSequence;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/CharSequence;",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$IHitCancellable<",
            "TV;>;)V"
        }
    .end annotation

    .line 121
    .local p0, "this":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<TV;>;"
    .local p2, "processor":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$IHitCancellable;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$IHitCancellable<TV;>;"
    const/4 v0, 0x0

    .line 122
    .local v0, "currentState":I
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_0
    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    move-result v2

    if-ge v1, v2, :cond_2

    .line 124
    add-int/lit8 v2, v1, 0x1

    .line 125
    .local v2, "position":I
    invoke-interface {p1, v1}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v3

    invoke-direct {p0, v0, v3}, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->getState(IC)I

    move-result v0

    .line 126
    iget-object v3, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->output:[[I

    aget-object v3, v3, v0

    .line 127
    .local v3, "hitArray":[I
    if-eqz v3, :cond_1

    .line 129
    array-length v4, v3

    const/4 v5, 0x0

    :goto_1
    if-ge v5, v4, :cond_1

    aget v6, v3, v5

    .line 131
    .local v6, "hit":I
    iget-object v7, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->l:[I

    aget v7, v7, v6

    sub-int v7, v2, v7

    iget-object v8, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->v:[Ljava/lang/Object;

    aget-object v8, v8, v6

    invoke-interface {p2, v7, v2, v8}, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$IHitCancellable;->hit(IILjava/lang/Object;)Z

    move-result v7

    .line 132
    .local v7, "proceed":Z
    if-nez v7, :cond_0

    .line 134
    return-void

    .line 129
    .end local v6    # "hit":I
    .end local v7    # "proceed":Z
    :cond_0
    add-int/lit8 v5, v5, 0x1

    goto :goto_1

    .line 122
    .end local v2    # "position":I
    .end local v3    # "hitArray":[I
    :cond_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 139
    .end local v1    # "i":I
    :cond_2
    return-void
.end method

.method public parseText([CLcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$IHit;)V
    .locals 12
    .param p1, "text"    # [C
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([C",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$IHit<",
            "TV;>;)V"
        }
    .end annotation

    .line 149
    .local p0, "this":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<TV;>;"
    .local p2, "processor":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$IHit;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$IHit<TV;>;"
    const/4 v0, 0x1

    .line 150
    .local v0, "position":I
    const/4 v1, 0x0

    .line 151
    .local v1, "currentState":I
    array-length v2, p1

    const/4 v3, 0x0

    move v4, v3

    :goto_0
    if-ge v4, v2, :cond_1

    aget-char v5, p1, v4

    .line 153
    .local v5, "c":C
    invoke-direct {p0, v1, v5}, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->getState(IC)I

    move-result v1

    .line 154
    iget-object v6, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->output:[[I

    aget-object v6, v6, v1

    .line 155
    .local v6, "hitArray":[I
    if-eqz v6, :cond_0

    .line 157
    array-length v7, v6

    move v8, v3

    :goto_1
    if-ge v8, v7, :cond_0

    aget v9, v6, v8

    .line 159
    .local v9, "hit":I
    iget-object v10, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->l:[I

    aget v10, v10, v9

    sub-int v10, v0, v10

    iget-object v11, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->v:[Ljava/lang/Object;

    aget-object v11, v11, v9

    invoke-interface {p2, v10, v0, v11}, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$IHit;->hit(IILjava/lang/Object;)V

    .line 157
    .end local v9    # "hit":I
    add-int/lit8 v8, v8, 0x1

    goto :goto_1

    .line 162
    :cond_0
    nop

    .end local v5    # "c":C
    .end local v6    # "hitArray":[I
    add-int/lit8 v0, v0, 0x1

    .line 151
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    .line 164
    :cond_1
    return-void
.end method

.method public parseText([CLcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$IHitFull;)V
    .locals 12
    .param p1, "text"    # [C
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([C",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$IHitFull<",
            "TV;>;)V"
        }
    .end annotation

    .line 174
    .local p0, "this":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<TV;>;"
    .local p2, "processor":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$IHitFull;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$IHitFull<TV;>;"
    const/4 v0, 0x1

    .line 175
    .local v0, "position":I
    const/4 v1, 0x0

    .line 176
    .local v1, "currentState":I
    array-length v2, p1

    const/4 v3, 0x0

    move v4, v3

    :goto_0
    if-ge v4, v2, :cond_1

    aget-char v5, p1, v4

    .line 178
    .local v5, "c":C
    invoke-direct {p0, v1, v5}, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->getState(IC)I

    move-result v1

    .line 179
    iget-object v6, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->output:[[I

    aget-object v6, v6, v1

    .line 180
    .local v6, "hitArray":[I
    if-eqz v6, :cond_0

    .line 182
    array-length v7, v6

    move v8, v3

    :goto_1
    if-ge v8, v7, :cond_0

    aget v9, v6, v8

    .line 184
    .local v9, "hit":I
    iget-object v10, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->l:[I

    aget v10, v10, v9

    sub-int v10, v0, v10

    iget-object v11, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->v:[Ljava/lang/Object;

    aget-object v11, v11, v9

    invoke-interface {p2, v10, v0, v11, v9}, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$IHitFull;->hit(IILjava/lang/Object;I)V

    .line 182
    .end local v9    # "hit":I
    add-int/lit8 v8, v8, 0x1

    goto :goto_1

    .line 187
    :cond_0
    nop

    .end local v5    # "c":C
    .end local v6    # "hitArray":[I
    add-int/lit8 v0, v0, 0x1

    .line 176
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    .line 189
    :cond_1
    return-void
.end method

.method public save(Ljava/io/ObjectOutputStream;)V
    .locals 1
    .param p1, "out"    # Ljava/io/ObjectOutputStream;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 245
    .local p0, "this":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<TV;>;"
    iget-object v0, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->base:[I

    invoke-virtual {p1, v0}, Ljava/io/ObjectOutputStream;->writeObject(Ljava/lang/Object;)V

    .line 246
    iget-object v0, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->check:[I

    invoke-virtual {p1, v0}, Ljava/io/ObjectOutputStream;->writeObject(Ljava/lang/Object;)V

    .line 247
    iget-object v0, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->fail:[I

    invoke-virtual {p1, v0}, Ljava/io/ObjectOutputStream;->writeObject(Ljava/lang/Object;)V

    .line 248
    iget-object v0, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->output:[[I

    invoke-virtual {p1, v0}, Ljava/io/ObjectOutputStream;->writeObject(Ljava/lang/Object;)V

    .line 249
    iget-object v0, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->l:[I

    invoke-virtual {p1, v0}, Ljava/io/ObjectOutputStream;->writeObject(Ljava/lang/Object;)V

    .line 250
    iget-object v0, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->v:[Ljava/lang/Object;

    invoke-virtual {p1, v0}, Ljava/io/ObjectOutputStream;->writeObject(Ljava/lang/Object;)V

    .line 251
    return-void
.end method

.method public set(Ljava/lang/String;Ljava/lang/Object;)Z
    .locals 2
    .param p1, "key"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "TV;)Z"
        }
    .end annotation

    .line 296
    .local p0, "this":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<TV;>;"
    .local p2, "value":Ljava/lang/Object;, "TV;"
    invoke-virtual {p0, p1}, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->exactMatchSearch(Ljava/lang/String;)I

    move-result v0

    .line 297
    .local v0, "index":I
    if-ltz v0, :cond_0

    .line 299
    iget-object v1, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->v:[Ljava/lang/Object;

    aput-object p2, v1, v0

    .line 300
    const/4 v1, 0x1

    return v1

    .line 303
    :cond_0
    const/4 v1, 0x0

    return v1
.end method

.method public size()I
    .locals 1

    .line 676
    .local p0, "this":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<TV;>;"
    iget-object v0, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->v:[Ljava/lang/Object;

    array-length v0, v0

    return v0
.end method

.method protected transition(IC)I
    .locals 3
    .param p1, "current"    # I
    .param p2, "c"    # C

    .line 445
    .local p0, "this":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<TV;>;"
    move v0, p1

    .line 448
    .local v0, "b":I
    add-int v1, v0, p2

    add-int/lit8 v1, v1, 0x1

    .line 449
    .local v1, "p":I
    iget-object v2, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->check:[I

    aget v2, v2, v1

    if-ne v0, v2, :cond_0

    .line 450
    iget-object v2, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->base:[I

    aget v0, v2, v1

    .line 454
    move v1, v0

    .line 455
    return v1

    .line 452
    :cond_0
    const/4 v2, -0x1

    return v2
.end method

.method protected transitionWithRoot(IC)I
    .locals 3
    .param p1, "nodePos"    # I
    .param p2, "c"    # C

    .line 467
    .local p0, "this":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<TV;>;"
    iget-object v0, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->base:[I

    aget v0, v0, p1

    .line 470
    .local v0, "b":I
    add-int v1, v0, p2

    add-int/lit8 v1, v1, 0x1

    .line 471
    .local v1, "p":I
    iget-object v2, p0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->check:[I

    aget v2, v2, v1

    if-eq v0, v2, :cond_1

    .line 473
    if-nez p1, :cond_0

    const/4 v2, 0x0

    return v2

    .line 474
    :cond_0
    const/4 v2, -0x1

    return v2

    .line 477
    :cond_1
    return v1
.end method
