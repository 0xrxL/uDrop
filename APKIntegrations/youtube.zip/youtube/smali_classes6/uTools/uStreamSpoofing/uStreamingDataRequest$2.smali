.class LuTools/uStreamSpoofing/uStreamingDataRequest$2;
.super Ljava/lang/Object;
.source "uStreamingDataRequest.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LuTools/uStreamSpoofing/uStreamingDataRequest;->VideoReload()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field msTimeCounter:I

.field final runnableHandler:Landroid/os/Handler;

.field final synthetic this$0:LuTools/uStreamSpoofing/uStreamingDataRequest;

.field final synthetic val$videoReloadHandler:Landroid/os/Handler;


# direct methods
.method constructor <init>(LuTools/uStreamSpoofing/uStreamingDataRequest;Landroid/os/Handler;)V
    .locals 0
    .param p1, "this$0"    # LuTools/uStreamSpoofing/uStreamingDataRequest;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            null,
            null
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 304
    iput-object p1, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$2;->this$0:LuTools/uStreamSpoofing/uStreamingDataRequest;

    iput-object p2, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$2;->val$videoReloadHandler:Landroid/os/Handler;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 305
    iget-object p2, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$2;->val$videoReloadHandler:Landroid/os/Handler;

    iput-object p2, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$2;->runnableHandler:Landroid/os/Handler;

    .line 306
    const/4 p2, 0x0

    iput p2, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$2;->msTimeCounter:I

    return-void
.end method

.method private terminate()V
    .locals 1

    .line 344
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$2;->runnableHandler:Landroid/os/Handler;

    invoke-virtual {v0, p0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 345
    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    .line 310
    invoke-static {}, LuTools/uStreamSpoofing/uStreamingDataRequest;->-$$Nest$sfgetvideoIDToReload()Ljava/lang/String;

    move-result-object v0

    invoke-static {}, LuTools/uStreamSpoofing/uStreamingDataRequest;->-$$Nest$sfgetvideoIDPlaying()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 313
    invoke-static {}, LuTools/uUtils;->GetVideoPlaybackStatus()Ljava/lang/Enum;

    move-result-object v0

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Enum;

    invoke-virtual {v0}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object v0

    invoke-static {}, LuTools/uStreamSpoofing/uStreamingDataRequest;->-$$Nest$sfgetvideoReloadExcludedPlaybackStates()Ljava/util/AbstractMap$SimpleEntry;

    move-result-object v1

    sget-object v2, LuTools/uUtils$Entries;->ANY:LuTools/uUtils$Entries;

    .line 312
    invoke-static {v0, v1, v2}, LuTools/uUtils;->SearchInSetCorasick(Ljava/lang/String;Ljava/util/AbstractMap$SimpleEntry;LuTools/uUtils$Entries;)Z

    move-result v0

    if-nez v0, :cond_1

    .line 318
    iget v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$2;->msTimeCounter:I

    const/16 v1, 0x1b58

    if-lt v0, v1, :cond_0

    .line 320
    invoke-static {}, LuTools/uUtils;->GetPlayerType()Ljava/lang/Enum;

    move-result-object v0

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Enum;

    invoke-virtual {v0}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object v0

    sget-object v1, LuTools/uBlocker;->playerMaximized:Ljava/util/AbstractMap$SimpleEntry;

    sget-object v2, LuTools/uUtils$Entries;->ANY:LuTools/uUtils$Entries;

    .line 319
    invoke-static {v0, v1, v2}, LuTools/uUtils;->SearchInSetCorasick(Ljava/lang/String;Ljava/util/AbstractMap$SimpleEntry;LuTools/uUtils$Entries;)Z

    move-result v0

    if-eqz v0, :cond_2

    .line 325
    invoke-static {}, LuTools/uStreamSpoofing/uStreamingDataRequest;->-$$Nest$sfgetvideoReloadingToast()LuTools/uUtils$MakeToast;

    move-result-object v0

    invoke-virtual {v0}, LuTools/uUtils$MakeToast;->ShowToast()V

    .line 327
    invoke-static {}, LuTools/uUtils;->DismissVideoPlayer()V

    .line 329
    invoke-static {}, LuTools/uStreamSpoofing/uStreamingDataRequest;->-$$Nest$sfgetvideoIDToReload()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, LuTools/uUtils;->OpenNewVideo(Ljava/lang/String;)V

    .line 331
    invoke-direct {p0}, LuTools/uStreamSpoofing/uStreamingDataRequest$2;->terminate()V

    goto :goto_0

    .line 334
    :cond_0
    iget v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$2;->msTimeCounter:I

    add-int/lit8 v0, v0, 0x64

    iput v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$2;->msTimeCounter:I

    .line 336
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$2;->runnableHandler:Landroid/os/Handler;

    const-wide/16 v1, 0x64

    invoke-virtual {v0, p0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    goto :goto_0

    .line 339
    :cond_1
    invoke-direct {p0}, LuTools/uStreamSpoofing/uStreamingDataRequest$2;->terminate()V

    .line 341
    :cond_2
    :goto_0
    return-void
.end method
