.class public LuTools/uStreamSpoofing/uSpoofing;
.super Ljava/lang/Object;
.source "uSpoofing.java"


# static fields
.field private static final pathExclusions:Ljava/util/AbstractMap$SimpleEntry;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/AbstractMap$SimpleEntry<",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 50
    new-instance v0, Ljava/util/AbstractMap$SimpleEntry;

    .line 53
    const-string v1, "heartbeat"

    const-string v2, "refresh"

    invoke-static {v1, v2}, Ljava/util/Set;->of(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v1

    const-string v2, "pathExclusions"

    invoke-direct {v0, v1, v2}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 51
    invoke-static {v0}, LuTools/uUtils;->InitializeNewBlockList(Ljava/util/AbstractMap$SimpleEntry;)Ljava/util/AbstractMap$SimpleEntry;

    move-result-object v0

    sput-object v0, LuTools/uStreamSpoofing/uSpoofing;->pathExclusions:Ljava/util/AbstractMap$SimpleEntry;

    .line 50
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 27
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static BlockGetWatchRequest(Landroid/net/Uri;)Landroid/net/Uri;
    .locals 2
    .param p0, "playerRequestUri"    # Landroid/net/Uri;

    .line 30
    :try_start_0
    invoke-virtual {p0}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    move-result-object v0

    const-string v1, "get_watch"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 31
    const-string v0, "https://127.0.0.0"

    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    .line 33
    :catch_0
    move-exception v0

    :cond_0
    nop

    .line 35
    return-object p0
.end method

.method public static BlockInitPlaybackRequest(Ljava/lang/String;)Ljava/lang/String;
    .locals 3
    .param p0, "originalUrlString"    # Ljava/lang/String;

    .line 40
    :try_start_0
    invoke-static {p0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    .line 42
    .local v0, "originalUri":Landroid/net/Uri;
    invoke-virtual {v0}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    move-result-object v1

    const-string v2, "initplayback"

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_0

    .line 43
    invoke-virtual {v0}, Landroid/net/Uri;->buildUpon()Landroid/net/Uri$Builder;

    move-result-object v1

    invoke-virtual {v1}, Landroid/net/Uri$Builder;->clearQuery()Landroid/net/Uri$Builder;

    move-result-object v1

    invoke-virtual {v1}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    move-result-object v1

    invoke-virtual {v1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v1

    .line 42
    .end local v0    # "originalUri":Landroid/net/Uri;
    :cond_0
    goto :goto_0

    .line 45
    :catch_0
    move-exception v0

    :goto_0
    nop

    .line 47
    return-object p0
.end method

.method public static FetchStreams(Ljava/lang/String;Ljava/util/Map;)V
    .locals 4
    .param p0, "url"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 63
    .local p1, "requestHeaders":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;"
    :try_start_0
    invoke-static {p0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    .line 64
    .local v0, "uri":Landroid/net/Uri;
    invoke-virtual {v0}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    move-result-object v1

    .line 66
    .local v1, "path":Ljava/lang/String;
    const-string v2, "player"

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_0

    sget-object v2, LuTools/uStreamSpoofing/uSpoofing;->pathExclusions:Ljava/util/AbstractMap$SimpleEntry;

    sget-object v3, LuTools/uUtils$Entries;->ALL:LuTools/uUtils$Entries;

    .line 67
    invoke-static {v1, v2, v3}, LuTools/uUtils;->SearchInSetCorasick(Ljava/lang/String;Ljava/util/AbstractMap$SimpleEntry;LuTools/uUtils$Entries;)Z

    move-result v2

    if-nez v2, :cond_0

    .line 73
    const-string v2, "id"

    .line 74
    invoke-virtual {v0, v2}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    .line 73
    invoke-static {v2, p1}, LuTools/uStreamSpoofing/uStreamingDataRequest;->FetchRequest(Ljava/lang/String;Ljava/util/Map;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 78
    .end local v0    # "uri":Landroid/net/Uri;
    .end local v1    # "path":Ljava/lang/String;
    :catch_0
    move-exception v0

    :cond_0
    :goto_0
    nop

    .line 79
    return-void
.end method

.method public static GetStreamingData(Ljava/lang/String;)Ljava/nio/ByteBuffer;
    .locals 1
    .param p0, "videoID"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/util/concurrent/ExecutionException;,
            Ljava/lang/InterruptedException;,
            Ljava/util/concurrent/TimeoutException;
        }
    .end annotation

    .line 83
    invoke-static {p0}, LuTools/uStreamSpoofing/uStreamingDataRequest;->GetRequestForVideoID(Ljava/lang/String;)LuTools/uStreamSpoofing/uStreamingDataRequest;

    move-result-object v0

    invoke-virtual {v0}, LuTools/uStreamSpoofing/uStreamingDataRequest;->GetStream()Ljava/nio/ByteBuffer;

    move-result-object v0

    return-object v0
.end method

.method public static RemoveVideoPlaybackPostBody(Landroid/net/Uri;I[B)[B
    .locals 2
    .param p0, "uri"    # Landroid/net/Uri;
    .param p1, "method"    # I
    .param p2, "postData"    # [B

    .line 89
    const/4 v0, 0x2

    if-ne p1, v0, :cond_0

    :try_start_0
    invoke-virtual {p0}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    move-result-object v0

    const-string v1, "videoplayback"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    if-eqz v0, :cond_0

    .line 90
    const/4 v0, 0x0

    return-object v0

    .line 92
    :catch_0
    move-exception v0

    :cond_0
    nop

    .line 94
    return-object p2
.end method
