.class public LuTools/uStreamSpoofing/uSpoofing;
.super Ljava/lang/Object;
.source "uSpoofing.java"


# static fields
.field private static final INTERNET_CONNECTION_CHECK_URI:Landroid/net/Uri;

.field private static final fetchStreamsExcludedPaths:Ljava/util/AbstractMap$SimpleEntry;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/AbstractMap$SimpleEntry<",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 5

    .line 27
    nop

    .line 28
    const-string v0, "https://www.google.com/gen_204"

    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    sput-object v0, LuTools/uStreamSpoofing/uSpoofing;->INTERNET_CONNECTION_CHECK_URI:Landroid/net/Uri;

    .line 64
    new-instance v0, Ljava/util/AbstractMap$SimpleEntry;

    .line 67
    const-string v1, "ad_break"

    const-string v2, "get_drm_license"

    const-string v3, "heartbeat"

    const-string v4, "refresh"

    invoke-static {v1, v2, v3, v4}, Ljava/util/Set;->of(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v1

    const-string v2, "fetchStreamsExcludedPaths"

    invoke-direct {v0, v1, v2}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 65
    invoke-static {v0}, LuTools/uUtils;->InitializeNewBlockList(Ljava/util/AbstractMap$SimpleEntry;)Ljava/util/AbstractMap$SimpleEntry;

    move-result-object v0

    sput-object v0, LuTools/uStreamSpoofing/uSpoofing;->fetchStreamsExcludedPaths:Ljava/util/AbstractMap$SimpleEntry;

    .line 64
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 26
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static BlockGetWatchRequest(Landroid/net/Uri;)Landroid/net/Uri;
    .locals 3
    .param p0, "playerRequestUri"    # Landroid/net/Uri;

    .line 32
    :try_start_0
    invoke-virtual {p0}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    move-result-object v0

    const-string v1, "get_watch"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 33
    sget-object v0, LuTools/uStreamSpoofing/uSpoofing;->INTERNET_CONNECTION_CHECK_URI:Landroid/net/Uri;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    .line 41
    :cond_0
    goto :goto_0

    .line 35
    :catch_0
    move-exception v0

    .line 37
    .local v0, "e":Ljava/lang/Exception;
    invoke-static {}, LuTools/uStreamSpoofing/uSpoofing;->GetClassName()Ljava/lang/String;

    move-result-object v1

    .line 39
    invoke-virtual {v0}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v2

    .line 36
    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 43
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_0
    return-object p0
.end method

.method public static BlockInitPlaybackRequest(Ljava/lang/String;)Ljava/lang/String;
    .locals 3
    .param p0, "originalUrlString"    # Ljava/lang/String;

    .line 48
    :try_start_0
    invoke-static {p0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    .line 50
    .local v0, "originalUri":Landroid/net/Uri;
    invoke-virtual {v0}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    move-result-object v1

    const-string v2, "initplayback"

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_0

    .line 51
    sget-object v1, LuTools/uStreamSpoofing/uSpoofing;->INTERNET_CONNECTION_CHECK_URI:Landroid/net/Uri;

    invoke-virtual {v1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v1

    .line 59
    .end local v0    # "originalUri":Landroid/net/Uri;
    :cond_0
    goto :goto_0

    .line 53
    :catch_0
    move-exception v0

    .line 55
    .local v0, "e":Ljava/lang/Exception;
    invoke-static {}, LuTools/uStreamSpoofing/uSpoofing;->GetClassName()Ljava/lang/String;

    move-result-object v1

    .line 57
    invoke-virtual {v0}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v2

    .line 54
    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 61
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_0
    return-object p0
.end method

.method public static FetchStreams(Ljava/lang/String;Ljava/util/Map;)V
    .locals 4
    .param p0, "url"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 79
    .local p1, "requestHeaders":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;"
    :try_start_0
    invoke-static {p0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    .line 80
    .local v0, "uri":Landroid/net/Uri;
    invoke-virtual {v0}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    move-result-object v1

    .line 82
    .local v1, "path":Ljava/lang/String;
    const-string v2, "player"

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_0

    sget-object v2, LuTools/uStreamSpoofing/uSpoofing;->fetchStreamsExcludedPaths:Ljava/util/AbstractMap$SimpleEntry;

    sget-object v3, LuTools/uUtils$Entries;->ANY:LuTools/uUtils$Entries;

    .line 83
    invoke-static {v1, v2, v3}, LuTools/uUtils;->SearchInSetCorasick(Ljava/lang/String;Ljava/util/AbstractMap$SimpleEntry;LuTools/uUtils$Entries;)Z

    move-result v2

    if-nez v2, :cond_0

    .line 89
    const-string v2, "id"

    .line 90
    invoke-virtual {v0, v2}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    .line 89
    invoke-static {v2, p1}, LuTools/uStreamSpoofing/uStreamingDataRequest;->FetchRequest(Ljava/lang/String;Ljava/util/Map;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 100
    .end local v0    # "uri":Landroid/net/Uri;
    .end local v1    # "path":Ljava/lang/String;
    :cond_0
    goto :goto_0

    .line 94
    :catch_0
    move-exception v0

    .line 96
    .local v0, "e":Ljava/lang/Exception;
    invoke-static {}, LuTools/uStreamSpoofing/uSpoofing;->GetClassName()Ljava/lang/String;

    move-result-object v1

    .line 98
    invoke-virtual {v0}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v2

    .line 95
    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 101
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_0
    return-void
.end method

.method private static GetClassName()Ljava/lang/String;
    .locals 1

    .line 104
    const-class v0, LuTools/uStreamSpoofing/uSpoofing;

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public static GetStreamingData(Ljava/lang/String;)Ljava/nio/ByteBuffer;
    .locals 3
    .param p0, "videoID"    # Ljava/lang/String;

    .line 110
    :try_start_0
    invoke-static {p0}, LuTools/uStreamSpoofing/uStreamingDataRequest;->GetRequestForVideoID(Ljava/lang/String;)LuTools/uStreamSpoofing/uStreamingDataRequest;

    move-result-object v0

    invoke-virtual {v0}, LuTools/uStreamSpoofing/uStreamingDataRequest;->GetStream()Ljava/nio/ByteBuffer;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    .line 111
    :catch_0
    move-exception v0

    .line 113
    .local v0, "e":Ljava/lang/Exception;
    invoke-static {}, LuTools/uStreamSpoofing/uSpoofing;->GetClassName()Ljava/lang/String;

    move-result-object v1

    .line 115
    invoke-virtual {v0}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v2

    .line 112
    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 119
    .end local v0    # "e":Ljava/lang/Exception;
    const/4 v0, 0x0

    return-object v0
.end method

.method public static RemoveVideoPlaybackPostBody(Landroid/net/Uri;I[B)[B
    .locals 3
    .param p0, "uri"    # Landroid/net/Uri;
    .param p1, "method"    # I
    .param p2, "postData"    # [B

    .line 125
    const/4 v0, 0x2

    if-ne p1, v0, :cond_0

    :try_start_0
    invoke-virtual {p0}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    move-result-object v0

    const-string v1, "videoplayback"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    if-eqz v0, :cond_0

    .line 126
    const/4 v0, 0x0

    return-object v0

    .line 128
    :catch_0
    move-exception v0

    .line 130
    .local v0, "e":Ljava/lang/Exception;
    invoke-static {}, LuTools/uStreamSpoofing/uSpoofing;->GetClassName()Ljava/lang/String;

    move-result-object v1

    .line 132
    invoke-virtual {v0}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v2

    .line 129
    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    .line 134
    .end local v0    # "e":Ljava/lang/Exception;
    :cond_0
    nop

    .line 136
    :goto_0
    return-object p2
.end method
