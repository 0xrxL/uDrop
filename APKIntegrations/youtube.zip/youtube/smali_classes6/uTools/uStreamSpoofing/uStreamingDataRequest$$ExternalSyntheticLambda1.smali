.class public final synthetic LuTools/uStreamSpoofing/uStreamingDataRequest$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/util/concurrent/Callable;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "LuTools/uStreamSpoofing/uStreamingDataRequest;"
    method = "lambda$new$0"
    proto = "(Ljava/util/Map;Ljava/lang/String;)Ljava/nio/ByteBuffer;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x13
    versionHash = "9aaf5f34c4c84da429ef7f8f6217a1817876f2618cfcf539aba3d7d5a0c703e0"
.end annotation


# instance fields
.field public final synthetic f$0:LuTools/uStreamSpoofing/uStreamingDataRequest;

.field public final synthetic f$1:Ljava/util/Map;

.field public final synthetic f$2:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(LuTools/uStreamSpoofing/uStreamingDataRequest;Ljava/util/Map;Ljava/lang/String;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$$ExternalSyntheticLambda1;->f$0:LuTools/uStreamSpoofing/uStreamingDataRequest;

    iput-object p2, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$$ExternalSyntheticLambda1;->f$1:Ljava/util/Map;

    iput-object p3, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$$ExternalSyntheticLambda1;->f$2:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final call()Ljava/lang/Object;
    .locals 3

    .line 0
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$$ExternalSyntheticLambda1;->f$0:LuTools/uStreamSpoofing/uStreamingDataRequest;

    iget-object v1, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$$ExternalSyntheticLambda1;->f$1:Ljava/util/Map;

    iget-object v2, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$$ExternalSyntheticLambda1;->f$2:Ljava/lang/String;

    invoke-static {v0, v1, v2}, LuTools/uStreamSpoofing/uStreamingDataRequest;->$r8$lambda$w9MmyL03FTq0ITUxar6F-eeCNGs(LuTools/uStreamSpoofing/uStreamingDataRequest;Ljava/util/Map;Ljava/lang/String;)Ljava/nio/ByteBuffer;

    move-result-object v0

    return-object v0
.end method
