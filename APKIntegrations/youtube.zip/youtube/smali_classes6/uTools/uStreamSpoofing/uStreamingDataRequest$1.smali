.class LuTools/uStreamSpoofing/uStreamingDataRequest$1;
.super Lorg/json/JSONObject;
.source "uStreamingDataRequest.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LuTools/uStreamSpoofing/uStreamingDataRequest;-><init>(Ljava/lang/String;Ljava/util/Map;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:LuTools/uStreamSpoofing/uStreamingDataRequest;

.field final synthetic val$clientType:LuTools/uStreamSpoofing/uClientType;

.field final synthetic val$videoID:Ljava/lang/String;


# direct methods
.method constructor <init>(LuTools/uStreamSpoofing/uStreamingDataRequest;LuTools/uStreamSpoofing/uClientType;Ljava/lang/String;)V
    .locals 0
    .param p1, "this$0"    # LuTools/uStreamSpoofing/uStreamingDataRequest;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010,
            0x1010
        }
        names = {
            null,
            null,
            null
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lorg/json/JSONException;
        }
    .end annotation

    .line 173
    iput-object p1, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$1;->this$0:LuTools/uStreamSpoofing/uStreamingDataRequest;

    iput-object p2, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$1;->val$clientType:LuTools/uStreamSpoofing/uClientType;

    iput-object p3, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$1;->val$videoID:Ljava/lang/String;

    invoke-direct {p0}, Lorg/json/JSONObject;-><init>()V

    .line 174
    new-instance p2, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;

    invoke-direct {p2, p0}, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;-><init>(LuTools/uStreamSpoofing/uStreamingDataRequest$1;)V

    const-string p3, "context"

    invoke-virtual {p0, p3, p2}, LuTools/uStreamSpoofing/uStreamingDataRequest$1;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 198
    const-string p2, "contentCheckOk"

    const/4 p3, 0x1

    invoke-virtual {p0, p2, p3}, LuTools/uStreamSpoofing/uStreamingDataRequest$1;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    .line 199
    const-string p2, "racyCheckOk"

    invoke-virtual {p0, p2, p3}, LuTools/uStreamSpoofing/uStreamingDataRequest$1;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    .line 200
    const-string p2, "videoId"

    iget-object p3, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$1;->val$videoID:Ljava/lang/String;

    invoke-virtual {p0, p2, p3}, LuTools/uStreamSpoofing/uStreamingDataRequest$1;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 201
    return-void
.end method
