.class LuTools/uStreamSpoofing/uStreamingDataRequest$1$1$1;
.super Lorg/json/JSONObject;
.source "uStreamingDataRequest.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$2:LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;


# direct methods
.method constructor <init>(LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;)V
    .locals 2
    .param p1, "this$2"    # LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lorg/json/JSONException;
        }
    .end annotation

    .line 186
    iput-object p1, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1$1;->this$2:LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;

    invoke-direct {p0}, Lorg/json/JSONObject;-><init>()V

    .line 187
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1$1;->this$2:LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;

    iget-object v0, v0, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;->this$1:LuTools/uStreamSpoofing/uStreamingDataRequest$1;

    iget-object v0, v0, LuTools/uStreamSpoofing/uStreamingDataRequest$1;->val$clientType:LuTools/uStreamSpoofing/uClientType;

    iget-object v0, v0, LuTools/uStreamSpoofing/uClientType;->clientName:Ljava/lang/String;

    const-string v1, "clientName"

    invoke-virtual {p0, v1, v0}, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1$1;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 188
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1$1;->this$2:LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;

    iget-object v0, v0, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;->this$1:LuTools/uStreamSpoofing/uStreamingDataRequest$1;

    iget-object v0, v0, LuTools/uStreamSpoofing/uStreamingDataRequest$1;->val$clientType:LuTools/uStreamSpoofing/uClientType;

    iget-object v0, v0, LuTools/uStreamSpoofing/uClientType;->clientVersion:Ljava/lang/String;

    const-string v1, "clientVersion"

    invoke-virtual {p0, v1, v0}, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1$1;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 189
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1$1;->this$2:LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;

    iget-object v0, v0, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;->this$1:LuTools/uStreamSpoofing/uStreamingDataRequest$1;

    iget-object v0, v0, LuTools/uStreamSpoofing/uStreamingDataRequest$1;->val$clientType:LuTools/uStreamSpoofing/uClientType;

    iget-object v0, v0, LuTools/uStreamSpoofing/uClientType;->deviceMake:Ljava/lang/String;

    const-string v1, "deviceMake"

    invoke-virtual {p0, v1, v0}, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1$1;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 190
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1$1;->this$2:LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;

    iget-object v0, v0, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;->this$1:LuTools/uStreamSpoofing/uStreamingDataRequest$1;

    iget-object v0, v0, LuTools/uStreamSpoofing/uStreamingDataRequest$1;->val$clientType:LuTools/uStreamSpoofing/uClientType;

    iget-object v0, v0, LuTools/uStreamSpoofing/uClientType;->deviceModel:Ljava/lang/String;

    const-string v1, "deviceModel"

    invoke-virtual {p0, v1, v0}, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1$1;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 191
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1$1;->this$2:LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;

    iget-object v0, v0, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;->this$1:LuTools/uStreamSpoofing/uStreamingDataRequest$1;

    iget-object v0, v0, LuTools/uStreamSpoofing/uStreamingDataRequest$1;->this$0:LuTools/uStreamSpoofing/uStreamingDataRequest;

    invoke-static {v0}, LuTools/uStreamSpoofing/uStreamingDataRequest;->-$$Nest$fgetvideoRequireLogin(LuTools/uStreamSpoofing/uStreamingDataRequest;)Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1$1;->this$2:LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;

    iget-object v0, v0, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;->this$1:LuTools/uStreamSpoofing/uStreamingDataRequest$1;

    iget-object v0, v0, LuTools/uStreamSpoofing/uStreamingDataRequest$1;->this$0:LuTools/uStreamSpoofing/uStreamingDataRequest;

    invoke-static {v0}, LuTools/uStreamSpoofing/uStreamingDataRequest;->-$$Nest$fgetdefaultAudioTrackLocale(LuTools/uStreamSpoofing/uStreamingDataRequest;)Ljava/util/Locale;

    move-result-object v0

    if-eqz v0, :cond_0

    .line 192
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1$1;->this$2:LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;

    iget-object v0, v0, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;->this$1:LuTools/uStreamSpoofing/uStreamingDataRequest$1;

    iget-object v0, v0, LuTools/uStreamSpoofing/uStreamingDataRequest$1;->this$0:LuTools/uStreamSpoofing/uStreamingDataRequest;

    invoke-static {v0}, LuTools/uStreamSpoofing/uStreamingDataRequest;->-$$Nest$fgetdefaultAudioTrackLocale(LuTools/uStreamSpoofing/uStreamingDataRequest;)Ljava/util/Locale;

    move-result-object v0

    const-string v1, "hl"

    invoke-virtual {p0, v1, v0}, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1$1;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 194
    :cond_0
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1$1;->this$2:LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;

    iget-object v0, v0, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;->this$1:LuTools/uStreamSpoofing/uStreamingDataRequest$1;

    iget-object v0, v0, LuTools/uStreamSpoofing/uStreamingDataRequest$1;->val$clientType:LuTools/uStreamSpoofing/uClientType;

    iget-object v0, v0, LuTools/uStreamSpoofing/uClientType;->osName:Ljava/lang/String;

    const-string v1, "osName"

    invoke-virtual {p0, v1, v0}, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1$1;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 195
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1$1;->this$2:LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;

    iget-object v0, v0, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;->this$1:LuTools/uStreamSpoofing/uStreamingDataRequest$1;

    iget-object v0, v0, LuTools/uStreamSpoofing/uStreamingDataRequest$1;->val$clientType:LuTools/uStreamSpoofing/uClientType;

    iget-object v0, v0, LuTools/uStreamSpoofing/uClientType;->osVersion:Ljava/lang/String;

    const-string v1, "osVersion"

    invoke-virtual {p0, v1, v0}, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1$1;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 196
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1$1;->this$2:LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;

    iget-object v0, v0, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;->this$1:LuTools/uStreamSpoofing/uStreamingDataRequest$1;

    iget-object v0, v0, LuTools/uStreamSpoofing/uStreamingDataRequest$1;->val$clientType:LuTools/uStreamSpoofing/uClientType;

    iget-object v0, v0, LuTools/uStreamSpoofing/uClientType;->androidSDKVersion:Ljava/lang/String;

    if-eqz v0, :cond_1

    .line 197
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1$1;->this$2:LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;

    iget-object v0, v0, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;->this$1:LuTools/uStreamSpoofing/uStreamingDataRequest$1;

    iget-object v0, v0, LuTools/uStreamSpoofing/uStreamingDataRequest$1;->val$clientType:LuTools/uStreamSpoofing/uClientType;

    iget-object v0, v0, LuTools/uStreamSpoofing/uClientType;->androidSDKVersion:Ljava/lang/String;

    const-string v1, "androidSdkVersion"

    invoke-virtual {p0, v1, v0}, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1$1;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 199
    :cond_1
    return-void
.end method
