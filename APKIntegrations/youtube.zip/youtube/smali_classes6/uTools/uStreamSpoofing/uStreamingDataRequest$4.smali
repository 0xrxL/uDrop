.class LuTools/uStreamSpoofing/uStreamingDataRequest$4;
.super Ljava/lang/Object;
.source "uStreamingDataRequest.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LuTools/uStreamSpoofing/uStreamingDataRequest;->InjectSaveVideoToWatchLaterButton(Landroid/view/View;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field savingAlreadyInQueue:Z

.field final videoAddedErrorToast:LuTools/uUtils$MakeToast;

.field final videoAddedToast:LuTools/uUtils$MakeToast;

.field final videoAlreadyAddedToast:LuTools/uUtils$MakeToast;


# direct methods
.method constructor <init>()V
    .locals 2

    .line 428
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 429
    const/4 v0, 0x0

    iput-boolean v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$4;->savingAlreadyInQueue:Z

    .line 430
    new-instance v0, LuTools/uUtils$MakeToast;

    const-string v1, "Video saved in Watch Later"

    invoke-direct {v0, v1}, LuTools/uUtils$MakeToast;-><init>(Ljava/lang/String;)V

    iput-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$4;->videoAddedToast:LuTools/uUtils$MakeToast;

    .line 432
    new-instance v0, LuTools/uUtils$MakeToast;

    const-string v1, "Error: Video cannot be saved in Watch Later"

    invoke-direct {v0, v1}, LuTools/uUtils$MakeToast;-><init>(Ljava/lang/String;)V

    iput-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$4;->videoAddedErrorToast:LuTools/uUtils$MakeToast;

    .line 434
    new-instance v0, LuTools/uUtils$MakeToast;

    const-string v1, "Video is already saved in Watch Later"

    invoke-direct {v0, v1}, LuTools/uUtils$MakeToast;-><init>(Ljava/lang/String;)V

    iput-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$4;->videoAlreadyAddedToast:LuTools/uUtils$MakeToast;

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 4
    .param p1, "v"    # Landroid/view/View;

    .line 439
    iget-boolean v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$4;->savingAlreadyInQueue:Z

    if-eqz v0, :cond_0

    .line 440
    return-void

    .line 443
    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$4;->savingAlreadyInQueue:Z

    .line 445
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$4;->videoAddedToast:LuTools/uUtils$MakeToast;

    invoke-virtual {v0}, LuTools/uUtils$MakeToast;->HideToast()V

    .line 446
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$4;->videoAddedErrorToast:LuTools/uUtils$MakeToast;

    invoke-virtual {v0}, LuTools/uUtils$MakeToast;->HideToast()V

    .line 447
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$4;->videoAlreadyAddedToast:LuTools/uUtils$MakeToast;

    invoke-virtual {v0}, LuTools/uUtils$MakeToast;->HideToast()V

    .line 450
    :try_start_0
    new-instance v0, LuTools/VideoDetails/uVideoDetailsRequest;

    invoke-static {}, LuTools/uStreamSpoofing/uStreamingDataRequest;->-$$Nest$sfgetvideoIDPlaying()Ljava/lang/String;

    move-result-object v1

    invoke-static {}, LuTools/uStreamSpoofing/uStreamingDataRequest;->-$$Nest$sfgetplayerHeadersPlaying()Ljava/util/Map;

    move-result-object v2

    const-string v3, "saveVideoToWatchLater"

    invoke-direct {v0, v1, v2, v3}, LuTools/VideoDetails/uVideoDetailsRequest;-><init>(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)V

    .line 456
    invoke-virtual {v0}, LuTools/VideoDetails/uVideoDetailsRequest;->GetRequestedInfo()Ljava/lang/Object;

    move-result-object v0

    .line 457
    .local v0, "savingStatusRequest":Ljava/lang/Object;
    move-object v1, v0

    check-cast v1, Ljava/lang/String;

    .line 459
    .local v1, "savingStatus":Ljava/lang/String;
    if-eqz v1, :cond_2

    const-string v2, "STATUS_SUCCEEDED"

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_2

    .line 460
    const-string v2, "setVideoId"

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_1

    .line 461
    iget-object v2, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$4;->videoAddedToast:LuTools/uUtils$MakeToast;

    invoke-virtual {v2}, LuTools/uUtils$MakeToast;->ShowToast()V

    goto :goto_0

    .line 463
    :cond_1
    iget-object v2, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$4;->videoAlreadyAddedToast:LuTools/uUtils$MakeToast;

    invoke-virtual {v2}, LuTools/uUtils$MakeToast;->ShowToast()V

    goto :goto_0

    .line 466
    :cond_2
    iget-object v2, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$4;->videoAddedErrorToast:LuTools/uUtils$MakeToast;

    invoke-virtual {v2}, LuTools/uUtils$MakeToast;->ShowToast()V

    .line 469
    :goto_0
    const/4 v2, 0x0

    iput-boolean v2, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$4;->savingAlreadyInQueue:Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 476
    .end local v0    # "savingStatusRequest":Ljava/lang/Object;
    .end local v1    # "savingStatus":Ljava/lang/String;
    goto :goto_1

    .line 470
    :catch_0
    move-exception v0

    .line 472
    .local v0, "e":Ljava/lang/Exception;
    invoke-static {}, LuTools/uStreamSpoofing/uStreamingDataRequest;->-$$Nest$smGetClassName()Ljava/lang/String;

    move-result-object v1

    .line 474
    invoke-virtual {v0}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v2

    .line 471
    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 477
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_1
    return-void
.end method
