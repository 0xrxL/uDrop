.class LuTools/uStreamSpoofing/uStreamingDataRequest$3;
.super Ljava/lang/Object;
.source "uStreamingDataRequest.java"

# interfaces
.implements Landroid/view/ViewTreeObserver$OnPreDrawListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LuTools/uStreamSpoofing/uStreamingDataRequest;->InjectSaveVideoToWatchLaterButton(Landroid/view/View;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field newSaveButtonPosX:F

.field newSaveButtonPosY:F

.field saveButtonBackground:Landroid/graphics/drawable/Drawable;

.field sourceButtonAlpha:F

.field sourceButtonBackground:Landroid/graphics/drawable/Drawable;

.field sourceButtonPadding:[I

.field sourceButtonVisibility:I

.field final synthetic val$saveButton:Landroid/widget/ImageView;

.field final synthetic val$sourceButton:Landroid/view/View;


# direct methods
.method constructor <init>(Landroid/view/View;Landroid/widget/ImageView;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 385
    iput-object p1, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->val$sourceButton:Landroid/view/View;

    iput-object p2, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->val$saveButton:Landroid/widget/ImageView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 388
    new-instance p1, Landroid/graphics/drawable/ColorDrawable;

    const/4 p2, 0x0

    invoke-direct {p1, p2}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    iput-object p1, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->saveButtonBackground:Landroid/graphics/drawable/Drawable;

    .line 389
    const/4 p1, 0x0

    iput p1, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->sourceButtonAlpha:F

    .line 390
    iput p2, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->sourceButtonVisibility:I

    .line 391
    iput p1, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->newSaveButtonPosX:F

    .line 392
    iput p1, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->newSaveButtonPosY:F

    return-void
.end method


# virtual methods
.method public onPreDraw()Z
    .locals 7

    .line 396
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->val$sourceButton:Landroid/view/View;

    .line 397
    invoke-virtual {v0}, Landroid/view/View;->getPaddingLeft()I

    move-result v0

    iget-object v1, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->val$sourceButton:Landroid/view/View;

    .line 398
    invoke-virtual {v1}, Landroid/view/View;->getPaddingTop()I

    move-result v1

    iget-object v2, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->val$sourceButton:Landroid/view/View;

    .line 399
    invoke-virtual {v2}, Landroid/view/View;->getPaddingRight()I

    move-result v2

    iget-object v3, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->val$sourceButton:Landroid/view/View;

    .line 400
    invoke-virtual {v3}, Landroid/view/View;->getPaddingBottom()I

    move-result v3

    filled-new-array {v0, v1, v2, v3}, [I

    move-result-object v0

    iput-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->sourceButtonPadding:[I

    .line 402
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->val$saveButton:Landroid/widget/ImageView;

    .line 404
    invoke-virtual {v0}, Landroid/widget/ImageView;->getPaddingLeft()I

    move-result v0

    iget-object v1, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->val$saveButton:Landroid/widget/ImageView;

    .line 405
    invoke-virtual {v1}, Landroid/widget/ImageView;->getPaddingTop()I

    move-result v1

    iget-object v2, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->val$saveButton:Landroid/widget/ImageView;

    .line 406
    invoke-virtual {v2}, Landroid/widget/ImageView;->getPaddingRight()I

    move-result v2

    iget-object v3, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->val$saveButton:Landroid/widget/ImageView;

    .line 407
    invoke-virtual {v3}, Landroid/widget/ImageView;->getPaddingBottom()I

    move-result v3

    filled-new-array {v0, v1, v2, v3}, [I

    move-result-object v0

    iget-object v1, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->sourceButtonPadding:[I

    .line 402
    invoke-static {v0, v1}, Ljava/util/Arrays;->equals([I[I)Z

    move-result v0

    const/4 v1, 0x1

    if-nez v0, :cond_0

    .line 413
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->val$saveButton:Landroid/widget/ImageView;

    iget-object v2, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->val$sourceButton:Landroid/view/View;

    invoke-virtual {v2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/widget/ImageView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 415
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->val$saveButton:Landroid/widget/ImageView;

    iget-object v2, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->sourceButtonPadding:[I

    const/4 v3, 0x0

    aget v2, v2, v3

    iget-object v3, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->sourceButtonPadding:[I

    aget v3, v3, v1

    iget-object v4, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->sourceButtonPadding:[I

    const/4 v5, 0x2

    aget v4, v4, v5

    iget-object v5, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->sourceButtonPadding:[I

    const/4 v6, 0x3

    aget v5, v5, v6

    invoke-virtual {v0, v2, v3, v4, v5}, Landroid/widget/ImageView;->setPadding(IIII)V

    .line 423
    :cond_0
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->val$sourceButton:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    iput-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->sourceButtonBackground:Landroid/graphics/drawable/Drawable;

    .line 424
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->saveButtonBackground:Landroid/graphics/drawable/Drawable;

    iget-object v2, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->sourceButtonBackground:Landroid/graphics/drawable/Drawable;

    if-eq v0, v2, :cond_1

    .line 425
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->val$saveButton:Landroid/widget/ImageView;

    iget-object v2, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->sourceButtonBackground:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v2}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/widget/ImageView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 427
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->val$saveButton:Landroid/widget/ImageView;

    invoke-virtual {v0}, Landroid/widget/ImageView;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    iput-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->saveButtonBackground:Landroid/graphics/drawable/Drawable;

    .line 430
    :cond_1
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->val$sourceButton:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getAlpha()F

    move-result v0

    iput v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->sourceButtonAlpha:F

    .line 431
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->val$saveButton:Landroid/widget/ImageView;

    invoke-virtual {v0}, Landroid/widget/ImageView;->getAlpha()F

    move-result v0

    iget v2, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->sourceButtonAlpha:F

    cmpl-float v0, v0, v2

    if-eqz v0, :cond_2

    .line 432
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->val$saveButton:Landroid/widget/ImageView;

    iget v2, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->sourceButtonAlpha:F

    invoke-virtual {v0, v2}, Landroid/widget/ImageView;->setAlpha(F)V

    .line 435
    :cond_2
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->val$sourceButton:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v0

    iput v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->sourceButtonVisibility:I

    .line 436
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->val$saveButton:Landroid/widget/ImageView;

    invoke-virtual {v0}, Landroid/widget/ImageView;->getVisibility()I

    move-result v0

    iget v2, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->sourceButtonVisibility:I

    if-eq v0, v2, :cond_3

    .line 437
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->val$saveButton:Landroid/widget/ImageView;

    iget v2, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->sourceButtonVisibility:I

    invoke-virtual {v0, v2}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 440
    :cond_3
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->val$sourceButton:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getX()F

    move-result v0

    iget-object v2, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->val$sourceButton:Landroid/view/View;

    invoke-virtual {v2}, Landroid/view/View;->getWidth()I

    move-result v2

    int-to-float v2, v2

    sub-float/2addr v0, v2

    iput v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->newSaveButtonPosX:F

    .line 441
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->val$saveButton:Landroid/widget/ImageView;

    invoke-virtual {v0}, Landroid/widget/ImageView;->getX()F

    move-result v0

    iget v2, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->newSaveButtonPosX:F

    cmpl-float v0, v0, v2

    if-eqz v0, :cond_4

    .line 442
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->val$saveButton:Landroid/widget/ImageView;

    iget v2, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->newSaveButtonPosX:F

    invoke-virtual {v0, v2}, Landroid/widget/ImageView;->setX(F)V

    .line 445
    :cond_4
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->val$sourceButton:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getY()F

    move-result v0

    iput v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->newSaveButtonPosY:F

    .line 446
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->val$saveButton:Landroid/widget/ImageView;

    invoke-virtual {v0}, Landroid/widget/ImageView;->getY()F

    move-result v0

    iget v2, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->newSaveButtonPosY:F

    cmpl-float v0, v0, v2

    if-eqz v0, :cond_5

    .line 447
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->val$saveButton:Landroid/widget/ImageView;

    iget v2, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$3;->newSaveButtonPosY:F

    invoke-virtual {v0, v2}, Landroid/widget/ImageView;->setY(F)V

    .line 450
    :cond_5
    return v1
.end method
