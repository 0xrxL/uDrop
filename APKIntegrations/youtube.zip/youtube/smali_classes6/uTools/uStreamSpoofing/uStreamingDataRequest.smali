.class public LuTools/uStreamSpoofing/uStreamingDataRequest;
.super Ljava/lang/Object;
.source "uStreamingDataRequest.java"


# static fields
.field private static final Cache:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "LuTools/uStreamSpoofing/uStreamingDataRequest;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final CLIENT_TYPES_ORDER_TO_USE:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LuTools/uStreamSpoofing/uClientType;",
            ">;"
        }
    .end annotation
.end field

.field private currentClientName:Ljava/lang/String;

.field private final defaultAudioTrackLocales:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/util/Locale;",
            ">;"
        }
    .end annotation
.end field

.field private final future:Ljava/util/concurrent/Future;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/Future<",
            "Ljava/nio/ByteBuffer;",
            ">;"
        }
    .end annotation
.end field

.field private requestBody:[B

.field private final videoID:Ljava/lang/String;

.field private videoRequireLogin:Z

.field private videoRequireSimplifiedLocale:Z


# direct methods
.method public static synthetic $r8$lambda$w9MmyL03FTq0ITUxar6F-eeCNGs(LuTools/uStreamSpoofing/uStreamingDataRequest;Ljava/util/Map;Ljava/lang/String;)Ljava/nio/ByteBuffer;
    .locals 0

    invoke-direct {p0, p1, p2}, LuTools/uStreamSpoofing/uStreamingDataRequest;->lambda$new$0(Ljava/util/Map;Ljava/lang/String;)Ljava/nio/ByteBuffer;

    move-result-object p0

    return-object p0
.end method

.method static constructor <clinit>()V
    .locals 1

    .line 244
    invoke-static {}, LuTools/uUtils;->InitializeStreamCache()Ljava/util/LinkedHashMap;

    move-result-object v0

    invoke-static {v0}, Ljava/util/Collections;->synchronizedMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object v0

    sput-object v0, LuTools/uStreamSpoofing/uStreamingDataRequest;->Cache:Ljava/util/Map;

    .line 243
    return-void
.end method

.method private constructor <init>(Ljava/lang/String;Ljava/util/Map;)V
    .locals 7
    .param p1, "videoID"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 58
    .local p2, "playerHeaders":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;"
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 41
    new-instance v0, Ljava/util/ArrayList;

    const/4 v1, 0x3

    new-array v1, v1, [LuTools/uStreamSpoofing/uClientType;

    sget-object v2, LuTools/uStreamSpoofing/uClientType;->ANDROID_VR:LuTools/uStreamSpoofing/uClientType;

    const/4 v3, 0x0

    aput-object v2, v1, v3

    sget-object v2, LuTools/uStreamSpoofing/uClientType;->ANDROID_UNPLUGGED:LuTools/uStreamSpoofing/uClientType;

    const/4 v4, 0x1

    aput-object v2, v1, v4

    const/4 v2, 0x2

    sget-object v5, LuTools/uStreamSpoofing/uClientType;->ANDROID_CREATOR:LuTools/uStreamSpoofing/uClientType;

    aput-object v5, v1, v2

    .line 43
    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    iput-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->CLIENT_TYPES_ORDER_TO_USE:Ljava/util/List;

    .line 52
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->defaultAudioTrackLocales:Ljava/util/List;

    .line 59
    invoke-static {p2}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 61
    new-instance v0, LuTools/VideoDetails/uVideoDetailsRequest;

    const-string v1, "defaultAudioTrackID"

    invoke-direct {v0, p1, p2, v1}, LuTools/VideoDetails/uVideoDetailsRequest;-><init>(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)V

    .line 66
    invoke-virtual {v0}, LuTools/VideoDetails/uVideoDetailsRequest;->GetRequestedInfo()Ljava/lang/Object;

    move-result-object v0

    .line 68
    .local v0, "defaultAudioTrackRequest":Ljava/lang/Object;
    instance-of v1, v0, Ljava/lang/String;

    if-eqz v1, :cond_0

    .line 70
    move-object v1, v0

    check-cast v1, Ljava/lang/String;

    goto :goto_0

    .line 72
    :cond_0
    const-string v1, "en-US"

    :goto_0
    nop

    .line 73
    .local v1, "defaultAudioTrackName":Ljava/lang/String;
    iget-object v2, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->defaultAudioTrackLocales:Ljava/util/List;

    invoke-interface {v2}, Ljava/util/List;->clear()V

    .line 75
    :try_start_0
    const-string v2, "-"

    invoke-virtual {v1, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    .line 77
    .local v2, "splitDefaultAudioTrackName":[Ljava/lang/String;
    iget-object v5, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->defaultAudioTrackLocales:Ljava/util/List;

    new-instance v6, Ljava/util/Locale;

    aget-object v3, v2, v3

    aget-object v4, v2, v4

    .line 81
    invoke-virtual {v4}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v6, v3, v4}, Ljava/util/Locale;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 77
    invoke-interface {v5, v6}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 98
    nop

    .end local v2    # "splitDefaultAudioTrackName":[Ljava/lang/String;
    goto :goto_1

    .line 84
    :catch_0
    move-exception v2

    .line 86
    .local v2, "e":Ljava/lang/Exception;
    invoke-static {}, LuTools/uStreamSpoofing/uStreamingDataRequest;->GetClassName()Ljava/lang/String;

    move-result-object v3

    .line 88
    invoke-virtual {v2}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v4

    .line 85
    invoke-static {v3, v4}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 91
    iget-object v3, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->defaultAudioTrackLocales:Ljava/util/List;

    new-instance v4, Ljava/util/Locale;

    .line 95
    invoke-virtual {v1}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v4, v1, v5}, Ljava/util/Locale;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 91
    invoke-interface {v3, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 99
    .end local v2    # "e":Ljava/lang/Exception;
    :goto_1
    iget-object v2, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->defaultAudioTrackLocales:Ljava/util/List;

    new-instance v3, Ljava/util/Locale;

    invoke-direct {v3, v1}, Ljava/util/Locale;-><init>(Ljava/lang/String;)V

    invoke-interface {v2, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 101
    new-instance v2, LuTools/VideoDetails/uVideoDetailsRequest;

    const-string v3, "actionButtons"

    invoke-direct {v2, p1, p2, v3}, LuTools/VideoDetails/uVideoDetailsRequest;-><init>(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)V

    .line 106
    invoke-virtual {v2}, LuTools/VideoDetails/uVideoDetailsRequest;->GetRequestedInfo()Ljava/lang/Object;

    move-result-object v2

    .line 107
    .local v2, "actionButtonsRequest":Ljava/lang/Object;
    invoke-static {}, LuTools/uUtils;->NullifiesCurrentActionButtonsList()V

    .line 109
    instance-of v3, v2, Ljava/util/List;

    if-eqz v3, :cond_1

    .line 111
    move-object v3, v2

    check-cast v3, Ljava/util/List;

    goto :goto_2

    .line 113
    :cond_1
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 108
    :goto_2
    invoke-static {v3}, LuTools/uUtils;->SetCurrentActionButtonsList(Ljava/util/List;)V

    .line 116
    iput-object p1, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoID:Ljava/lang/String;

    .line 117
    sget-object v3, LuTools/uUtils;->BackgroundThreadPool:Ljava/util/concurrent/ThreadPoolExecutor;

    new-instance v4, LuTools/uStreamSpoofing/uStreamingDataRequest$$ExternalSyntheticLambda0;

    invoke-direct {v4, p0, p2, p1}, LuTools/uStreamSpoofing/uStreamingDataRequest$$ExternalSyntheticLambda0;-><init>(LuTools/uStreamSpoofing/uStreamingDataRequest;Ljava/util/Map;Ljava/lang/String;)V

    invoke-virtual {v3, v4}, Ljava/util/concurrent/ThreadPoolExecutor;->submit(Ljava/util/concurrent/Callable;)Ljava/util/concurrent/Future;

    move-result-object v3

    iput-object v3, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->future:Ljava/util/concurrent/Future;

    .line 241
    return-void
.end method

.method public static FetchRequest(Ljava/lang/String;Ljava/util/Map;)V
    .locals 2
    .param p0, "videoID"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 247
    .local p1, "fetchHeaders":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;"
    sget-object v0, LuTools/uStreamSpoofing/uStreamingDataRequest;->Cache:Ljava/util/Map;

    new-instance v1, LuTools/uStreamSpoofing/uStreamingDataRequest;

    invoke-direct {v1, p0, p1}, LuTools/uStreamSpoofing/uStreamingDataRequest;-><init>(Ljava/lang/String;Ljava/util/Map;)V

    invoke-interface {v0, p0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 248
    return-void
.end method

.method private static GetClassName()Ljava/lang/String;
    .locals 1

    .line 251
    const-class v0, LuTools/uStreamSpoofing/uStreamingDataRequest;

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public static GetRequestForVideoID(Ljava/lang/String;)LuTools/uStreamSpoofing/uStreamingDataRequest;
    .locals 1
    .param p0, "videoID"    # Ljava/lang/String;

    .line 256
    sget-object v0, LuTools/uStreamSpoofing/uStreamingDataRequest;->Cache:Ljava/util/Map;

    invoke-interface {v0, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LuTools/uStreamSpoofing/uStreamingDataRequest;

    return-object v0
.end method

.method private synthetic lambda$new$0(Ljava/util/Map;Ljava/lang/String;)Ljava/nio/ByteBuffer;
    .locals 18
    .param p1, "playerHeaders"    # Ljava/util/Map;
    .param p2, "videoID"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 119
    move-object/from16 v1, p0

    iget-object v0, v1, LuTools/uStreamSpoofing/uStreamingDataRequest;->CLIENT_TYPES_ORDER_TO_USE:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_a

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    move-object v4, v0

    check-cast v4, LuTools/uStreamSpoofing/uClientType;

    .line 120
    .local v4, "clientType":LuTools/uStreamSpoofing/uClientType;
    const/4 v5, 0x0

    iput-boolean v5, v1, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoRequireLogin:Z

    .line 122
    const/4 v0, 0x0

    move v6, v0

    .local v6, "i":I
    :goto_1
    const/4 v0, 0x4

    if-ge v6, v0, :cond_9

    .line 123
    iput-boolean v5, v1, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoRequireSimplifiedLocale:Z

    .line 125
    const/4 v0, 0x0

    move v7, v0

    .local v7, "j":I
    :goto_2
    const/4 v0, 0x2

    if-ge v7, v0, :cond_8

    .line 126
    new-instance v0, LuTools/uStreamSpoofing/uRoute;

    sget-object v9, LuTools/uStreamSpoofing/uRoute$Method;->POST:LuTools/uStreamSpoofing/uRoute$Method;

    const-string v10, "player?fields=streamingData&alt=proto"

    invoke-direct {v0, v9, v10}, LuTools/uStreamSpoofing/uRoute;-><init>(LuTools/uStreamSpoofing/uRoute$Method;Ljava/lang/String;)V

    new-array v9, v5, [Ljava/lang/String;

    .line 131
    invoke-virtual {v0, v9}, LuTools/uStreamSpoofing/uRoute;->Compile([Ljava/lang/String;)LuTools/uStreamSpoofing/uRoute$CompiledRoute;

    move-result-object v0

    iget-object v9, v4, LuTools/uStreamSpoofing/uClientType;->userAgent:Ljava/lang/String;

    iget v10, v4, LuTools/uStreamSpoofing/uClientType;->clientID:I

    .line 135
    invoke-static {v10}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v10

    iget-object v11, v4, LuTools/uStreamSpoofing/uClientType;->clientVersion:Ljava/lang/String;

    filled-new-array {v9, v10, v11}, [Ljava/lang/Object;

    move-result-object v9

    .line 133
    invoke-static {v9}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v9

    .line 126
    invoke-static {v0, v9}, LuTools/uStreamSpoofing/uPlayerRoutes;->GetPlayerResponseConnectionFromRoute(LuTools/uStreamSpoofing/uRoute$CompiledRoute;Ljava/util/List;)Ljava/net/HttpURLConnection;

    move-result-object v9

    .line 140
    .local v9, "connection":Ljava/net/HttpURLConnection;
    if-eqz v9, :cond_7

    .line 141
    sget-object v0, LuTools/uStreamSpoofing/uPlayerRoutes;->requestKeys:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_3
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/String;

    .line 142
    .local v10, "requestKey":Ljava/lang/String;
    sget-object v11, LuTools/uStreamSpoofing/uPlayerRoutes;->requestKeys:Ljava/util/List;

    invoke-interface {v11, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_0

    iget-boolean v11, v1, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoRequireLogin:Z

    if-nez v11, :cond_0

    .line 143
    goto :goto_3

    .line 146
    :cond_0
    move-object/from16 v11, p1

    invoke-interface {v11, v10}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/lang/String;

    invoke-virtual {v9, v10, v12}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 147
    .end local v10    # "requestKey":Ljava/lang/String;
    goto :goto_3

    .line 150
    :cond_1
    move-object/from16 v11, p1

    iget-boolean v0, v1, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoRequireLogin:Z

    if-nez v0, :cond_3

    .line 152
    iget-object v0, v1, LuTools/uStreamSpoofing/uStreamingDataRequest;->defaultAudioTrackLocales:Ljava/util/List;

    .line 153
    iget-boolean v10, v1, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoRequireSimplifiedLocale:Z

    if-nez v10, :cond_2

    .line 155
    move v10, v5

    goto :goto_4

    .line 157
    :cond_2
    const/4 v10, 0x1

    .line 152
    :goto_4
    invoke-interface {v0, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Locale;

    goto :goto_5

    .line 160
    :cond_3
    const/4 v0, 0x0

    :goto_5
    move-object v10, v0

    .line 162
    .local v10, "defaultAudioTrackLocale":Ljava/util/Locale;
    new-instance v0, LuTools/uStreamSpoofing/uStreamingDataRequest$1;

    move-object/from16 v12, p2

    invoke-direct {v0, v1, v4, v10, v12}, LuTools/uStreamSpoofing/uStreamingDataRequest$1;-><init>(LuTools/uStreamSpoofing/uStreamingDataRequest;LuTools/uStreamSpoofing/uClientType;Ljava/util/Locale;Ljava/lang/String;)V

    .line 189
    invoke-virtual {v0}, LuTools/uStreamSpoofing/uStreamingDataRequest$1;->toString()Ljava/lang/String;

    move-result-object v0

    sget-object v13, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    .line 190
    invoke-virtual {v0, v13}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v0

    iput-object v0, v1, LuTools/uStreamSpoofing/uStreamingDataRequest;->requestBody:[B

    .line 192
    iget-object v0, v1, LuTools/uStreamSpoofing/uStreamingDataRequest;->requestBody:[B

    array-length v0, v0

    invoke-virtual {v9, v0}, Ljava/net/HttpURLConnection;->setFixedLengthStreamingMode(I)V

    .line 193
    invoke-virtual {v9}, Ljava/net/HttpURLConnection;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v0

    iget-object v13, v1, LuTools/uStreamSpoofing/uStreamingDataRequest;->requestBody:[B

    invoke-virtual {v0, v13}, Ljava/io/OutputStream;->write([B)V

    .line 195
    invoke-virtual {v9}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v0

    const/16 v13, 0xc8

    if-ne v0, v13, :cond_6

    invoke-virtual {v9}, Ljava/net/HttpURLConnection;->getContentLength()I

    move-result v0

    if-eqz v0, :cond_6

    .line 197
    :try_start_0
    new-instance v0, Ljava/io/BufferedInputStream;

    invoke-virtual {v9}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v13

    invoke-direct {v0, v13}, Ljava/io/BufferedInputStream;-><init>(Ljava/io/InputStream;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    move-object v13, v0

    .line 198
    .local v13, "inputStream":Ljava/io/InputStream;
    :try_start_1
    new-instance v0, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_5

    move-object v14, v0

    .line 200
    .local v14, "bAOS":Ljava/io/ByteArrayOutputStream;
    const/16 v0, 0x800

    :try_start_2
    new-array v0, v0, [B

    .line 202
    .local v0, "buffer":[B
    :goto_6
    invoke-virtual {v13, v0}, Ljava/io/InputStream;->read([B)I

    move-result v15
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    move/from16 v16, v15

    .local v16, "bytesRead":I
    if-ltz v15, :cond_4

    .line 203
    move/from16 v15, v16

    .end local v16    # "bytesRead":I
    .local v15, "bytesRead":I
    :try_start_3
    invoke-virtual {v14, v0, v5, v15}, Ljava/io/ByteArrayOutputStream;->write([BII)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    goto :goto_6

    .line 196
    .end local v0    # "buffer":[B
    .end local v15    # "bytesRead":I
    :catchall_0
    move-exception v0

    move-object v3, v0

    const/16 v16, 0x0

    goto :goto_9

    .line 206
    .restart local v0    # "buffer":[B
    .restart local v16    # "bytesRead":I
    :cond_4
    move/from16 v15, v16

    .end local v16    # "bytesRead":I
    .restart local v15    # "bytesRead":I
    const/16 v16, 0x0

    :try_start_4
    const-string v3, " (%s - %s)"

    .line 210
    invoke-virtual {v4}, LuTools/uStreamSpoofing/uClientType;->name()Ljava/lang/String;

    move-result-object v5

    .line 211
    iget-boolean v8, v1, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoRequireLogin:Z

    if-nez v8, :cond_5

    const-string v8, "NO_AUTH"

    goto :goto_7

    :cond_5
    const-string v8, "WITH_AUTH"

    :goto_7
    filled-new-array {v5, v8}, [Ljava/lang/Object;

    move-result-object v5

    .line 207
    invoke-static {v3, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    iput-object v3, v1, LuTools/uStreamSpoofing/uStreamingDataRequest;->currentClientName:Ljava/lang/String;

    .line 213
    iget-object v3, v1, LuTools/uStreamSpoofing/uStreamingDataRequest;->currentClientName:Ljava/lang/String;

    invoke-static {v3}, LuTools/uUtils;->SetStatsForNerdsClientName(Ljava/lang/String;)V

    .line 214
    invoke-static {}, LuTools/uStreamSpoofing/uStreamingDataRequest;->GetClassName()Ljava/lang/String;

    move-result-object v3

    iget-object v5, v1, LuTools/uStreamSpoofing/uStreamingDataRequest;->currentClientName:Ljava/lang/String;

    invoke-static {v3, v5}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 216
    invoke-virtual {v14}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v3

    invoke-static {v3}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object v3
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    .line 217
    :try_start_5
    invoke-virtual {v14}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_4

    :try_start_6
    invoke-virtual {v13}, Ljava/io/InputStream;->close()V
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_0

    .line 216
    return-object v3

    .line 196
    .end local v0    # "buffer":[B
    .end local v15    # "bytesRead":I
    :catchall_1
    move-exception v0

    goto :goto_8

    :catchall_2
    move-exception v0

    const/16 v16, 0x0

    :goto_8
    move-object v3, v0

    :goto_9
    :try_start_7
    invoke-virtual {v14}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_3

    goto :goto_a

    :catchall_3
    move-exception v0

    :try_start_8
    invoke-virtual {v3, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .end local v4    # "clientType":LuTools/uStreamSpoofing/uClientType;
    .end local v6    # "i":I
    .end local v7    # "j":I
    .end local v9    # "connection":Ljava/net/HttpURLConnection;
    .end local v10    # "defaultAudioTrackLocale":Ljava/util/Locale;
    .end local v13    # "inputStream":Ljava/io/InputStream;
    .end local p0    # "this":LuTools/uStreamSpoofing/uStreamingDataRequest;
    .end local p1    # "playerHeaders":Ljava/util/Map;
    .end local p2    # "videoID":Ljava/lang/String;
    :goto_a
    throw v3
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_4

    .end local v14    # "bAOS":Ljava/io/ByteArrayOutputStream;
    .restart local v4    # "clientType":LuTools/uStreamSpoofing/uClientType;
    .restart local v6    # "i":I
    .restart local v7    # "j":I
    .restart local v9    # "connection":Ljava/net/HttpURLConnection;
    .restart local v10    # "defaultAudioTrackLocale":Ljava/util/Locale;
    .restart local v13    # "inputStream":Ljava/io/InputStream;
    .restart local p0    # "this":LuTools/uStreamSpoofing/uStreamingDataRequest;
    .restart local p1    # "playerHeaders":Ljava/util/Map;
    .restart local p2    # "videoID":Ljava/lang/String;
    :catchall_4
    move-exception v0

    goto :goto_b

    :catchall_5
    move-exception v0

    const/16 v16, 0x0

    :goto_b
    move-object v3, v0

    :try_start_9
    invoke-virtual {v13}, Ljava/io/InputStream;->close()V
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_6

    goto :goto_c

    :catchall_6
    move-exception v0

    :try_start_a
    invoke-virtual {v3, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .end local v4    # "clientType":LuTools/uStreamSpoofing/uClientType;
    .end local v6    # "i":I
    .end local v7    # "j":I
    .end local v9    # "connection":Ljava/net/HttpURLConnection;
    .end local v10    # "defaultAudioTrackLocale":Ljava/util/Locale;
    .end local p0    # "this":LuTools/uStreamSpoofing/uStreamingDataRequest;
    .end local p1    # "playerHeaders":Ljava/util/Map;
    .end local p2    # "videoID":Ljava/lang/String;
    :goto_c
    throw v3
    :try_end_a
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_a} :catch_0

    .line 217
    .end local v13    # "inputStream":Ljava/io/InputStream;
    .restart local v4    # "clientType":LuTools/uStreamSpoofing/uClientType;
    .restart local v6    # "i":I
    .restart local v7    # "j":I
    .restart local v9    # "connection":Ljava/net/HttpURLConnection;
    .restart local v10    # "defaultAudioTrackLocale":Ljava/util/Locale;
    .restart local p0    # "this":LuTools/uStreamSpoofing/uStreamingDataRequest;
    .restart local p1    # "playerHeaders":Ljava/util/Map;
    .restart local p2    # "videoID":Ljava/lang/String;
    :catch_0
    move-exception v0

    goto :goto_d

    :catch_1
    move-exception v0

    const/16 v16, 0x0

    .line 219
    .local v0, "e":Ljava/lang/Exception;
    :goto_d
    invoke-static {}, LuTools/uStreamSpoofing/uStreamingDataRequest;->GetClassName()Ljava/lang/String;

    move-result-object v3

    .line 221
    invoke-virtual {v0}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v5

    .line 218
    invoke-static {v3, v5}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_e

    .line 195
    .end local v0    # "e":Ljava/lang/Exception;
    :cond_6
    const/16 v16, 0x0

    goto :goto_e

    .line 140
    .end local v10    # "defaultAudioTrackLocale":Ljava/util/Locale;
    :cond_7
    move-object/from16 v11, p1

    move-object/from16 v12, p2

    const/16 v16, 0x0

    .line 227
    :goto_e
    const/4 v3, 0x1

    iput-boolean v3, v1, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoRequireSimplifiedLocale:Z

    .line 125
    .end local v9    # "connection":Ljava/net/HttpURLConnection;
    add-int/lit8 v7, v7, 0x1

    const/4 v5, 0x0

    goto/16 :goto_2

    :cond_8
    move-object/from16 v11, p1

    move-object/from16 v12, p2

    const/16 v16, 0x0

    .line 230
    .end local v7    # "j":I
    iget-boolean v0, v1, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoRequireLogin:Z

    const/16 v17, 0x1

    xor-int/lit8 v0, v0, 0x1

    iput-boolean v0, v1, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoRequireLogin:Z

    .line 122
    add-int/lit8 v6, v6, 0x1

    const/4 v5, 0x0

    goto/16 :goto_1

    :cond_9
    move-object/from16 v11, p1

    move-object/from16 v12, p2

    .line 232
    .end local v4    # "clientType":LuTools/uStreamSpoofing/uClientType;
    .end local v6    # "i":I
    goto/16 :goto_0

    .line 234
    :cond_a
    move-object/from16 v11, p1

    move-object/from16 v12, p2

    const/16 v16, 0x0

    const-string v0, "Original"

    iput-object v0, v1, LuTools/uStreamSpoofing/uStreamingDataRequest;->currentClientName:Ljava/lang/String;

    .line 235
    iget-object v0, v1, LuTools/uStreamSpoofing/uStreamingDataRequest;->currentClientName:Ljava/lang/String;

    filled-new-array {v0}, [Ljava/lang/Object;

    move-result-object v0

    const-string v2, " (%s)"

    invoke-static {v2, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, LuTools/uUtils;->SetStatsForNerdsClientName(Ljava/lang/String;)V

    .line 236
    invoke-static {}, LuTools/uStreamSpoofing/uStreamingDataRequest;->GetClassName()Ljava/lang/String;

    move-result-object v0

    iget-object v2, v1, LuTools/uStreamSpoofing/uStreamingDataRequest;->currentClientName:Ljava/lang/String;

    invoke-static {v0, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 238
    return-object v16
.end method


# virtual methods
.method public GetStream()Ljava/nio/ByteBuffer;
    .locals 4

    .line 262
    :try_start_0
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->future:Ljava/util/concurrent/Future;

    sget-object v1, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v2, 0x2710

    invoke-interface {v0, v2, v3, v1}, Ljava/util/concurrent/Future;->get(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/nio/ByteBuffer;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    .line 263
    :catch_0
    move-exception v0

    .line 265
    .local v0, "e":Ljava/lang/Exception;
    invoke-static {}, LuTools/uStreamSpoofing/uStreamingDataRequest;->GetClassName()Ljava/lang/String;

    move-result-object v1

    .line 267
    invoke-virtual {v0}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v2

    .line 264
    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 271
    .end local v0    # "e":Ljava/lang/Exception;
    const/4 v0, 0x0

    return-object v0
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    .line 277
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoID:Ljava/lang/String;

    filled-new-array {v0}, [Ljava/lang/Object;

    move-result-object v0

    const-string v1, "StreamingDataRequest{videoId=\'%s\'}"

    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
