.class public LuTools/uStreamSpoofing/uStreamingDataRequest;
.super Ljava/lang/Object;
.source "uStreamingDataRequest.java"


# static fields
.field private static final Cache:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "LuTools/uStreamSpoofing/uStreamingDataRequest;",
            ">;"
        }
    .end annotation
.end field

.field private static previousVideoID:Ljava/lang/String;


# instance fields
.field private final CLIENT_TYPES_ORDER_TO_USE:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LuTools/uStreamSpoofing/uClientType;",
            ">;"
        }
    .end annotation
.end field

.field private currentClientName:Ljava/lang/String;

.field private final defaultAudioTrackLocales:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/util/Locale;",
            ">;"
        }
    .end annotation
.end field

.field private final future:Ljava/util/concurrent/Future;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/Future<",
            "Ljava/nio/ByteBuffer;",
            ">;"
        }
    .end annotation
.end field

.field private requestBody:[B

.field private final videoID:Ljava/lang/String;

.field private videoRequireLogin:Z

.field private videoRequireSimplifiedLocale:Z


# direct methods
.method public static synthetic $r8$lambda$w9MmyL03FTq0ITUxar6F-eeCNGs(LuTools/uStreamSpoofing/uStreamingDataRequest;Ljava/util/Map;Ljava/lang/String;)Ljava/nio/ByteBuffer;
    .locals 0

    invoke-direct {p0, p1, p2}, LuTools/uStreamSpoofing/uStreamingDataRequest;->lambda$new$0(Ljava/util/Map;Ljava/lang/String;)Ljava/nio/ByteBuffer;

    move-result-object p0

    return-object p0
.end method

.method static constructor <clinit>()V
    .locals 1

    .line 235
    invoke-static {}, LuTools/uUtils;->InitializeStreamCache()Ljava/util/LinkedHashMap;

    move-result-object v0

    invoke-static {v0}, Ljava/util/Collections;->synchronizedMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object v0

    sput-object v0, LuTools/uStreamSpoofing/uStreamingDataRequest;->Cache:Ljava/util/Map;

    .line 234
    return-void
.end method

.method private constructor <init>(Ljava/lang/String;Ljava/util/Map;)V
    .locals 7
    .param p1, "videoID"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 57
    .local p2, "playerHeaders":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;"
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 44
    new-instance v0, Ljava/util/ArrayList;

    const/4 v1, 0x3

    new-array v1, v1, [LuTools/uStreamSpoofing/uClientType;

    sget-object v2, LuTools/uStreamSpoofing/uClientType;->ANDROID_VR:LuTools/uStreamSpoofing/uClientType;

    const/4 v3, 0x0

    aput-object v2, v1, v3

    sget-object v2, LuTools/uStreamSpoofing/uClientType;->ANDROID_UNPLUGGED:LuTools/uStreamSpoofing/uClientType;

    const/4 v4, 0x1

    aput-object v2, v1, v4

    const/4 v2, 0x2

    sget-object v5, LuTools/uStreamSpoofing/uClientType;->ANDROID_CREATOR:LuTools/uStreamSpoofing/uClientType;

    aput-object v5, v1, v2

    .line 46
    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    iput-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->CLIENT_TYPES_ORDER_TO_USE:Ljava/util/List;

    .line 54
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->defaultAudioTrackLocales:Ljava/util/List;

    .line 58
    invoke-static {p2}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 60
    sget-object v0, LuTools/uStreamSpoofing/uStreamingDataRequest;->previousVideoID:Ljava/lang/String;

    invoke-static {v0, p1}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2

    .line 61
    new-instance v0, LuTools/VideoDetails/uVideoDetailsRequest;

    const-string v1, "defaultAudioTrackID"

    invoke-direct {v0, p1, p2, v1}, LuTools/VideoDetails/uVideoDetailsRequest;-><init>(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)V

    .line 66
    invoke-virtual {v0}, LuTools/VideoDetails/uVideoDetailsRequest;->GetRequestedInfo()Ljava/lang/Object;

    move-result-object v0

    .line 68
    .local v0, "defaultAudioTrackRequest":Ljava/lang/Object;
    instance-of v1, v0, Ljava/lang/String;

    if-eqz v1, :cond_0

    .line 70
    move-object v1, v0

    check-cast v1, Ljava/lang/String;

    goto :goto_0

    .line 72
    :cond_0
    const-string v1, "en-US"

    :goto_0
    nop

    .line 73
    .local v1, "defaultAudioTrackName":Ljava/lang/String;
    iget-object v2, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->defaultAudioTrackLocales:Ljava/util/List;

    invoke-interface {v2}, Ljava/util/List;->clear()V

    .line 75
    :try_start_0
    const-string v2, "-"

    invoke-virtual {v1, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    .line 77
    .local v2, "splitDefaultAudioTrackName":[Ljava/lang/String;
    iget-object v5, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->defaultAudioTrackLocales:Ljava/util/List;

    new-instance v6, Ljava/util/Locale;

    aget-object v3, v2, v3

    aget-object v4, v2, v4

    .line 81
    invoke-virtual {v4}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v6, v3, v4}, Ljava/util/Locale;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 77
    invoke-interface {v5, v6}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 92
    nop

    .end local v2    # "splitDefaultAudioTrackName":[Ljava/lang/String;
    goto :goto_1

    .line 84
    :catch_0
    move-exception v2

    .line 85
    .local v2, "ignore":Ljava/lang/Exception;
    iget-object v3, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->defaultAudioTrackLocales:Ljava/util/List;

    new-instance v4, Ljava/util/Locale;

    .line 89
    invoke-virtual {v1}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v4, v1, v5}, Ljava/util/Locale;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 85
    invoke-interface {v3, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 93
    .end local v2    # "ignore":Ljava/lang/Exception;
    :goto_1
    iget-object v2, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->defaultAudioTrackLocales:Ljava/util/List;

    new-instance v3, Ljava/util/Locale;

    invoke-direct {v3, v1}, Ljava/util/Locale;-><init>(Ljava/lang/String;)V

    invoke-interface {v2, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 95
    new-instance v2, LuTools/VideoDetails/uVideoDetailsRequest;

    const-string v3, "actionButtons"

    invoke-direct {v2, p1, p2, v3}, LuTools/VideoDetails/uVideoDetailsRequest;-><init>(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)V

    .line 100
    invoke-virtual {v2}, LuTools/VideoDetails/uVideoDetailsRequest;->GetRequestedInfo()Ljava/lang/Object;

    move-result-object v2

    .line 101
    .local v2, "actionButtonsRequest":Ljava/lang/Object;
    invoke-static {}, LuTools/uUtils;->NullifiesCurrentActionButtonsList()V

    .line 103
    instance-of v3, v2, Ljava/util/List;

    if-eqz v3, :cond_1

    .line 105
    move-object v3, v2

    check-cast v3, Ljava/util/List;

    goto :goto_2

    .line 107
    :cond_1
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 102
    :goto_2
    invoke-static {v3}, LuTools/uUtils;->SetCurrentActionButtonsList(Ljava/util/List;)V

    .line 110
    sput-object p1, LuTools/uStreamSpoofing/uStreamingDataRequest;->previousVideoID:Ljava/lang/String;

    .line 113
    .end local v0    # "defaultAudioTrackRequest":Ljava/lang/Object;
    .end local v1    # "defaultAudioTrackName":Ljava/lang/String;
    .end local v2    # "actionButtonsRequest":Ljava/lang/Object;
    :cond_2
    iput-object p1, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoID:Ljava/lang/String;

    .line 114
    sget-object v0, LuTools/uUtils;->BackgroundThreadPool:Ljava/util/concurrent/ThreadPoolExecutor;

    new-instance v1, LuTools/uStreamSpoofing/uStreamingDataRequest$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0, p2, p1}, LuTools/uStreamSpoofing/uStreamingDataRequest$$ExternalSyntheticLambda0;-><init>(LuTools/uStreamSpoofing/uStreamingDataRequest;Ljava/util/Map;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Ljava/util/concurrent/ThreadPoolExecutor;->submit(Ljava/util/concurrent/Callable;)Ljava/util/concurrent/Future;

    move-result-object v0

    iput-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->future:Ljava/util/concurrent/Future;

    .line 232
    return-void
.end method

.method public static FetchRequest(Ljava/lang/String;Ljava/util/Map;)V
    .locals 2
    .param p0, "videoID"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 238
    .local p1, "fetchHeaders":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;"
    sget-object v0, LuTools/uStreamSpoofing/uStreamingDataRequest;->Cache:Ljava/util/Map;

    new-instance v1, LuTools/uStreamSpoofing/uStreamingDataRequest;

    invoke-direct {v1, p0, p1}, LuTools/uStreamSpoofing/uStreamingDataRequest;-><init>(Ljava/lang/String;Ljava/util/Map;)V

    invoke-interface {v0, p0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 239
    return-void
.end method

.method public static GetRequestForVideoID(Ljava/lang/String;)LuTools/uStreamSpoofing/uStreamingDataRequest;
    .locals 1
    .param p0, "videoID"    # Ljava/lang/String;

    .line 243
    sget-object v0, LuTools/uStreamSpoofing/uStreamingDataRequest;->Cache:Ljava/util/Map;

    invoke-interface {v0, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LuTools/uStreamSpoofing/uStreamingDataRequest;

    return-object v0
.end method

.method private synthetic lambda$new$0(Ljava/util/Map;Ljava/lang/String;)Ljava/nio/ByteBuffer;
    .locals 13
    .param p1, "playerHeaders"    # Ljava/util/Map;
    .param p2, "videoID"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 116
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->CLIENT_TYPES_ORDER_TO_USE:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v2, 0x0

    const-string v3, "uStreamingDataRequest"

    if-eqz v1, :cond_9

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LuTools/uStreamSpoofing/uClientType;

    .line 117
    .local v1, "clientType":LuTools/uStreamSpoofing/uClientType;
    const/4 v4, 0x0

    iput-boolean v4, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoRequireLogin:Z

    .line 119
    const/4 v5, 0x0

    .local v5, "i":I
    :goto_1
    const/4 v6, 0x4

    if-ge v5, v6, :cond_8

    .line 120
    iput-boolean v4, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoRequireSimplifiedLocale:Z

    .line 122
    const/4 v6, 0x0

    .local v6, "j":I
    :goto_2
    const/4 v7, 0x2

    const/4 v8, 0x1

    if-ge v6, v7, :cond_7

    .line 123
    new-instance v7, LuTools/uStreamSpoofing/uRoute;

    sget-object v9, LuTools/uStreamSpoofing/uRoute$Method;->POST:LuTools/uStreamSpoofing/uRoute$Method;

    const-string v10, "player?fields=streamingData&alt=proto"

    invoke-direct {v7, v9, v10}, LuTools/uStreamSpoofing/uRoute;-><init>(LuTools/uStreamSpoofing/uRoute$Method;Ljava/lang/String;)V

    new-array v9, v4, [Ljava/lang/String;

    .line 128
    invoke-virtual {v7, v9}, LuTools/uStreamSpoofing/uRoute;->Compile([Ljava/lang/String;)LuTools/uStreamSpoofing/uRoute$CompiledRoute;

    move-result-object v7

    iget-object v9, v1, LuTools/uStreamSpoofing/uClientType;->userAgent:Ljava/lang/String;

    iget v10, v1, LuTools/uStreamSpoofing/uClientType;->clientID:I

    .line 132
    invoke-static {v10}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v10

    iget-object v11, v1, LuTools/uStreamSpoofing/uClientType;->clientVersion:Ljava/lang/String;

    filled-new-array {v9, v10, v11}, [Ljava/lang/Object;

    move-result-object v9

    .line 130
    invoke-static {v9}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v9

    .line 123
    invoke-static {v7, v9}, LuTools/uStreamSpoofing/uPlayerRoutes;->GetPlayerResponseConnectionFromRoute(LuTools/uStreamSpoofing/uRoute$CompiledRoute;Ljava/util/List;)Ljava/net/HttpURLConnection;

    move-result-object v7

    .line 137
    .local v7, "connection":Ljava/net/HttpURLConnection;
    if-eqz v7, :cond_6

    .line 138
    sget-object v9, LuTools/uStreamSpoofing/uPlayerRoutes;->requestKeys:Ljava/util/List;

    invoke-interface {v9}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :goto_3
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_1

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/String;

    .line 139
    .local v10, "requestKey":Ljava/lang/String;
    sget-object v11, LuTools/uStreamSpoofing/uPlayerRoutes;->requestKeys:Ljava/util/List;

    invoke-interface {v11, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_0

    iget-boolean v11, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoRequireLogin:Z

    if-nez v11, :cond_0

    .line 140
    goto :goto_3

    .line 143
    :cond_0
    invoke-interface {p1, v10}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/lang/String;

    invoke-virtual {v7, v10, v11}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 144
    .end local v10    # "requestKey":Ljava/lang/String;
    goto :goto_3

    .line 147
    :cond_1
    iget-boolean v9, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoRequireLogin:Z

    if-nez v9, :cond_3

    .line 149
    iget-object v9, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->defaultAudioTrackLocales:Ljava/util/List;

    .line 150
    iget-boolean v10, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoRequireSimplifiedLocale:Z

    if-nez v10, :cond_2

    .line 152
    move v10, v4

    goto :goto_4

    .line 154
    :cond_2
    move v10, v8

    .line 149
    :goto_4
    invoke-interface {v9, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/util/Locale;

    goto :goto_5

    .line 157
    :cond_3
    move-object v9, v2

    :goto_5
    nop

    .line 159
    .local v9, "defaultAudioTrackLocale":Ljava/util/Locale;
    new-instance v10, LuTools/uStreamSpoofing/uStreamingDataRequest$1;

    invoke-direct {v10, p0, v1, v9, p2}, LuTools/uStreamSpoofing/uStreamingDataRequest$1;-><init>(LuTools/uStreamSpoofing/uStreamingDataRequest;LuTools/uStreamSpoofing/uClientType;Ljava/util/Locale;Ljava/lang/String;)V

    .line 186
    invoke-virtual {v10}, LuTools/uStreamSpoofing/uStreamingDataRequest$1;->toString()Ljava/lang/String;

    move-result-object v10

    sget-object v11, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    .line 187
    invoke-virtual {v10, v11}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v10

    iput-object v10, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->requestBody:[B

    .line 189
    iget-object v10, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->requestBody:[B

    array-length v10, v10

    invoke-virtual {v7, v10}, Ljava/net/HttpURLConnection;->setFixedLengthStreamingMode(I)V

    .line 190
    invoke-virtual {v7}, Ljava/net/HttpURLConnection;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v10

    iget-object v11, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->requestBody:[B

    invoke-virtual {v10, v11}, Ljava/io/OutputStream;->write([B)V

    .line 192
    invoke-virtual {v7}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v10

    const/16 v11, 0xc8

    if-ne v10, v11, :cond_6

    invoke-virtual {v7}, Ljava/net/HttpURLConnection;->getContentLength()I

    move-result v10

    if-eqz v10, :cond_6

    .line 194
    new-instance v0, Ljava/io/BufferedInputStream;

    invoke-virtual {v7}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v2

    invoke-direct {v0, v2}, Ljava/io/BufferedInputStream;-><init>(Ljava/io/InputStream;)V

    .line 195
    .local v0, "inputStream":Ljava/io/InputStream;
    :try_start_0
    new-instance v2, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v2}, Ljava/io/ByteArrayOutputStream;-><init>()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    .line 197
    .local v2, "bAOS":Ljava/io/ByteArrayOutputStream;
    const/16 v8, 0x800

    :try_start_1
    new-array v8, v8, [B

    .line 199
    .local v8, "buffer":[B
    :goto_6
    invoke-virtual {v0, v8}, Ljava/io/InputStream;->read([B)I

    move-result v10

    move v11, v10

    .local v11, "bytesRead":I
    if-ltz v10, :cond_4

    .line 200
    invoke-virtual {v2, v8, v4, v11}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    goto :goto_6

    .line 203
    :cond_4
    const-string v4, " (%s - %s)"

    .line 207
    invoke-virtual {v1}, LuTools/uStreamSpoofing/uClientType;->name()Ljava/lang/String;

    move-result-object v10

    .line 208
    iget-boolean v12, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoRequireLogin:Z

    if-nez v12, :cond_5

    const-string v12, "NO_AUTH"

    goto :goto_7

    :cond_5
    const-string v12, "WITH_AUTH"

    :goto_7
    filled-new-array {v10, v12}, [Ljava/lang/Object;

    move-result-object v10

    .line 204
    invoke-static {v4, v10}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    iput-object v4, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->currentClientName:Ljava/lang/String;

    .line 210
    iget-object v4, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->currentClientName:Ljava/lang/String;

    invoke-static {v4}, LuTools/uUtils;->SetStatsForNerdsClientName(Ljava/lang/String;)V

    .line 211
    iget-object v4, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->currentClientName:Ljava/lang/String;

    invoke-static {v3, v4}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 213
    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v3

    invoke-static {v3}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object v3
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 214
    :try_start_2
    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    invoke-virtual {v0}, Ljava/io/InputStream;->close()V

    .line 213
    return-object v3

    .line 193
    .end local v8    # "buffer":[B
    .end local v11    # "bytesRead":I
    :catchall_0
    move-exception v3

    :try_start_3
    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    goto :goto_8

    :catchall_1
    move-exception v4

    :try_start_4
    invoke-virtual {v3, v4}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .end local v0    # "inputStream":Ljava/io/InputStream;
    .end local v1    # "clientType":LuTools/uStreamSpoofing/uClientType;
    .end local v5    # "i":I
    .end local v6    # "j":I
    .end local v7    # "connection":Ljava/net/HttpURLConnection;
    .end local v9    # "defaultAudioTrackLocale":Ljava/util/Locale;
    .end local p0    # "this":LuTools/uStreamSpoofing/uStreamingDataRequest;
    .end local p1    # "playerHeaders":Ljava/util/Map;
    .end local p2    # "videoID":Ljava/lang/String;
    :goto_8
    throw v3
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    .end local v2    # "bAOS":Ljava/io/ByteArrayOutputStream;
    .restart local v0    # "inputStream":Ljava/io/InputStream;
    .restart local v1    # "clientType":LuTools/uStreamSpoofing/uClientType;
    .restart local v5    # "i":I
    .restart local v6    # "j":I
    .restart local v7    # "connection":Ljava/net/HttpURLConnection;
    .restart local v9    # "defaultAudioTrackLocale":Ljava/util/Locale;
    .restart local p0    # "this":LuTools/uStreamSpoofing/uStreamingDataRequest;
    .restart local p1    # "playerHeaders":Ljava/util/Map;
    .restart local p2    # "videoID":Ljava/lang/String;
    :catchall_2
    move-exception v2

    :try_start_5
    invoke-virtual {v0}, Ljava/io/InputStream;->close()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_3

    goto :goto_9

    :catchall_3
    move-exception v3

    invoke-virtual {v2, v3}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_9
    throw v2

    .line 218
    .end local v0    # "inputStream":Ljava/io/InputStream;
    .end local v9    # "defaultAudioTrackLocale":Ljava/util/Locale;
    :cond_6
    iput-boolean v8, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoRequireSimplifiedLocale:Z

    .line 122
    .end local v7    # "connection":Ljava/net/HttpURLConnection;
    add-int/lit8 v6, v6, 0x1

    goto/16 :goto_2

    .line 221
    .end local v6    # "j":I
    :cond_7
    iget-boolean v6, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoRequireLogin:Z

    xor-int/2addr v6, v8

    iput-boolean v6, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoRequireLogin:Z

    .line 119
    add-int/lit8 v5, v5, 0x1

    goto/16 :goto_1

    .line 223
    .end local v1    # "clientType":LuTools/uStreamSpoofing/uClientType;
    .end local v5    # "i":I
    :cond_8
    goto/16 :goto_0

    .line 225
    :cond_9
    const-string v0, "Original"

    iput-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->currentClientName:Ljava/lang/String;

    .line 226
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->currentClientName:Ljava/lang/String;

    filled-new-array {v0}, [Ljava/lang/Object;

    move-result-object v0

    const-string v1, " (%s)"

    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, LuTools/uUtils;->SetStatsForNerdsClientName(Ljava/lang/String;)V

    .line 227
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->currentClientName:Ljava/lang/String;

    invoke-static {v3, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 229
    return-object v2
.end method


# virtual methods
.method public GetStream()Ljava/nio/ByteBuffer;
    .locals 4

    .line 249
    :try_start_0
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->future:Ljava/util/concurrent/Future;

    sget-object v1, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v2, 0x2710

    invoke-interface {v0, v2, v3, v1}, Ljava/util/concurrent/Future;->get(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/nio/ByteBuffer;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    .line 250
    :catch_0
    move-exception v0

    .line 252
    const/4 v0, 0x0

    return-object v0
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    .line 258
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoID:Ljava/lang/String;

    filled-new-array {v0}, [Ljava/lang/Object;

    move-result-object v0

    const-string v1, "StreamingDataRequest{videoId=\'%s\'}"

    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
