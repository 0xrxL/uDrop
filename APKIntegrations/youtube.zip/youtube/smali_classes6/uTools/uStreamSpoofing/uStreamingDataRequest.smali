.class public LuTools/uStreamSpoofing/uStreamingDataRequest;
.super Ljava/lang/Object;
.source "uStreamingDataRequest.java"


# static fields
.field private static final Cache:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "LuTools/uStreamSpoofing/uStreamingDataRequest;",
            ">;"
        }
    .end annotation
.end field

.field private static final openVideoChannelToastDone:LuTools/uUtils$MakeToast;

.field private static final openVideoChannelToastError:LuTools/uUtils$MakeToast;

.field private static final openVideoChannelToastInProgress:LuTools/uUtils$MakeToast;

.field private static playerHeadersPlaying:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static videoChannelOpeningAlreadyInQueue:Z

.field private static videoIDPlaying:Ljava/lang/String;

.field private static videoIDToReload:Ljava/lang/String;

.field private static final videoReloadExcludedPlaybackStates:Ljava/util/AbstractMap$SimpleEntry;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/AbstractMap$SimpleEntry<",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static final videoReloadingToast:LuTools/uUtils$MakeToast;


# instance fields
.field private final CLIENT_TYPES_ORDER_TO_USE:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LuTools/uStreamSpoofing/uClientType;",
            ">;"
        }
    .end annotation
.end field

.field private currentClientName:Ljava/lang/String;

.field private defaultAudioTrackLocale:Ljava/util/Locale;

.field private final future:Ljava/util/concurrent/Future;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/Future<",
            "Ljava/nio/ByteBuffer;",
            ">;"
        }
    .end annotation
.end field

.field private requestBody:[B

.field private videoReloadHandlerAlreadyInQueue:Z

.field private videoRequireLogin:Z


# direct methods
.method public static synthetic $r8$lambda$w9MmyL03FTq0ITUxar6F-eeCNGs(LuTools/uStreamSpoofing/uStreamingDataRequest;Ljava/util/Map;Ljava/lang/String;)Ljava/nio/ByteBuffer;
    .locals 0

    invoke-direct {p0, p1, p2}, LuTools/uStreamSpoofing/uStreamingDataRequest;->lambda$new$0(Ljava/util/Map;Ljava/lang/String;)Ljava/nio/ByteBuffer;

    move-result-object p0

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetdefaultAudioTrackLocale(LuTools/uStreamSpoofing/uStreamingDataRequest;)Ljava/util/Locale;
    .locals 0

    iget-object p0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->defaultAudioTrackLocale:Ljava/util/Locale;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetvideoRequireLogin(LuTools/uStreamSpoofing/uStreamingDataRequest;)Z
    .locals 0

    iget-boolean p0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoRequireLogin:Z

    return p0
.end method

.method static bridge synthetic -$$Nest$sfgetplayerHeadersPlaying()Ljava/util/Map;
    .locals 1

    sget-object v0, LuTools/uStreamSpoofing/uStreamingDataRequest;->playerHeadersPlaying:Ljava/util/Map;

    return-object v0
.end method

.method static bridge synthetic -$$Nest$sfgetvideoIDPlaying()Ljava/lang/String;
    .locals 1

    sget-object v0, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoIDPlaying:Ljava/lang/String;

    return-object v0
.end method

.method static bridge synthetic -$$Nest$sfgetvideoIDToReload()Ljava/lang/String;
    .locals 1

    sget-object v0, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoIDToReload:Ljava/lang/String;

    return-object v0
.end method

.method static bridge synthetic -$$Nest$sfgetvideoReloadExcludedPlaybackStates()Ljava/util/AbstractMap$SimpleEntry;
    .locals 1

    sget-object v0, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoReloadExcludedPlaybackStates:Ljava/util/AbstractMap$SimpleEntry;

    return-object v0
.end method

.method static bridge synthetic -$$Nest$sfgetvideoReloadingToast()LuTools/uUtils$MakeToast;
    .locals 1

    sget-object v0, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoReloadingToast:LuTools/uUtils$MakeToast;

    return-object v0
.end method

.method static bridge synthetic -$$Nest$smGetClassName()Ljava/lang/String;
    .locals 1

    invoke-static {}, LuTools/uStreamSpoofing/uStreamingDataRequest;->GetClassName()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method static constructor <clinit>()V
    .locals 3

    .line 64
    const-string v0, ""

    sput-object v0, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoIDToReload:Ljava/lang/String;

    .line 65
    sput-object v0, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoIDPlaying:Ljava/lang/String;

    .line 262
    invoke-static {}, LuTools/uUtils;->InitializeStreamCache()Ljava/util/LinkedHashMap;

    move-result-object v0

    invoke-static {v0}, Ljava/util/Collections;->synchronizedMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object v0

    sput-object v0, LuTools/uStreamSpoofing/uStreamingDataRequest;->Cache:Ljava/util/Map;

    .line 292
    new-instance v0, LuTools/uUtils$MakeToast;

    const-string v1, "Timeout: Reloading video..."

    invoke-direct {v0, v1}, LuTools/uUtils$MakeToast;-><init>(Ljava/lang/String;)V

    sput-object v0, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoReloadingToast:LuTools/uUtils$MakeToast;

    .line 294
    new-instance v0, Ljava/util/AbstractMap$SimpleEntry;

    .line 297
    const-string v1, "READY"

    const-string v2, "VIDEO_PLAYING"

    invoke-static {v1, v2}, Ljava/util/Set;->of(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v1

    const-string v2, "videoReloadExcludedPlaybackStates"

    invoke-direct {v0, v1, v2}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 295
    invoke-static {v0}, LuTools/uUtils;->InitializeNewBlockList(Ljava/util/AbstractMap$SimpleEntry;)Ljava/util/AbstractMap$SimpleEntry;

    move-result-object v0

    sput-object v0, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoReloadExcludedPlaybackStates:Ljava/util/AbstractMap$SimpleEntry;

    .line 496
    new-instance v0, LuTools/uUtils$MakeToast;

    const-string v1, "Opening video channel..."

    invoke-direct {v0, v1}, LuTools/uUtils$MakeToast;-><init>(Ljava/lang/String;)V

    sput-object v0, LuTools/uStreamSpoofing/uStreamingDataRequest;->openVideoChannelToastInProgress:LuTools/uUtils$MakeToast;

    .line 498
    new-instance v0, LuTools/uUtils$MakeToast;

    const-string v1, "Channel opened"

    invoke-direct {v0, v1}, LuTools/uUtils$MakeToast;-><init>(Ljava/lang/String;)V

    sput-object v0, LuTools/uStreamSpoofing/uStreamingDataRequest;->openVideoChannelToastDone:LuTools/uUtils$MakeToast;

    .line 500
    new-instance v0, LuTools/uUtils$MakeToast;

    const-string v1, "Error: Failed to open video channel"

    invoke-direct {v0, v1}, LuTools/uUtils$MakeToast;-><init>(Ljava/lang/String;)V

    sput-object v0, LuTools/uStreamSpoofing/uStreamingDataRequest;->openVideoChannelToastError:LuTools/uUtils$MakeToast;

    .line 502
    const/4 v0, 0x0

    sput-boolean v0, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoChannelOpeningAlreadyInQueue:Z

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;Ljava/util/Map;)V
    .locals 7
    .param p1, "videoID"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 88
    .local p2, "playerHeaders":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;"
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 68
    new-instance v0, Ljava/util/ArrayList;

    const/4 v1, 0x5

    new-array v1, v1, [LuTools/uStreamSpoofing/uClientType;

    sget-object v2, LuTools/uStreamSpoofing/uClientType;->Android_VR_No_AV1:LuTools/uStreamSpoofing/uClientType;

    const/4 v3, 0x0

    aput-object v2, v1, v3

    const/4 v2, 0x1

    sget-object v4, LuTools/uStreamSpoofing/uClientType;->Android_VR_No_AV1:LuTools/uStreamSpoofing/uClientType;

    aput-object v4, v1, v2

    const/4 v2, 0x2

    sget-object v4, LuTools/uStreamSpoofing/uClientType;->Vision_OS:LuTools/uStreamSpoofing/uClientType;

    aput-object v4, v1, v2

    const/4 v2, 0x3

    sget-object v4, LuTools/uStreamSpoofing/uClientType;->Android_Studio:LuTools/uStreamSpoofing/uClientType;

    aput-object v4, v1, v2

    const/4 v2, 0x4

    sget-object v4, LuTools/uStreamSpoofing/uClientType;->Android_No_SDK:LuTools/uStreamSpoofing/uClientType;

    aput-object v4, v1, v2

    .line 70
    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    iput-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->CLIENT_TYPES_ORDER_TO_USE:Ljava/util/List;

    .line 83
    const/4 v0, 0x0

    iput-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->defaultAudioTrackLocale:Ljava/util/Locale;

    .line 89
    invoke-static {p2}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 91
    iput-boolean v3, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoReloadHandlerAlreadyInQueue:Z

    .line 94
    :try_start_0
    new-instance v0, LuTools/VideoDetails/uVideoDetailsRequest;

    const-string v1, "defaultAudioTrackID"

    invoke-direct {v0, p1, p2, v1}, LuTools/VideoDetails/uVideoDetailsRequest;-><init>(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)V

    .line 101
    invoke-virtual {v0}, LuTools/VideoDetails/uVideoDetailsRequest;->GetRequestedInfo()Ljava/lang/Object;

    move-result-object v0

    .line 102
    .local v0, "defaultAudioTrackNameRequest":Ljava/lang/Object;
    move-object v1, v0

    check-cast v1, Ljava/lang/String;

    .line 104
    .local v1, "defaultAudioTrackName":Ljava/lang/String;
    if-eqz v1, :cond_2

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_2

    .line 105
    const-string v2, "-"

    .line 106
    .local v2, "hyphen":Ljava/lang/String;
    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    .line 108
    .local v3, "hyphenExists":Z
    if-nez v3, :cond_0

    .line 110
    invoke-static {}, LuTools/uStreamSpoofing/uStreamingDataRequest;->GetClassName()Ljava/lang/String;

    move-result-object v4

    const-string v5, "The audio track name is not separated by a hyphen"

    .line 109
    invoke-static {v4, v5}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 116
    :cond_0
    new-instance v4, Ljava/util/Locale;

    .line 117
    if-nez v3, :cond_1

    .line 119
    const-string v5, "%s%s%s"

    .line 124
    invoke-virtual {v1}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object v6

    filled-new-array {v1, v2, v6}, [Ljava/lang/Object;

    move-result-object v6

    .line 119
    invoke-static {v5, v6}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    goto :goto_0

    .line 127
    :cond_1
    move-object v5, v1

    :goto_0
    invoke-direct {v4, v5}, Ljava/util/Locale;-><init>(Ljava/lang/String;)V

    iput-object v4, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->defaultAudioTrackLocale:Ljava/util/Locale;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 136
    .end local v0    # "defaultAudioTrackNameRequest":Ljava/lang/Object;
    .end local v1    # "defaultAudioTrackName":Ljava/lang/String;
    .end local v2    # "hyphen":Ljava/lang/String;
    .end local v3    # "hyphenExists":Z
    :cond_2
    goto :goto_1

    .line 130
    :catch_0
    move-exception v0

    .line 132
    .local v0, "e":Ljava/lang/Exception;
    invoke-static {}, LuTools/uStreamSpoofing/uStreamingDataRequest;->GetClassName()Ljava/lang/String;

    move-result-object v1

    .line 134
    invoke-virtual {v0}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v2

    .line 131
    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 138
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_1
    sget-object v0, LuTools/uUtils;->BackgroundThreadPool:Ljava/util/concurrent/ThreadPoolExecutor;

    new-instance v1, LuTools/uStreamSpoofing/uStreamingDataRequest$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0, p2, p1}, LuTools/uStreamSpoofing/uStreamingDataRequest$$ExternalSyntheticLambda0;-><init>(LuTools/uStreamSpoofing/uStreamingDataRequest;Ljava/util/Map;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Ljava/util/concurrent/ThreadPoolExecutor;->submit(Ljava/util/concurrent/Callable;)Ljava/util/concurrent/Future;

    move-result-object v0

    iput-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->future:Ljava/util/concurrent/Future;

    .line 259
    return-void
.end method

.method public static FetchRequest(Ljava/lang/String;Ljava/util/Map;)V
    .locals 2
    .param p0, "videoID"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 265
    .local p1, "fetchHeaders":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;"
    sget-object v0, LuTools/uStreamSpoofing/uStreamingDataRequest;->Cache:Ljava/util/Map;

    new-instance v1, LuTools/uStreamSpoofing/uStreamingDataRequest;

    invoke-direct {v1, p0, p1}, LuTools/uStreamSpoofing/uStreamingDataRequest;-><init>(Ljava/lang/String;Ljava/util/Map;)V

    invoke-interface {v0, p0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 266
    return-void
.end method

.method private static GetClassName()Ljava/lang/String;
    .locals 1

    .line 269
    const-class v0, LuTools/uStreamSpoofing/uStreamingDataRequest;

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public static GetRequestForVideoID(Ljava/lang/String;)LuTools/uStreamSpoofing/uStreamingDataRequest;
    .locals 1
    .param p0, "videoID"    # Ljava/lang/String;

    .line 274
    sget-object v0, LuTools/uStreamSpoofing/uStreamingDataRequest;->Cache:Ljava/util/Map;

    invoke-interface {v0, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LuTools/uStreamSpoofing/uStreamingDataRequest;

    return-object v0
.end method

.method public static InjectSaveVideoToWatchLaterButton(Landroid/view/View;)V
    .locals 4
    .param p0, "sourceButton"    # Landroid/view/View;

    .line 362
    if-eqz p0, :cond_0

    .line 364
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    instance-of v1, v0, Landroid/view/ViewGroup;

    if-eqz v1, :cond_0

    check-cast v0, Landroid/view/ViewGroup;

    .line 366
    .local v0, "sourceButtonGroupParent":Landroid/view/ViewGroup;
    new-instance v1, Landroid/widget/ImageView;

    invoke-static {}, LuTools/uUtils;->GetAppContext()Landroid/content/Context;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    .line 367
    .local v1, "saveButton":Landroid/widget/ImageView;
    invoke-static {}, Landroid/view/View;->generateViewId()I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setId(I)V

    .line 368
    sget-object v2, Landroid/widget/ImageView$ScaleType;->CENTER_INSIDE:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    .line 369
    const-string v2, "utube_bookmark_icon"

    invoke-static {v2}, LuTools/uUtils;->GetDrawableInt(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 370
    invoke-virtual {p0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v2

    new-instance v3, LuTools/uStreamSpoofing/uStreamingDataRequest$3;

    invoke-direct {v3, p0, v1}, LuTools/uStreamSpoofing/uStreamingDataRequest$3;-><init>(Landroid/view/View;Landroid/widget/ImageView;)V

    invoke-virtual {v2, v3}, Landroid/view/ViewTreeObserver;->addOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    .line 440
    new-instance v2, LuTools/uStreamSpoofing/uStreamingDataRequest$4;

    invoke-direct {v2}, LuTools/uStreamSpoofing/uStreamingDataRequest$4;-><init>()V

    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 492
    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 494
    .end local v0    # "sourceButtonGroupParent":Landroid/view/ViewGroup;
    .end local v1    # "saveButton":Landroid/widget/ImageView;
    :cond_0
    return-void
.end method

.method public static OpenVideoChannel(Ljava/lang/String;)Z
    .locals 7
    .param p0, "videoID"    # Ljava/lang/String;

    .line 504
    sget-boolean v0, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoChannelOpeningAlreadyInQueue:Z

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    .line 505
    return v1

    .line 508
    :cond_0
    invoke-static {}, LuTools/uUtils;->GetCommentsPanelOpen()Z

    move-result v0

    const/4 v2, 0x0

    if-nez v0, :cond_1

    invoke-static {}, LuTools/uUtils;->GetLithoActionDownDuration()J

    move-result-wide v3

    const-wide/16 v5, 0x3e8

    cmp-long v0, v3, v5

    if-ltz v0, :cond_1

    .line 509
    sput-boolean v1, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoChannelOpeningAlreadyInQueue:Z

    .line 511
    sget-object v0, LuTools/uStreamSpoofing/uStreamingDataRequest;->openVideoChannelToastInProgress:LuTools/uUtils$MakeToast;

    invoke-virtual {v0}, LuTools/uUtils$MakeToast;->ShowToast()V

    .line 513
    const-string v0, ""

    .line 515
    .local v0, "channelID":Ljava/lang/String;
    :try_start_0
    new-instance v3, LuTools/VideoDetails/uVideoDetailsRequest;

    const-string v4, "channelID"

    const/4 v5, 0x0

    invoke-direct {v3, p0, v5, v4}, LuTools/VideoDetails/uVideoDetailsRequest;-><init>(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)V

    .line 522
    invoke-virtual {v3}, LuTools/VideoDetails/uVideoDetailsRequest;->GetRequestedInfo()Ljava/lang/Object;

    move-result-object v3

    .line 524
    .local v3, "channelIDRequest":Ljava/lang/Object;
    move-object v4, v3

    check-cast v4, Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-object v0, v4

    .line 535
    .end local v3    # "channelIDRequest":Ljava/lang/Object;
    goto :goto_0

    .line 525
    :catch_0
    move-exception v3

    .line 527
    .local v3, "e":Ljava/lang/Exception;
    invoke-static {}, LuTools/uStreamSpoofing/uStreamingDataRequest;->GetClassName()Ljava/lang/String;

    move-result-object v4

    .line 529
    invoke-virtual {v3}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v5

    .line 526
    invoke-static {v4, v5}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 532
    sget-object v4, LuTools/uStreamSpoofing/uStreamingDataRequest;->openVideoChannelToastError:LuTools/uUtils$MakeToast;

    invoke-virtual {v4}, LuTools/uUtils$MakeToast;->ShowToast()V

    .line 534
    sput-boolean v2, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoChannelOpeningAlreadyInQueue:Z

    .line 537
    .end local v3    # "e":Ljava/lang/Exception;
    :goto_0
    invoke-static {}, LuTools/uUtils;->GetMainActivity()Landroid/app/Activity;

    move-result-object v3

    .line 539
    .local v3, "context":Landroid/content/Context;
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_1

    if-eqz v3, :cond_1

    .line 540
    new-instance v4, Landroid/content/Intent;

    filled-new-array {v0}, [Ljava/lang/Object;

    move-result-object v5

    .line 544
    const-string v6, "https://www.youtube.com/channel/%s"

    invoke-static {v6, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    .line 543
    invoke-static {v5}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v5

    const-string v6, "android.intent.action.VIEW"

    invoke-direct {v4, v6, v5}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 551
    .local v4, "openLiveChannelIntent":Landroid/content/Intent;
    const/high16 v5, 0x10000000

    invoke-virtual {v4, v5}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 552
    invoke-virtual {v3}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 554
    invoke-virtual {v3, v4}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 556
    sget-object v5, LuTools/uStreamSpoofing/uStreamingDataRequest;->openVideoChannelToastInProgress:LuTools/uUtils$MakeToast;

    invoke-virtual {v5}, LuTools/uUtils$MakeToast;->HideToast()V

    .line 557
    sget-object v5, LuTools/uStreamSpoofing/uStreamingDataRequest;->openVideoChannelToastDone:LuTools/uUtils$MakeToast;

    invoke-virtual {v5}, LuTools/uUtils$MakeToast;->ShowToast()V

    .line 559
    sput-boolean v2, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoChannelOpeningAlreadyInQueue:Z

    .line 561
    return v1

    .line 565
    .end local v0    # "channelID":Ljava/lang/String;
    .end local v3    # "context":Landroid/content/Context;
    .end local v4    # "openLiveChannelIntent":Landroid/content/Intent;
    :cond_1
    return v2
.end method

.method private VideoReload()V
    .locals 2

    .line 306
    iget-boolean v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoReloadHandlerAlreadyInQueue:Z

    if-eqz v0, :cond_0

    .line 307
    return-void

    .line 309
    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoReloadHandlerAlreadyInQueue:Z

    .line 311
    sget-object v0, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoIDPlaying:Ljava/lang/String;

    sput-object v0, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoIDToReload:Ljava/lang/String;

    .line 313
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 314
    .local v0, "videoReloadHandler":Landroid/os/Handler;
    new-instance v1, LuTools/uStreamSpoofing/uStreamingDataRequest$2;

    invoke-direct {v1, p0, v0}, LuTools/uStreamSpoofing/uStreamingDataRequest$2;-><init>(LuTools/uStreamSpoofing/uStreamingDataRequest;Landroid/os/Handler;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 359
    return-void
.end method

.method private synthetic lambda$new$0(Ljava/util/Map;Ljava/lang/String;)Ljava/nio/ByteBuffer;
    .locals 12
    .param p1, "playerHeaders"    # Ljava/util/Map;
    .param p2, "videoID"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 140
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->CLIENT_TYPES_ORDER_TO_USE:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_7

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LuTools/uStreamSpoofing/uClientType;

    .line 141
    .local v1, "clientType":LuTools/uStreamSpoofing/uClientType;
    const/4 v2, 0x0

    iput-boolean v2, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoRequireLogin:Z

    .line 143
    const/4 v3, 0x0

    .local v3, "i":I
    :goto_1
    const/4 v4, 0x2

    if-ge v3, v4, :cond_6

    .line 144
    iget-boolean v4, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoRequireLogin:Z

    if-eqz v4, :cond_0

    iget-boolean v4, v1, LuTools/uStreamSpoofing/uClientType;->useAuth:Z

    if-nez v4, :cond_0

    .line 145
    goto/16 :goto_7

    .line 148
    :cond_0
    new-instance v4, LuTools/uStreamSpoofing/uRoute;

    sget-object v5, LuTools/uStreamSpoofing/uRoute$Method;->POST:LuTools/uStreamSpoofing/uRoute$Method;

    const-string v6, "player?fields=streamingData&alt=proto"

    invoke-direct {v4, v5, v6}, LuTools/uStreamSpoofing/uRoute;-><init>(LuTools/uStreamSpoofing/uRoute$Method;Ljava/lang/String;)V

    new-array v5, v2, [Ljava/lang/String;

    .line 153
    invoke-virtual {v4, v5}, LuTools/uStreamSpoofing/uRoute;->Compile([Ljava/lang/String;)LuTools/uStreamSpoofing/uRoute$CompiledRoute;

    move-result-object v4

    iget-object v5, v1, LuTools/uStreamSpoofing/uClientType;->userAgent:Ljava/lang/String;

    iget v6, v1, LuTools/uStreamSpoofing/uClientType;->clientID:I

    .line 158
    invoke-static {v6}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v6

    iget-object v7, v1, LuTools/uStreamSpoofing/uClientType;->clientVersion:Ljava/lang/String;

    filled-new-array {v5, v6, v7}, [Ljava/lang/Object;

    move-result-object v5

    .line 155
    invoke-static {v5}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v5

    .line 148
    invoke-static {v4, v5}, LuTools/uStreamSpoofing/uPlayerRoutes;->GetPlayerResponseConnectionFromRoute(LuTools/uStreamSpoofing/uRoute$CompiledRoute;Ljava/util/List;)Ljava/net/HttpURLConnection;

    move-result-object v4

    .line 164
    .local v4, "connection":Ljava/net/HttpURLConnection;
    if-eqz v4, :cond_5

    .line 165
    sget-object v5, LuTools/uStreamSpoofing/uPlayerRoutes;->requestKeys:Ljava/util/List;

    invoke-interface {v5}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_2
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_2

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    .line 166
    .local v6, "requestKey":Ljava/lang/String;
    sget-object v7, LuTools/uStreamSpoofing/uPlayerRoutes;->requestKeys:Ljava/util/List;

    invoke-interface {v7, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_1

    iget-boolean v7, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoRequireLogin:Z

    if-nez v7, :cond_1

    .line 167
    goto :goto_2

    .line 170
    :cond_1
    invoke-interface {p1, v6}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    invoke-virtual {v4, v6, v7}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 171
    .end local v6    # "requestKey":Ljava/lang/String;
    goto :goto_2

    .line 173
    :cond_2
    new-instance v5, LuTools/uStreamSpoofing/uStreamingDataRequest$1;

    invoke-direct {v5, p0, v1, p2}, LuTools/uStreamSpoofing/uStreamingDataRequest$1;-><init>(LuTools/uStreamSpoofing/uStreamingDataRequest;LuTools/uStreamSpoofing/uClientType;Ljava/lang/String;)V

    .line 202
    invoke-virtual {v5}, LuTools/uStreamSpoofing/uStreamingDataRequest$1;->toString()Ljava/lang/String;

    move-result-object v5

    sget-object v6, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    .line 203
    invoke-virtual {v5, v6}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v5

    iput-object v5, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->requestBody:[B

    .line 205
    iget-object v5, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->requestBody:[B

    array-length v5, v5

    invoke-virtual {v4, v5}, Ljava/net/HttpURLConnection;->setFixedLengthStreamingMode(I)V

    .line 206
    invoke-virtual {v4}, Ljava/net/HttpURLConnection;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v5

    iget-object v6, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->requestBody:[B

    invoke-virtual {v5, v6}, Ljava/io/OutputStream;->write([B)V

    .line 208
    invoke-virtual {v4}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v5

    const/16 v6, 0xc8

    if-ne v5, v6, :cond_5

    .line 209
    invoke-virtual {v4}, Ljava/net/HttpURLConnection;->getContentLength()I

    move-result v5

    if-eqz v5, :cond_5

    .line 211
    :try_start_0
    new-instance v5, Ljava/io/BufferedInputStream;

    invoke-virtual {v4}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v6

    invoke-direct {v5, v6}, Ljava/io/BufferedInputStream;-><init>(Ljava/io/InputStream;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 212
    .local v5, "inputStream":Ljava/io/InputStream;
    :try_start_1
    new-instance v6, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v6}, Ljava/io/ByteArrayOutputStream;-><init>()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    .line 214
    .local v6, "bAOS":Ljava/io/ByteArrayOutputStream;
    const/16 v7, 0x800

    :try_start_2
    new-array v7, v7, [B

    .line 217
    .local v7, "buffer":[B
    :goto_3
    invoke-virtual {v5, v7}, Ljava/io/InputStream;->read([B)I

    move-result v8

    move v9, v8

    .local v9, "bytesRead":I
    if-ltz v8, :cond_3

    .line 218
    invoke-virtual {v6, v7, v2, v9}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    goto :goto_3

    .line 221
    :cond_3
    const-string v8, " (%s - %s)"

    .line 225
    invoke-virtual {v1}, LuTools/uStreamSpoofing/uClientType;->name()Ljava/lang/String;

    move-result-object v10

    .line 226
    iget-boolean v11, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoRequireLogin:Z

    if-nez v11, :cond_4

    const-string v11, "NO_AUTH"

    goto :goto_4

    :cond_4
    const-string v11, "WITH_AUTH"

    :goto_4
    filled-new-array {v10, v11}, [Ljava/lang/Object;

    move-result-object v10

    .line 222
    invoke-static {v8, v10}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v8

    iput-object v8, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->currentClientName:Ljava/lang/String;

    .line 229
    iget-object v8, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->currentClientName:Ljava/lang/String;

    invoke-static {v8}, LuTools/uUtils;->SetStatsForNerdsClientName(Ljava/lang/String;)V

    .line 230
    invoke-static {}, LuTools/uStreamSpoofing/uStreamingDataRequest;->GetClassName()Ljava/lang/String;

    move-result-object v8

    iget-object v10, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->currentClientName:Ljava/lang/String;

    invoke-static {v8, v10}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 232
    sput-object p2, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoIDPlaying:Ljava/lang/String;

    .line 233
    sput-object p1, LuTools/uStreamSpoofing/uStreamingDataRequest;->playerHeadersPlaying:Ljava/util/Map;

    .line 235
    invoke-direct {p0}, LuTools/uStreamSpoofing/uStreamingDataRequest;->VideoReload()V

    .line 237
    invoke-virtual {v6}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v8

    invoke-static {v8}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object v8
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 238
    :try_start_3
    invoke-virtual {v6}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    :try_start_4
    invoke-virtual {v5}, Ljava/io/InputStream;->close()V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0

    .line 237
    return-object v8

    .line 210
    .end local v7    # "buffer":[B
    .end local v9    # "bytesRead":I
    :catchall_0
    move-exception v7

    :try_start_5
    invoke-virtual {v6}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    goto :goto_5

    :catchall_1
    move-exception v8

    :try_start_6
    invoke-virtual {v7, v8}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .end local v1    # "clientType":LuTools/uStreamSpoofing/uClientType;
    .end local v3    # "i":I
    .end local v4    # "connection":Ljava/net/HttpURLConnection;
    .end local v5    # "inputStream":Ljava/io/InputStream;
    .end local p0    # "this":LuTools/uStreamSpoofing/uStreamingDataRequest;
    .end local p1    # "playerHeaders":Ljava/util/Map;
    .end local p2    # "videoID":Ljava/lang/String;
    :goto_5
    throw v7
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    .end local v6    # "bAOS":Ljava/io/ByteArrayOutputStream;
    .restart local v1    # "clientType":LuTools/uStreamSpoofing/uClientType;
    .restart local v3    # "i":I
    .restart local v4    # "connection":Ljava/net/HttpURLConnection;
    .restart local v5    # "inputStream":Ljava/io/InputStream;
    .restart local p0    # "this":LuTools/uStreamSpoofing/uStreamingDataRequest;
    .restart local p1    # "playerHeaders":Ljava/util/Map;
    .restart local p2    # "videoID":Ljava/lang/String;
    :catchall_2
    move-exception v6

    :try_start_7
    invoke-virtual {v5}, Ljava/io/InputStream;->close()V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_3

    goto :goto_6

    :catchall_3
    move-exception v7

    :try_start_8
    invoke-virtual {v6, v7}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .end local v1    # "clientType":LuTools/uStreamSpoofing/uClientType;
    .end local v3    # "i":I
    .end local v4    # "connection":Ljava/net/HttpURLConnection;
    .end local p0    # "this":LuTools/uStreamSpoofing/uStreamingDataRequest;
    .end local p1    # "playerHeaders":Ljava/util/Map;
    .end local p2    # "videoID":Ljava/lang/String;
    :goto_6
    throw v6
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_0

    .line 238
    .end local v5    # "inputStream":Ljava/io/InputStream;
    .restart local v1    # "clientType":LuTools/uStreamSpoofing/uClientType;
    .restart local v3    # "i":I
    .restart local v4    # "connection":Ljava/net/HttpURLConnection;
    .restart local p0    # "this":LuTools/uStreamSpoofing/uStreamingDataRequest;
    .restart local p1    # "playerHeaders":Ljava/util/Map;
    .restart local p2    # "videoID":Ljava/lang/String;
    :catch_0
    move-exception v5

    .line 240
    .local v5, "e":Ljava/lang/Exception;
    invoke-static {}, LuTools/uStreamSpoofing/uStreamingDataRequest;->GetClassName()Ljava/lang/String;

    move-result-object v6

    .line 242
    invoke-virtual {v5}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v7

    .line 239
    invoke-static {v6, v7}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 248
    .end local v5    # "e":Ljava/lang/Exception;
    :cond_5
    iget-boolean v5, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoRequireLogin:Z

    xor-int/lit8 v5, v5, 0x1

    iput-boolean v5, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoRequireLogin:Z

    .line 143
    .end local v4    # "connection":Ljava/net/HttpURLConnection;
    :goto_7
    add-int/lit8 v3, v3, 0x1

    goto/16 :goto_1

    .line 250
    .end local v1    # "clientType":LuTools/uStreamSpoofing/uClientType;
    .end local v3    # "i":I
    :cond_6
    goto/16 :goto_0

    .line 252
    :cond_7
    const-string v0, "Original"

    iput-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->currentClientName:Ljava/lang/String;

    .line 253
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->currentClientName:Ljava/lang/String;

    filled-new-array {v0}, [Ljava/lang/Object;

    move-result-object v0

    const-string v1, " (%s)"

    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, LuTools/uUtils;->SetStatsForNerdsClientName(Ljava/lang/String;)V

    .line 254
    invoke-static {}, LuTools/uStreamSpoofing/uStreamingDataRequest;->GetClassName()Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->currentClientName:Ljava/lang/String;

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 256
    const/4 v0, 0x0

    return-object v0
.end method


# virtual methods
.method public GetStream()Ljava/nio/ByteBuffer;
    .locals 4

    .line 280
    :try_start_0
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->future:Ljava/util/concurrent/Future;

    sget-object v1, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v2, 0x2710

    invoke-interface {v0, v2, v3, v1}, Ljava/util/concurrent/Future;->get(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/nio/ByteBuffer;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    .line 281
    :catch_0
    move-exception v0

    .line 283
    .local v0, "e":Ljava/lang/Exception;
    invoke-static {}, LuTools/uStreamSpoofing/uStreamingDataRequest;->GetClassName()Ljava/lang/String;

    move-result-object v1

    .line 285
    invoke-virtual {v0}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v2

    .line 282
    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 289
    .end local v0    # "e":Ljava/lang/Exception;
    const/4 v0, 0x0

    return-object v0
.end method
