.class public LuTools/uStreamSpoofing/uStreamingDataRequest;
.super Ljava/lang/Object;
.source "uStreamingDataRequest.java"


# static fields
.field private static final Cache:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "LuTools/uStreamSpoofing/uStreamingDataRequest;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final CLIENT_TYPES_ORDER_TO_USE:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LuTools/uStreamSpoofing/uClientType;",
            ">;"
        }
    .end annotation
.end field

.field private final READ_BUFFER_SIZE:I

.field private defaultAudioTrackLocale:Ljava/util/Locale;

.field private final defaultAudioTrackLocales:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/util/Locale;",
            ">;"
        }
    .end annotation
.end field

.field private final future:Ljava/util/concurrent/Future;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/Future<",
            "Ljava/nio/ByteBuffer;",
            ">;"
        }
    .end annotation
.end field

.field private final videoID:Ljava/lang/String;


# direct methods
.method public static synthetic $r8$lambda$w9MmyL03FTq0ITUxar6F-eeCNGs(LuTools/uStreamSpoofing/uStreamingDataRequest;Ljava/util/Map;Ljava/lang/String;)Ljava/nio/ByteBuffer;
    .locals 0

    invoke-direct {p0, p1, p2}, LuTools/uStreamSpoofing/uStreamingDataRequest;->lambda$new$0(Ljava/util/Map;Ljava/lang/String;)Ljava/nio/ByteBuffer;

    move-result-object p0

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetdefaultAudioTrackLocale(LuTools/uStreamSpoofing/uStreamingDataRequest;)Ljava/util/Locale;
    .locals 0

    iget-object p0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->defaultAudioTrackLocale:Ljava/util/Locale;

    return-object p0
.end method

.method static constructor <clinit>()V
    .locals 1

    .line 203
    invoke-static {}, LuTools/uUtils;->InitializeStreamCache()Ljava/util/LinkedHashMap;

    move-result-object v0

    invoke-static {v0}, Ljava/util/Collections;->synchronizedMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object v0

    sput-object v0, LuTools/uStreamSpoofing/uStreamingDataRequest;->Cache:Ljava/util/Map;

    .line 202
    return-void
.end method

.method private constructor <init>(Ljava/lang/String;Ljava/util/Map;)V
    .locals 4
    .param p1, "videoID"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 54
    .local p2, "playerHeaders":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;"
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 43
    new-instance v0, Ljava/util/ArrayList;

    const/4 v1, 0x3

    new-array v1, v1, [LuTools/uStreamSpoofing/uClientType;

    const/4 v2, 0x0

    sget-object v3, LuTools/uStreamSpoofing/uClientType;->ANDROID_VR:LuTools/uStreamSpoofing/uClientType;

    aput-object v3, v1, v2

    const/4 v2, 0x1

    sget-object v3, LuTools/uStreamSpoofing/uClientType;->ANDROID_UNPLUGGED:LuTools/uStreamSpoofing/uClientType;

    aput-object v3, v1, v2

    const/4 v2, 0x2

    sget-object v3, LuTools/uStreamSpoofing/uClientType;->ANDROID_CREATOR:LuTools/uStreamSpoofing/uClientType;

    aput-object v3, v1, v2

    .line 45
    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    iput-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->CLIENT_TYPES_ORDER_TO_USE:Ljava/util/List;

    .line 51
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->defaultAudioTrackLocales:Ljava/util/List;

    .line 53
    const/16 v0, 0x2000

    iput v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->READ_BUFFER_SIZE:I

    .line 55
    invoke-static {p2}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 57
    iput-object p1, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoID:Ljava/lang/String;

    .line 58
    sget-object v0, LuTools/uUtils;->BackgroundThreadPool:Ljava/util/concurrent/ThreadPoolExecutor;

    new-instance v1, LuTools/uStreamSpoofing/uStreamingDataRequest$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0, p2, p1}, LuTools/uStreamSpoofing/uStreamingDataRequest$$ExternalSyntheticLambda0;-><init>(LuTools/uStreamSpoofing/uStreamingDataRequest;Ljava/util/Map;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Ljava/util/concurrent/ThreadPoolExecutor;->submit(Ljava/util/concurrent/Callable;)Ljava/util/concurrent/Future;

    move-result-object v0

    iput-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->future:Ljava/util/concurrent/Future;

    .line 200
    return-void
.end method

.method public static FetchRequest(Ljava/lang/String;Ljava/util/Map;)V
    .locals 2
    .param p0, "videoID"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 206
    .local p1, "fetchHeaders":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;"
    sget-object v0, LuTools/uStreamSpoofing/uStreamingDataRequest;->Cache:Ljava/util/Map;

    new-instance v1, LuTools/uStreamSpoofing/uStreamingDataRequest;

    invoke-direct {v1, p0, p1}, LuTools/uStreamSpoofing/uStreamingDataRequest;-><init>(Ljava/lang/String;Ljava/util/Map;)V

    invoke-interface {v0, p0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 207
    return-void
.end method

.method public static GetRequestForVideoID(Ljava/lang/String;)LuTools/uStreamSpoofing/uStreamingDataRequest;
    .locals 1
    .param p0, "videoID"    # Ljava/lang/String;

    .line 211
    sget-object v0, LuTools/uStreamSpoofing/uStreamingDataRequest;->Cache:Ljava/util/Map;

    invoke-interface {v0, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LuTools/uStreamSpoofing/uStreamingDataRequest;

    return-object v0
.end method

.method private synthetic lambda$new$0(Ljava/util/Map;Ljava/lang/String;)Ljava/nio/ByteBuffer;
    .locals 22
    .param p1, "playerHeaders"    # Ljava/util/Map;
    .param p2, "videoID"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 60
    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    iget-object v0, v1, LuTools/uStreamSpoofing/uStreamingDataRequest;->CLIENT_TYPES_ORDER_TO_USE:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_0
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const-string v6, "uStreamingDataRequest"

    if-eqz v0, :cond_8

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    move-object v7, v0

    check-cast v7, LuTools/uStreamSpoofing/uClientType;

    .line 61
    .local v7, "clientType":LuTools/uStreamSpoofing/uClientType;
    const/4 v0, 0x0

    .line 63
    .local v0, "videoRequireLogin":Z
    const/4 v8, 0x0

    move v9, v8

    move v8, v0

    .end local v0    # "videoRequireLogin":Z
    .local v8, "videoRequireLogin":Z
    .local v9, "i":I
    :goto_1
    const/4 v10, 0x2

    if-ge v9, v10, :cond_7

    .line 64
    const/4 v0, 0x0

    .line 66
    .local v0, "videoRequireSimplifiedLocale":Z
    const/4 v11, 0x0

    move v12, v11

    move v11, v0

    .end local v0    # "videoRequireSimplifiedLocale":Z
    .local v11, "videoRequireSimplifiedLocale":Z
    .local v12, "j":I
    :goto_2
    if-ge v12, v10, :cond_6

    .line 67
    new-instance v0, LuTools/uStreamSpoofing/uRoute;

    sget-object v13, LuTools/uStreamSpoofing/uRoute$Method;->POST:LuTools/uStreamSpoofing/uRoute$Method;

    const-string v14, "player?fields=streamingData&alt=proto"

    invoke-direct {v0, v13, v14}, LuTools/uStreamSpoofing/uRoute;-><init>(LuTools/uStreamSpoofing/uRoute$Method;Ljava/lang/String;)V

    const/4 v13, 0x0

    new-array v14, v13, [Ljava/lang/String;

    .line 72
    invoke-virtual {v0, v14}, LuTools/uStreamSpoofing/uRoute;->Compile([Ljava/lang/String;)LuTools/uStreamSpoofing/uRoute$CompiledRoute;

    move-result-object v0

    iget-object v14, v7, LuTools/uStreamSpoofing/uClientType;->userAgent:Ljava/lang/String;

    iget v15, v7, LuTools/uStreamSpoofing/uClientType;->clientID:I

    .line 76
    invoke-static {v15}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v15

    iget-object v10, v7, LuTools/uStreamSpoofing/uClientType;->clientVersion:Ljava/lang/String;

    filled-new-array {v14, v15, v10}, [Ljava/lang/Object;

    move-result-object v10

    .line 74
    invoke-static {v10}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v10

    .line 67
    invoke-static {v0, v10}, LuTools/uStreamSpoofing/uPlayerRoutes;->GetPlayerResponseConnectionFromRoute(LuTools/uStreamSpoofing/uRoute$CompiledRoute;Ljava/util/List;)Ljava/net/HttpURLConnection;

    move-result-object v10

    .line 81
    .local v10, "connection":Ljava/net/HttpURLConnection;
    if-eqz v10, :cond_5

    .line 82
    sget-object v0, LuTools/uStreamSpoofing/uPlayerRoutes;->requestKeys:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_3
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v14

    if-eqz v14, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Ljava/lang/String;

    .line 83
    .local v14, "requestKey":Ljava/lang/String;
    sget-object v15, LuTools/uStreamSpoofing/uPlayerRoutes;->requestKeys:Ljava/util/List;

    invoke-interface {v15, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v15

    invoke-virtual {v14, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v15

    if-eqz v15, :cond_0

    if-nez v8, :cond_0

    .line 84
    goto :goto_3

    .line 87
    :cond_0
    invoke-interface {v2, v14}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Ljava/lang/String;

    invoke-virtual {v10, v14, v15}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 88
    .end local v14    # "requestKey":Ljava/lang/String;
    goto :goto_3

    .line 90
    :cond_1
    new-instance v0, LuTools/VideoDetails/uVideoDetailsRequest;

    const-string v14, "defaultAudioTrackID"

    invoke-direct {v0, v3, v2, v14}, LuTools/VideoDetails/uVideoDetailsRequest;-><init>(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)V

    move-object v14, v0

    .line 92
    .local v14, "defaultAudioTrackRequest":LuTools/VideoDetails/uVideoDetailsRequest;
    invoke-virtual {v14}, LuTools/VideoDetails/uVideoDetailsRequest;->GetRequestedInfo()Ljava/lang/String;

    move-result-object v15

    .line 95
    .local v15, "defaultAudioTrackName":Ljava/lang/String;
    :try_start_0
    const-string v0, "-"

    invoke-virtual {v15, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_2

    .line 97
    .local v0, "splitDefaultAudioTrackName":[Ljava/lang/String;
    const/16 v18, 0x1

    :try_start_1
    iget-object v5, v1, LuTools/uStreamSpoofing/uStreamingDataRequest;->defaultAudioTrackLocales:Ljava/util/List;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    move/from16 v19, v13

    :try_start_2
    new-instance v13, Ljava/util/Locale;

    move-object/from16 v20, v0

    .end local v0    # "splitDefaultAudioTrackName":[Ljava/lang/String;
    .local v20, "splitDefaultAudioTrackName":[Ljava/lang/String;
    aget-object v0, v20, v19

    aget-object v21, v20, v18

    .line 101
    invoke-virtual/range {v21 .. v21}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v13, v0, v2}, Ljava/util/Locale;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 97
    invoke-interface {v5, v13}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    .line 112
    nop

    .end local v20    # "splitDefaultAudioTrackName":[Ljava/lang/String;
    goto :goto_5

    .line 104
    :catch_0
    move-exception v0

    goto :goto_4

    :catch_1
    move-exception v0

    move/from16 v19, v13

    goto :goto_4

    :catch_2
    move-exception v0

    move/from16 v19, v13

    const/16 v18, 0x1

    .line 105
    .local v0, "ignore":Ljava/lang/Exception;
    :goto_4
    iget-object v2, v1, LuTools/uStreamSpoofing/uStreamingDataRequest;->defaultAudioTrackLocales:Ljava/util/List;

    new-instance v5, Ljava/util/Locale;

    .line 109
    invoke-virtual {v15}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object v13

    invoke-direct {v5, v15, v13}, Ljava/util/Locale;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 105
    invoke-interface {v2, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 113
    .end local v0    # "ignore":Ljava/lang/Exception;
    :goto_5
    iget-object v0, v1, LuTools/uStreamSpoofing/uStreamingDataRequest;->defaultAudioTrackLocales:Ljava/util/List;

    new-instance v2, Ljava/util/Locale;

    invoke-direct {v2, v15}, Ljava/util/Locale;-><init>(Ljava/lang/String;)V

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 115
    if-nez v8, :cond_3

    .line 116
    if-nez v11, :cond_2

    .line 117
    iget-object v0, v1, LuTools/uStreamSpoofing/uStreamingDataRequest;->defaultAudioTrackLocales:Ljava/util/List;

    move/from16 v2, v19

    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Locale;

    iput-object v0, v1, LuTools/uStreamSpoofing/uStreamingDataRequest;->defaultAudioTrackLocale:Ljava/util/Locale;

    goto :goto_6

    .line 119
    :cond_2
    iget-object v0, v1, LuTools/uStreamSpoofing/uStreamingDataRequest;->defaultAudioTrackLocales:Ljava/util/List;

    move/from16 v2, v18

    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Locale;

    iput-object v0, v1, LuTools/uStreamSpoofing/uStreamingDataRequest;->defaultAudioTrackLocale:Ljava/util/Locale;

    .line 123
    :cond_3
    :goto_6
    iget-object v0, v1, LuTools/uStreamSpoofing/uStreamingDataRequest;->defaultAudioTrackLocales:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 125
    new-instance v0, LuTools/uStreamSpoofing/uStreamingDataRequest$1;

    invoke-direct {v0, v1, v7, v3}, LuTools/uStreamSpoofing/uStreamingDataRequest$1;-><init>(LuTools/uStreamSpoofing/uStreamingDataRequest;LuTools/uStreamSpoofing/uClientType;Ljava/lang/String;)V

    move-object v2, v0

    .line 153
    .local v2, "innerTubeBody":Lorg/json/JSONObject;
    const/4 v5, 0x0

    iput-object v5, v1, LuTools/uStreamSpoofing/uStreamingDataRequest;->defaultAudioTrackLocale:Ljava/util/Locale;

    .line 155
    invoke-virtual {v2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0

    sget-object v5, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {v0, v5}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v5

    .line 157
    .local v5, "requestBody":[B
    array-length v0, v5

    invoke-virtual {v10, v0}, Ljava/net/HttpURLConnection;->setFixedLengthStreamingMode(I)V

    .line 158
    invoke-virtual {v10}, Ljava/net/HttpURLConnection;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v0

    invoke-virtual {v0, v5}, Ljava/io/OutputStream;->write([B)V

    .line 160
    invoke-virtual {v10}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v0

    const/16 v13, 0xc8

    if-ne v0, v13, :cond_5

    .line 161
    invoke-virtual {v10}, Ljava/net/HttpURLConnection;->getContentLength()I

    move-result v13

    .line 163
    .local v13, "contentLength":I
    if-eqz v13, :cond_5

    .line 164
    new-instance v0, Ljava/io/BufferedInputStream;

    invoke-virtual {v10}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v4

    invoke-direct {v0, v4}, Ljava/io/BufferedInputStream;-><init>(Ljava/io/InputStream;)V

    move-object v4, v0

    .line 165
    .local v4, "inputStream":Ljava/io/InputStream;
    :try_start_3
    new-instance v0, Ljava/io/ByteArrayOutputStream;

    const/16 v1, 0x2000

    invoke-static {v13, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    invoke-direct {v0, v1}, Ljava/io/ByteArrayOutputStream;-><init>(I)V

    .line 167
    .local v0, "baos":Ljava/io/ByteArrayOutputStream;
    invoke-virtual {v4, v0}, Ljava/io/InputStream;->transferTo(Ljava/io/OutputStream;)J

    .line 169
    invoke-virtual {v7}, LuTools/uStreamSpoofing/uClientType;->name()Ljava/lang/String;

    move-result-object v1

    invoke-static {v6, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 171
    const-string v1, " (%s - %s)"

    .line 175
    invoke-virtual {v7}, LuTools/uStreamSpoofing/uClientType;->name()Ljava/lang/String;

    move-result-object v6

    .line 176
    if-nez v8, :cond_4

    const-string v16, "NO_AUTH"

    goto :goto_7

    :cond_4
    const-string v16, "WITH_AUTH"

    :goto_7
    move-object/from16 v17, v0

    move-object/from16 v0, v16

    .end local v0    # "baos":Ljava/io/ByteArrayOutputStream;
    .local v17, "baos":Ljava/io/ByteArrayOutputStream;
    filled-new-array {v6, v0}, [Ljava/lang/Object;

    move-result-object v0

    .line 172
    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    .line 171
    invoke-static {v0}, LuTools/uUtils;->SetStatsForNerdsClientName(Ljava/lang/String;)V

    .line 180
    invoke-virtual/range {v17 .. v17}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v0

    invoke-static {v0}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object v0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 181
    invoke-virtual {v4}, Ljava/io/InputStream;->close()V

    .line 180
    return-object v0

    .line 164
    .end local v17    # "baos":Ljava/io/ByteArrayOutputStream;
    :catchall_0
    move-exception v0

    move-object v1, v0

    :try_start_4
    invoke-virtual {v4}, Ljava/io/InputStream;->close()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    goto :goto_8

    :catchall_1
    move-exception v0

    invoke-virtual {v1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_8
    throw v1

    .line 186
    .end local v2    # "innerTubeBody":Lorg/json/JSONObject;
    .end local v4    # "inputStream":Ljava/io/InputStream;
    .end local v5    # "requestBody":[B
    .end local v13    # "contentLength":I
    .end local v14    # "defaultAudioTrackRequest":LuTools/VideoDetails/uVideoDetailsRequest;
    .end local v15    # "defaultAudioTrackName":Ljava/lang/String;
    :cond_5
    const/4 v11, 0x1

    .line 66
    .end local v10    # "connection":Ljava/net/HttpURLConnection;
    add-int/lit8 v12, v12, 0x1

    const/4 v10, 0x2

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    goto/16 :goto_2

    .line 189
    .end local v12    # "j":I
    :cond_6
    const/4 v8, 0x1

    .line 63
    .end local v11    # "videoRequireSimplifiedLocale":Z
    add-int/lit8 v9, v9, 0x1

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    goto/16 :goto_1

    .line 191
    .end local v7    # "clientType":LuTools/uStreamSpoofing/uClientType;
    .end local v8    # "videoRequireLogin":Z
    .end local v9    # "i":I
    :cond_7
    move-object/from16 v1, p0

    move-object/from16 v2, p1

    goto/16 :goto_0

    .line 193
    :cond_8
    const-string v0, "null"

    invoke-static {v6, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 195
    const-string v0, " (Unknown)"

    invoke-static {v0}, LuTools/uUtils;->SetStatsForNerdsClientName(Ljava/lang/String;)V

    .line 197
    const/16 v17, 0x0

    return-object v17
.end method


# virtual methods
.method public GetStream()Ljava/nio/ByteBuffer;
    .locals 4

    .line 217
    :try_start_0
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->future:Ljava/util/concurrent/Future;

    sget-object v1, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v2, 0x4e20

    invoke-interface {v0, v2, v3, v1}, Ljava/util/concurrent/Future;->get(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/nio/ByteBuffer;
    :try_end_0
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/util/concurrent/TimeoutException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    .line 218
    :catch_0
    move-exception v0

    .line 220
    const/4 v0, 0x0

    return-object v0
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    .line 226
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoID:Ljava/lang/String;

    filled-new-array {v0}, [Ljava/lang/Object;

    move-result-object v0

    const-string v1, "StreamingDataRequest{videoId=\'%s\'}"

    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
