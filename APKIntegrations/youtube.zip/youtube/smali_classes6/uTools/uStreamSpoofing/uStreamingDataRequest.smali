.class public LuTools/uStreamSpoofing/uStreamingDataRequest;
.super Ljava/lang/Object;
.source "uStreamingDataRequest.java"


# static fields
.field private static final Cache:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "LuTools/uStreamSpoofing/uStreamingDataRequest;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final CLIENT_TYPES_ORDER_TO_USE:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LuTools/uStreamSpoofing/uClientType;",
            ">;"
        }
    .end annotation
.end field

.field private final READ_BUFFER_SIZE:I

.field private defaultAudioTrackLocale:Ljava/util/Locale;

.field private final defaultAudioTrackLocales:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/util/Locale;",
            ">;"
        }
    .end annotation
.end field

.field private final future:Ljava/util/concurrent/Future;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/Future<",
            "Ljava/nio/ByteBuffer;",
            ">;"
        }
    .end annotation
.end field

.field private final videoID:Ljava/lang/String;


# direct methods
.method public static synthetic $r8$lambda$w9MmyL03FTq0ITUxar6F-eeCNGs(LuTools/uStreamSpoofing/uStreamingDataRequest;Ljava/util/Map;Ljava/lang/String;)Ljava/nio/ByteBuffer;
    .locals 0

    invoke-direct {p0, p1, p2}, LuTools/uStreamSpoofing/uStreamingDataRequest;->lambda$new$0(Ljava/util/Map;Ljava/lang/String;)Ljava/nio/ByteBuffer;

    move-result-object p0

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetdefaultAudioTrackLocale(LuTools/uStreamSpoofing/uStreamingDataRequest;)Ljava/util/Locale;
    .locals 0

    iget-object p0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->defaultAudioTrackLocale:Ljava/util/Locale;

    return-object p0
.end method

.method static constructor <clinit>()V
    .locals 1

    .line 232
    invoke-static {}, LuTools/uUtils;->InitializeStreamCache()Ljava/util/LinkedHashMap;

    move-result-object v0

    invoke-static {v0}, Ljava/util/Collections;->synchronizedMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object v0

    sput-object v0, LuTools/uStreamSpoofing/uStreamingDataRequest;->Cache:Ljava/util/Map;

    .line 231
    return-void
.end method

.method private constructor <init>(Ljava/lang/String;Ljava/util/Map;)V
    .locals 4
    .param p1, "videoID"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 56
    .local p2, "playerHeaders":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;"
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 45
    new-instance v0, Ljava/util/ArrayList;

    const/4 v1, 0x3

    new-array v1, v1, [LuTools/uStreamSpoofing/uClientType;

    const/4 v2, 0x0

    sget-object v3, LuTools/uStreamSpoofing/uClientType;->ANDROID_VR:LuTools/uStreamSpoofing/uClientType;

    aput-object v3, v1, v2

    const/4 v2, 0x1

    sget-object v3, LuTools/uStreamSpoofing/uClientType;->ANDROID_UNPLUGGED:LuTools/uStreamSpoofing/uClientType;

    aput-object v3, v1, v2

    const/4 v2, 0x2

    sget-object v3, LuTools/uStreamSpoofing/uClientType;->ANDROID_CREATOR:LuTools/uStreamSpoofing/uClientType;

    aput-object v3, v1, v2

    .line 47
    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    iput-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->CLIENT_TYPES_ORDER_TO_USE:Ljava/util/List;

    .line 53
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->defaultAudioTrackLocales:Ljava/util/List;

    .line 55
    const/16 v0, 0x2000

    iput v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->READ_BUFFER_SIZE:I

    .line 57
    invoke-static {p2}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 59
    iput-object p1, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoID:Ljava/lang/String;

    .line 60
    sget-object v0, LuTools/uUtils;->BackgroundThreadPool:Ljava/util/concurrent/ThreadPoolExecutor;

    new-instance v1, LuTools/uStreamSpoofing/uStreamingDataRequest$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0, p2, p1}, LuTools/uStreamSpoofing/uStreamingDataRequest$$ExternalSyntheticLambda0;-><init>(LuTools/uStreamSpoofing/uStreamingDataRequest;Ljava/util/Map;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Ljava/util/concurrent/ThreadPoolExecutor;->submit(Ljava/util/concurrent/Callable;)Ljava/util/concurrent/Future;

    move-result-object v0

    iput-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->future:Ljava/util/concurrent/Future;

    .line 229
    return-void
.end method

.method public static FetchRequest(Ljava/lang/String;Ljava/util/Map;)V
    .locals 2
    .param p0, "videoID"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 235
    .local p1, "fetchHeaders":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;"
    sget-object v0, LuTools/uStreamSpoofing/uStreamingDataRequest;->Cache:Ljava/util/Map;

    new-instance v1, LuTools/uStreamSpoofing/uStreamingDataRequest;

    invoke-direct {v1, p0, p1}, LuTools/uStreamSpoofing/uStreamingDataRequest;-><init>(Ljava/lang/String;Ljava/util/Map;)V

    invoke-interface {v0, p0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 236
    return-void
.end method

.method public static GetRequestForVideoID(Ljava/lang/String;)LuTools/uStreamSpoofing/uStreamingDataRequest;
    .locals 1
    .param p0, "videoID"    # Ljava/lang/String;

    .line 240
    sget-object v0, LuTools/uStreamSpoofing/uStreamingDataRequest;->Cache:Ljava/util/Map;

    invoke-interface {v0, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LuTools/uStreamSpoofing/uStreamingDataRequest;

    return-object v0
.end method

.method private synthetic lambda$new$0(Ljava/util/Map;Ljava/lang/String;)Ljava/nio/ByteBuffer;
    .locals 23
    .param p1, "playerHeaders"    # Ljava/util/Map;
    .param p2, "videoID"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 64
    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    iget-object v0, v1, LuTools/uStreamSpoofing/uStreamingDataRequest;->CLIENT_TYPES_ORDER_TO_USE:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_0
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const-string v6, "uStreamingDataRequest"

    if-eqz v0, :cond_c

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    move-object v7, v0

    check-cast v7, LuTools/uStreamSpoofing/uClientType;

    .line 65
    .local v7, "clientType":LuTools/uStreamSpoofing/uClientType;
    const/4 v0, 0x0

    .line 67
    .local v0, "videoRequireLogin":Z
    const/4 v8, 0x0

    move v9, v8

    move v8, v0

    .end local v0    # "videoRequireLogin":Z
    .local v8, "videoRequireLogin":Z
    .local v9, "i":I
    :goto_1
    const/4 v10, 0x2

    if-ge v9, v10, :cond_b

    .line 68
    const/4 v0, 0x0

    .line 70
    .local v0, "videoRequireSimplifiedLocale":Z
    const/4 v11, 0x0

    move v12, v11

    move v11, v0

    .end local v0    # "videoRequireSimplifiedLocale":Z
    .local v11, "videoRequireSimplifiedLocale":Z
    .local v12, "j":I
    :goto_2
    if-ge v12, v10, :cond_a

    .line 71
    new-instance v0, LuTools/uStreamSpoofing/uRoute;

    sget-object v13, LuTools/uStreamSpoofing/uRoute$Method;->POST:LuTools/uStreamSpoofing/uRoute$Method;

    const-string v14, "player?fields=streamingData&alt=proto"

    invoke-direct {v0, v13, v14}, LuTools/uStreamSpoofing/uRoute;-><init>(LuTools/uStreamSpoofing/uRoute$Method;Ljava/lang/String;)V

    const/4 v13, 0x0

    new-array v14, v13, [Ljava/lang/String;

    .line 76
    invoke-virtual {v0, v14}, LuTools/uStreamSpoofing/uRoute;->Compile([Ljava/lang/String;)LuTools/uStreamSpoofing/uRoute$CompiledRoute;

    move-result-object v0

    iget-object v14, v7, LuTools/uStreamSpoofing/uClientType;->userAgent:Ljava/lang/String;

    iget v15, v7, LuTools/uStreamSpoofing/uClientType;->clientID:I

    .line 80
    invoke-static {v15}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v15

    iget-object v10, v7, LuTools/uStreamSpoofing/uClientType;->clientVersion:Ljava/lang/String;

    filled-new-array {v14, v15, v10}, [Ljava/lang/Object;

    move-result-object v10

    .line 78
    invoke-static {v10}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v10

    .line 71
    invoke-static {v0, v10}, LuTools/uStreamSpoofing/uPlayerRoutes;->GetPlayerResponseConnectionFromRoute(LuTools/uStreamSpoofing/uRoute$CompiledRoute;Ljava/util/List;)Ljava/net/HttpURLConnection;

    move-result-object v10

    .line 85
    .local v10, "connection":Ljava/net/HttpURLConnection;
    if-eqz v10, :cond_9

    .line 86
    sget-object v0, LuTools/uStreamSpoofing/uPlayerRoutes;->requestKeys:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_3
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v14

    if-eqz v14, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Ljava/lang/String;

    .line 87
    .local v14, "requestKey":Ljava/lang/String;
    sget-object v15, LuTools/uStreamSpoofing/uPlayerRoutes;->requestKeys:Ljava/util/List;

    invoke-interface {v15, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v15

    invoke-virtual {v14, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v15

    if-eqz v15, :cond_0

    if-nez v8, :cond_0

    .line 88
    goto :goto_3

    .line 91
    :cond_0
    invoke-interface {v2, v14}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Ljava/lang/String;

    invoke-virtual {v10, v14, v15}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 92
    .end local v14    # "requestKey":Ljava/lang/String;
    goto :goto_3

    .line 94
    :cond_1
    new-instance v0, LuTools/VideoDetails/uVideoDetailsRequest;

    const-string v14, "actionButtons"

    invoke-direct {v0, v3, v2, v14}, LuTools/VideoDetails/uVideoDetailsRequest;-><init>(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)V

    .line 99
    invoke-virtual {v0}, LuTools/VideoDetails/uVideoDetailsRequest;->GetRequestedInfo()Ljava/lang/Object;

    move-result-object v14

    .line 101
    .local v14, "actionButtonsRequest":Ljava/lang/Object;
    invoke-static {}, LuTools/uUtils;->NullifiesCurrentActionButtonsList()V

    .line 103
    instance-of v0, v14, Ljava/util/List;

    if-eqz v0, :cond_2

    .line 105
    move-object v0, v14

    check-cast v0, Ljava/util/List;

    goto :goto_4

    .line 107
    :cond_2
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 102
    :goto_4
    invoke-static {v0}, LuTools/uUtils;->SetCurrentActionButtonsList(Ljava/util/List;)V

    .line 110
    new-instance v0, LuTools/VideoDetails/uVideoDetailsRequest;

    const-string v15, "defaultAudioTrackID"

    invoke-direct {v0, v3, v2, v15}, LuTools/VideoDetails/uVideoDetailsRequest;-><init>(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)V

    .line 115
    invoke-virtual {v0}, LuTools/VideoDetails/uVideoDetailsRequest;->GetRequestedInfo()Ljava/lang/Object;

    move-result-object v15

    .line 117
    .local v15, "defaultAudioTrackRequest":Ljava/lang/Object;
    instance-of v0, v15, Ljava/lang/String;

    if-eqz v0, :cond_3

    .line 119
    move-object v0, v15

    check-cast v0, Ljava/lang/String;

    goto :goto_5

    .line 121
    :cond_3
    const-string v0, ""

    :goto_5
    move-object/from16 v17, v0

    .line 124
    .local v17, "defaultAudioTrackName":Ljava/lang/String;
    :try_start_0
    const-string v0, "-"
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_3

    move-object/from16 v5, v17

    const/16 v19, 0x1

    .end local v17    # "defaultAudioTrackName":Ljava/lang/String;
    .local v5, "defaultAudioTrackName":Ljava/lang/String;
    :try_start_1
    invoke-virtual {v5, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_2

    .line 126
    .local v0, "splitDefaultAudioTrackName":[Ljava/lang/String;
    move/from16 v17, v13

    :try_start_2
    iget-object v13, v1, LuTools/uStreamSpoofing/uStreamingDataRequest;->defaultAudioTrackLocales:Ljava/util/List;

    move-object/from16 v20, v0

    .end local v0    # "splitDefaultAudioTrackName":[Ljava/lang/String;
    .local v20, "splitDefaultAudioTrackName":[Ljava/lang/String;
    new-instance v0, Ljava/util/Locale;

    aget-object v2, v20, v17

    aget-object v21, v20, v19
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    .line 130
    move-object/from16 v22, v4

    :try_start_3
    invoke-virtual/range {v21 .. v21}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v2, v4}, Ljava/util/Locale;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 126
    invoke-interface {v13, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_0

    .line 141
    nop

    .end local v20    # "splitDefaultAudioTrackName":[Ljava/lang/String;
    goto :goto_7

    .line 133
    :catch_0
    move-exception v0

    goto :goto_6

    :catch_1
    move-exception v0

    move-object/from16 v22, v4

    goto :goto_6

    :catch_2
    move-exception v0

    move-object/from16 v22, v4

    move/from16 v17, v13

    goto :goto_6

    .end local v5    # "defaultAudioTrackName":Ljava/lang/String;
    .restart local v17    # "defaultAudioTrackName":Ljava/lang/String;
    :catch_3
    move-exception v0

    move-object/from16 v22, v4

    move-object/from16 v5, v17

    const/16 v19, 0x1

    move/from16 v17, v13

    .line 134
    .end local v17    # "defaultAudioTrackName":Ljava/lang/String;
    .local v0, "ignore":Ljava/lang/Exception;
    .restart local v5    # "defaultAudioTrackName":Ljava/lang/String;
    :goto_6
    iget-object v2, v1, LuTools/uStreamSpoofing/uStreamingDataRequest;->defaultAudioTrackLocales:Ljava/util/List;

    new-instance v4, Ljava/util/Locale;

    .line 138
    invoke-virtual {v5}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object v13

    invoke-direct {v4, v5, v13}, Ljava/util/Locale;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 134
    invoke-interface {v2, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 142
    .end local v0    # "ignore":Ljava/lang/Exception;
    :goto_7
    iget-object v0, v1, LuTools/uStreamSpoofing/uStreamingDataRequest;->defaultAudioTrackLocales:Ljava/util/List;

    new-instance v2, Ljava/util/Locale;

    invoke-direct {v2, v5}, Ljava/util/Locale;-><init>(Ljava/lang/String;)V

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 144
    if-nez v8, :cond_5

    .line 145
    if-nez v11, :cond_4

    .line 146
    iget-object v0, v1, LuTools/uStreamSpoofing/uStreamingDataRequest;->defaultAudioTrackLocales:Ljava/util/List;

    move/from16 v2, v17

    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Locale;

    iput-object v0, v1, LuTools/uStreamSpoofing/uStreamingDataRequest;->defaultAudioTrackLocale:Ljava/util/Locale;

    goto :goto_8

    .line 148
    :cond_4
    iget-object v0, v1, LuTools/uStreamSpoofing/uStreamingDataRequest;->defaultAudioTrackLocales:Ljava/util/List;

    move/from16 v2, v19

    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Locale;

    iput-object v0, v1, LuTools/uStreamSpoofing/uStreamingDataRequest;->defaultAudioTrackLocale:Ljava/util/Locale;

    .line 152
    :cond_5
    :goto_8
    iget-object v0, v1, LuTools/uStreamSpoofing/uStreamingDataRequest;->defaultAudioTrackLocales:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 154
    new-instance v0, LuTools/uStreamSpoofing/uStreamingDataRequest$1;

    invoke-direct {v0, v1, v7, v3}, LuTools/uStreamSpoofing/uStreamingDataRequest$1;-><init>(LuTools/uStreamSpoofing/uStreamingDataRequest;LuTools/uStreamSpoofing/uClientType;Ljava/lang/String;)V

    move-object v2, v0

    .line 182
    .local v2, "innerTubeBody":Lorg/json/JSONObject;
    const/4 v4, 0x0

    iput-object v4, v1, LuTools/uStreamSpoofing/uStreamingDataRequest;->defaultAudioTrackLocale:Ljava/util/Locale;

    .line 184
    invoke-virtual {v2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0

    sget-object v4, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {v0, v4}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v4

    .line 186
    .local v4, "requestBody":[B
    array-length v0, v4

    invoke-virtual {v10, v0}, Ljava/net/HttpURLConnection;->setFixedLengthStreamingMode(I)V

    .line 187
    invoke-virtual {v10}, Ljava/net/HttpURLConnection;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v0

    invoke-virtual {v0, v4}, Ljava/io/OutputStream;->write([B)V

    .line 189
    invoke-virtual {v10}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v0

    const/16 v13, 0xc8

    if-ne v0, v13, :cond_8

    .line 190
    invoke-virtual {v10}, Ljava/net/HttpURLConnection;->getContentLength()I

    move-result v13

    .line 192
    .local v13, "contentLength":I
    if-eqz v13, :cond_7

    .line 194
    new-instance v0, Ljava/io/BufferedInputStream;

    invoke-virtual {v10}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/io/BufferedInputStream;-><init>(Ljava/io/InputStream;)V

    move-object v1, v0

    .line 195
    .local v1, "inputStream":Ljava/io/InputStream;
    :try_start_4
    new-instance v0, Ljava/io/ByteArrayOutputStream;
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_7

    move-object/from16 v17, v2

    .end local v2    # "innerTubeBody":Lorg/json/JSONObject;
    .local v17, "innerTubeBody":Lorg/json/JSONObject;
    const/16 v2, 0x2000

    :try_start_5
    invoke-static {v13, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    invoke-direct {v0, v2}, Ljava/io/ByteArrayOutputStream;-><init>(I)V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_6

    move-object v2, v0

    .line 197
    .local v2, "baos":Ljava/io/ByteArrayOutputStream;
    :try_start_6
    invoke-virtual {v1, v2}, Ljava/io/InputStream;->transferTo(Ljava/io/OutputStream;)J

    .line 199
    const-string v0, " (%s - %s)"
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_3

    .line 203
    move-object/from16 v16, v1

    .end local v1    # "inputStream":Ljava/io/InputStream;
    .local v16, "inputStream":Ljava/io/InputStream;
    :try_start_7
    invoke-virtual {v7}, LuTools/uStreamSpoofing/uClientType;->name()Ljava/lang/String;

    move-result-object v1
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_2

    .line 204
    if-nez v8, :cond_6

    :try_start_8
    const-string v18, "NO_AUTH"
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_0

    goto :goto_9

    .line 193
    :catchall_0
    move-exception v0

    move-object v1, v0

    move-object/from16 v19, v2

    goto :goto_a

    .line 204
    :cond_6
    :try_start_9
    const-string v18, "WITH_AUTH"
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_2

    :goto_9
    move-object/from16 v19, v2

    move-object/from16 v2, v18

    .end local v2    # "baos":Ljava/io/ByteArrayOutputStream;
    .local v19, "baos":Ljava/io/ByteArrayOutputStream;
    :try_start_a
    filled-new-array {v1, v2}, [Ljava/lang/Object;

    move-result-object v1

    .line 200
    invoke-static {v0, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    .line 206
    .local v0, "currentClientName":Ljava/lang/String;
    invoke-static {v0}, LuTools/uUtils;->SetStatsForNerdsClientName(Ljava/lang/String;)V

    .line 207
    invoke-static {v6, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 209
    invoke-virtual/range {v19 .. v19}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v1

    invoke-static {v1}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object v1
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_1

    .line 210
    :try_start_b
    invoke-virtual/range {v19 .. v19}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_5

    invoke-virtual/range {v16 .. v16}, Ljava/io/InputStream;->close()V

    .line 209
    return-object v1

    .line 193
    .end local v0    # "currentClientName":Ljava/lang/String;
    :catchall_1
    move-exception v0

    move-object v1, v0

    goto :goto_a

    .end local v19    # "baos":Ljava/io/ByteArrayOutputStream;
    .restart local v2    # "baos":Ljava/io/ByteArrayOutputStream;
    :catchall_2
    move-exception v0

    move-object/from16 v19, v2

    move-object v1, v0

    .end local v2    # "baos":Ljava/io/ByteArrayOutputStream;
    .restart local v19    # "baos":Ljava/io/ByteArrayOutputStream;
    goto :goto_a

    .end local v16    # "inputStream":Ljava/io/InputStream;
    .end local v19    # "baos":Ljava/io/ByteArrayOutputStream;
    .restart local v1    # "inputStream":Ljava/io/InputStream;
    .restart local v2    # "baos":Ljava/io/ByteArrayOutputStream;
    :catchall_3
    move-exception v0

    move-object/from16 v16, v1

    move-object/from16 v19, v2

    move-object v1, v0

    .end local v1    # "inputStream":Ljava/io/InputStream;
    .end local v2    # "baos":Ljava/io/ByteArrayOutputStream;
    .restart local v16    # "inputStream":Ljava/io/InputStream;
    .restart local v19    # "baos":Ljava/io/ByteArrayOutputStream;
    :goto_a
    :try_start_c
    invoke-virtual/range {v19 .. v19}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_4

    goto :goto_b

    :catchall_4
    move-exception v0

    :try_start_d
    invoke-virtual {v1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .end local v4    # "requestBody":[B
    .end local v5    # "defaultAudioTrackName":Ljava/lang/String;
    .end local v7    # "clientType":LuTools/uStreamSpoofing/uClientType;
    .end local v8    # "videoRequireLogin":Z
    .end local v9    # "i":I
    .end local v10    # "connection":Ljava/net/HttpURLConnection;
    .end local v11    # "videoRequireSimplifiedLocale":Z
    .end local v12    # "j":I
    .end local v13    # "contentLength":I
    .end local v14    # "actionButtonsRequest":Ljava/lang/Object;
    .end local v15    # "defaultAudioTrackRequest":Ljava/lang/Object;
    .end local v16    # "inputStream":Ljava/io/InputStream;
    .end local v17    # "innerTubeBody":Lorg/json/JSONObject;
    .end local p0    # "this":LuTools/uStreamSpoofing/uStreamingDataRequest;
    .end local p1    # "playerHeaders":Ljava/util/Map;
    .end local p2    # "videoID":Ljava/lang/String;
    :goto_b
    throw v1
    :try_end_d
    .catchall {:try_start_d .. :try_end_d} :catchall_5

    .end local v19    # "baos":Ljava/io/ByteArrayOutputStream;
    .restart local v4    # "requestBody":[B
    .restart local v5    # "defaultAudioTrackName":Ljava/lang/String;
    .restart local v7    # "clientType":LuTools/uStreamSpoofing/uClientType;
    .restart local v8    # "videoRequireLogin":Z
    .restart local v9    # "i":I
    .restart local v10    # "connection":Ljava/net/HttpURLConnection;
    .restart local v11    # "videoRequireSimplifiedLocale":Z
    .restart local v12    # "j":I
    .restart local v13    # "contentLength":I
    .restart local v14    # "actionButtonsRequest":Ljava/lang/Object;
    .restart local v15    # "defaultAudioTrackRequest":Ljava/lang/Object;
    .restart local v16    # "inputStream":Ljava/io/InputStream;
    .restart local v17    # "innerTubeBody":Lorg/json/JSONObject;
    .restart local p0    # "this":LuTools/uStreamSpoofing/uStreamingDataRequest;
    .restart local p1    # "playerHeaders":Ljava/util/Map;
    .restart local p2    # "videoID":Ljava/lang/String;
    :catchall_5
    move-exception v0

    move-object v1, v0

    goto :goto_c

    .end local v16    # "inputStream":Ljava/io/InputStream;
    .restart local v1    # "inputStream":Ljava/io/InputStream;
    :catchall_6
    move-exception v0

    move-object/from16 v16, v1

    move-object v1, v0

    .end local v1    # "inputStream":Ljava/io/InputStream;
    .restart local v16    # "inputStream":Ljava/io/InputStream;
    goto :goto_c

    .end local v16    # "inputStream":Ljava/io/InputStream;
    .end local v17    # "innerTubeBody":Lorg/json/JSONObject;
    .restart local v1    # "inputStream":Ljava/io/InputStream;
    .local v2, "innerTubeBody":Lorg/json/JSONObject;
    :catchall_7
    move-exception v0

    move-object/from16 v16, v1

    move-object/from16 v17, v2

    move-object v1, v0

    .end local v1    # "inputStream":Ljava/io/InputStream;
    .end local v2    # "innerTubeBody":Lorg/json/JSONObject;
    .restart local v16    # "inputStream":Ljava/io/InputStream;
    .restart local v17    # "innerTubeBody":Lorg/json/JSONObject;
    :goto_c
    :try_start_e
    invoke-virtual/range {v16 .. v16}, Ljava/io/InputStream;->close()V
    :try_end_e
    .catchall {:try_start_e .. :try_end_e} :catchall_8

    goto :goto_d

    :catchall_8
    move-exception v0

    invoke-virtual {v1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_d
    throw v1

    .line 192
    .end local v16    # "inputStream":Ljava/io/InputStream;
    .end local v17    # "innerTubeBody":Lorg/json/JSONObject;
    .restart local v2    # "innerTubeBody":Lorg/json/JSONObject;
    :cond_7
    move-object/from16 v17, v2

    .end local v2    # "innerTubeBody":Lorg/json/JSONObject;
    .restart local v17    # "innerTubeBody":Lorg/json/JSONObject;
    goto :goto_e

    .line 189
    .end local v13    # "contentLength":I
    .end local v17    # "innerTubeBody":Lorg/json/JSONObject;
    .restart local v2    # "innerTubeBody":Lorg/json/JSONObject;
    :cond_8
    move-object/from16 v17, v2

    .end local v2    # "innerTubeBody":Lorg/json/JSONObject;
    .restart local v17    # "innerTubeBody":Lorg/json/JSONObject;
    goto :goto_e

    .line 85
    .end local v4    # "requestBody":[B
    .end local v5    # "defaultAudioTrackName":Ljava/lang/String;
    .end local v14    # "actionButtonsRequest":Ljava/lang/Object;
    .end local v15    # "defaultAudioTrackRequest":Ljava/lang/Object;
    .end local v17    # "innerTubeBody":Lorg/json/JSONObject;
    :cond_9
    move-object/from16 v22, v4

    .line 215
    :goto_e
    const/4 v11, 0x1

    .line 70
    .end local v10    # "connection":Ljava/net/HttpURLConnection;
    add-int/lit8 v12, v12, 0x1

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v4, v22

    const/4 v10, 0x2

    goto/16 :goto_2

    :cond_a
    move-object/from16 v22, v4

    .line 218
    .end local v12    # "j":I
    const/4 v8, 0x1

    .line 67
    .end local v11    # "videoRequireSimplifiedLocale":Z
    add-int/lit8 v9, v9, 0x1

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    goto/16 :goto_1

    :cond_b
    move-object/from16 v22, v4

    .line 220
    .end local v7    # "clientType":LuTools/uStreamSpoofing/uClientType;
    .end local v8    # "videoRequireLogin":Z
    .end local v9    # "i":I
    move-object/from16 v1, p0

    move-object/from16 v2, p1

    goto/16 :goto_0

    .line 222
    :cond_c
    const-string v0, "Unknown"

    .line 223
    .restart local v0    # "currentClientName":Ljava/lang/String;
    const-string v1, " (%s)"

    filled-new-array {v0}, [Ljava/lang/Object;

    move-result-object v2

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, LuTools/uUtils;->SetStatsForNerdsClientName(Ljava/lang/String;)V

    .line 224
    invoke-static {v6, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 226
    const/16 v18, 0x0

    return-object v18
.end method


# virtual methods
.method public GetStream()Ljava/nio/ByteBuffer;
    .locals 4

    .line 246
    :try_start_0
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->future:Ljava/util/concurrent/Future;

    sget-object v1, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v2, 0x4e20

    invoke-interface {v0, v2, v3, v1}, Ljava/util/concurrent/Future;->get(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/nio/ByteBuffer;
    :try_end_0
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/util/concurrent/TimeoutException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    .line 247
    :catch_0
    move-exception v0

    .line 249
    const/4 v0, 0x0

    return-object v0
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    .line 255
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest;->videoID:Ljava/lang/String;

    filled-new-array {v0}, [Ljava/lang/Object;

    move-result-object v0

    const-string v1, "StreamingDataRequest{videoId=\'%s\'}"

    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
