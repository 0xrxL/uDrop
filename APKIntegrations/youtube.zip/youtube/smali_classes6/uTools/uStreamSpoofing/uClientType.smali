.class public final enum LuTools/uStreamSpoofing/uClientType;
.super Ljava/lang/Enum;
.source "uClientType.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "LuTools/uStreamSpoofing/uClientType;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[LuTools/uStreamSpoofing/uClientType;

.field public static final enum Android_No_SDK:LuTools/uStreamSpoofing/uClientType;

.field public static final enum Android_Studio:LuTools/uStreamSpoofing/uClientType;

.field public static final enum Android_VR_AV1:LuTools/uStreamSpoofing/uClientType;

.field public static final enum Android_VR_No_AV1:LuTools/uStreamSpoofing/uClientType;

.field public static final enum Vision_OS:LuTools/uStreamSpoofing/uClientType;


# instance fields
.field public final androidSDKVersion:Ljava/lang/String;

.field public final clientID:I

.field public final clientName:Ljava/lang/String;

.field public final clientPackageName:Ljava/lang/String;

.field public final clientVersion:Ljava/lang/String;

.field public final cronetVersion:Ljava/lang/String;

.field public final deviceMake:Ljava/lang/String;

.field public final deviceModel:Ljava/lang/String;

.field public final osBuildID:Ljava/lang/String;

.field public final osName:Ljava/lang/String;

.field public final osVersion:Ljava/lang/String;

.field public final useAuth:Z

.field public userAgent:Ljava/lang/String;


# direct methods
.method private static synthetic $values()[LuTools/uStreamSpoofing/uClientType;
    .locals 5

    .line 7
    sget-object v0, LuTools/uStreamSpoofing/uClientType;->Android_No_SDK:LuTools/uStreamSpoofing/uClientType;

    sget-object v1, LuTools/uStreamSpoofing/uClientType;->Android_Studio:LuTools/uStreamSpoofing/uClientType;

    sget-object v2, LuTools/uStreamSpoofing/uClientType;->Android_VR_AV1:LuTools/uStreamSpoofing/uClientType;

    sget-object v3, LuTools/uStreamSpoofing/uClientType;->Android_VR_No_AV1:LuTools/uStreamSpoofing/uClientType;

    sget-object v4, LuTools/uStreamSpoofing/uClientType;->Vision_OS:LuTools/uStreamSpoofing/uClientType;

    filled-new-array {v0, v1, v2, v3, v4}, [LuTools/uStreamSpoofing/uClientType;

    move-result-object v0

    return-object v0
.end method

.method static constructor <clinit>()V
    .locals 20

    .line 8
    new-instance v0, LuTools/uStreamSpoofing/uClientType;

    const/4 v14, 0x0

    const/4 v15, 0x0

    const-string v1, "Android_No_SDK"

    const/4 v2, 0x0

    const-string v3, "ANDROID"

    const/4 v4, 0x0

    const/4 v5, 0x3

    const-string v6, "com.google.android.youtube"

    const-string v7, "20.05.46"

    const-string v8, ""

    const-string v9, ""

    const-string v10, ""

    const-string v11, ""

    const-string v12, "Android"

    const-string v13, " 16;"

    invoke-direct/range {v0 .. v15}, LuTools/uStreamSpoofing/uClientType;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)V

    sput-object v0, LuTools/uStreamSpoofing/uClientType;->Android_No_SDK:LuTools/uStreamSpoofing/uClientType;

    .line 23
    new-instance v1, LuTools/uStreamSpoofing/uClientType;

    const/4 v15, 0x1

    const/16 v16, 0x0

    const-string v2, "Android_Studio"

    const/4 v3, 0x1

    const-string v4, "ANDROID_CREATOR"

    const-string v5, "35"

    const/16 v6, 0xe

    const-string v7, "com.google.android.apps.youtube.creator"

    const-string v8, "23.47.101"

    const-string v9, " Cronet/132.0.6779.0;"

    const-string v10, "Pixel 9 Pro Fold"

    const-string v11, " Google;"

    const-string v12, " Build/AP3A.241005.015.A2;"

    const-string v13, "Android"

    const-string v14, " 15;"

    invoke-direct/range {v1 .. v16}, LuTools/uStreamSpoofing/uClientType;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)V

    sput-object v1, LuTools/uStreamSpoofing/uClientType;->Android_Studio:LuTools/uStreamSpoofing/uClientType;

    .line 38
    new-instance v2, LuTools/uStreamSpoofing/uClientType;

    const/16 v16, 0x0

    const/16 v17, 0x0

    const-string v3, "Android_VR_AV1"

    const/4 v4, 0x2

    const-string v5, "ANDROID_VR"

    const-string v6, "34"

    const/16 v7, 0x1c

    const-string v8, "com.google.android.apps.youtube.vr.oculus"

    const-string v9, "1.54.20"

    const-string v10, " Cronet/122.0.6238.3;"

    const-string v11, "Quest 3"

    const-string v12, " Oculus;"

    const-string v13, " Build/UP1A.231005.007.A1;"

    const-string v14, "Android"

    const-string v15, " 14;"

    invoke-direct/range {v2 .. v17}, LuTools/uStreamSpoofing/uClientType;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)V

    sput-object v2, LuTools/uStreamSpoofing/uClientType;->Android_VR_AV1:LuTools/uStreamSpoofing/uClientType;

    .line 53
    new-instance v3, LuTools/uStreamSpoofing/uClientType;

    sget-object v0, LuTools/uStreamSpoofing/uClientType;->Android_VR_AV1:LuTools/uStreamSpoofing/uClientType;

    iget-object v6, v0, LuTools/uStreamSpoofing/uClientType;->clientName:Ljava/lang/String;

    sget-object v0, LuTools/uStreamSpoofing/uClientType;->Android_VR_AV1:LuTools/uStreamSpoofing/uClientType;

    iget v8, v0, LuTools/uStreamSpoofing/uClientType;->clientID:I

    sget-object v0, LuTools/uStreamSpoofing/uClientType;->Android_VR_AV1:LuTools/uStreamSpoofing/uClientType;

    iget-object v9, v0, LuTools/uStreamSpoofing/uClientType;->clientPackageName:Ljava/lang/String;

    sget-object v0, LuTools/uStreamSpoofing/uClientType;->Android_VR_AV1:LuTools/uStreamSpoofing/uClientType;

    iget-object v12, v0, LuTools/uStreamSpoofing/uClientType;->deviceMake:Ljava/lang/String;

    sget-object v0, LuTools/uStreamSpoofing/uClientType;->Android_VR_AV1:LuTools/uStreamSpoofing/uClientType;

    iget-object v13, v0, LuTools/uStreamSpoofing/uClientType;->deviceModel:Ljava/lang/String;

    sget-object v0, LuTools/uStreamSpoofing/uClientType;->Android_VR_AV1:LuTools/uStreamSpoofing/uClientType;

    iget-object v15, v0, LuTools/uStreamSpoofing/uClientType;->osName:Ljava/lang/String;

    const/16 v17, 0x0

    const/16 v18, 0x0

    const-string v4, "Android_VR_No_AV1"

    const/4 v5, 0x3

    const-string v7, "29"

    const-string v10, "1.47.48"

    const-string v11, " Cronet/113.0.5672.24;"

    const-string v14, " Build/QQ3A.200805.001"

    const-string v16, " 10;"

    invoke-direct/range {v3 .. v18}, LuTools/uStreamSpoofing/uClientType;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)V

    sput-object v3, LuTools/uStreamSpoofing/uClientType;->Android_VR_No_AV1:LuTools/uStreamSpoofing/uClientType;

    .line 68
    new-instance v4, LuTools/uStreamSpoofing/uClientType;

    const/16 v18, 0x0

    const-string v19, "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Safari/605.1.15"

    const-string v5, "Vision_OS"

    const/4 v6, 0x4

    const-string v7, "VISIONOS"

    const/4 v8, 0x0

    const/16 v9, 0x65

    const/4 v10, 0x0

    const-string v11, "0.1"

    const/4 v12, 0x0

    const-string v13, "RealityDevice14,1"

    const-string v14, "Apple"

    const/4 v15, 0x0

    const-string v16, "visionOS"

    const-string v17, "1.3.21O771"

    invoke-direct/range {v4 .. v19}, LuTools/uStreamSpoofing/uClientType;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)V

    sput-object v4, LuTools/uStreamSpoofing/uClientType;->Vision_OS:LuTools/uStreamSpoofing/uClientType;

    .line 7
    invoke-static {}, LuTools/uStreamSpoofing/uClientType;->$values()[LuTools/uStreamSpoofing/uClientType;

    move-result-object v0

    sput-object v0, LuTools/uStreamSpoofing/uClientType;->$VALUES:[LuTools/uStreamSpoofing/uClientType;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)V
    .locals 13
    .param p3, "clientName"    # Ljava/lang/String;
    .param p4, "androidSDKVersion"    # Ljava/lang/String;
    .param p5, "clientID"    # I
    .param p6, "clientPackageName"    # Ljava/lang/String;
    .param p7, "clientVersion"    # Ljava/lang/String;
    .param p8, "cronetVersion"    # Ljava/lang/String;
    .param p9, "deviceMake"    # Ljava/lang/String;
    .param p10, "deviceModel"    # Ljava/lang/String;
    .param p11, "osBuildID"    # Ljava/lang/String;
    .param p12, "osName"    # Ljava/lang/String;
    .param p13, "osVersion"    # Ljava/lang/String;
    .param p14, "useAuth"    # Z
    .param p15, "userAgent"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "I",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Z",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 97
    move-object/from16 v0, p12

    move-object/from16 v1, p15

    invoke-direct/range {p0 .. p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 96
    const-string p1, ""

    iput-object p1, p0, LuTools/uStreamSpoofing/uClientType;->userAgent:Ljava/lang/String;

    .line 98
    move-object/from16 p1, p3

    iput-object p1, p0, LuTools/uStreamSpoofing/uClientType;->clientName:Ljava/lang/String;

    .line 99
    move-object/from16 v2, p4

    iput-object v2, p0, LuTools/uStreamSpoofing/uClientType;->androidSDKVersion:Ljava/lang/String;

    .line 100
    move/from16 v3, p5

    iput v3, p0, LuTools/uStreamSpoofing/uClientType;->clientID:I

    .line 101
    move-object/from16 v4, p6

    iput-object v4, p0, LuTools/uStreamSpoofing/uClientType;->clientPackageName:Ljava/lang/String;

    .line 102
    move-object/from16 v5, p7

    iput-object v5, p0, LuTools/uStreamSpoofing/uClientType;->clientVersion:Ljava/lang/String;

    .line 103
    move-object/from16 v9, p8

    iput-object v9, p0, LuTools/uStreamSpoofing/uClientType;->cronetVersion:Ljava/lang/String;

    .line 104
    move-object/from16 v10, p9

    iput-object v10, p0, LuTools/uStreamSpoofing/uClientType;->deviceMake:Ljava/lang/String;

    .line 105
    move-object/from16 v7, p10

    iput-object v7, p0, LuTools/uStreamSpoofing/uClientType;->deviceModel:Ljava/lang/String;

    .line 106
    move-object/from16 v8, p11

    iput-object v8, p0, LuTools/uStreamSpoofing/uClientType;->osBuildID:Ljava/lang/String;

    .line 107
    iput-object v0, p0, LuTools/uStreamSpoofing/uClientType;->osName:Ljava/lang/String;

    .line 108
    move-object/from16 v6, p13

    iput-object v6, p0, LuTools/uStreamSpoofing/uClientType;->osVersion:Ljava/lang/String;

    .line 109
    move/from16 v11, p14

    iput-boolean v11, p0, LuTools/uStreamSpoofing/uClientType;->useAuth:Z

    .line 111
    if-nez v1, :cond_0

    .line 112
    const-string v12, "Android"

    invoke-static {v0, v12}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_1

    .line 113
    filled-new-array/range {v4 .. v9}, [Ljava/lang/Object;

    move-result-object v12

    .line 114
    const-string v4, "%s/%s (Linux; U; Android%s%s%s%s) gzip"

    invoke-static {v4, v12}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    iput-object v4, p0, LuTools/uStreamSpoofing/uClientType;->userAgent:Ljava/lang/String;

    goto :goto_0

    .line 126
    :cond_0
    iput-object v1, p0, LuTools/uStreamSpoofing/uClientType;->userAgent:Ljava/lang/String;

    .line 128
    :cond_1
    :goto_0
    return-void
.end method

.method public static valueOf(Ljava/lang/String;)LuTools/uStreamSpoofing/uClientType;
    .locals 1
    .param p0, "name"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            null
        }
    .end annotation

    .line 7
    const-class v0, LuTools/uStreamSpoofing/uClientType;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v0

    check-cast v0, LuTools/uStreamSpoofing/uClientType;

    return-object v0
.end method

.method public static values()[LuTools/uStreamSpoofing/uClientType;
    .locals 1

    .line 7
    sget-object v0, LuTools/uStreamSpoofing/uClientType;->$VALUES:[LuTools/uStreamSpoofing/uClientType;

    invoke-virtual {v0}, [LuTools/uStreamSpoofing/uClientType;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [LuTools/uStreamSpoofing/uClientType;

    return-object v0
.end method
