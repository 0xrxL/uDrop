.class public final enum LuTools/uStreamSpoofing/uClientType;
.super Ljava/lang/Enum;
.source "uClientType.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "LuTools/uStreamSpoofing/uClientType;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[LuTools/uStreamSpoofing/uClientType;

.field public static final enum ANDROID_CREATOR:LuTools/uStreamSpoofing/uClientType;

.field public static final enum ANDROID_UNPLUGGED:LuTools/uStreamSpoofing/uClientType;

.field public static final enum ANDROID_VR:LuTools/uStreamSpoofing/uClientType;


# instance fields
.field public final androidSDKVersion:Ljava/lang/String;

.field public final clientID:I

.field public final clientVersion:Ljava/lang/String;

.field public final cronetVersion:Ljava/lang/String;

.field public final deviceModel:Ljava/lang/String;

.field public final osBrand:Ljava/lang/String;

.field public final osBuildID:Ljava/lang/String;

.field public final osName:Ljava/lang/String;

.field public final osVersion:Ljava/lang/String;

.field public final userAgent:Ljava/lang/String;


# direct methods
.method private static synthetic $values()[LuTools/uStreamSpoofing/uClientType;
    .locals 3

    .line 5
    sget-object v0, LuTools/uStreamSpoofing/uClientType;->ANDROID_CREATOR:LuTools/uStreamSpoofing/uClientType;

    sget-object v1, LuTools/uStreamSpoofing/uClientType;->ANDROID_UNPLUGGED:LuTools/uStreamSpoofing/uClientType;

    sget-object v2, LuTools/uStreamSpoofing/uClientType;->ANDROID_VR:LuTools/uStreamSpoofing/uClientType;

    filled-new-array {v0, v1, v2}, [LuTools/uStreamSpoofing/uClientType;

    move-result-object v0

    return-object v0
.end method

.method static constructor <clinit>()V
    .locals 15

    .line 6
    new-instance v0, LuTools/uStreamSpoofing/uClientType;

    const-string v11, "Android"

    const-string v12, "15"

    const-string v1, "ANDROID_CREATOR"

    const/4 v2, 0x0

    const-string v3, "35"

    const/16 v4, 0xe

    const-string v5, "com.google.android.apps.youtube.creator"

    const-string v6, "25.23.100"

    const-string v7, "139.0.7238.0"

    const-string v8, "Pixel 9 Pro XL"

    const-string v9, "Google"

    const-string v10, "BP2A.250605.031.A2"

    invoke-direct/range {v0 .. v12}, LuTools/uStreamSpoofing/uClientType;-><init>(Ljava/lang/String;ILjava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    sput-object v0, LuTools/uStreamSpoofing/uClientType;->ANDROID_CREATOR:LuTools/uStreamSpoofing/uClientType;

    .line 18
    new-instance v1, LuTools/uStreamSpoofing/uClientType;

    const-string v12, "Android"

    const-string v13, "14"

    const-string v2, "ANDROID_UNPLUGGED"

    const/4 v3, 0x1

    const-string v4, "34"

    const/16 v5, 0x1d

    const-string v6, "com.google.android.apps.youtube.unplugged"

    const-string v7, "9.23.1"

    const-string v8, "139.0.7238.0"

    const-string v9, "Google TV Streamer"

    const-string v10, "Google"

    const-string v11, "UTTK.241210.003"

    invoke-direct/range {v1 .. v13}, LuTools/uStreamSpoofing/uClientType;-><init>(Ljava/lang/String;ILjava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    sput-object v1, LuTools/uStreamSpoofing/uClientType;->ANDROID_UNPLUGGED:LuTools/uStreamSpoofing/uClientType;

    .line 30
    new-instance v2, LuTools/uStreamSpoofing/uClientType;

    const-string v13, "Android"

    const-string v14, "15"

    const-string v3, "ANDROID_VR"

    const/4 v4, 0x2

    const-string v5, "35"

    const/16 v6, 0x1c

    const-string v7, "com.google.android.apps.youtube.vr.oculus"

    const-string v8, "1.64.34"

    const-string v9, "139.0.7238.0"

    const-string v10, "Quest 3S"

    const-string v11, "Oculus"

    const-string v12, "BP2A.250605.031.A2"

    invoke-direct/range {v2 .. v14}, LuTools/uStreamSpoofing/uClientType;-><init>(Ljava/lang/String;ILjava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    sput-object v2, LuTools/uStreamSpoofing/uClientType;->ANDROID_VR:LuTools/uStreamSpoofing/uClientType;

    .line 5
    invoke-static {}, LuTools/uStreamSpoofing/uClientType;->$values()[LuTools/uStreamSpoofing/uClientType;

    move-result-object v0

    sput-object v0, LuTools/uStreamSpoofing/uClientType;->$VALUES:[LuTools/uStreamSpoofing/uClientType;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;ILjava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 9
    .param p3, "androidSDKVersion"    # Ljava/lang/String;
    .param p4, "clientID"    # I
    .param p5, "clientPackageName"    # Ljava/lang/String;
    .param p6, "clientVersion"    # Ljava/lang/String;
    .param p7, "cronetVersion"    # Ljava/lang/String;
    .param p8, "deviceModel"    # Ljava/lang/String;
    .param p9, "osBrand"    # Ljava/lang/String;
    .param p10, "osBuildID"    # Ljava/lang/String;
    .param p11, "osName"    # Ljava/lang/String;
    .param p12, "osVersion"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "I",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 53
    invoke-direct/range {p0 .. p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 54
    iput-object p3, p0, LuTools/uStreamSpoofing/uClientType;->androidSDKVersion:Ljava/lang/String;

    .line 55
    iput p4, p0, LuTools/uStreamSpoofing/uClientType;->clientID:I

    .line 56
    iput-object p6, p0, LuTools/uStreamSpoofing/uClientType;->clientVersion:Ljava/lang/String;

    .line 57
    move-object/from16 v5, p7

    iput-object v5, p0, LuTools/uStreamSpoofing/uClientType;->cronetVersion:Ljava/lang/String;

    .line 58
    move-object/from16 v3, p8

    iput-object v3, p0, LuTools/uStreamSpoofing/uClientType;->deviceModel:Ljava/lang/String;

    .line 59
    move-object/from16 p2, p9

    iput-object p2, p0, LuTools/uStreamSpoofing/uClientType;->osBrand:Ljava/lang/String;

    .line 60
    move-object/from16 v4, p10

    iput-object v4, p0, LuTools/uStreamSpoofing/uClientType;->osBuildID:Ljava/lang/String;

    .line 61
    move-object/from16 v6, p11

    iput-object v6, p0, LuTools/uStreamSpoofing/uClientType;->osName:Ljava/lang/String;

    .line 62
    move-object/from16 v2, p12

    iput-object v2, p0, LuTools/uStreamSpoofing/uClientType;->osVersion:Ljava/lang/String;

    .line 63
    const-string v7, "%s/%s (Linux; U; Android %s; %s; Build/%s; Cronet/%s)"

    move-object v0, p5

    move-object v1, p6

    filled-new-array/range {v0 .. v5}, [Ljava/lang/Object;

    move-result-object v8

    invoke-static {v7, v8}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, LuTools/uStreamSpoofing/uClientType;->userAgent:Ljava/lang/String;

    .line 73
    return-void
.end method

.method public static valueOf(Ljava/lang/String;)LuTools/uStreamSpoofing/uClientType;
    .locals 1
    .param p0, "name"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            null
        }
    .end annotation

    .line 5
    const-class v0, LuTools/uStreamSpoofing/uClientType;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v0

    check-cast v0, LuTools/uStreamSpoofing/uClientType;

    return-object v0
.end method

.method public static values()[LuTools/uStreamSpoofing/uClientType;
    .locals 1

    .line 5
    sget-object v0, LuTools/uStreamSpoofing/uClientType;->$VALUES:[LuTools/uStreamSpoofing/uClientType;

    invoke-virtual {v0}, [LuTools/uStreamSpoofing/uClientType;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [LuTools/uStreamSpoofing/uClientType;

    return-object v0
.end method
