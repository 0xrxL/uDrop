.class public final enum LuTools/uStreamSpoofing/uClientType;
.super Ljava/lang/Enum;
.source "uClientType.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "LuTools/uStreamSpoofing/uClientType;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[LuTools/uStreamSpoofing/uClientType;

.field public static final enum ANDROID:LuTools/uStreamSpoofing/uClientType;

.field public static final enum ANDROID_CREATOR:LuTools/uStreamSpoofing/uClientType;

.field public static final enum ANDROID_VR:LuTools/uStreamSpoofing/uClientType;

.field public static final enum VISIONOS:LuTools/uStreamSpoofing/uClientType;


# instance fields
.field public final androidSDKVersion:Ljava/lang/String;

.field public final clientID:I

.field public final clientVersion:Ljava/lang/String;

.field public final deviceMake:Ljava/lang/String;

.field public final deviceModel:Ljava/lang/String;

.field public final osName:Ljava/lang/String;

.field public final osVersion:Ljava/lang/String;

.field public final useAuth:Z

.field public userAgent:Ljava/lang/String;


# direct methods
.method private static synthetic $values()[LuTools/uStreamSpoofing/uClientType;
    .locals 4

    .line 7
    sget-object v0, LuTools/uStreamSpoofing/uClientType;->ANDROID:LuTools/uStreamSpoofing/uClientType;

    sget-object v1, LuTools/uStreamSpoofing/uClientType;->ANDROID_CREATOR:LuTools/uStreamSpoofing/uClientType;

    sget-object v2, LuTools/uStreamSpoofing/uClientType;->ANDROID_VR:LuTools/uStreamSpoofing/uClientType;

    sget-object v3, LuTools/uStreamSpoofing/uClientType;->VISIONOS:LuTools/uStreamSpoofing/uClientType;

    filled-new-array {v0, v1, v2, v3}, [LuTools/uStreamSpoofing/uClientType;

    move-result-object v0

    return-object v0
.end method

.method static constructor <clinit>()V
    .locals 18

    .line 8
    new-instance v0, LuTools/uStreamSpoofing/uClientType;

    const/4 v13, 0x0

    const/4 v14, 0x0

    const-string v1, "ANDROID"

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    const-string v5, "com.google.android.youtube"

    const-string v6, "20.05.46"

    const-string v7, ""

    const-string v8, ""

    const-string v9, ""

    const-string v10, ""

    const-string v11, "Android"

    const-string v12, " 16;"

    invoke-direct/range {v0 .. v14}, LuTools/uStreamSpoofing/uClientType;-><init>(Ljava/lang/String;ILjava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)V

    sput-object v0, LuTools/uStreamSpoofing/uClientType;->ANDROID:LuTools/uStreamSpoofing/uClientType;

    .line 22
    new-instance v1, LuTools/uStreamSpoofing/uClientType;

    const/4 v14, 0x1

    const/4 v15, 0x0

    const-string v2, "ANDROID_CREATOR"

    const/4 v3, 0x1

    const-string v4, "35"

    const/16 v5, 0xe

    const-string v6, "com.google.android.apps.youtube.creator"

    const-string v7, "23.47.101"

    const-string v8, " Cronet/132.0.6779.0;"

    const-string v9, "Pixel 9 Pro Fold"

    const-string v10, " Google;"

    const-string v11, " Build/AP3A.241005.015.A2;"

    const-string v12, "Android"

    const-string v13, " 15;"

    invoke-direct/range {v1 .. v15}, LuTools/uStreamSpoofing/uClientType;-><init>(Ljava/lang/String;ILjava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)V

    sput-object v1, LuTools/uStreamSpoofing/uClientType;->ANDROID_CREATOR:LuTools/uStreamSpoofing/uClientType;

    .line 36
    new-instance v2, LuTools/uStreamSpoofing/uClientType;

    const/4 v15, 0x0

    const/16 v16, 0x0

    const-string v3, "ANDROID_VR"

    const/4 v4, 0x2

    const-string v5, "29"

    const/16 v6, 0x1c

    const-string v7, "com.google.android.apps.youtube.vr.oculus"

    const-string v8, "1.47.48"

    const-string v9, " Cronet/113.0.5672.24;"

    const-string v10, "Quest 3"

    const-string v11, " Oculus;"

    const-string v12, " Build/QQ3A.200805.001;"

    const-string v13, "Android"

    const-string v14, " 10;"

    invoke-direct/range {v2 .. v16}, LuTools/uStreamSpoofing/uClientType;-><init>(Ljava/lang/String;ILjava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)V

    sput-object v2, LuTools/uStreamSpoofing/uClientType;->ANDROID_VR:LuTools/uStreamSpoofing/uClientType;

    .line 50
    new-instance v3, LuTools/uStreamSpoofing/uClientType;

    const/16 v16, 0x0

    const-string v17, "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Safari/605.1.15"

    const-string v4, "VISIONOS"

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/16 v7, 0x65

    const/4 v8, 0x0

    const-string v9, "0.1"

    const/4 v10, 0x0

    const-string v11, "RealityDevice14,1"

    const-string v12, "Apple"

    const/4 v13, 0x0

    const-string v14, "visionOS"

    const-string v15, "1.3.21O771"

    invoke-direct/range {v3 .. v17}, LuTools/uStreamSpoofing/uClientType;-><init>(Ljava/lang/String;ILjava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)V

    sput-object v3, LuTools/uStreamSpoofing/uClientType;->VISIONOS:LuTools/uStreamSpoofing/uClientType;

    .line 7
    invoke-static {}, LuTools/uStreamSpoofing/uClientType;->$values()[LuTools/uStreamSpoofing/uClientType;

    move-result-object v0

    sput-object v0, LuTools/uStreamSpoofing/uClientType;->$VALUES:[LuTools/uStreamSpoofing/uClientType;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;ILjava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)V
    .locals 11
    .param p3, "androidSDKVersion"    # Ljava/lang/String;
    .param p4, "clientID"    # I
    .param p5, "clientPackageName"    # Ljava/lang/String;
    .param p6, "clientVersion"    # Ljava/lang/String;
    .param p7, "cronetVersion"    # Ljava/lang/String;
    .param p8, "deviceMake"    # Ljava/lang/String;
    .param p9, "deviceModel"    # Ljava/lang/String;
    .param p10, "osBuildID"    # Ljava/lang/String;
    .param p11, "osName"    # Ljava/lang/String;
    .param p12, "osVersion"    # Ljava/lang/String;
    .param p13, "useAuth"    # Z
    .param p14, "userAgent"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "I",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Z",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 74
    move-object/from16 v0, p11

    move-object/from16 v1, p14

    invoke-direct/range {p0 .. p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 73
    const-string p1, ""

    iput-object p1, p0, LuTools/uStreamSpoofing/uClientType;->userAgent:Ljava/lang/String;

    .line 75
    iput-object p3, p0, LuTools/uStreamSpoofing/uClientType;->androidSDKVersion:Ljava/lang/String;

    .line 76
    iput p4, p0, LuTools/uStreamSpoofing/uClientType;->clientID:I

    .line 77
    move-object/from16 v3, p6

    iput-object v3, p0, LuTools/uStreamSpoofing/uClientType;->clientVersion:Ljava/lang/String;

    .line 78
    move-object/from16 v8, p8

    iput-object v8, p0, LuTools/uStreamSpoofing/uClientType;->deviceMake:Ljava/lang/String;

    .line 79
    move-object/from16 v5, p9

    iput-object v5, p0, LuTools/uStreamSpoofing/uClientType;->deviceModel:Ljava/lang/String;

    .line 80
    iput-object v0, p0, LuTools/uStreamSpoofing/uClientType;->osName:Ljava/lang/String;

    .line 81
    move-object/from16 v4, p12

    iput-object v4, p0, LuTools/uStreamSpoofing/uClientType;->osVersion:Ljava/lang/String;

    .line 82
    move/from16 v9, p13

    iput-boolean v9, p0, LuTools/uStreamSpoofing/uClientType;->useAuth:Z

    .line 84
    if-nez v1, :cond_0

    .line 85
    const-string v2, "Android"

    invoke-static {v0, v2}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_1

    .line 86
    move-object/from16 v2, p5

    move-object/from16 v7, p7

    move-object/from16 v6, p10

    filled-new-array/range {v2 .. v7}, [Ljava/lang/Object;

    move-result-object v10

    .line 87
    const-string v2, "%s/%s (Linux; U; Android%s%s%s%s) gzip"

    invoke-static {v2, v10}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    iput-object v2, p0, LuTools/uStreamSpoofing/uClientType;->userAgent:Ljava/lang/String;

    goto :goto_0

    .line 99
    :cond_0
    iput-object v1, p0, LuTools/uStreamSpoofing/uClientType;->userAgent:Ljava/lang/String;

    .line 101
    :cond_1
    :goto_0
    return-void
.end method

.method public static valueOf(Ljava/lang/String;)LuTools/uStreamSpoofing/uClientType;
    .locals 1
    .param p0, "name"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            null
        }
    .end annotation

    .line 7
    const-class v0, LuTools/uStreamSpoofing/uClientType;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v0

    check-cast v0, LuTools/uStreamSpoofing/uClientType;

    return-object v0
.end method

.method public static values()[LuTools/uStreamSpoofing/uClientType;
    .locals 1

    .line 7
    sget-object v0, LuTools/uStreamSpoofing/uClientType;->$VALUES:[LuTools/uStreamSpoofing/uClientType;

    invoke-virtual {v0}, [LuTools/uStreamSpoofing/uClientType;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [LuTools/uStreamSpoofing/uClientType;

    return-object v0
.end method
