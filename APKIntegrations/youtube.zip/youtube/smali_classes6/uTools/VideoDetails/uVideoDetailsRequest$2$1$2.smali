.class LuTools/VideoDetails/uVideoDetailsRequest$2$1$2;
.super Lorg/json/JSONObject;
.source "uVideoDetailsRequest.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LuTools/VideoDetails/uVideoDetailsRequest$2$1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$2:LuTools/VideoDetails/uVideoDetailsRequest$2$1;


# direct methods
.method constructor <init>(LuTools/VideoDetails/uVideoDetailsRequest$2$1;)V
    .locals 2
    .param p1, "this$2"    # LuTools/VideoDetails/uVideoDetailsRequest$2$1;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lorg/json/JSONException;
        }
    .end annotation

    .line 96
    iput-object p1, p0, LuTools/VideoDetails/uVideoDetailsRequest$2$1$2;->this$2:LuTools/VideoDetails/uVideoDetailsRequest$2$1;

    invoke-direct {p0}, Lorg/json/JSONObject;-><init>()V

    .line 97
    const-string v0, "lockedSafetyMode"

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, LuTools/VideoDetails/uVideoDetailsRequest$2$1$2;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    .line 98
    return-void
.end method
