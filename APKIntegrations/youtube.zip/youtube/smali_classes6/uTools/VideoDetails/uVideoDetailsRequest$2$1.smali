.class LuTools/VideoDetails/uVideoDetailsRequest$2$1;
.super Lorg/json/JSONObject;
.source "uVideoDetailsRequest.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LuTools/VideoDetails/uVideoDetailsRequest$2;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:LuTools/VideoDetails/uVideoDetailsRequest$2;


# direct methods
.method constructor <init>(LuTools/VideoDetails/uVideoDetailsRequest$2;)V
    .locals 2
    .param p1, "this$1"    # LuTools/VideoDetails/uVideoDetailsRequest$2;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lorg/json/JSONException;
        }
    .end annotation

    .line 78
    iput-object p1, p0, LuTools/VideoDetails/uVideoDetailsRequest$2$1;->this$1:LuTools/VideoDetails/uVideoDetailsRequest$2;

    invoke-direct {p0}, Lorg/json/JSONObject;-><init>()V

    .line 79
    new-instance v0, LuTools/VideoDetails/uVideoDetailsRequest$2$1$1;

    invoke-direct {v0, p0}, LuTools/VideoDetails/uVideoDetailsRequest$2$1$1;-><init>(LuTools/VideoDetails/uVideoDetailsRequest$2$1;)V

    const-string v1, "client"

    invoke-virtual {p0, v1, v0}, LuTools/VideoDetails/uVideoDetailsRequest$2$1;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 94
    new-instance v0, LuTools/VideoDetails/uVideoDetailsRequest$2$1$2;

    invoke-direct {v0, p0}, LuTools/VideoDetails/uVideoDetailsRequest$2$1$2;-><init>(LuTools/VideoDetails/uVideoDetailsRequest$2$1;)V

    const-string v1, "user"

    invoke-virtual {p0, v1, v0}, LuTools/VideoDetails/uVideoDetailsRequest$2$1;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 101
    return-void
.end method
