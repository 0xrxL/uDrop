.class public final synthetic LuTools/VideoDetails/uVideoDetailsRequest$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/util/concurrent/Callable;


# instance fields
.field public final synthetic f$0:LuTools/VideoDetails/uVideoDetailsRequest;


# direct methods
.method public synthetic constructor <init>(LuTools/VideoDetails/uVideoDetailsRequest;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LuTools/VideoDetails/uVideoDetailsRequest$$ExternalSyntheticLambda0;->f$0:LuTools/VideoDetails/uVideoDetailsRequest;

    return-void
.end method


# virtual methods
.method public final call()Ljava/lang/Object;
    .locals 1

    .line 0
    iget-object v0, p0, LuTools/VideoDetails/uVideoDetailsRequest$$ExternalSyntheticLambda0;->f$0:LuTools/VideoDetails/uVideoDetailsRequest;

    invoke-static {v0}, LuTools/VideoDetails/uVideoDetailsRequest;->$r8$lambda$N78LXxngQ87bP8BJhSc5dUEKRPc(LuTools/VideoDetails/uVideoDetailsRequest;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
