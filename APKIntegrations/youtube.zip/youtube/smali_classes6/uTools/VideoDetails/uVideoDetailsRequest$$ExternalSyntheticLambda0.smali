.class public final synthetic LuTools/VideoDetails/uVideoDetailsRequest$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/util/concurrent/Callable;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "LuTools/VideoDetails/uVideoDetailsRequest;"
    method = "lambda$new$0"
    proto = "(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)Ljava/lang/String;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x13
    versionHash = "9aaf5f34c4c84da429ef7f8f6217a1817876f2618cfcf539aba3d7d5a0c703e0"
.end annotation


# instance fields
.field public final synthetic f$0:LuTools/VideoDetails/uVideoDetailsRequest;

.field public final synthetic f$1:Ljava/lang/String;

.field public final synthetic f$2:Ljava/util/Map;

.field public final synthetic f$3:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(LuTools/VideoDetails/uVideoDetailsRequest;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LuTools/VideoDetails/uVideoDetailsRequest$$ExternalSyntheticLambda0;->f$0:LuTools/VideoDetails/uVideoDetailsRequest;

    iput-object p2, p0, LuTools/VideoDetails/uVideoDetailsRequest$$ExternalSyntheticLambda0;->f$1:Ljava/lang/String;

    iput-object p3, p0, LuTools/VideoDetails/uVideoDetailsRequest$$ExternalSyntheticLambda0;->f$2:Ljava/util/Map;

    iput-object p4, p0, LuTools/VideoDetails/uVideoDetailsRequest$$ExternalSyntheticLambda0;->f$3:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final call()Ljava/lang/Object;
    .locals 4

    .line 0
    iget-object v0, p0, LuTools/VideoDetails/uVideoDetailsRequest$$ExternalSyntheticLambda0;->f$0:LuTools/VideoDetails/uVideoDetailsRequest;

    iget-object v1, p0, LuTools/VideoDetails/uVideoDetailsRequest$$ExternalSyntheticLambda0;->f$1:Ljava/lang/String;

    iget-object v2, p0, LuTools/VideoDetails/uVideoDetailsRequest$$ExternalSyntheticLambda0;->f$2:Ljava/util/Map;

    iget-object v3, p0, LuTools/VideoDetails/uVideoDetailsRequest$$ExternalSyntheticLambda0;->f$3:Ljava/lang/String;

    invoke-static {v0, v1, v2, v3}, LuTools/VideoDetails/uVideoDetailsRequest;->$r8$lambda$hIkEDm3ekSqxueZ5LhtxjAvWQxE(LuTools/VideoDetails/uVideoDetailsRequest;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
