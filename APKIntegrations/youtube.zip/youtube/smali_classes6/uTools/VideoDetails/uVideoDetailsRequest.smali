.class public LuTools/VideoDetails/uVideoDetailsRequest;
.super Ljava/lang/Object;
.source "uVideoDetailsRequest.java"


# instance fields
.field private final future:Ljava/util/concurrent/Future;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/Future<",
            "*>;"
        }
    .end annotation
.end field

.field private final infoTypes:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private requestBody:[B


# direct methods
.method public static synthetic $r8$lambda$hIkEDm3ekSqxueZ5LhtxjAvWQxE(LuTools/VideoDetails/uVideoDetailsRequest;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    invoke-direct {p0, p1, p2, p3}, LuTools/VideoDetails/uVideoDetailsRequest;->lambda$new$0(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)V
    .locals 2
    .param p1, "videoID"    # Ljava/lang/String;
    .param p3, "infoToFetch"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 39
    .local p2, "playerHeaders":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;"
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 32
    new-instance v0, LuTools/VideoDetails/uVideoDetailsRequest$1;

    invoke-direct {v0, p0}, LuTools/VideoDetails/uVideoDetailsRequest$1;-><init>(LuTools/VideoDetails/uVideoDetailsRequest;)V

    iput-object v0, p0, LuTools/VideoDetails/uVideoDetailsRequest;->infoTypes:Ljava/util/Map;

    .line 40
    sget-object v0, LuTools/uUtils;->BackgroundThreadPool:Ljava/util/concurrent/ThreadPoolExecutor;

    new-instance v1, LuTools/VideoDetails/uVideoDetailsRequest$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0, p3, p2, p1}, LuTools/VideoDetails/uVideoDetailsRequest$$ExternalSyntheticLambda0;-><init>(LuTools/VideoDetails/uVideoDetailsRequest;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Ljava/util/concurrent/ThreadPoolExecutor;->submit(Ljava/util/concurrent/Callable;)Ljava/util/concurrent/Future;

    move-result-object v0

    iput-object v0, p0, LuTools/VideoDetails/uVideoDetailsRequest;->future:Ljava/util/concurrent/Future;

    .line 208
    return-void
.end method

.method private static GetClassName()Ljava/lang/String;
    .locals 1

    .line 29
    const-class v0, LuTools/VideoDetails/uVideoDetailsRequest;

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private synthetic lambda$new$0(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)Ljava/lang/String;
    .locals 21
    .param p1, "infoToFetch"    # Ljava/lang/String;
    .param p2, "playerHeaders"    # Ljava/util/Map;
    .param p3, "videoID"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 42
    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    invoke-static {}, LuTools/VideoDetails/uVideoDetailsClients;->values()[LuTools/VideoDetails/uVideoDetailsClients;

    move-result-object v4

    array-length v5, v4

    const/4 v6, 0x0

    move v7, v6

    :goto_0
    if-ge v7, v5, :cond_a

    aget-object v8, v4, v7

    .line 43
    .local v8, "client":LuTools/VideoDetails/uVideoDetailsClients;
    iget-object v0, v8, LuTools/VideoDetails/uVideoDetailsClients;->infoToBindTo:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_9

    .line 44
    new-instance v0, LuTools/uStreamSpoofing/uRoute;

    sget-object v9, LuTools/uStreamSpoofing/uRoute$Method;->POST:LuTools/uStreamSpoofing/uRoute$Method;

    iget-object v10, v1, LuTools/VideoDetails/uVideoDetailsRequest;->infoTypes:Ljava/util/Map;

    .line 49
    invoke-interface {v10, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/String;

    .line 48
    const-string v11, "Cannot get the info type to fetch"

    invoke-static {v10, v11}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/String;

    invoke-direct {v0, v9, v10}, LuTools/uStreamSpoofing/uRoute;-><init>(LuTools/uStreamSpoofing/uRoute$Method;Ljava/lang/String;)V

    new-array v9, v6, [Ljava/lang/String;

    .line 53
    invoke-virtual {v0, v9}, LuTools/uStreamSpoofing/uRoute;->Compile([Ljava/lang/String;)LuTools/uStreamSpoofing/uRoute$CompiledRoute;

    move-result-object v0

    iget-object v9, v8, LuTools/VideoDetails/uVideoDetailsClients;->userAgent:Ljava/lang/String;

    iget v10, v8, LuTools/VideoDetails/uVideoDetailsClients;->clientID:I

    .line 58
    invoke-static {v10}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v10

    iget-object v11, v8, LuTools/VideoDetails/uVideoDetailsClients;->clientVersion:Ljava/lang/String;

    filled-new-array {v9, v10, v11}, [Ljava/lang/Object;

    move-result-object v9

    .line 55
    invoke-static {v9}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v9

    .line 44
    invoke-static {v0, v9}, LuTools/uStreamSpoofing/uPlayerRoutes;->GetPlayerResponseConnectionFromRoute(LuTools/uStreamSpoofing/uRoute$CompiledRoute;Ljava/util/List;)Ljava/net/HttpURLConnection;

    move-result-object v9

    .line 64
    .local v9, "connection":Ljava/net/HttpURLConnection;
    if-eqz v9, :cond_8

    .line 65
    if-eqz v3, :cond_0

    .line 66
    sget-object v0, LuTools/uStreamSpoofing/uPlayerRoutes;->requestKeys:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_1
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/String;

    .line 67
    .local v10, "requestKey":Ljava/lang/String;
    invoke-interface {v3, v10}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/lang/String;

    invoke-virtual {v9, v10, v11}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 68
    .end local v10    # "requestKey":Ljava/lang/String;
    goto :goto_1

    .line 71
    :cond_0
    new-instance v0, LuTools/VideoDetails/uVideoDetailsRequest$2;

    move-object/from16 v10, p3

    invoke-direct {v0, v1, v8, v10, v2}, LuTools/VideoDetails/uVideoDetailsRequest$2;-><init>(LuTools/VideoDetails/uVideoDetailsRequest;LuTools/VideoDetails/uVideoDetailsClients;Ljava/lang/String;Ljava/lang/String;)V

    .line 123
    invoke-virtual {v0}, LuTools/VideoDetails/uVideoDetailsRequest$2;->toString()Ljava/lang/String;

    move-result-object v0

    sget-object v11, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    .line 124
    invoke-virtual {v0, v11}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v0

    iput-object v0, v1, LuTools/VideoDetails/uVideoDetailsRequest;->requestBody:[B

    .line 126
    iget-object v0, v1, LuTools/VideoDetails/uVideoDetailsRequest;->requestBody:[B

    array-length v0, v0

    invoke-virtual {v9, v0}, Ljava/net/HttpURLConnection;->setFixedLengthStreamingMode(I)V

    .line 127
    invoke-virtual {v9}, Ljava/net/HttpURLConnection;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v0

    iget-object v11, v1, LuTools/VideoDetails/uVideoDetailsRequest;->requestBody:[B

    invoke-virtual {v0, v11}, Ljava/io/OutputStream;->write([B)V

    .line 129
    invoke-virtual {v9}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v0

    const/16 v11, 0xc8

    if-ne v0, v11, :cond_7

    .line 130
    :try_start_0
    new-instance v0, Ljava/io/BufferedReader;

    new-instance v11, Ljava/io/InputStreamReader;

    .line 132
    invoke-virtual {v9}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v12

    invoke-direct {v11, v12}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    invoke-direct {v0, v11}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    move-object v11, v0

    .line 135
    .local v11, "reader":Ljava/io/BufferedReader;
    :try_start_1
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 138
    .local v0, "jsonBuilder":Ljava/lang/StringBuilder;
    :goto_2
    invoke-virtual {v11}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v12
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    move-object v13, v12

    .local v13, "line":Ljava/lang/String;
    if-eqz v12, :cond_1

    .line 139
    :try_start_2
    const-string v12, "%s\n"

    filled-new-array {v13}, [Ljava/lang/Object;

    move-result-object v14

    .line 140
    invoke-static {v12, v14}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v12

    .line 139
    invoke-virtual {v0, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    goto :goto_2

    .line 130
    .end local v0    # "jsonBuilder":Ljava/lang/StringBuilder;
    .end local v13    # "line":Ljava/lang/String;
    :catchall_0
    move-exception v0

    move-object v1, v0

    move/from16 v16, v6

    goto/16 :goto_8

    .line 148
    .restart local v0    # "jsonBuilder":Ljava/lang/StringBuilder;
    .restart local v13    # "line":Ljava/lang/String;
    :cond_1
    :try_start_3
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    .line 149
    .local v12, "jsonBuilderString":Ljava/lang/String;
    new-instance v14, Lorg/json/JSONObject;

    invoke-direct {v14, v12}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 151
    .local v14, "jsonResponse":Lorg/json/JSONObject;
    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v15
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    sparse-switch v15, :sswitch_data_0

    :cond_2
    goto :goto_3

    :sswitch_0
    :try_start_4
    const-string v15, "defaultAudioTrackID"

    invoke-virtual {v2, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v15

    if-eqz v15, :cond_2

    const/4 v15, 0x1

    goto :goto_4

    :sswitch_1
    const-string v15, "channelID"

    invoke-virtual {v2, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v15

    if-eqz v15, :cond_2

    move v15, v6

    goto :goto_4

    :sswitch_2
    const-string v15, "saveVideoToWatchLater"

    invoke-virtual {v2, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v15
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    if-eqz v15, :cond_2

    const/4 v15, 0x2

    goto :goto_4

    :goto_3
    const/4 v15, -0x1

    :goto_4
    packed-switch v15, :pswitch_data_0

    move-object/from16 v18, v0

    move/from16 v16, v6

    .end local v0    # "jsonBuilder":Ljava/lang/StringBuilder;
    .local v18, "jsonBuilder":Ljava/lang/StringBuilder;
    goto/16 :goto_6

    .line 190
    .end local v18    # "jsonBuilder":Ljava/lang/StringBuilder;
    .restart local v0    # "jsonBuilder":Ljava/lang/StringBuilder;
    :pswitch_0
    nop

    .line 193
    :try_start_5
    invoke-virtual {v11}, Ljava/io/BufferedReader;->close()V
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_1

    .line 190
    return-object v12

    .line 159
    :pswitch_1
    :try_start_6
    const-string v15, "streamingData"

    .line 161
    invoke-virtual {v14, v15}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v15
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    move/from16 v16, v6

    :try_start_7
    const-string v6, "adaptiveFormats"

    .line 162
    invoke-virtual {v15, v6}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v6

    .line 164
    .local v6, "availableAudioTracks":Lorg/json/JSONArray;
    const-string v15, "audioTrack"

    .line 166
    .local v15, "audioTrackNodeName":Ljava/lang/String;
    const/16 v17, 0x0

    move-object/from16 v18, v0

    move/from16 v0, v17

    .local v0, "i":I
    .restart local v18    # "jsonBuilder":Ljava/lang/StringBuilder;
    :goto_5
    invoke-virtual {v6}, Lorg/json/JSONArray;->length()I

    move-result v1

    if-ge v0, v1, :cond_6

    .line 167
    nop

    .line 168
    invoke-virtual {v6, v0}, Lorg/json/JSONArray;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lorg/json/JSONObject;

    .line 170
    .local v1, "rootAudioTrack":Lorg/json/JSONObject;
    invoke-virtual {v1, v15}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v17

    if-eqz v17, :cond_4

    .line 171
    nop

    .line 173
    invoke-virtual {v1, v15}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v17

    move-object/from16 v19, v17

    .line 175
    .local v19, "audioTrack":Lorg/json/JSONObject;
    move/from16 v17, v0

    .end local v0    # "i":I
    .local v17, "i":I
    const-string v0, "id"

    .line 176
    move-object/from16 v20, v1

    move-object/from16 v1, v19

    .end local v19    # "audioTrack":Lorg/json/JSONObject;
    .local v1, "audioTrack":Lorg/json/JSONObject;
    .local v20, "rootAudioTrack":Lorg/json/JSONObject;
    invoke-virtual {v1, v0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 178
    .local v0, "audioTrackID":Ljava/lang/String;
    const-string v2, "displayName"

    .line 179
    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    move-object/from16 v19, v1

    .end local v1    # "audioTrack":Lorg/json/JSONObject;
    .restart local v19    # "audioTrack":Lorg/json/JSONObject;
    const-string v1, "original"

    .line 180
    invoke-virtual {v2, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_3

    const-string v1, ".4"

    .line 182
    invoke-virtual {v0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_5

    .line 183
    :cond_3
    const-string v1, "\\."

    invoke-virtual {v0, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    aget-object v1, v1, v16
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_1

    .line 193
    :try_start_8
    invoke-virtual {v11}, Ljava/io/BufferedReader;->close()V
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_0

    .line 183
    return-object v1

    .line 170
    .end local v17    # "i":I
    .end local v19    # "audioTrack":Lorg/json/JSONObject;
    .end local v20    # "rootAudioTrack":Lorg/json/JSONObject;
    .local v0, "i":I
    .local v1, "rootAudioTrack":Lorg/json/JSONObject;
    :cond_4
    move/from16 v17, v0

    move-object/from16 v20, v1

    .line 166
    .end local v0    # "i":I
    .end local v1    # "rootAudioTrack":Lorg/json/JSONObject;
    .restart local v17    # "i":I
    :cond_5
    add-int/lit8 v0, v17, 0x1

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    .end local v17    # "i":I
    .restart local v0    # "i":I
    goto :goto_5

    :cond_6
    move/from16 v17, v0

    .line 187
    .end local v0    # "i":I
    .end local v6    # "availableAudioTracks":Lorg/json/JSONArray;
    .end local v15    # "audioTrackNodeName":Ljava/lang/String;
    goto :goto_6

    .line 153
    .end local v18    # "jsonBuilder":Ljava/lang/StringBuilder;
    .local v0, "jsonBuilder":Ljava/lang/StringBuilder;
    :pswitch_2
    move-object/from16 v18, v0

    move/from16 v16, v6

    .end local v0    # "jsonBuilder":Ljava/lang/StringBuilder;
    .restart local v18    # "jsonBuilder":Ljava/lang/StringBuilder;
    :try_start_9
    const-string v0, "videoDetails"

    .line 154
    invoke-virtual {v14, v0}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    const-string v1, "channelId"

    .line 155
    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_1

    .line 193
    :try_start_a
    invoke-virtual {v11}, Ljava/io/BufferedReader;->close()V

    .line 153
    return-object v0

    .line 130
    .end local v12    # "jsonBuilderString":Ljava/lang/String;
    .end local v13    # "line":Ljava/lang/String;
    .end local v14    # "jsonResponse":Lorg/json/JSONObject;
    .end local v18    # "jsonBuilder":Ljava/lang/StringBuilder;
    :catchall_1
    move-exception v0

    goto :goto_7

    .line 193
    :goto_6
    invoke-virtual {v11}, Ljava/io/BufferedReader;->close()V
    :try_end_a
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_a} :catch_0

    .line 199
    .end local v11    # "reader":Ljava/io/BufferedReader;
    goto :goto_b

    .line 130
    .restart local v11    # "reader":Ljava/io/BufferedReader;
    :catchall_2
    move-exception v0

    move/from16 v16, v6

    :goto_7
    move-object v1, v0

    :goto_8
    :try_start_b
    invoke-virtual {v11}, Ljava/io/BufferedReader;->close()V
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_3

    goto :goto_9

    :catchall_3
    move-exception v0

    :try_start_c
    invoke-virtual {v1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .end local v8    # "client":LuTools/VideoDetails/uVideoDetailsClients;
    .end local v9    # "connection":Ljava/net/HttpURLConnection;
    .end local p0    # "this":LuTools/VideoDetails/uVideoDetailsRequest;
    .end local p1    # "infoToFetch":Ljava/lang/String;
    .end local p2    # "playerHeaders":Ljava/util/Map;
    .end local p3    # "videoID":Ljava/lang/String;
    :goto_9
    throw v1
    :try_end_c
    .catch Ljava/lang/Exception; {:try_start_c .. :try_end_c} :catch_0

    .line 193
    .end local v11    # "reader":Ljava/io/BufferedReader;
    .restart local v8    # "client":LuTools/VideoDetails/uVideoDetailsClients;
    .restart local v9    # "connection":Ljava/net/HttpURLConnection;
    .restart local p0    # "this":LuTools/VideoDetails/uVideoDetailsRequest;
    .restart local p1    # "infoToFetch":Ljava/lang/String;
    .restart local p2    # "playerHeaders":Ljava/util/Map;
    .restart local p3    # "videoID":Ljava/lang/String;
    :catch_0
    move-exception v0

    goto :goto_a

    :catch_1
    move-exception v0

    move/from16 v16, v6

    .line 195
    .local v0, "e":Ljava/lang/Exception;
    :goto_a
    invoke-static {}, LuTools/VideoDetails/uVideoDetailsRequest;->GetClassName()Ljava/lang/String;

    move-result-object v1

    .line 197
    invoke-virtual {v0}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v2

    .line 194
    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_b

    .line 129
    .end local v0    # "e":Ljava/lang/Exception;
    :cond_7
    move/from16 v16, v6

    goto :goto_b

    .line 64
    :cond_8
    move-object/from16 v10, p3

    move/from16 v16, v6

    goto :goto_b

    .line 43
    .end local v9    # "connection":Ljava/net/HttpURLConnection;
    :cond_9
    move-object/from16 v10, p3

    move/from16 v16, v6

    .line 42
    .end local v8    # "client":LuTools/VideoDetails/uVideoDetailsClients;
    :goto_b
    add-int/lit8 v7, v7, 0x1

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move/from16 v6, v16

    goto/16 :goto_0

    .line 205
    :cond_a
    move-object/from16 v10, p3

    const/4 v0, 0x0

    return-object v0

    nop

    :sswitch_data_0
    .sparse-switch
        -0x74b86c0a -> :sswitch_2
        0x5720515e -> :sswitch_1
        0x59e5c3d1 -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method


# virtual methods
.method public GetRequestedInfo()Ljava/lang/Object;
    .locals 4

    .line 212
    :try_start_0
    iget-object v0, p0, LuTools/VideoDetails/uVideoDetailsRequest;->future:Ljava/util/concurrent/Future;

    sget-object v1, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v2, 0x2710

    invoke-interface {v0, v2, v3, v1}, Ljava/util/concurrent/Future;->get(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    .line 213
    :catch_0
    move-exception v0

    .line 215
    .local v0, "e":Ljava/lang/Exception;
    invoke-static {}, LuTools/VideoDetails/uVideoDetailsRequest;->GetClassName()Ljava/lang/String;

    move-result-object v1

    .line 217
    invoke-virtual {v0}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v2

    .line 214
    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 220
    const/4 v1, 0x0

    return-object v1
.end method
