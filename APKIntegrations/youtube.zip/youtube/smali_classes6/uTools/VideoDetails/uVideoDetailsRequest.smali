.class public LuTools/VideoDetails/uVideoDetailsRequest;
.super Ljava/lang/Object;
.source "uVideoDetailsRequest.java"


# instance fields
.field private final future:Ljava/util/concurrent/Future;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/Future<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final infoTypes:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static synthetic $r8$lambda$hIkEDm3ekSqxueZ5LhtxjAvWQxE(LuTools/VideoDetails/uVideoDetailsRequest;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    invoke-direct {p0, p1, p2, p3}, LuTools/VideoDetails/uVideoDetailsRequest;->lambda$new$0(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)V
    .locals 2
    .param p1, "videoID"    # Ljava/lang/String;
    .param p3, "infoToFetch"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 37
    .local p2, "playerHeaders":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;"
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 31
    new-instance v0, LuTools/VideoDetails/uVideoDetailsRequest$1;

    invoke-direct {v0, p0}, LuTools/VideoDetails/uVideoDetailsRequest$1;-><init>(LuTools/VideoDetails/uVideoDetailsRequest;)V

    iput-object v0, p0, LuTools/VideoDetails/uVideoDetailsRequest;->infoTypes:Ljava/util/Map;

    .line 38
    sget-object v0, LuTools/uUtils;->BackgroundThreadPool:Ljava/util/concurrent/ThreadPoolExecutor;

    new-instance v1, LuTools/VideoDetails/uVideoDetailsRequest$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0, p3, p2, p1}, LuTools/VideoDetails/uVideoDetailsRequest$$ExternalSyntheticLambda0;-><init>(LuTools/VideoDetails/uVideoDetailsRequest;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Ljava/util/concurrent/ThreadPoolExecutor;->submit(Ljava/util/concurrent/Callable;)Ljava/util/concurrent/Future;

    move-result-object v0

    iput-object v0, p0, LuTools/VideoDetails/uVideoDetailsRequest;->future:Ljava/util/concurrent/Future;

    .line 157
    return-void
.end method

.method private synthetic lambda$new$0(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)Ljava/lang/String;
    .locals 20
    .param p1, "infoToFetch"    # Ljava/lang/String;
    .param p2, "playerHeaders"    # Ljava/util/Map;
    .param p3, "videoID"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 40
    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    invoke-static {}, LuTools/VideoDetails/uVideoDetailsClients;->values()[LuTools/VideoDetails/uVideoDetailsClients;

    move-result-object v4

    array-length v5, v4

    const/4 v6, 0x0

    move v7, v6

    :goto_0
    if-ge v7, v5, :cond_9

    aget-object v8, v4, v7

    .line 41
    .local v8, "client":LuTools/VideoDetails/uVideoDetailsClients;
    iget-object v0, v8, LuTools/VideoDetails/uVideoDetailsClients;->infoToBindTo:Ljava/lang/String;

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_8

    .line 42
    new-instance v0, LuTools/uStreamSpoofing/uRoute;

    sget-object v9, LuTools/uStreamSpoofing/uRoute$Method;->POST:LuTools/uStreamSpoofing/uRoute$Method;

    iget-object v10, v1, LuTools/VideoDetails/uVideoDetailsRequest;->infoTypes:Ljava/util/Map;

    .line 47
    invoke-interface {v10, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/String;

    .line 46
    const-string v11, "Cannot get the info type to fetch"

    invoke-static {v10, v11}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/String;

    invoke-direct {v0, v9, v10}, LuTools/uStreamSpoofing/uRoute;-><init>(LuTools/uStreamSpoofing/uRoute$Method;Ljava/lang/String;)V

    new-array v9, v6, [Ljava/lang/String;

    .line 51
    invoke-virtual {v0, v9}, LuTools/uStreamSpoofing/uRoute;->Compile([Ljava/lang/String;)LuTools/uStreamSpoofing/uRoute$CompiledRoute;

    move-result-object v0

    iget-object v9, v8, LuTools/VideoDetails/uVideoDetailsClients;->userAgent:Ljava/lang/String;

    iget v10, v8, LuTools/VideoDetails/uVideoDetailsClients;->clientID:I

    .line 55
    invoke-static {v10}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v10

    iget-object v11, v8, LuTools/VideoDetails/uVideoDetailsClients;->clientVersion:Ljava/lang/String;

    filled-new-array {v9, v10, v11}, [Ljava/lang/Object;

    move-result-object v9

    .line 53
    invoke-static {v9}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v9

    .line 42
    invoke-static {v0, v9}, LuTools/uStreamSpoofing/uPlayerRoutes;->GetPlayerResponseConnectionFromRoute(LuTools/uStreamSpoofing/uRoute$CompiledRoute;Ljava/util/List;)Ljava/net/HttpURLConnection;

    move-result-object v9

    .line 60
    .local v9, "connection":Ljava/net/HttpURLConnection;
    if-eqz v9, :cond_7

    .line 61
    if-eqz v3, :cond_0

    .line 62
    sget-object v0, LuTools/uStreamSpoofing/uPlayerRoutes;->requestKeys:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_1
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/String;

    .line 63
    .local v10, "requestKey":Ljava/lang/String;
    invoke-interface {v3, v10}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/lang/String;

    invoke-virtual {v9, v10, v11}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 64
    .end local v10    # "requestKey":Ljava/lang/String;
    goto :goto_1

    .line 67
    :cond_0
    new-instance v0, LuTools/VideoDetails/uVideoDetailsRequest$2;

    move-object/from16 v10, p3

    invoke-direct {v0, v1, v8, v10}, LuTools/VideoDetails/uVideoDetailsRequest$2;-><init>(LuTools/VideoDetails/uVideoDetailsRequest;LuTools/VideoDetails/uVideoDetailsClients;Ljava/lang/String;)V

    move-object v11, v0

    .line 87
    .local v11, "innerTubeBody":Lorg/json/JSONObject;
    invoke-virtual {v11}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0

    sget-object v12, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {v0, v12}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v12

    .line 88
    .local v12, "requestBody":[B
    array-length v0, v12

    invoke-virtual {v9, v0}, Ljava/net/HttpURLConnection;->setFixedLengthStreamingMode(I)V

    .line 89
    invoke-virtual {v9}, Ljava/net/HttpURLConnection;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v0

    invoke-virtual {v0, v12}, Ljava/io/OutputStream;->write([B)V

    .line 91
    invoke-virtual {v9}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v0

    const/16 v13, 0xc8

    if-ne v0, v13, :cond_6

    .line 92
    :try_start_0
    new-instance v0, Ljava/io/BufferedReader;

    new-instance v13, Ljava/io/InputStreamReader;

    .line 94
    invoke-virtual {v9}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v14

    invoke-direct {v13, v14}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    invoke-direct {v0, v13}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_4

    move-object v13, v0

    .line 98
    .local v13, "reader":Ljava/io/BufferedReader;
    :try_start_1
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    move-object v14, v0

    .line 101
    .local v14, "jsonBuilder":Ljava/lang/StringBuilder;
    :goto_2
    invoke-virtual {v13}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v0

    move-object v15, v0

    .local v15, "line":Ljava/lang/String;
    if-eqz v0, :cond_1

    .line 102
    const-string v0, "%s%s"
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 107
    const/16 v16, 0xa

    move/from16 v17, v6

    :try_start_2
    invoke-static/range {v16 .. v16}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v6

    filled-new-array {v15, v6}, [Ljava/lang/Object;

    move-result-object v6

    .line 103
    invoke-static {v0, v6}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    .line 102
    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move/from16 v6, v17

    goto :goto_2

    .line 112
    :cond_1
    move/from16 v17, v6

    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v0

    sparse-switch v0, :sswitch_data_0

    :cond_2
    goto :goto_3

    :sswitch_0
    const-string v0, "defaultAudioTrackID"

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    const/4 v0, 0x1

    goto :goto_4

    :sswitch_1
    const-string v0, "channelID"

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    move/from16 v0, v17

    goto :goto_4

    :goto_3
    const/4 v0, -0x1

    :goto_4
    packed-switch v0, :pswitch_data_0

    goto/16 :goto_8

    .line 120
    :pswitch_0
    new-instance v0, Lorg/json/JSONObject;

    .line 121
    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v0, v6}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string v6, "streamingData"

    .line 122
    invoke-virtual {v0, v6}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    const-string v6, "adaptiveFormats"

    .line 123
    invoke-virtual {v0, v6}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v0

    move-object v6, v0

    .line 125
    .local v6, "availableAudioTracks":Lorg/json/JSONArray;
    const/4 v0, 0x0

    move v1, v0

    .local v1, "i":I
    :goto_5
    invoke-virtual {v6}, Lorg/json/JSONArray;->length()I

    move-result v0

    if-ge v1, v0, :cond_5

    .line 126
    nop

    .line 127
    invoke-virtual {v6, v1}, Lorg/json/JSONArray;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lorg/json/JSONObject;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    move-object/from16 v16, v0

    .line 130
    .local v16, "rootAudioTrack":Lorg/json/JSONObject;
    :try_start_3
    const-string v0, "audioTrack"
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 132
    move/from16 v18, v1

    move-object/from16 v1, v16

    .end local v16    # "rootAudioTrack":Lorg/json/JSONObject;
    .local v1, "rootAudioTrack":Lorg/json/JSONObject;
    .local v18, "i":I
    :try_start_4
    invoke-virtual {v1, v0}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_1
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    .line 134
    .local v0, "audioTrack":Lorg/json/JSONObject;
    move-object/from16 v16, v1

    .end local v1    # "rootAudioTrack":Lorg/json/JSONObject;
    .restart local v16    # "rootAudioTrack":Lorg/json/JSONObject;
    :try_start_5
    const-string v1, "id"

    .line 135
    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 137
    .local v1, "audioTrackID":Ljava/lang/String;
    const-string v2, "displayName"

    .line 138
    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    move-object/from16 v19, v0

    .end local v0    # "audioTrack":Lorg/json/JSONObject;
    .local v19, "audioTrack":Lorg/json/JSONObject;
    const-string v0, "original"

    .line 139
    invoke-virtual {v2, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_4

    const-string v0, ".4"

    .line 141
    invoke-virtual {v1, v0}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_3

    goto :goto_6

    .end local v1    # "audioTrackID":Ljava/lang/String;
    .end local v19    # "audioTrack":Lorg/json/JSONObject;
    :cond_3
    goto :goto_7

    .line 142
    .restart local v1    # "audioTrackID":Ljava/lang/String;
    .restart local v19    # "audioTrack":Lorg/json/JSONObject;
    :cond_4
    :goto_6
    const-string v0, "\\."

    invoke-virtual {v1, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    aget-object v0, v0, v17
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_0
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    .line 148
    :try_start_6
    invoke-virtual {v13}, Ljava/io/BufferedReader;->close()V
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_3

    .line 142
    return-object v0

    .line 144
    .end local v1    # "audioTrackID":Ljava/lang/String;
    .end local v19    # "audioTrack":Lorg/json/JSONObject;
    :catch_0
    move-exception v0

    goto :goto_7

    .end local v16    # "rootAudioTrack":Lorg/json/JSONObject;
    .local v1, "rootAudioTrack":Lorg/json/JSONObject;
    :catch_1
    move-exception v0

    move-object/from16 v16, v1

    .end local v1    # "rootAudioTrack":Lorg/json/JSONObject;
    .restart local v16    # "rootAudioTrack":Lorg/json/JSONObject;
    goto :goto_7

    .end local v18    # "i":I
    .local v1, "i":I
    :catch_2
    move-exception v0

    move/from16 v18, v1

    .end local v1    # "i":I
    .restart local v18    # "i":I
    :goto_7
    nop

    .line 125
    .end local v16    # "rootAudioTrack":Lorg/json/JSONObject;
    add-int/lit8 v1, v18, 0x1

    move-object/from16 v2, p1

    .end local v18    # "i":I
    .restart local v1    # "i":I
    goto :goto_5

    :cond_5
    move/from16 v18, v1

    .end local v1    # "i":I
    .restart local v18    # "i":I
    goto :goto_8

    .line 114
    .end local v6    # "availableAudioTracks":Lorg/json/JSONArray;
    .end local v18    # "i":I
    :pswitch_1
    :try_start_7
    new-instance v0, Lorg/json/JSONObject;

    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string v1, "videoDetails"

    .line 115
    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    const-string v1, "channelId"

    .line 116
    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_0

    .line 148
    :try_start_8
    invoke-virtual {v13}, Ljava/io/BufferedReader;->close()V

    .line 114
    return-object v0

    .line 148
    .end local v14    # "jsonBuilder":Ljava/lang/StringBuilder;
    .end local v15    # "line":Ljava/lang/String;
    :goto_8
    invoke-virtual {v13}, Ljava/io/BufferedReader;->close()V
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_3

    goto :goto_b

    .line 92
    :catchall_0
    move-exception v0

    goto :goto_9

    :catchall_1
    move-exception v0

    move/from16 v17, v6

    :goto_9
    move-object v1, v0

    :try_start_9
    invoke-virtual {v13}, Ljava/io/BufferedReader;->close()V
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_2

    goto :goto_a

    :catchall_2
    move-exception v0

    :try_start_a
    invoke-virtual {v1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .end local v8    # "client":LuTools/VideoDetails/uVideoDetailsClients;
    .end local v9    # "connection":Ljava/net/HttpURLConnection;
    .end local v11    # "innerTubeBody":Lorg/json/JSONObject;
    .end local v12    # "requestBody":[B
    .end local p0    # "this":LuTools/VideoDetails/uVideoDetailsRequest;
    .end local p1    # "infoToFetch":Ljava/lang/String;
    .end local p2    # "playerHeaders":Ljava/util/Map;
    .end local p3    # "videoID":Ljava/lang/String;
    :goto_a
    throw v1
    :try_end_a
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_a} :catch_3

    .line 148
    .end local v13    # "reader":Ljava/io/BufferedReader;
    .restart local v8    # "client":LuTools/VideoDetails/uVideoDetailsClients;
    .restart local v9    # "connection":Ljava/net/HttpURLConnection;
    .restart local v11    # "innerTubeBody":Lorg/json/JSONObject;
    .restart local v12    # "requestBody":[B
    .restart local p0    # "this":LuTools/VideoDetails/uVideoDetailsRequest;
    .restart local p1    # "infoToFetch":Ljava/lang/String;
    .restart local p2    # "playerHeaders":Ljava/util/Map;
    .restart local p3    # "videoID":Ljava/lang/String;
    :catch_3
    move-exception v0

    goto :goto_b

    :catch_4
    move-exception v0

    move/from16 v17, v6

    goto :goto_b

    .line 91
    :cond_6
    move/from16 v17, v6

    goto :goto_b

    .line 60
    .end local v11    # "innerTubeBody":Lorg/json/JSONObject;
    .end local v12    # "requestBody":[B
    :cond_7
    move-object/from16 v10, p3

    move/from16 v17, v6

    goto :goto_b

    .line 41
    .end local v9    # "connection":Ljava/net/HttpURLConnection;
    :cond_8
    move-object/from16 v10, p3

    move/from16 v17, v6

    .line 40
    .end local v8    # "client":LuTools/VideoDetails/uVideoDetailsClients;
    :goto_b
    add-int/lit8 v7, v7, 0x1

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move/from16 v6, v17

    goto/16 :goto_0

    .line 154
    :cond_9
    move-object/from16 v10, p3

    const-string v0, ""

    return-object v0

    :sswitch_data_0
    .sparse-switch
        0x5720515e -> :sswitch_1
        0x59e5c3d1 -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method


# virtual methods
.method public GetRequestedInfo()Ljava/lang/String;
    .locals 4

    .line 161
    :try_start_0
    iget-object v0, p0, LuTools/VideoDetails/uVideoDetailsRequest;->future:Ljava/util/concurrent/Future;

    sget-object v1, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v2, 0x4e20

    invoke-interface {v0, v2, v3, v1}, Ljava/util/concurrent/Future;->get(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;
    :try_end_0
    .catch Ljava/util/concurrent/TimeoutException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    .line 162
    :catch_0
    move-exception v0

    .line 164
    const/4 v0, 0x0

    return-object v0
.end method
