.class public LuTools/VideoDetails/uVideoDetailsRequest;
.super Ljava/lang/Object;
.source "uVideoDetailsRequest.java"


# instance fields
.field private final future:Ljava/util/concurrent/Future;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/Future<",
            "*>;"
        }
    .end annotation
.end field

.field private final infoTypes:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static synthetic $r8$lambda$56ZFA34RrDRknqW7fNmeAdB1EuA(LuTools/VideoDetails/uVideoDetailsRequest;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)Ljava/lang/Object;
    .locals 0

    invoke-direct {p0, p1, p2, p3}, LuTools/VideoDetails/uVideoDetailsRequest;->lambda$new$0(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)V
    .locals 2
    .param p1, "videoID"    # Ljava/lang/String;
    .param p3, "infoToFetch"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 40
    .local p2, "playerHeaders":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;"
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 33
    new-instance v0, LuTools/VideoDetails/uVideoDetailsRequest$1;

    invoke-direct {v0, p0}, LuTools/VideoDetails/uVideoDetailsRequest$1;-><init>(LuTools/VideoDetails/uVideoDetailsRequest;)V

    iput-object v0, p0, LuTools/VideoDetails/uVideoDetailsRequest;->infoTypes:Ljava/util/Map;

    .line 41
    sget-object v0, LuTools/uUtils;->BackgroundThreadPool:Ljava/util/concurrent/ThreadPoolExecutor;

    new-instance v1, LuTools/VideoDetails/uVideoDetailsRequest$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0, p3, p2, p1}, LuTools/VideoDetails/uVideoDetailsRequest$$ExternalSyntheticLambda0;-><init>(LuTools/VideoDetails/uVideoDetailsRequest;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Ljava/util/concurrent/ThreadPoolExecutor;->submit(Ljava/util/concurrent/Callable;)Ljava/util/concurrent/Future;

    move-result-object v0

    iput-object v0, p0, LuTools/VideoDetails/uVideoDetailsRequest;->future:Ljava/util/concurrent/Future;

    .line 217
    return-void
.end method

.method private synthetic lambda$new$0(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)Ljava/lang/Object;
    .locals 25
    .param p1, "infoToFetch"    # Ljava/lang/String;
    .param p2, "playerHeaders"    # Ljava/util/Map;
    .param p3, "videoID"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 43
    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    const-string v4, "results"

    const-string v5, "contents"

    invoke-static {}, LuTools/VideoDetails/uVideoDetailsClients;->values()[LuTools/VideoDetails/uVideoDetailsClients;

    move-result-object v6

    array-length v7, v6

    const/4 v8, 0x0

    move v9, v8

    :goto_0
    if-ge v9, v7, :cond_c

    aget-object v10, v6, v9

    .line 44
    .local v10, "client":LuTools/VideoDetails/uVideoDetailsClients;
    iget-object v0, v10, LuTools/VideoDetails/uVideoDetailsClients;->infoToBindTo:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_b

    .line 45
    new-instance v0, LuTools/uStreamSpoofing/uRoute;

    sget-object v11, LuTools/uStreamSpoofing/uRoute$Method;->POST:LuTools/uStreamSpoofing/uRoute$Method;

    iget-object v12, v1, LuTools/VideoDetails/uVideoDetailsRequest;->infoTypes:Ljava/util/Map;

    .line 50
    invoke-interface {v12, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/lang/String;

    .line 49
    const-string v13, "Cannot get the info type to fetch"

    invoke-static {v12, v13}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/lang/String;

    invoke-direct {v0, v11, v12}, LuTools/uStreamSpoofing/uRoute;-><init>(LuTools/uStreamSpoofing/uRoute$Method;Ljava/lang/String;)V

    new-array v11, v8, [Ljava/lang/String;

    .line 54
    invoke-virtual {v0, v11}, LuTools/uStreamSpoofing/uRoute;->Compile([Ljava/lang/String;)LuTools/uStreamSpoofing/uRoute$CompiledRoute;

    move-result-object v0

    iget-object v11, v10, LuTools/VideoDetails/uVideoDetailsClients;->userAgent:Ljava/lang/String;

    iget v12, v10, LuTools/VideoDetails/uVideoDetailsClients;->clientID:I

    .line 58
    invoke-static {v12}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v12

    iget-object v13, v10, LuTools/VideoDetails/uVideoDetailsClients;->clientVersion:Ljava/lang/String;

    filled-new-array {v11, v12, v13}, [Ljava/lang/Object;

    move-result-object v11

    .line 56
    invoke-static {v11}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v11

    .line 45
    invoke-static {v0, v11}, LuTools/uStreamSpoofing/uPlayerRoutes;->GetPlayerResponseConnectionFromRoute(LuTools/uStreamSpoofing/uRoute$CompiledRoute;Ljava/util/List;)Ljava/net/HttpURLConnection;

    move-result-object v11

    .line 63
    .local v11, "connection":Ljava/net/HttpURLConnection;
    if-eqz v11, :cond_a

    .line 64
    if-eqz v3, :cond_0

    .line 65
    sget-object v0, LuTools/uStreamSpoofing/uPlayerRoutes;->requestKeys:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_1
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/lang/String;

    .line 66
    .local v12, "requestKey":Ljava/lang/String;
    invoke-interface {v3, v12}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/lang/String;

    invoke-virtual {v11, v12, v13}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 67
    .end local v12    # "requestKey":Ljava/lang/String;
    goto :goto_1

    .line 70
    :cond_0
    new-instance v0, LuTools/VideoDetails/uVideoDetailsRequest$2;

    move-object/from16 v12, p3

    invoke-direct {v0, v1, v10, v12}, LuTools/VideoDetails/uVideoDetailsRequest$2;-><init>(LuTools/VideoDetails/uVideoDetailsRequest;LuTools/VideoDetails/uVideoDetailsClients;Ljava/lang/String;)V

    move-object v13, v0

    .line 104
    .local v13, "innerTubeBody":Lorg/json/JSONObject;
    invoke-virtual {v13}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0

    sget-object v14, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {v0, v14}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v14

    .line 105
    .local v14, "requestBody":[B
    array-length v0, v14

    invoke-virtual {v11, v0}, Ljava/net/HttpURLConnection;->setFixedLengthStreamingMode(I)V

    .line 106
    invoke-virtual {v11}, Ljava/net/HttpURLConnection;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v0

    invoke-virtual {v0, v14}, Ljava/io/OutputStream;->write([B)V

    .line 108
    invoke-virtual {v11}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v0

    const/16 v15, 0xc8

    if-ne v0, v15, :cond_9

    .line 109
    :try_start_0
    new-instance v0, Ljava/io/BufferedReader;

    new-instance v15, Ljava/io/InputStreamReader;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_5

    .line 111
    move/from16 v16, v8

    :try_start_1
    invoke-virtual {v11}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v8

    invoke-direct {v15, v8}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    invoke-direct {v0, v15}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_4

    move-object v8, v0

    .line 114
    .local v8, "reader":Ljava/io/BufferedReader;
    :try_start_2
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    move-object v15, v0

    .line 117
    .local v15, "jsonBuilder":Ljava/lang/StringBuilder;
    :goto_2
    invoke-virtual {v8}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v0

    move-object/from16 v17, v0

    .local v17, "line":Ljava/lang/String;
    if-eqz v0, :cond_1

    .line 118
    const-string v0, "%s%s"

    .line 123
    const/16 v18, 0xa

    invoke-static/range {v18 .. v18}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v1

    move-object/from16 v3, v17

    .end local v17    # "line":Ljava/lang/String;
    .local v3, "line":Ljava/lang/String;
    filled-new-array {v3, v1}, [Ljava/lang/Object;

    move-result-object v1

    .line 119
    invoke-static {v0, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    .line 118
    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-object/from16 v1, p0

    move-object/from16 v3, p2

    goto :goto_2

    .line 128
    .end local v3    # "line":Ljava/lang/String;
    .restart local v17    # "line":Ljava/lang/String;
    :cond_1
    move-object/from16 v3, v17

    .end local v17    # "line":Ljava/lang/String;
    .restart local v3    # "line":Ljava/lang/String;
    new-instance v0, Lorg/json/JSONObject;

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    move-object v1, v0

    .line 130
    .local v1, "jsonResponse":Lorg/json/JSONObject;
    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/16 v17, 0x1

    sparse-switch v0, :sswitch_data_0

    :cond_2
    goto :goto_3

    :sswitch_0
    const-string v0, "actionButtons"

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    move/from16 v0, v16

    goto :goto_4

    :sswitch_1
    const-string v0, "defaultAudioTrackID"

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    const/4 v0, 0x2

    goto :goto_4

    :sswitch_2
    const-string v0, "channelID"

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    move/from16 v0, v17

    goto :goto_4

    :goto_3
    const/4 v0, -0x1

    :goto_4
    packed-switch v0, :pswitch_data_0

    move-object/from16 v20, v1

    move-object/from16 v18, v3

    .end local v1    # "jsonResponse":Lorg/json/JSONObject;
    .end local v3    # "line":Ljava/lang/String;
    .local v18, "line":Ljava/lang/String;
    .local v20, "jsonResponse":Lorg/json/JSONObject;
    goto/16 :goto_a

    .line 180
    .end local v18    # "line":Ljava/lang/String;
    .end local v20    # "jsonResponse":Lorg/json/JSONObject;
    .restart local v1    # "jsonResponse":Lorg/json/JSONObject;
    .restart local v3    # "line":Ljava/lang/String;
    :pswitch_0
    const-string v0, "streamingData"

    .line 182
    invoke-virtual {v1, v0}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    const-string v2, "adaptiveFormats"

    .line 183
    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v0

    move-object v2, v0

    .line 185
    .local v2, "availableAudioTracks":Lorg/json/JSONArray;
    const/4 v0, 0x0

    move-object/from16 v18, v3

    move v3, v0

    .local v3, "i":I
    .restart local v18    # "line":Ljava/lang/String;
    :goto_5
    invoke-virtual {v2}, Lorg/json/JSONArray;->length()I

    move-result v0

    if-ge v3, v0, :cond_5

    .line 186
    nop

    .line 187
    invoke-virtual {v2, v3}, Lorg/json/JSONArray;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lorg/json/JSONObject;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    move-object/from16 v17, v0

    .line 190
    .local v17, "rootAudioTrack":Lorg/json/JSONObject;
    :try_start_3
    const-string v0, "audioTrack"
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 192
    move-object/from16 v19, v2

    move-object/from16 v2, v17

    .end local v17    # "rootAudioTrack":Lorg/json/JSONObject;
    .local v2, "rootAudioTrack":Lorg/json/JSONObject;
    .local v19, "availableAudioTracks":Lorg/json/JSONArray;
    :try_start_4
    invoke-virtual {v2, v0}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_2
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    .line 194
    .local v0, "audioTrack":Lorg/json/JSONObject;
    move-object/from16 v17, v2

    .end local v2    # "rootAudioTrack":Lorg/json/JSONObject;
    .restart local v17    # "rootAudioTrack":Lorg/json/JSONObject;
    :try_start_5
    const-string v2, "id"

    .line 195
    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_1
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    .line 197
    .local v2, "audioTrackID":Ljava/lang/String;
    move/from16 v20, v3

    .end local v3    # "i":I
    .local v20, "i":I
    :try_start_6
    const-string v3, "displayName"

    .line 198
    invoke-virtual {v0, v3}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    move-object/from16 v21, v0

    .end local v0    # "audioTrack":Lorg/json/JSONObject;
    .local v21, "audioTrack":Lorg/json/JSONObject;
    const-string v0, "original"

    .line 199
    invoke-virtual {v3, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_4

    const-string v0, ".4"

    .line 201
    invoke-virtual {v2, v0}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_3

    goto :goto_6

    .end local v2    # "audioTrackID":Ljava/lang/String;
    .end local v21    # "audioTrack":Lorg/json/JSONObject;
    :cond_3
    goto :goto_7

    .line 202
    .restart local v2    # "audioTrackID":Ljava/lang/String;
    .restart local v21    # "audioTrack":Lorg/json/JSONObject;
    :cond_4
    :goto_6
    const-string v0, "\\."

    invoke-virtual {v2, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    aget-object v0, v0, v16
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_0
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    .line 208
    :try_start_7
    invoke-virtual {v8}, Ljava/io/BufferedReader;->close()V
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_4

    .line 202
    return-object v0

    .line 204
    .end local v2    # "audioTrackID":Ljava/lang/String;
    .end local v21    # "audioTrack":Lorg/json/JSONObject;
    :catch_0
    move-exception v0

    goto :goto_7

    .end local v20    # "i":I
    .restart local v3    # "i":I
    :catch_1
    move-exception v0

    move/from16 v20, v3

    .end local v3    # "i":I
    .restart local v20    # "i":I
    goto :goto_7

    .end local v17    # "rootAudioTrack":Lorg/json/JSONObject;
    .end local v20    # "i":I
    .local v2, "rootAudioTrack":Lorg/json/JSONObject;
    .restart local v3    # "i":I
    :catch_2
    move-exception v0

    move-object/from16 v17, v2

    move/from16 v20, v3

    .end local v2    # "rootAudioTrack":Lorg/json/JSONObject;
    .end local v3    # "i":I
    .restart local v17    # "rootAudioTrack":Lorg/json/JSONObject;
    .restart local v20    # "i":I
    goto :goto_7

    .end local v19    # "availableAudioTracks":Lorg/json/JSONArray;
    .end local v20    # "i":I
    .local v2, "availableAudioTracks":Lorg/json/JSONArray;
    .restart local v3    # "i":I
    :catch_3
    move-exception v0

    move-object/from16 v19, v2

    move/from16 v20, v3

    .end local v2    # "availableAudioTracks":Lorg/json/JSONArray;
    .end local v3    # "i":I
    .restart local v19    # "availableAudioTracks":Lorg/json/JSONArray;
    .restart local v20    # "i":I
    :goto_7
    nop

    .line 185
    .end local v17    # "rootAudioTrack":Lorg/json/JSONObject;
    add-int/lit8 v3, v20, 0x1

    move-object/from16 v2, v19

    .end local v20    # "i":I
    .restart local v3    # "i":I
    goto :goto_5

    .end local v19    # "availableAudioTracks":Lorg/json/JSONArray;
    .restart local v2    # "availableAudioTracks":Lorg/json/JSONArray;
    :cond_5
    move-object/from16 v19, v2

    move/from16 v20, v3

    .end local v2    # "availableAudioTracks":Lorg/json/JSONArray;
    .end local v3    # "i":I
    .restart local v19    # "availableAudioTracks":Lorg/json/JSONArray;
    .restart local v20    # "i":I
    goto/16 :goto_a

    .line 174
    .end local v18    # "line":Ljava/lang/String;
    .end local v19    # "availableAudioTracks":Lorg/json/JSONArray;
    .end local v20    # "i":I
    .local v3, "line":Ljava/lang/String;
    :pswitch_1
    move-object/from16 v18, v3

    .end local v3    # "line":Ljava/lang/String;
    .restart local v18    # "line":Ljava/lang/String;
    :try_start_8
    const-string v0, "videoDetails"

    .line 175
    invoke-virtual {v1, v0}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    const-string v2, "channelId"

    .line 176
    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_0

    .line 208
    :try_start_9
    invoke-virtual {v8}, Ljava/io/BufferedReader;->close()V
    :try_end_9
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_9} :catch_4

    .line 174
    return-object v0

    .line 132
    .end local v18    # "line":Ljava/lang/String;
    .restart local v3    # "line":Ljava/lang/String;
    :pswitch_2
    move-object/from16 v18, v3

    .line 134
    .end local v3    # "line":Ljava/lang/String;
    .restart local v18    # "line":Ljava/lang/String;
    :try_start_a
    invoke-virtual {v1, v5}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    const-string v2, "singleColumnWatchNextResults"

    .line 135
    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    .line 136
    invoke-virtual {v0, v4}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    .line 137
    invoke-virtual {v0, v4}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    .line 138
    invoke-virtual {v0, v5}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v0

    .line 140
    .local v0, "primaryContentsArray":Lorg/json/JSONArray;
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_8
    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    move-result v3

    if-ge v2, v3, :cond_8

    .line 141
    invoke-virtual {v0, v2}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v3

    .line 143
    .local v3, "primaryContentsArrayObject":Lorg/json/JSONObject;
    const-string v19, "slimVideoMetadataSectionRenderer"

    move-object/from16 v20, v19

    .line 145
    .local v20, "secondaryContentsObjectTarget":Ljava/lang/String;
    move-object/from16 v19, v0

    move-object/from16 v0, v20

    .end local v20    # "secondaryContentsObjectTarget":Ljava/lang/String;
    .local v0, "secondaryContentsObjectTarget":Ljava/lang/String;
    .local v19, "primaryContentsArray":Lorg/json/JSONArray;
    invoke-virtual {v3, v0}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v20

    if-eqz v20, :cond_7

    .line 146
    nop

    .line 148
    move-object/from16 v20, v1

    .end local v1    # "jsonResponse":Lorg/json/JSONObject;
    .local v20, "jsonResponse":Lorg/json/JSONObject;
    invoke-virtual {v3, v0}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v1

    .line 149
    invoke-virtual {v1, v5}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v1

    .line 151
    .local v1, "secondaryContentsArray":Lorg/json/JSONArray;
    nop

    .line 152
    invoke-virtual {v1}, Lorg/json/JSONArray;->length()I

    move-result v21

    move-object/from16 v22, v0

    .end local v0    # "secondaryContentsObjectTarget":Ljava/lang/String;
    .local v22, "secondaryContentsObjectTarget":Ljava/lang/String;
    add-int/lit8 v0, v21, -0x1

    invoke-virtual {v1, v0}, Lorg/json/JSONArray;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lorg/json/JSONObject;

    move-object/from16 v21, v1

    .end local v1    # "secondaryContentsArray":Lorg/json/JSONArray;
    .local v21, "secondaryContentsArray":Lorg/json/JSONArray;
    const-string v1, "elementRenderer"

    .line 153
    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    const-string v1, "newElement"

    .line 154
    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    const-string v1, "type"

    .line 155
    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    const-string v1, "componentType"

    .line 156
    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    const-string v1, "model"

    .line 157
    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    const-string v1, "videoActionBarModel"

    .line 158
    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    const-string v1, "videoActionBarData"

    .line 159
    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    const-string v1, "buttons"

    .line 160
    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v0

    .line 162
    .local v0, "buttons":Lorg/json/JSONArray;
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 164
    .local v1, "buttonsList":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    const/16 v17, 0x0

    move/from16 v23, v2

    move/from16 v2, v17

    .local v2, "j":I
    .local v23, "i":I
    :goto_9
    move-object/from16 v24, v3

    .end local v3    # "primaryContentsArrayObject":Lorg/json/JSONObject;
    .local v24, "primaryContentsArrayObject":Lorg/json/JSONObject;
    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    move-result v3

    if-ge v2, v3, :cond_6

    .line 165
    invoke-virtual {v0, v2}, Lorg/json/JSONArray;->get(I)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-interface {v1, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_0

    .line 164
    add-int/lit8 v2, v2, 0x1

    move-object/from16 v3, v24

    goto :goto_9

    .line 168
    .end local v2    # "j":I
    :cond_6
    nop

    .line 208
    :try_start_b
    invoke-virtual {v8}, Ljava/io/BufferedReader;->close()V

    .line 168
    return-object v1

    .line 145
    .end local v20    # "jsonResponse":Lorg/json/JSONObject;
    .end local v21    # "secondaryContentsArray":Lorg/json/JSONArray;
    .end local v22    # "secondaryContentsObjectTarget":Ljava/lang/String;
    .end local v23    # "i":I
    .end local v24    # "primaryContentsArrayObject":Lorg/json/JSONObject;
    .local v0, "secondaryContentsObjectTarget":Ljava/lang/String;
    .local v1, "jsonResponse":Lorg/json/JSONObject;
    .local v2, "i":I
    .restart local v3    # "primaryContentsArrayObject":Lorg/json/JSONObject;
    :cond_7
    move-object/from16 v22, v0

    move-object/from16 v20, v1

    move/from16 v23, v2

    move-object/from16 v24, v3

    .line 140
    .end local v0    # "secondaryContentsObjectTarget":Ljava/lang/String;
    .end local v1    # "jsonResponse":Lorg/json/JSONObject;
    .end local v2    # "i":I
    .end local v3    # "primaryContentsArrayObject":Lorg/json/JSONObject;
    .restart local v20    # "jsonResponse":Lorg/json/JSONObject;
    .restart local v23    # "i":I
    add-int/lit8 v2, v23, 0x1

    move-object/from16 v0, v19

    .end local v23    # "i":I
    .restart local v2    # "i":I
    goto/16 :goto_8

    .end local v19    # "primaryContentsArray":Lorg/json/JSONArray;
    .end local v20    # "jsonResponse":Lorg/json/JSONObject;
    .local v0, "primaryContentsArray":Lorg/json/JSONArray;
    .restart local v1    # "jsonResponse":Lorg/json/JSONObject;
    :cond_8
    move-object/from16 v19, v0

    move-object/from16 v20, v1

    move/from16 v23, v2

    .line 171
    .end local v0    # "primaryContentsArray":Lorg/json/JSONArray;
    .end local v1    # "jsonResponse":Lorg/json/JSONObject;
    .end local v2    # "i":I
    .restart local v20    # "jsonResponse":Lorg/json/JSONObject;
    nop

    .line 208
    .end local v15    # "jsonBuilder":Ljava/lang/StringBuilder;
    .end local v18    # "line":Ljava/lang/String;
    .end local v20    # "jsonResponse":Lorg/json/JSONObject;
    :goto_a
    invoke-virtual {v8}, Ljava/io/BufferedReader;->close()V
    :try_end_b
    .catch Ljava/lang/Exception; {:try_start_b .. :try_end_b} :catch_4

    goto :goto_c

    .line 109
    :catchall_0
    move-exception v0

    move-object v1, v0

    :try_start_c
    invoke-virtual {v8}, Ljava/io/BufferedReader;->close()V
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_1

    goto :goto_b

    :catchall_1
    move-exception v0

    :try_start_d
    invoke-virtual {v1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .end local v10    # "client":LuTools/VideoDetails/uVideoDetailsClients;
    .end local v11    # "connection":Ljava/net/HttpURLConnection;
    .end local v13    # "innerTubeBody":Lorg/json/JSONObject;
    .end local v14    # "requestBody":[B
    .end local p0    # "this":LuTools/VideoDetails/uVideoDetailsRequest;
    .end local p1    # "infoToFetch":Ljava/lang/String;
    .end local p2    # "playerHeaders":Ljava/util/Map;
    .end local p3    # "videoID":Ljava/lang/String;
    :goto_b
    throw v1
    :try_end_d
    .catch Ljava/lang/Exception; {:try_start_d .. :try_end_d} :catch_4

    .line 208
    .end local v8    # "reader":Ljava/io/BufferedReader;
    .restart local v10    # "client":LuTools/VideoDetails/uVideoDetailsClients;
    .restart local v11    # "connection":Ljava/net/HttpURLConnection;
    .restart local v13    # "innerTubeBody":Lorg/json/JSONObject;
    .restart local v14    # "requestBody":[B
    .restart local p0    # "this":LuTools/VideoDetails/uVideoDetailsRequest;
    .restart local p1    # "infoToFetch":Ljava/lang/String;
    .restart local p2    # "playerHeaders":Ljava/util/Map;
    .restart local p3    # "videoID":Ljava/lang/String;
    :catch_4
    move-exception v0

    goto :goto_c

    :catch_5
    move-exception v0

    move/from16 v16, v8

    goto :goto_c

    .line 108
    :cond_9
    move/from16 v16, v8

    goto :goto_c

    .line 63
    .end local v13    # "innerTubeBody":Lorg/json/JSONObject;
    .end local v14    # "requestBody":[B
    :cond_a
    move-object/from16 v12, p3

    move/from16 v16, v8

    goto :goto_c

    .line 44
    .end local v11    # "connection":Ljava/net/HttpURLConnection;
    :cond_b
    move-object/from16 v12, p3

    move/from16 v16, v8

    .line 43
    .end local v10    # "client":LuTools/VideoDetails/uVideoDetailsClients;
    :goto_c
    add-int/lit8 v9, v9, 0x1

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move/from16 v8, v16

    goto/16 :goto_0

    .line 214
    :cond_c
    move-object/from16 v12, p3

    const/4 v0, 0x0

    return-object v0

    :sswitch_data_0
    .sparse-switch
        0x5720515e -> :sswitch_2
        0x59e5c3d1 -> :sswitch_1
        0x6121906b -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method


# virtual methods
.method public GetRequestedInfo()Ljava/lang/Object;
    .locals 4

    .line 221
    :try_start_0
    iget-object v0, p0, LuTools/VideoDetails/uVideoDetailsRequest;->future:Ljava/util/concurrent/Future;

    sget-object v1, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v2, 0x2710

    invoke-interface {v0, v2, v3, v1}, Ljava/util/concurrent/Future;->get(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    .line 222
    :catch_0
    move-exception v0

    .line 223
    .local v0, "ignore":Ljava/lang/Exception;
    const/4 v1, 0x0

    return-object v1
.end method
