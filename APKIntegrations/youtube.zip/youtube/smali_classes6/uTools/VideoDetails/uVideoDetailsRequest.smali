.class public LuTools/VideoDetails/uVideoDetailsRequest;
.super Ljava/lang/Object;
.source "uVideoDetailsRequest.java"


# static fields
.field private static final Cache:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "LuTools/VideoDetails/uVideoDetailsRequest;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final future:Ljava/util/concurrent/Future;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/Future<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private videoID:Ljava/lang/String;


# direct methods
.method public static synthetic $r8$lambda$N78LXxngQ87bP8BJhSc5dUEKRPc(LuTools/VideoDetails/uVideoDetailsRequest;)Ljava/lang/String;
    .locals 0

    invoke-direct {p0}, LuTools/VideoDetails/uVideoDetailsRequest;->lambda$new$0()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetvideoID(LuTools/VideoDetails/uVideoDetailsRequest;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, LuTools/VideoDetails/uVideoDetailsRequest;->videoID:Ljava/lang/String;

    return-object p0
.end method

.method static constructor <clinit>()V
    .locals 1

    .line 116
    invoke-static {}, LuTools/uUtils;->InitializeStreamCache()Ljava/util/LinkedHashMap;

    move-result-object v0

    invoke-static {v0}, Ljava/util/Collections;->synchronizedMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object v0

    sput-object v0, LuTools/VideoDetails/uVideoDetailsRequest;->Cache:Ljava/util/Map;

    .line 115
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .locals 2
    .param p1, "videoID"    # Ljava/lang/String;

    .line 31
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 35
    sget-object v0, LuTools/uUtils;->BackgroundThreadPool:Ljava/util/concurrent/ThreadPoolExecutor;

    new-instance v1, LuTools/VideoDetails/uVideoDetailsRequest$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0}, LuTools/VideoDetails/uVideoDetailsRequest$$ExternalSyntheticLambda0;-><init>(LuTools/VideoDetails/uVideoDetailsRequest;)V

    invoke-virtual {v0, v1}, Ljava/util/concurrent/ThreadPoolExecutor;->submit(Ljava/util/concurrent/Callable;)Ljava/util/concurrent/Future;

    move-result-object v0

    iput-object v0, p0, LuTools/VideoDetails/uVideoDetailsRequest;->future:Ljava/util/concurrent/Future;

    .line 32
    iput-object p1, p0, LuTools/VideoDetails/uVideoDetailsRequest;->videoID:Ljava/lang/String;

    .line 33
    return-void
.end method

.method public static GetRequestForVideoID(Ljava/lang/String;)LuTools/VideoDetails/uVideoDetailsRequest;
    .locals 1
    .param p0, "videoID"    # Ljava/lang/String;

    .line 131
    sget-object v0, LuTools/VideoDetails/uVideoDetailsRequest;->Cache:Ljava/util/Map;

    invoke-interface {v0, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LuTools/VideoDetails/uVideoDetailsRequest;

    return-object v0
.end method

.method public static SetFetchRequest(Ljava/lang/String;)V
    .locals 2
    .param p0, "videoID"    # Ljava/lang/String;

    .line 119
    sget-object v0, LuTools/VideoDetails/uVideoDetailsRequest;->Cache:Ljava/util/Map;

    new-instance v1, LuTools/VideoDetails/uVideoDetailsRequest;

    invoke-direct {v1, p0}, LuTools/VideoDetails/uVideoDetailsRequest;-><init>(Ljava/lang/String;)V

    invoke-interface {v0, p0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 120
    return-void
.end method

.method private synthetic lambda$new$0()Ljava/lang/String;
    .locals 10
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 37
    invoke-static {}, LuTools/VideoDetails/uWebClientType;->values()[LuTools/VideoDetails/uWebClientType;

    move-result-object v0

    array-length v1, v0

    const/4 v2, 0x0

    move v3, v2

    :goto_0
    if-ge v3, v1, :cond_2

    aget-object v4, v0, v3

    .line 38
    .local v4, "webClientType":LuTools/VideoDetails/uWebClientType;
    new-instance v5, LuTools/uStreamSpoofing/uRoute;

    sget-object v6, LuTools/uStreamSpoofing/uRoute$Method;->POST:LuTools/uStreamSpoofing/uRoute$Method;

    const-string v7, "?prettyPrint=false"

    const-string v8, "&fields=videoDetails.channelId"

    const-string v9, "player"

    filled-new-array {v9, v7, v8}, [Ljava/lang/Object;

    move-result-object v7

    .line 42
    const-string v8, "%s%s%s"

    invoke-static {v8, v7}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v7

    invoke-direct {v5, v6, v7}, LuTools/uStreamSpoofing/uRoute;-><init>(LuTools/uStreamSpoofing/uRoute$Method;Ljava/lang/String;)V

    new-array v6, v2, [Ljava/lang/String;

    .line 49
    invoke-virtual {v5, v6}, LuTools/uStreamSpoofing/uRoute;->Compile([Ljava/lang/String;)LuTools/uStreamSpoofing/uRoute$CompiledRoute;

    move-result-object v5

    iget-object v6, v4, LuTools/VideoDetails/uWebClientType;->userAgent:Ljava/lang/String;

    iget v7, v4, LuTools/VideoDetails/uWebClientType;->clientID:I

    .line 53
    invoke-static {v7}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v7

    iget-object v8, v4, LuTools/VideoDetails/uWebClientType;->clientVersion:Ljava/lang/String;

    filled-new-array {v6, v7, v8}, [Ljava/lang/Object;

    move-result-object v6

    .line 51
    invoke-static {v6}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v6

    .line 38
    invoke-static {v5, v6}, LuTools/uStreamSpoofing/uPlayerRoutes;->GetPlayerResponseConnectionFromRoute(LuTools/uStreamSpoofing/uRoute$CompiledRoute;Ljava/util/List;)Ljava/net/HttpURLConnection;

    move-result-object v5

    .line 58
    .local v5, "connection":Ljava/net/HttpURLConnection;
    if-eqz v5, :cond_1

    .line 59
    new-instance v6, LuTools/VideoDetails/uVideoDetailsRequest$1;

    invoke-direct {v6, p0, v4}, LuTools/VideoDetails/uVideoDetailsRequest$1;-><init>(LuTools/VideoDetails/uVideoDetailsRequest;LuTools/VideoDetails/uWebClientType;)V

    .line 79
    .local v6, "innerTubeBody":Lorg/json/JSONObject;
    invoke-virtual {v6}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v7

    sget-object v8, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {v7, v8}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v7

    .line 80
    .local v7, "requestBody":[B
    array-length v8, v7

    invoke-virtual {v5, v8}, Ljava/net/HttpURLConnection;->setFixedLengthStreamingMode(I)V

    .line 81
    invoke-virtual {v5}, Ljava/net/HttpURLConnection;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v8

    invoke-virtual {v8, v7}, Ljava/io/OutputStream;->write([B)V

    .line 83
    invoke-virtual {v5}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v8

    const/16 v9, 0xc8

    if-ne v8, v9, :cond_1

    .line 84
    new-instance v0, Ljava/io/BufferedReader;

    new-instance v1, Ljava/io/InputStreamReader;

    .line 86
    invoke-virtual {v5}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    invoke-direct {v0, v1}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    .line 89
    .local v0, "reader":Ljava/io/BufferedReader;
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 93
    .local v1, "jsonBuilder":Ljava/lang/StringBuilder;
    :goto_1
    invoke-virtual {v0}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v2

    move-object v3, v2

    .local v3, "line":Ljava/lang/String;
    if-eqz v2, :cond_0

    .line 94
    nop

    .line 99
    const/16 v2, 0xa

    invoke-static {v2}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v2

    filled-new-array {v3, v2}, [Ljava/lang/Object;

    move-result-object v2

    .line 95
    const-string v8, "%s%s"

    invoke-static {v8, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    .line 94
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_1

    .line 104
    :cond_0
    new-instance v2, Lorg/json/JSONObject;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-direct {v2, v8}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 105
    const-string v8, "videoDetails"

    invoke-virtual {v2, v8}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    .line 106
    const-string v8, "channelId"

    invoke-virtual {v2, v8}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 104
    return-object v2

    .line 37
    .end local v0    # "reader":Ljava/io/BufferedReader;
    .end local v1    # "jsonBuilder":Ljava/lang/StringBuilder;
    .end local v3    # "line":Ljava/lang/String;
    .end local v4    # "webClientType":LuTools/VideoDetails/uWebClientType;
    .end local v5    # "connection":Ljava/net/HttpURLConnection;
    .end local v6    # "innerTubeBody":Lorg/json/JSONObject;
    .end local v7    # "requestBody":[B
    :cond_1
    add-int/lit8 v3, v3, 0x1

    goto/16 :goto_0

    .line 111
    :cond_2
    const/4 v0, 0x0

    return-object v0
.end method


# virtual methods
.method public GetChannelID()Ljava/lang/String;
    .locals 4

    .line 124
    :try_start_0
    iget-object v0, p0, LuTools/VideoDetails/uVideoDetailsRequest;->future:Ljava/util/concurrent/Future;

    sget-object v1, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v2, 0x4e20

    invoke-interface {v0, v2, v3, v1}, Ljava/util/concurrent/Future;->get(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;
    :try_end_0
    .catch Ljava/util/concurrent/TimeoutException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    .line 125
    :catch_0
    move-exception v0

    .line 127
    const/4 v0, 0x0

    return-object v0
.end method
