.class public final enum LuTools/VideoDetails/uVideoDetailsClients;
.super Ljava/lang/Enum;
.source "uVideoDetailsClients.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "LuTools/VideoDetails/uVideoDetailsClients;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[LuTools/VideoDetails/uVideoDetailsClients;

.field public static final enum ANDROID:LuTools/VideoDetails/uVideoDetailsClients;

.field public static final enum WEB_REMIX:LuTools/VideoDetails/uVideoDetailsClients;


# instance fields
.field public final clientID:I

.field public final clientVersion:Ljava/lang/String;

.field public final infoToBindTo:Ljava/lang/String;

.field public final userAgent:Ljava/lang/String;


# direct methods
.method private static synthetic $values()[LuTools/VideoDetails/uVideoDetailsClients;
    .locals 2

    .line 5
    sget-object v0, LuTools/VideoDetails/uVideoDetailsClients;->ANDROID:LuTools/VideoDetails/uVideoDetailsClients;

    sget-object v1, LuTools/VideoDetails/uVideoDetailsClients;->WEB_REMIX:LuTools/VideoDetails/uVideoDetailsClients;

    filled-new-array {v0, v1}, [LuTools/VideoDetails/uVideoDetailsClients;

    move-result-object v0

    return-object v0
.end method

.method static constructor <clinit>()V
    .locals 8

    .line 6
    new-instance v0, LuTools/VideoDetails/uVideoDetailsClients;

    const-string v5, "20.30.35"

    const-string v6, "com.google.android.youtube/20.30.35 (Linux; U; Android 15)"

    const-string v1, "ANDROID"

    const/4 v2, 0x0

    const-string v3, "defaultAudioTrackID,actionButtons"

    const/4 v4, 0x3

    invoke-direct/range {v0 .. v6}, LuTools/VideoDetails/uVideoDetailsClients;-><init>(Ljava/lang/String;ILjava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    sput-object v0, LuTools/VideoDetails/uVideoDetailsClients;->ANDROID:LuTools/VideoDetails/uVideoDetailsClients;

    .line 12
    new-instance v1, LuTools/VideoDetails/uVideoDetailsClients;

    const-string v6, "1.20241218.01.00"

    const-string v7, "Mozilla/5.0 (iPad; CPU OS 16_7_10 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1,gzip(gfe)"

    const-string v2, "WEB_REMIX"

    const/4 v3, 0x1

    const-string v4, "channelID"

    const/16 v5, 0x1d

    invoke-direct/range {v1 .. v7}, LuTools/VideoDetails/uVideoDetailsClients;-><init>(Ljava/lang/String;ILjava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    sput-object v1, LuTools/VideoDetails/uVideoDetailsClients;->WEB_REMIX:LuTools/VideoDetails/uVideoDetailsClients;

    .line 5
    invoke-static {}, LuTools/VideoDetails/uVideoDetailsClients;->$values()[LuTools/VideoDetails/uVideoDetailsClients;

    move-result-object v0

    sput-object v0, LuTools/VideoDetails/uVideoDetailsClients;->$VALUES:[LuTools/VideoDetails/uVideoDetailsClients;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;ILjava/lang/String;ILjava/lang/String;Ljava/lang/String;)V
    .locals 0
    .param p3, "infoToBindTo"    # Ljava/lang/String;
    .param p4, "clientID"    # I
    .param p5, "clientVersion"    # Ljava/lang/String;
    .param p6, "userAgent"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            null,
            null,
            null,
            null,
            null,
            null
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "I",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 24
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 25
    iput-object p3, p0, LuTools/VideoDetails/uVideoDetailsClients;->infoToBindTo:Ljava/lang/String;

    .line 26
    iput p4, p0, LuTools/VideoDetails/uVideoDetailsClients;->clientID:I

    .line 27
    iput-object p5, p0, LuTools/VideoDetails/uVideoDetailsClients;->clientVersion:Ljava/lang/String;

    .line 28
    iput-object p6, p0, LuTools/VideoDetails/uVideoDetailsClients;->userAgent:Ljava/lang/String;

    .line 29
    return-void
.end method

.method public static valueOf(Ljava/lang/String;)LuTools/VideoDetails/uVideoDetailsClients;
    .locals 1
    .param p0, "name"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            null
        }
    .end annotation

    .line 5
    const-class v0, LuTools/VideoDetails/uVideoDetailsClients;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v0

    check-cast v0, LuTools/VideoDetails/uVideoDetailsClients;

    return-object v0
.end method

.method public static values()[LuTools/VideoDetails/uVideoDetailsClients;
    .locals 1

    .line 5
    sget-object v0, LuTools/VideoDetails/uVideoDetailsClients;->$VALUES:[LuTools/VideoDetails/uVideoDetailsClients;

    invoke-virtual {v0}, [LuTools/VideoDetails/uVideoDetailsClients;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [LuTools/VideoDetails/uVideoDetailsClients;

    return-object v0
.end method
