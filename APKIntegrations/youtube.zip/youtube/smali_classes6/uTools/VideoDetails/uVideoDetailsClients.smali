.class public final enum LuTools/VideoDetails/uVideoDetailsClients;
.super Ljava/lang/Enum;
.source "uVideoDetailsClients.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "LuTools/VideoDetails/uVideoDetailsClients;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[LuTools/VideoDetails/uVideoDetailsClients;

.field public static final enum ANDROID:LuTools/VideoDetails/uVideoDetailsClients;

.field public static final enum WEB_REMIX:LuTools/VideoDetails/uVideoDetailsClients;


# instance fields
.field public final androidSDKVersion:Ljava/lang/String;

.field public final clientID:I

.field public final clientVersion:Ljava/lang/String;

.field public final cronetVersion:Ljava/lang/String;

.field public final deviceMake:Ljava/lang/String;

.field public final deviceModel:Ljava/lang/String;

.field public final infoToBindTo:Ljava/lang/String;

.field public final osBuildID:Ljava/lang/String;

.field public final osName:Ljava/lang/String;

.field public final osVersion:Ljava/lang/String;

.field public final userAgent:Ljava/lang/String;


# direct methods
.method private static synthetic $values()[LuTools/VideoDetails/uVideoDetailsClients;
    .locals 2

    .line 9
    sget-object v0, LuTools/VideoDetails/uVideoDetailsClients;->ANDROID:LuTools/VideoDetails/uVideoDetailsClients;

    sget-object v1, LuTools/VideoDetails/uVideoDetailsClients;->WEB_REMIX:LuTools/VideoDetails/uVideoDetailsClients;

    filled-new-array {v0, v1}, [LuTools/VideoDetails/uVideoDetailsClients;

    move-result-object v0

    return-object v0
.end method

.method static constructor <clinit>()V
    .locals 16

    .line 10
    new-instance v0, LuTools/VideoDetails/uVideoDetailsClients;

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 12
    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v4

    .line 15
    invoke-static {}, LuTools/uUtils;->GetAppVersion()Ljava/lang/String;

    move-result-object v7

    sget-object v9, Landroid/os/Build;->MODEL:Ljava/lang/String;

    sget-object v10, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    sget-object v11, Landroid/os/Build;->DISPLAY:Ljava/lang/String;

    sget-object v13, Landroid/os/Build$VERSION;->RELEASE:Ljava/lang/String;

    const/4 v14, 0x0

    const-string v1, "ANDROID"

    const/4 v2, 0x0

    const-string v3, "defaultAudioTrackID,saveVideoToWatchLater"

    const/4 v5, 0x3

    const-string v6, "com.google.android.youtube"

    const-string v8, "132.0.6779.0"

    const-string v12, "Android"

    invoke-direct/range {v0 .. v14}, LuTools/VideoDetails/uVideoDetailsClients;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    sput-object v0, LuTools/VideoDetails/uVideoDetailsClients;->ANDROID:LuTools/VideoDetails/uVideoDetailsClients;

    .line 24
    new-instance v1, LuTools/VideoDetails/uVideoDetailsClients;

    const-string v15, "Mozilla/5.0 (iPad; CPU OS 16_7_10 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1,gzip(gfe)"

    const-string v2, "WEB_REMIX"

    const/4 v3, 0x1

    const-string v4, "channelID"

    const/4 v5, 0x0

    const/16 v6, 0x1d

    const/4 v7, 0x0

    const-string v8, "1.20241218.01.00"

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    invoke-direct/range {v1 .. v15}, LuTools/VideoDetails/uVideoDetailsClients;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    sput-object v1, LuTools/VideoDetails/uVideoDetailsClients;->WEB_REMIX:LuTools/VideoDetails/uVideoDetailsClients;

    .line 9
    invoke-static {}, LuTools/VideoDetails/uVideoDetailsClients;->$values()[LuTools/VideoDetails/uVideoDetailsClients;

    move-result-object v0

    sput-object v0, LuTools/VideoDetails/uVideoDetailsClients;->$VALUES:[LuTools/VideoDetails/uVideoDetailsClients;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 11
    .param p3, "infoToBindTo"    # Ljava/lang/String;
    .param p4, "androidSDKVersion"    # Ljava/lang/String;
    .param p5, "clientID"    # I
    .param p6, "clientPackageName"    # Ljava/lang/String;
    .param p7, "clientVersion"    # Ljava/lang/String;
    .param p8, "cronetVersion"    # Ljava/lang/String;
    .param p9, "deviceMake"    # Ljava/lang/String;
    .param p10, "deviceModel"    # Ljava/lang/String;
    .param p11, "osBuildID"    # Ljava/lang/String;
    .param p12, "osName"    # Ljava/lang/String;
    .param p13, "osVersion"    # Ljava/lang/String;
    .param p14, "userAgent"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "I",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 50
    invoke-direct/range {p0 .. p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 51
    iput-object p3, p0, LuTools/VideoDetails/uVideoDetailsClients;->infoToBindTo:Ljava/lang/String;

    .line 52
    iput-object p4, p0, LuTools/VideoDetails/uVideoDetailsClients;->androidSDKVersion:Ljava/lang/String;

    .line 53
    move/from16 v0, p5

    iput v0, p0, LuTools/VideoDetails/uVideoDetailsClients;->clientID:I

    .line 54
    move-object/from16 v2, p7

    iput-object v2, p0, LuTools/VideoDetails/uVideoDetailsClients;->clientVersion:Ljava/lang/String;

    .line 55
    move-object/from16 v6, p8

    iput-object v6, p0, LuTools/VideoDetails/uVideoDetailsClients;->cronetVersion:Ljava/lang/String;

    .line 56
    move-object/from16 v7, p9

    iput-object v7, p0, LuTools/VideoDetails/uVideoDetailsClients;->deviceMake:Ljava/lang/String;

    .line 57
    move-object/from16 v4, p10

    iput-object v4, p0, LuTools/VideoDetails/uVideoDetailsClients;->deviceModel:Ljava/lang/String;

    .line 58
    move-object/from16 v5, p11

    iput-object v5, p0, LuTools/VideoDetails/uVideoDetailsClients;->osBuildID:Ljava/lang/String;

    .line 59
    move-object/from16 v8, p12

    iput-object v8, p0, LuTools/VideoDetails/uVideoDetailsClients;->osName:Ljava/lang/String;

    .line 60
    move-object/from16 v3, p13

    iput-object v3, p0, LuTools/VideoDetails/uVideoDetailsClients;->osVersion:Ljava/lang/String;

    .line 62
    nop

    .line 63
    if-nez p14, :cond_0

    .line 65
    const-string v9, "%s/%s (Linux; U; Android %s; %s; Build/%s; Cronet/%s)"

    move-object/from16 v1, p6

    filled-new-array/range {v1 .. v6}, [Ljava/lang/Object;

    move-result-object v10

    invoke-static {v9, v10}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    goto :goto_0

    .line 76
    :cond_0
    move-object/from16 v1, p14

    :goto_0
    iput-object v1, p0, LuTools/VideoDetails/uVideoDetailsClients;->userAgent:Ljava/lang/String;

    .line 77
    return-void
.end method

.method public static valueOf(Ljava/lang/String;)LuTools/VideoDetails/uVideoDetailsClients;
    .locals 1
    .param p0, "name"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            null
        }
    .end annotation

    .line 9
    const-class v0, LuTools/VideoDetails/uVideoDetailsClients;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v0

    check-cast v0, LuTools/VideoDetails/uVideoDetailsClients;

    return-object v0
.end method

.method public static values()[LuTools/VideoDetails/uVideoDetailsClients;
    .locals 1

    .line 9
    sget-object v0, LuTools/VideoDetails/uVideoDetailsClients;->$VALUES:[LuTools/VideoDetails/uVideoDetailsClients;

    invoke-virtual {v0}, [LuTools/VideoDetails/uVideoDetailsClients;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [LuTools/VideoDetails/uVideoDetailsClients;

    return-object v0
.end method
