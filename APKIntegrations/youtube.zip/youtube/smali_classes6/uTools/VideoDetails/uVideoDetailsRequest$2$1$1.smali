.class LuTools/VideoDetails/uVideoDetailsRequest$2$1$1;
.super Lorg/json/JSONObject;
.source "uVideoDetailsRequest.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LuTools/VideoDetails/uVideoDetailsRequest$2$1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$2:LuTools/VideoDetails/uVideoDetailsRequest$2$1;


# direct methods
.method constructor <init>(LuTools/VideoDetails/uVideoDetailsRequest$2$1;)V
    .locals 2
    .param p1, "this$2"    # LuTools/VideoDetails/uVideoDetailsRequest$2$1;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lorg/json/JSONException;
        }
    .end annotation

    .line 78
    iput-object p1, p0, LuTools/VideoDetails/uVideoDetailsRequest$2$1$1;->this$2:LuTools/VideoDetails/uVideoDetailsRequest$2$1;

    invoke-direct {p0}, Lorg/json/JSONObject;-><init>()V

    .line 79
    iget-object v0, p0, LuTools/VideoDetails/uVideoDetailsRequest$2$1$1;->this$2:LuTools/VideoDetails/uVideoDetailsRequest$2$1;

    iget-object v0, v0, LuTools/VideoDetails/uVideoDetailsRequest$2$1;->this$1:LuTools/VideoDetails/uVideoDetailsRequest$2;

    iget-object v0, v0, LuTools/VideoDetails/uVideoDetailsRequest$2;->val$client:LuTools/VideoDetails/uVideoDetailsClients;

    invoke-virtual {v0}, LuTools/VideoDetails/uVideoDetailsClients;->name()Ljava/lang/String;

    move-result-object v0

    const-string v1, "clientName"

    invoke-virtual {p0, v1, v0}, LuTools/VideoDetails/uVideoDetailsRequest$2$1$1;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 80
    iget-object v0, p0, LuTools/VideoDetails/uVideoDetailsRequest$2$1$1;->this$2:LuTools/VideoDetails/uVideoDetailsRequest$2$1;

    iget-object v0, v0, LuTools/VideoDetails/uVideoDetailsRequest$2$1;->this$1:LuTools/VideoDetails/uVideoDetailsRequest$2;

    iget-object v0, v0, LuTools/VideoDetails/uVideoDetailsRequest$2;->val$client:LuTools/VideoDetails/uVideoDetailsClients;

    iget-object v0, v0, LuTools/VideoDetails/uVideoDetailsClients;->clientVersion:Ljava/lang/String;

    const-string v1, "clientVersion"

    invoke-virtual {p0, v1, v0}, LuTools/VideoDetails/uVideoDetailsRequest$2$1$1;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 81
    iget-object v0, p0, LuTools/VideoDetails/uVideoDetailsRequest$2$1$1;->this$2:LuTools/VideoDetails/uVideoDetailsRequest$2$1;

    iget-object v0, v0, LuTools/VideoDetails/uVideoDetailsRequest$2$1;->this$1:LuTools/VideoDetails/uVideoDetailsRequest$2;

    iget-object v0, v0, LuTools/VideoDetails/uVideoDetailsRequest$2;->val$client:LuTools/VideoDetails/uVideoDetailsClients;

    iget-object v0, v0, LuTools/VideoDetails/uVideoDetailsClients;->deviceModel:Ljava/lang/String;

    if-eqz v0, :cond_0

    .line 82
    iget-object v0, p0, LuTools/VideoDetails/uVideoDetailsRequest$2$1$1;->this$2:LuTools/VideoDetails/uVideoDetailsRequest$2$1;

    iget-object v0, v0, LuTools/VideoDetails/uVideoDetailsRequest$2$1;->this$1:LuTools/VideoDetails/uVideoDetailsRequest$2;

    iget-object v0, v0, LuTools/VideoDetails/uVideoDetailsRequest$2;->val$client:LuTools/VideoDetails/uVideoDetailsClients;

    iget-object v0, v0, LuTools/VideoDetails/uVideoDetailsClients;->osBrand:Ljava/lang/String;

    const-string v1, "deviceMake"

    invoke-virtual {p0, v1, v0}, LuTools/VideoDetails/uVideoDetailsRequest$2$1$1;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 83
    iget-object v0, p0, LuTools/VideoDetails/uVideoDetailsRequest$2$1$1;->this$2:LuTools/VideoDetails/uVideoDetailsRequest$2$1;

    iget-object v0, v0, LuTools/VideoDetails/uVideoDetailsRequest$2$1;->this$1:LuTools/VideoDetails/uVideoDetailsRequest$2;

    iget-object v0, v0, LuTools/VideoDetails/uVideoDetailsRequest$2;->val$client:LuTools/VideoDetails/uVideoDetailsClients;

    iget-object v0, v0, LuTools/VideoDetails/uVideoDetailsClients;->deviceModel:Ljava/lang/String;

    const-string v1, "deviceModel"

    invoke-virtual {p0, v1, v0}, LuTools/VideoDetails/uVideoDetailsRequest$2$1$1;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 84
    iget-object v0, p0, LuTools/VideoDetails/uVideoDetailsRequest$2$1$1;->this$2:LuTools/VideoDetails/uVideoDetailsRequest$2$1;

    iget-object v0, v0, LuTools/VideoDetails/uVideoDetailsRequest$2$1;->this$1:LuTools/VideoDetails/uVideoDetailsRequest$2;

    iget-object v0, v0, LuTools/VideoDetails/uVideoDetailsRequest$2;->val$client:LuTools/VideoDetails/uVideoDetailsClients;

    iget-object v0, v0, LuTools/VideoDetails/uVideoDetailsClients;->osName:Ljava/lang/String;

    const-string v1, "osName"

    invoke-virtual {p0, v1, v0}, LuTools/VideoDetails/uVideoDetailsRequest$2$1$1;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 85
    iget-object v0, p0, LuTools/VideoDetails/uVideoDetailsRequest$2$1$1;->this$2:LuTools/VideoDetails/uVideoDetailsRequest$2$1;

    iget-object v0, v0, LuTools/VideoDetails/uVideoDetailsRequest$2$1;->this$1:LuTools/VideoDetails/uVideoDetailsRequest$2;

    iget-object v0, v0, LuTools/VideoDetails/uVideoDetailsRequest$2;->val$client:LuTools/VideoDetails/uVideoDetailsClients;

    iget-object v0, v0, LuTools/VideoDetails/uVideoDetailsClients;->osVersion:Ljava/lang/String;

    const-string v1, "osVersion"

    invoke-virtual {p0, v1, v0}, LuTools/VideoDetails/uVideoDetailsRequest$2$1$1;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 86
    iget-object v0, p0, LuTools/VideoDetails/uVideoDetailsRequest$2$1$1;->this$2:LuTools/VideoDetails/uVideoDetailsRequest$2$1;

    iget-object v0, v0, LuTools/VideoDetails/uVideoDetailsRequest$2$1;->this$1:LuTools/VideoDetails/uVideoDetailsRequest$2;

    iget-object v0, v0, LuTools/VideoDetails/uVideoDetailsRequest$2;->val$client:LuTools/VideoDetails/uVideoDetailsClients;

    iget-object v0, v0, LuTools/VideoDetails/uVideoDetailsClients;->androidSDKVersion:Ljava/lang/String;

    const-string v1, "androidSdkVersion"

    invoke-virtual {p0, v1, v0}, LuTools/VideoDetails/uVideoDetailsRequest$2$1$1;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 88
    :cond_0
    return-void
.end method
