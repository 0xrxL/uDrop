.class LuTools/VideoDetails/uVideoDetailsRequest$2$2;
.super Lorg/json/JSONArray;
.source "uVideoDetailsRequest.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LuTools/VideoDetails/uVideoDetailsRequest$2;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:LuTools/VideoDetails/uVideoDetailsRequest$2;


# direct methods
.method constructor <init>(LuTools/VideoDetails/uVideoDetailsRequest$2;)V
    .locals 2
    .param p1, "this$1"    # LuTools/VideoDetails/uVideoDetailsRequest$2;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lorg/json/JSONException;
        }
    .end annotation

    .line 110
    iput-object p1, p0, LuTools/VideoDetails/uVideoDetailsRequest$2$2;->this$1:LuTools/VideoDetails/uVideoDetailsRequest$2;

    invoke-direct {p0}, Lorg/json/JSONArray;-><init>()V

    .line 111
    new-instance v0, LuTools/VideoDetails/uVideoDetailsRequest$2$2$1;

    invoke-direct {v0, p0}, LuTools/VideoDetails/uVideoDetailsRequest$2$2$1;-><init>(LuTools/VideoDetails/uVideoDetailsRequest$2$2;)V

    const/4 v1, 0x0

    invoke-virtual {p0, v1, v0}, LuTools/VideoDetails/uVideoDetailsRequest$2$2;->put(ILjava/lang/Object;)Lorg/json/JSONArray;

    .line 119
    return-void
.end method
