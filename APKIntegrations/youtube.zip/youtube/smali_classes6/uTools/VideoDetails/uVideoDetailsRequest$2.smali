.class LuTools/VideoDetails/uVideoDetailsRequest$2;
.super Lorg/json/JSONObject;
.source "uVideoDetailsRequest.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LuTools/VideoDetails/uVideoDetailsRequest;-><init>(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:LuTools/VideoDetails/uVideoDetailsRequest;

.field final synthetic val$client:LuTools/VideoDetails/uVideoDetailsClients;

.field final synthetic val$videoID:Ljava/lang/String;


# direct methods
.method constructor <init>(LuTools/VideoDetails/uVideoDetailsRequest;LuTools/VideoDetails/uVideoDetailsClients;Ljava/lang/String;)V
    .locals 0
    .param p1, "this$0"    # LuTools/VideoDetails/uVideoDetailsRequest;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010,
            0x1010
        }
        names = {
            null,
            null,
            null
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lorg/json/JSONException;
        }
    .end annotation

    .line 70
    iput-object p1, p0, LuTools/VideoDetails/uVideoDetailsRequest$2;->this$0:LuTools/VideoDetails/uVideoDetailsRequest;

    iput-object p2, p0, LuTools/VideoDetails/uVideoDetailsRequest$2;->val$client:LuTools/VideoDetails/uVideoDetailsClients;

    iput-object p3, p0, LuTools/VideoDetails/uVideoDetailsRequest$2;->val$videoID:Ljava/lang/String;

    invoke-direct {p0}, Lorg/json/JSONObject;-><init>()V

    .line 71
    new-instance p2, LuTools/VideoDetails/uVideoDetailsRequest$2$1;

    invoke-direct {p2, p0}, LuTools/VideoDetails/uVideoDetailsRequest$2$1;-><init>(LuTools/VideoDetails/uVideoDetailsRequest$2;)V

    const-string p3, "context"

    invoke-virtual {p0, p3, p2}, LuTools/VideoDetails/uVideoDetailsRequest$2;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 92
    const-string p2, "contentCheckOk"

    const/4 p3, 0x1

    invoke-virtual {p0, p2, p3}, LuTools/VideoDetails/uVideoDetailsRequest$2;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    .line 93
    const-string p2, "racyCheckOk"

    invoke-virtual {p0, p2, p3}, LuTools/VideoDetails/uVideoDetailsRequest$2;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    .line 94
    const-string p2, "videoId"

    iget-object p3, p0, LuTools/VideoDetails/uVideoDetailsRequest$2;->val$videoID:Ljava/lang/String;

    invoke-virtual {p0, p2, p3}, LuTools/VideoDetails/uVideoDetailsRequest$2;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 95
    return-void
.end method
