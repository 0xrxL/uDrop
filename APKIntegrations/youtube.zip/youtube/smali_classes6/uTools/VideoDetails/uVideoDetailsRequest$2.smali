.class LuTools/VideoDetails/uVideoDetailsRequest$2;
.super Lorg/json/JSONObject;
.source "uVideoDetailsRequest.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LuTools/VideoDetails/uVideoDetailsRequest;-><init>(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:LuTools/VideoDetails/uVideoDetailsRequest;

.field final synthetic val$client:LuTools/VideoDetails/uVideoDetailsClients;

.field final synthetic val$infoToFetch:Ljava/lang/String;

.field final synthetic val$videoID:Ljava/lang/String;


# direct methods
.method constructor <init>(LuTools/VideoDetails/uVideoDetailsRequest;LuTools/VideoDetails/uVideoDetailsClients;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0
    .param p1, "this$0"    # LuTools/VideoDetails/uVideoDetailsRequest;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            null,
            null,
            null,
            null
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lorg/json/JSONException;
        }
    .end annotation

    .line 71
    iput-object p1, p0, LuTools/VideoDetails/uVideoDetailsRequest$2;->this$0:LuTools/VideoDetails/uVideoDetailsRequest;

    iput-object p2, p0, LuTools/VideoDetails/uVideoDetailsRequest$2;->val$client:LuTools/VideoDetails/uVideoDetailsClients;

    iput-object p3, p0, LuTools/VideoDetails/uVideoDetailsRequest$2;->val$videoID:Ljava/lang/String;

    iput-object p4, p0, LuTools/VideoDetails/uVideoDetailsRequest$2;->val$infoToFetch:Ljava/lang/String;

    invoke-direct {p0}, Lorg/json/JSONObject;-><init>()V

    .line 72
    new-instance p2, LuTools/VideoDetails/uVideoDetailsRequest$2$1;

    invoke-direct {p2, p0}, LuTools/VideoDetails/uVideoDetailsRequest$2$1;-><init>(LuTools/VideoDetails/uVideoDetailsRequest$2;)V

    const-string p3, "context"

    invoke-virtual {p0, p3, p2}, LuTools/VideoDetails/uVideoDetailsRequest$2;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 101
    const-string p2, "contentCheckOk"

    const/4 p3, 0x1

    invoke-virtual {p0, p2, p3}, LuTools/VideoDetails/uVideoDetailsRequest$2;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    .line 102
    const-string p2, "racyCheckOk"

    invoke-virtual {p0, p2, p3}, LuTools/VideoDetails/uVideoDetailsRequest$2;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    .line 103
    const-string p2, "videoId"

    iget-object p3, p0, LuTools/VideoDetails/uVideoDetailsRequest$2;->val$videoID:Ljava/lang/String;

    invoke-virtual {p0, p2, p3}, LuTools/VideoDetails/uVideoDetailsRequest$2;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 104
    iget-object p2, p0, LuTools/VideoDetails/uVideoDetailsRequest$2;->val$infoToFetch:Ljava/lang/String;

    const-string p3, "saveVideoToWatchLater"

    invoke-virtual {p2, p3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_0

    .line 105
    const-string p2, "playlistId"

    const-string p3, "WL"

    invoke-virtual {p0, p2, p3}, LuTools/VideoDetails/uVideoDetailsRequest$2;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 106
    const-string p2, "excludeWatchLater"

    const/4 p3, 0x0

    invoke-virtual {p0, p2, p3}, LuTools/VideoDetails/uVideoDetailsRequest$2;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    .line 107
    new-instance p2, LuTools/VideoDetails/uVideoDetailsRequest$2$2;

    invoke-direct {p2, p0}, LuTools/VideoDetails/uVideoDetailsRequest$2$2;-><init>(LuTools/VideoDetails/uVideoDetailsRequest$2;)V

    const-string p3, "actions"

    invoke-virtual {p0, p3, p2}, LuTools/VideoDetails/uVideoDetailsRequest$2;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 122
    :cond_0
    return-void
.end method
