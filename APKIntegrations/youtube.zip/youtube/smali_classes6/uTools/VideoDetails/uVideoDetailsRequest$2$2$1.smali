.class LuTools/VideoDetails/uVideoDetailsRequest$2$2$1;
.super Lorg/json/JSONObject;
.source "uVideoDetailsRequest.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LuTools/VideoDetails/uVideoDetailsRequest$2$2;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$2:LuTools/VideoDetails/uVideoDetailsRequest$2$2;


# direct methods
.method constructor <init>(LuTools/VideoDetails/uVideoDetailsRequest$2$2;)V
    .locals 2
    .param p1, "this$2"    # LuTools/VideoDetails/uVideoDetailsRequest$2$2;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lorg/json/JSONException;
        }
    .end annotation

    .line 114
    iput-object p1, p0, LuTools/VideoDetails/uVideoDetailsRequest$2$2$1;->this$2:LuTools/VideoDetails/uVideoDetailsRequest$2$2;

    invoke-direct {p0}, Lorg/json/JSONObject;-><init>()V

    .line 115
    const-string v0, "action"

    const-string v1, "ACTION_ADD_VIDEO"

    invoke-virtual {p0, v0, v1}, LuTools/VideoDetails/uVideoDetailsRequest$2$2$1;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 116
    iget-object v0, p0, LuTools/VideoDetails/uVideoDetailsRequest$2$2$1;->this$2:LuTools/VideoDetails/uVideoDetailsRequest$2$2;

    iget-object v0, v0, LuTools/VideoDetails/uVideoDetailsRequest$2$2;->this$1:LuTools/VideoDetails/uVideoDetailsRequest$2;

    iget-object v0, v0, LuTools/VideoDetails/uVideoDetailsRequest$2;->val$videoID:Ljava/lang/String;

    const-string v1, "addedVideoId"

    invoke-virtual {p0, v1, v0}, LuTools/VideoDetails/uVideoDetailsRequest$2$2$1;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 117
    return-void
.end method
