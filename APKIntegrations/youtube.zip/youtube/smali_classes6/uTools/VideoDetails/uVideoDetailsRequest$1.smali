.class LuTools/VideoDetails/uVideoDetailsRequest$1;
.super Lorg/json/JSONObject;
.source "uVideoDetailsRequest.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LuTools/VideoDetails/uVideoDetailsRequest;-><init>(Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:LuTools/VideoDetails/uVideoDetailsRequest;

.field final synthetic val$webClientType:LuTools/VideoDetails/uWebClientType;


# direct methods
.method constructor <init>(LuTools/VideoDetails/uVideoDetailsRequest;LuTools/VideoDetails/uWebClientType;)V
    .locals 1
    .param p1, "this$0"    # LuTools/VideoDetails/uVideoDetailsRequest;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            null,
            null
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lorg/json/JSONException;
        }
    .end annotation

    .line 59
    iput-object p1, p0, LuTools/VideoDetails/uVideoDetailsRequest$1;->this$0:LuTools/VideoDetails/uVideoDetailsRequest;

    iput-object p2, p0, LuTools/VideoDetails/uVideoDetailsRequest$1;->val$webClientType:LuTools/VideoDetails/uWebClientType;

    invoke-direct {p0}, Lorg/json/JSONObject;-><init>()V

    .line 60
    new-instance p2, LuTools/VideoDetails/uVideoDetailsRequest$1$1;

    invoke-direct {p2, p0}, LuTools/VideoDetails/uVideoDetailsRequest$1$1;-><init>(LuTools/VideoDetails/uVideoDetailsRequest$1;)V

    const-string v0, "context"

    invoke-virtual {p0, v0, p2}, LuTools/VideoDetails/uVideoDetailsRequest$1;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 74
    const-string p2, "contentCheckOk"

    const/4 v0, 0x1

    invoke-virtual {p0, p2, v0}, LuTools/VideoDetails/uVideoDetailsRequest$1;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    .line 75
    const-string p2, "racyCheckOk"

    invoke-virtual {p0, p2, v0}, LuTools/VideoDetails/uVideoDetailsRequest$1;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    .line 76
    iget-object p2, p0, LuTools/VideoDetails/uVideoDetailsRequest$1;->this$0:LuTools/VideoDetails/uVideoDetailsRequest;

    invoke-static {p2}, LuTools/VideoDetails/uVideoDetailsRequest;->-$$Nest$fgetvideoID(LuTools/VideoDetails/uVideoDetailsRequest;)Ljava/lang/String;

    move-result-object p2

    const-string v0, "videoId"

    invoke-virtual {p0, v0, p2}, LuTools/VideoDetails/uVideoDetailsRequest$1;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 77
    return-void
.end method
