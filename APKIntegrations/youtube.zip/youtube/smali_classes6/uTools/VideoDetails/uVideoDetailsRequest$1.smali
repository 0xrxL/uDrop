.class LuTools/VideoDetails/uVideoDetailsRequest$1;
.super Ljava/util/HashMap;
.source "uVideoDetailsRequest.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LuTools/VideoDetails/uVideoDetailsRequest;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/util/HashMap<",
        "Ljava/lang/String;",
        "Ljava/lang/String;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:LuTools/VideoDetails/uVideoDetailsRequest;


# direct methods
.method constructor <init>(LuTools/VideoDetails/uVideoDetailsRequest;)V
    .locals 2
    .param p1, "this$0"    # LuTools/VideoDetails/uVideoDetailsRequest;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 37
    iput-object p1, p0, LuTools/VideoDetails/uVideoDetailsRequest$1;->this$0:LuTools/VideoDetails/uVideoDetailsRequest;

    invoke-direct {p0}, Ljava/util/HashMap;-><init>()V

    .line 38
    const-string v0, "actionButtons"

    const-string v1, "next?fields=contents.singleColumnWatchNextResults.results.results.contents.slimVideoMetadataSectionRenderer.contents.elementRenderer.newElement.type.componentType.model.videoActionBarModel.videoActionBarData.buttons.buttonViewModel"

    invoke-virtual {p0, v0, v1}, LuTools/VideoDetails/uVideoDetailsRequest$1;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 39
    const-string v0, "channelID"

    const-string v1, "player?prettyPrint=false&fields=videoDetails.channelId"

    invoke-virtual {p0, v0, v1}, LuTools/VideoDetails/uVideoDetailsRequest$1;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 40
    const-string v0, "defaultAudioTrackID"

    const-string v1, "player?fields=streamingData.adaptiveFormats.audioTrack"

    invoke-virtual {p0, v0, v1}, LuTools/VideoDetails/uVideoDetailsRequest$1;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 41
    return-void
.end method
