.class public final synthetic LuTools/uUtils$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/util/function/Predicate;


# instance fields
.field public final synthetic f$0:Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;


# direct methods
.method public synthetic constructor <init>(Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LuTools/uUtils$$ExternalSyntheticLambda0;->f$0:Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;

    return-void
.end method


# virtual methods
.method public final test(Ljava/lang/Object;)Z
    .locals 1

    .line 0
    iget-object v0, p0, LuTools/uUtils$$ExternalSyntheticLambda0;->f$0:Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;

    check-cast p1, Ljava/lang/String;

    invoke-static {v0, p1}, LuTools/uUtils;->$r8$lambda$yKRGTDwFHgOlK-w-W5TPtJhLgqE(Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;Ljava/lang/String;)Z

    move-result p1

    return p1
.end method
