.class public LuTools/uBlocker;
.super Ljava/lang/Object;
.source "uBlocker.java"


# static fields
.field private static final DARK_COLORS:Ljava/util/AbstractMap$SimpleEntry;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/AbstractMap$SimpleEntry<",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static final LIGHT_COLORS:Ljava/util/AbstractMap$SimpleEntry;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/AbstractMap$SimpleEntry<",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static final WHITE_COLOR:I = 0xffffff

.field private static final checkMicroGPackageToastError:Landroid/widget/Toast;

.field private static final commentsComponentsFirst:Ljava/util/AbstractMap$SimpleEntry;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/AbstractMap$SimpleEntry<",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static final commentsComponentsSecond:Ljava/util/AbstractMap$SimpleEntry;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/AbstractMap$SimpleEntry<",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static final fullscreenVideoPlayerComponents:Ljava/util/AbstractMap$SimpleEntry;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/AbstractMap$SimpleEntry<",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static final generalComponents:Ljava/util/AbstractMap$SimpleEntry;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/AbstractMap$SimpleEntry<",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static final hiddenTabMeAccountButtons:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static final hiddenVideoPreviewFlyoutButtons:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static final horizontalShelf:Ljava/util/AbstractMap$SimpleEntry;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/AbstractMap$SimpleEntry<",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static final libraryNavButtonIndex:I = 0x4

.field private static moreDrawerAppsAndInfo:Z

.field private static final openCommentsButtonComponents:Ljava/util/AbstractMap$SimpleEntry;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/AbstractMap$SimpleEntry<",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static openVideoChannelThread:Ljava/lang/Thread;

.field private static final openVideoChannelToastDone:Landroid/widget/Toast;

.field private static final openVideoChannelToastError:Landroid/widget/Toast;

.field private static final openVideoChannelToastInProgress:Landroid/widget/Toast;

.field private static final playerMaximized:Ljava/util/AbstractMap$SimpleEntry;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/AbstractMap$SimpleEntry<",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static quickQualityBottomSheet:Z

.field private static final shortVideoPreviewOverflowButton:Ljava/util/AbstractMap$SimpleEntry;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/AbstractMap$SimpleEntry<",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static final sponsorShipPanelComponents:Ljava/util/AbstractMap$SimpleEntry;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/AbstractMap$SimpleEntry<",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static final topBarButtons:Ljava/util/AbstractMap$SimpleEntry;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/AbstractMap$SimpleEntry<",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static final videoInformationPanelComponents:Ljava/util/AbstractMap$SimpleEntry;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/AbstractMap$SimpleEntry<",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static final videoLookupComponentsFirst:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static final videoLookupComponentsSecond:Ljava/util/AbstractMap$SimpleEntry;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/AbstractMap$SimpleEntry<",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static final videoOtherSettingsPanelComponent:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static final visibleActionButtons:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static synthetic $r8$lambda$40yWSUzeLiR0N6W93Rr05xn1FW4(Ljava/lang/String;Ljava/lang/CharSequence;)Z
    .locals 0

    invoke-virtual {p0, p1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p0

    return p0
.end method

.method static constructor <clinit>()V
    .locals 8

    .line 46
    new-instance v0, Ljava/util/AbstractMap$SimpleEntry;

    .line 49
    const-string v1, "-1"

    const-string v2, "-394759"

    const-string v3, "-83886081"

    invoke-static {v1, v2, v3}, Ljava/util/Set;->of(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v1

    const-string v2, "LIGHT_COLORS"

    invoke-direct {v0, v1, v2}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 47
    invoke-static {v0}, LuTools/uUtils;->InitializeNewBlockList(Ljava/util/AbstractMap$SimpleEntry;)Ljava/util/AbstractMap$SimpleEntry;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->LIGHT_COLORS:Ljava/util/AbstractMap$SimpleEntry;

    .line 58
    new-instance v0, Ljava/util/AbstractMap$SimpleEntry;

    .line 61
    const-string v1, "-14145496"

    const-string v2, "-14606047"

    const-string v3, "-15198184"

    const-string v4, "-15790321"

    const-string v5, "-98492127"

    invoke-static {v1, v2, v3, v4, v5}, Ljava/util/Set;->of(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v1

    const-string v2, "DARK_COLORS"

    invoke-direct {v0, v1, v2}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 59
    invoke-static {v0}, LuTools/uUtils;->InitializeNewBlockList(Ljava/util/AbstractMap$SimpleEntry;)Ljava/util/AbstractMap$SimpleEntry;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->DARK_COLORS:Ljava/util/AbstractMap$SimpleEntry;

    .line 86
    nop

    .line 87
    const-string v0, "Error: No MicroG Installed"

    invoke-static {v0}, LuTools/uUtils;->GetNewToast(Ljava/lang/String;)Landroid/widget/Toast;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->checkMicroGPackageToastError:Landroid/widget/Toast;

    .line 108
    const-string v0, "yt_outline_share"

    const-string v1, "addToPlaylistButtonViewModel"

    const-string v2, "segmentedLikeDislikeButtonViewModel"

    invoke-static {v2, v0, v1}, Ljava/util/List;->of(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->visibleActionButtons:Ljava/util/List;

    .line 160
    const-string v6, "OUTLINE_YOUTUBE_SHORTS_PLUS"

    const-string v7, "QUEUE_PLAY_NEXT"

    const-string v1, "EXTERNAL_LINK"

    const-string v2, "FEEDBACK"

    const-string v3, "FLAG"

    const-string v4, "OFFLINE_DOWNLOAD"

    const-string v5, "OUTLINE_YOUTUBE_MUSIC"

    invoke-static/range {v1 .. v7}, Ljava/util/Set;->of(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->hiddenVideoPreviewFlyoutButtons:Ljava/util/Set;

    .line 184
    new-instance v0, Ljava/util/AbstractMap$SimpleEntry;

    .line 187
    const-string v1, "WATCH_WHILE_FULLSCREEN"

    const-string v2, "WATCH_WHILE_MAXIMIZED"

    invoke-static {v1, v2}, Ljava/util/Set;->of(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v1

    const-string v2, "horizontalShelfSecond"

    invoke-direct {v0, v1, v2}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 185
    invoke-static {v0}, LuTools/uUtils;->InitializeNewBlockList(Ljava/util/AbstractMap$SimpleEntry;)Ljava/util/AbstractMap$SimpleEntry;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->playerMaximized:Ljava/util/AbstractMap$SimpleEntry;

    .line 195
    new-instance v0, Ljava/util/AbstractMap$SimpleEntry;

    .line 198
    const-string v1, "composer_short_creation_button"

    const-string v2, "composer_timestamp_button"

    const-string v3, "sponsorships_comments"

    const-string v4, "super_thanks_button"

    const-string v5, "|CellType|ContainerType|ContainerType|ContainerType|ContainerType|ContainerType|"

    invoke-static {v1, v2, v3, v4, v5}, Ljava/util/Set;->of(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v1

    const-string v2, "commentsComponentsFirst"

    invoke-direct {v0, v1, v2}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 196
    invoke-static {v0}, LuTools/uUtils;->InitializeNewBlockList(Ljava/util/AbstractMap$SimpleEntry;)Ljava/util/AbstractMap$SimpleEntry;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->commentsComponentsFirst:Ljava/util/AbstractMap$SimpleEntry;

    .line 209
    new-instance v0, Ljava/util/AbstractMap$SimpleEntry;

    .line 212
    const-string v1, "leaderboard_item_action_content"

    const-string v2, "button"

    invoke-static {v1, v2}, Ljava/util/Set;->of(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v1

    const-string v3, "commentsComponentsSecond"

    invoke-direct {v0, v1, v3}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 210
    invoke-static {v0}, LuTools/uUtils;->InitializeNewBlockList(Ljava/util/AbstractMap$SimpleEntry;)Ljava/util/AbstractMap$SimpleEntry;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->commentsComponentsSecond:Ljava/util/AbstractMap$SimpleEntry;

    .line 220
    new-instance v0, Ljava/util/AbstractMap$SimpleEntry;

    .line 223
    const-string v1, "overflow_menu_button"

    const-string v3, "quick_actions"

    invoke-static {v1, v3}, Ljava/util/Set;->of(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v1

    const-string v3, "fullscreenVideoPlayerComponents"

    invoke-direct {v0, v1, v3}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 221
    invoke-static {v0}, LuTools/uUtils;->InitializeNewBlockList(Ljava/util/AbstractMap$SimpleEntry;)Ljava/util/AbstractMap$SimpleEntry;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->fullscreenVideoPlayerComponents:Ljava/util/AbstractMap$SimpleEntry;

    .line 231
    new-instance v0, Ljava/util/AbstractMap$SimpleEntry;

    .line 234
    const-string v1, "horizontal_video_shelf"

    const-string v3, "horizontal_shelf."

    invoke-static {v1, v3}, Ljava/util/Set;->of(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v1

    const-string v3, "horizontalShelf"

    invoke-direct {v0, v1, v3}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 232
    invoke-static {v0}, LuTools/uUtils;->InitializeNewBlockList(Ljava/util/AbstractMap$SimpleEntry;)Ljava/util/AbstractMap$SimpleEntry;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->horizontalShelf:Ljava/util/AbstractMap$SimpleEntry;

    .line 242
    new-instance v0, Ljava/util/AbstractMap$SimpleEntry;

    .line 245
    const-string v1, "carousel_header"

    const-string v3, "|ContainerType|ContainerType|ContainerType|"

    invoke-static {v1, v3}, Ljava/util/Set;->of(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v1

    const-string v3, "openCommentsButtonComponents"

    invoke-direct {v0, v1, v3}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 243
    invoke-static {v0}, LuTools/uUtils;->InitializeNewBlockList(Ljava/util/AbstractMap$SimpleEntry;)Ljava/util/AbstractMap$SimpleEntry;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->openCommentsButtonComponents:Ljava/util/AbstractMap$SimpleEntry;

    .line 253
    new-instance v0, Ljava/util/AbstractMap$SimpleEntry;

    .line 256
    const-string v1, "shorts"

    const-string v3, "overflow_button"

    invoke-static {v1, v3}, Ljava/util/Set;->of(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v1

    const-string v3, "shortVideoPreviewOverflowButton"

    invoke-direct {v0, v1, v3}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 254
    invoke-static {v0}, LuTools/uUtils;->InitializeNewBlockList(Ljava/util/AbstractMap$SimpleEntry;)Ljava/util/AbstractMap$SimpleEntry;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->shortVideoPreviewOverflowButton:Ljava/util/AbstractMap$SimpleEntry;

    .line 264
    new-instance v0, Ljava/util/AbstractMap$SimpleEntry;

    .line 267
    const-string v1, "sponsorships_section_list_root"

    invoke-static {v1, v2}, Ljava/util/Set;->of(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v1

    const-string v3, "sponsorShipPanelComponents"

    invoke-direct {v0, v1, v3}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 265
    invoke-static {v0}, LuTools/uUtils;->InitializeNewBlockList(Ljava/util/AbstractMap$SimpleEntry;)Ljava/util/AbstractMap$SimpleEntry;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->sponsorShipPanelComponents:Ljava/util/AbstractMap$SimpleEntry;

    .line 275
    new-instance v0, Ljava/util/AbstractMap$SimpleEntry;

    .line 278
    const-string v1, "video_description_header"

    invoke-static {v1, v2}, Ljava/util/Set;->of(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v1

    const-string v2, "videoInformationPanelComponents"

    invoke-direct {v0, v1, v2}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 276
    invoke-static {v0}, LuTools/uUtils;->InitializeNewBlockList(Ljava/util/AbstractMap$SimpleEntry;)Ljava/util/AbstractMap$SimpleEntry;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->videoInformationPanelComponents:Ljava/util/AbstractMap$SimpleEntry;

    .line 286
    nop

    .line 287
    const-string v0, "tvfilm_attachment"

    invoke-static {v0}, Ljava/util/Set;->of(Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->videoLookupComponentsFirst:Ljava/util/Set;

    .line 290
    new-instance v0, Ljava/util/AbstractMap$SimpleEntry;

    .line 293
    const-string v1, "endorsement_header_footer"

    const-string v2, "expandable_metadata"

    const-string v3, "set_reminder_button"

    const-string v4, "slimline_survey_video_with_context"

    const-string v5, "snappy_horizontal_shelf"

    const-string v6, "video_metadata_carousel"

    invoke-static/range {v1 .. v6}, Ljava/util/Set;->of(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v1

    const-string v2, "videoLookupComponentsSecond"

    invoke-direct {v0, v1, v2}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 291
    invoke-static {v0}, LuTools/uUtils;->InitializeNewBlockList(Ljava/util/AbstractMap$SimpleEntry;)Ljava/util/AbstractMap$SimpleEntry;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->videoLookupComponentsSecond:Ljava/util/AbstractMap$SimpleEntry;

    .line 305
    nop

    .line 306
    const-string v0, "yt_outline_question_circle"

    const-string v1, "yt_outline_volume_stable"

    const-string v2, "yt_outline_youtube_music"

    invoke-static {v0, v1, v2}, Ljava/util/Set;->of(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->videoOtherSettingsPanelComponent:Ljava/util/Set;

    .line 311
    new-instance v0, Ljava/util/AbstractMap$SimpleEntry;

    const/16 v1, 0x39

    new-array v1, v1, [Ljava/lang/String;

    const-string v2, "banner_text_icon_buttoned_layout"

    const/4 v3, 0x0

    aput-object v2, v1, v3

    const/4 v2, 0x1

    const-string v4, "brand_video_"

    aput-object v4, v1, v2

    const/4 v2, 0x2

    const-string v4, "carousel_footered_"

    aput-object v4, v1, v2

    const/4 v2, 0x3

    const-string v4, "compact_landscape_image_layout"

    aput-object v4, v1, v2

    const/4 v2, 0x4

    const-string v4, "composite_concurrent_carousel_layout"

    aput-object v4, v1, v2

    const/4 v2, 0x5

    const-string v4, "full_width_"

    aput-object v4, v1, v2

    const/4 v2, 0x6

    const-string v4, "inline_injection_entrypoint_layout"

    aput-object v4, v1, v2

    const/4 v2, 0x7

    const-string v4, "landscape_image_wide_button_layout"

    aput-object v4, v1, v2

    const/16 v2, 0x8

    const-string v4, "square_image_layout"

    aput-object v4, v1, v2

    const/16 v2, 0x9

    const-string v4, "statement_banner"

    aput-object v4, v1, v2

    const/16 v2, 0xa

    const-string v4, "text_image_"

    aput-object v4, v1, v2

    const/16 v2, 0xb

    const-string v4, "video_display_"

    aput-object v4, v1, v2

    const/16 v2, 0xc

    const-string v4, "browsy_bar"

    aput-object v4, v1, v2

    const/16 v2, 0xd

    const-string v4, "cell_divider"

    aput-object v4, v1, v2

    const/16 v2, 0xe

    const-string v4, "cell_expandable_metadata"

    aput-object v4, v1, v2

    const/16 v2, 0xf

    const-string v4, "channel_guidelines_entry_banner"

    aput-object v4, v1, v2

    const/16 v2, 0x10

    const-string v4, "chips_shelf"

    aput-object v4, v1, v2

    const/16 v2, 0x11

    const-string v4, "community_guidelines"

    aput-object v4, v1, v2

    const/16 v2, 0x12

    const-string v4, "compact_tvfilm_item"

    aput-object v4, v1, v2

    const/16 v2, 0x13

    const-string v4, "emergency_onebox"

    aput-object v4, v1, v2

    const/16 v2, 0x14

    const-string v4, "expandable_list"

    aput-object v4, v1, v2

    const/16 v2, 0x15

    const-string v4, "expandable_section"

    aput-object v4, v1, v2

    const/16 v2, 0x16

    const-string v4, "feed_nudge"

    aput-object v4, v1, v2

    const/16 v2, 0x17

    const-string v4, "fullscreen_related_videos_entry_point"

    aput-object v4, v1, v2

    const/16 v2, 0x18

    const-string v4, "grid_channel_shelf"

    aput-object v4, v1, v2

    const/16 v2, 0x19

    const-string v4, "hero_carousel"

    aput-object v4, v1, v2

    const/16 v2, 0x1a

    const-string v4, "horizontal_gaming_shelf"

    aput-object v4, v1, v2

    const/16 v2, 0x1b

    const-string v4, "horizontal_tile_shelf"

    aput-object v4, v1, v2

    const/16 v2, 0x1c

    const-string v4, "how_this_was_made_section"

    aput-object v4, v1, v2

    const/16 v2, 0x1d

    const-string v4, "image_shelf"

    aput-object v4, v1, v2

    const/16 v2, 0x1e

    const-string v4, "info_card_teaser_overlay"

    aput-object v4, v1, v2

    const/16 v2, 0x1f

    const-string v4, "infocards_section"

    aput-object v4, v1, v2

    const/16 v2, 0x20

    const-string v4, "live_viewer_leaderboard_chat_entry_point"

    aput-object v4, v1, v2

    const/16 v2, 0x21

    const-string v4, "live_chat_sponsorships_new_member_announcement"

    aput-object v4, v1, v2

    const/16 v2, 0x22

    const-string v4, "live_chat_text_message_banner"

    aput-object v4, v1, v2

    const/16 v2, 0x23

    const-string v4, "live_chat_ticker_creator_goal_view_model"

    aput-object v4, v1, v2

    const/16 v2, 0x24

    const-string v4, "macro_markers_carousel"

    aput-object v4, v1, v2

    const/16 v2, 0x25

    const-string v4, "medical_panel"

    aput-object v4, v1, v2

    const/16 v2, 0x26

    const-string v4, "member_recognition_shelf"

    aput-object v4, v1, v2

    const/16 v2, 0x27

    const-string v4, "music_recap_banner"

    aput-object v4, v1, v2

    const/16 v2, 0x28

    const-string v4, "offer_module_root"

    aput-object v4, v1, v2

    const/16 v2, 0x29

    const-string v4, "paid_content_overlay"

    aput-object v4, v1, v2

    const/16 v2, 0x2a

    const-string v4, "playlist_section"

    aput-object v4, v1, v2

    const/16 v2, 0x2b

    const-string v4, "product_carousel"

    aput-object v4, v1, v2

    const/16 v2, 0x2c

    const-string v4, "products_in_video_with_preview"

    aput-object v4, v1, v2

    const/16 v2, 0x2d

    const-string v4, "publisher_transparency_panel"

    aput-object v4, v1, v2

    const/16 v2, 0x2e

    const-string v4, "search_friction"

    aput-object v4, v1, v2

    const/16 v2, 0x2f

    const-string v4, "shelf_header"

    aput-object v4, v1, v2

    const/16 v2, 0x30

    const-string v4, "shopping_description_shelf"

    aput-object v4, v1, v2

    const/16 v2, 0x31

    const-string v4, "shorts_shelf"

    aput-object v4, v1, v2

    const/16 v2, 0x32

    const-string v4, "single_item_information_panel"

    aput-object v4, v1, v2

    const/16 v2, 0x33

    const-string v4, "super_chat_item"

    aput-object v4, v1, v2

    const/16 v2, 0x34

    const-string v4, "timed_reaction"

    aput-object v4, v1, v2

    const/16 v2, 0x35

    const-string v4, "topic_with_thumbnail_view_model"

    aput-object v4, v1, v2

    const/16 v2, 0x36

    const-string v4, "transcript_section"

    aput-object v4, v1, v2

    const/16 v2, 0x37

    const-string v4, "video_attributes_section"

    aput-object v4, v1, v2

    const/16 v2, 0x38

    const-string v4, "|suggested_action."

    aput-object v4, v1, v2

    .line 314
    invoke-static {v1}, Ljava/util/Set;->of([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v1

    const-string v2, "generalComponents"

    invoke-direct {v0, v1, v2}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 312
    invoke-static {v0}, LuTools/uUtils;->InitializeNewBlockList(Ljava/util/AbstractMap$SimpleEntry;)Ljava/util/AbstractMap$SimpleEntry;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->generalComponents:Ljava/util/AbstractMap$SimpleEntry;

    .line 380
    sput-boolean v3, LuTools/uBlocker;->moreDrawerAppsAndInfo:Z

    .line 381
    sput-boolean v3, LuTools/uBlocker;->quickQualityBottomSheet:Z

    .line 576
    const-string v0, "UNLIMITED"

    const-string v1, "HELP"

    const-string v2, "ASSESSMENT"

    const-string v3, "FEEDBACK"

    invoke-static {v2, v3, v0, v1}, Ljava/util/Set;->of(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->hiddenTabMeAccountButtons:Ljava/util/Set;

    .line 606
    new-instance v0, Ljava/util/AbstractMap$SimpleEntry;

    .line 609
    const-string v1, "CREATION_ENTRY"

    const-string v2, "FAB_CAMERA"

    const-string v3, "TAB_ACTIVITY_CAIRO"

    invoke-static {v1, v2, v3}, Ljava/util/Set;->of(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v1

    const-string v2, "topbarButtons"

    invoke-direct {v0, v1, v2}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 607
    invoke-static {v0}, LuTools/uUtils;->InitializeNewBlockList(Ljava/util/AbstractMap$SimpleEntry;)Ljava/util/AbstractMap$SimpleEntry;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->topBarButtons:Ljava/util/AbstractMap$SimpleEntry;

    .line 631
    nop

    .line 632
    const-string v0, "Opening video channel..."

    invoke-static {v0}, LuTools/uUtils;->GetNewToast(Ljava/lang/String;)Landroid/widget/Toast;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->openVideoChannelToastInProgress:Landroid/widget/Toast;

    .line 633
    nop

    .line 634
    const-string v0, "Channel opened"

    invoke-static {v0}, LuTools/uUtils;->GetNewToast(Ljava/lang/String;)Landroid/widget/Toast;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->openVideoChannelToastDone:Landroid/widget/Toast;

    .line 635
    nop

    .line 636
    const-string v0, "Error: Failed to open video channel"

    invoke-static {v0}, LuTools/uUtils;->GetNewToast(Ljava/lang/String;)Landroid/widget/Toast;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->openVideoChannelToastError:Landroid/widget/Toast;

    .line 637
    const/4 v0, 0x0

    sput-object v0, LuTools/uBlocker;->openVideoChannelThread:Ljava/lang/Thread;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 45
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static ChangeLithoUIColor(I)I
    .locals 3
    .param p0, "originalValue"    # I

    .line 74
    nop

    .line 75
    invoke-static {p0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    .line 76
    invoke-static {}, LuTools/uUtils;->GetDarkTheme()Z

    move-result v1

    if-eqz v1, :cond_0

    sget-object v1, LuTools/uBlocker;->DARK_COLORS:Ljava/util/AbstractMap$SimpleEntry;

    goto :goto_0

    :cond_0
    sget-object v1, LuTools/uBlocker;->LIGHT_COLORS:Ljava/util/AbstractMap$SimpleEntry;

    :goto_0
    sget-object v2, LuTools/uUtils$Entries;->ANY:LuTools/uUtils$Entries;

    .line 74
    invoke-static {v0, v1, v2}, LuTools/uUtils;->SearchInSetCorasick(Ljava/lang/String;Ljava/util/AbstractMap$SimpleEntry;LuTools/uUtils$Entries;)Z

    move-result v0

    if-eqz v0, :cond_2

    .line 80
    invoke-static {}, LuTools/uUtils;->GetDarkTheme()Z

    move-result v0

    if-eqz v0, :cond_1

    const v0, -0xffffff

    goto :goto_1

    :cond_1
    const v0, 0xffffff

    :goto_1
    return v0

    .line 82
    :cond_2
    return p0
.end method

.method public static CheckMicroGPackage(Landroid/app/Activity;)V
    .locals 3
    .param p0, "activity"    # Landroid/app/Activity;

    .line 90
    nop

    .line 91
    :try_start_0
    invoke-virtual {p0}, Landroid/app/Activity;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const-string v1, "app.revanced.android.gms"

    .line 92
    const/4 v2, 0x1

    invoke-virtual {v0, v1, v2}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    .line 99
    goto :goto_0

    .line 97
    :catch_0
    move-exception v0

    .line 98
    .local v0, "exception":Landroid/content/pm/PackageManager$NameNotFoundException;
    sget-object v1, LuTools/uBlocker;->checkMicroGPackageToastError:Landroid/widget/Toast;

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    .line 100
    .end local v0    # "exception":Landroid/content/pm/PackageManager$NameNotFoundException;
    :goto_0
    return-void
.end method

.method public static DisableAutoPlayCountdown(Landroid/view/View;)V
    .locals 1
    .param p0, "view"    # Landroid/view/View;

    .line 104
    :try_start_0
    invoke-virtual {p0}, Landroid/view/View;->callOnClick()Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 105
    :goto_0
    goto :goto_1

    :catch_0
    move-exception v0

    goto :goto_0

    .line 106
    :goto_1
    return-void
.end method

.method public static HideActionButtons(Ljava/util/List;Ljava/lang/String;)V
    .locals 9
    .param p1, "identifier"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/Object;",
            ">;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 114
    .local p0, "list":Ljava/util/List;, "Ljava/util/List<Ljava/lang/Object;>;"
    const/4 v0, 0x0

    invoke-interface {p0, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    .line 116
    .local v0, "firstListElem":Ljava/lang/Object;
    invoke-static {}, LuTools/uUtils;->GetCurrentActionButtonsList()Ljava/util/List;

    move-result-object v1

    .line 118
    .local v1, "currentActionButtonsList":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    if-eqz p1, :cond_5

    .line 119
    const-string v2, "video_action_bar"

    invoke-virtual {p1, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_5

    if-eqz p0, :cond_5

    .line 121
    invoke-interface {p0}, Ljava/util/List;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_5

    .line 122
    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_5

    if-eqz v0, :cond_5

    .line 124
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    const-string v3, "LazilyConvertedElement"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_5

    .line 126
    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v2

    .line 127
    .local v2, "listSize":I
    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v3

    .line 129
    .local v3, "currentActionButtonsListSize":I
    const/4 v4, 0x3

    if-le v2, v4, :cond_4

    .line 131
    invoke-interface {v1}, Ljava/util/List;->stream()Ljava/util/stream/Stream;

    move-result-object v5

    new-instance v6, LuTools/uBlocker$$ExternalSyntheticLambda3;

    invoke-direct {v6}, LuTools/uBlocker$$ExternalSyntheticLambda3;-><init>()V

    .line 132
    invoke-interface {v5, v6}, Ljava/util/stream/Stream;->noneMatch(Ljava/util/function/Predicate;)Z

    move-result v5

    if-eqz v5, :cond_0

    goto :goto_2

    .line 141
    :cond_0
    sub-int v5, v2, v3

    const/4 v6, 0x1

    if-ne v5, v6, :cond_1

    .line 142
    const-string v5, "yt_outline_youtube_shorts_plus"

    invoke-interface {v1, v4, v5}, Ljava/util/List;->add(ILjava/lang/Object;)V

    .line 145
    :cond_1
    add-int/lit8 v4, v3, -0x1

    .local v4, "i":I
    :goto_0
    if-ltz v4, :cond_5

    .line 146
    if-le v4, v6, :cond_3

    sget-object v5, LuTools/uBlocker;->visibleActionButtons:Ljava/util/List;

    .line 148
    invoke-interface {v5}, Ljava/util/List;->stream()Ljava/util/stream/Stream;

    move-result-object v5

    invoke-interface {v1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    invoke-static {v7}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v8, LuTools/uBlocker$$ExternalSyntheticLambda4;

    invoke-direct {v8, v7}, LuTools/uBlocker$$ExternalSyntheticLambda4;-><init>(Ljava/lang/String;)V

    invoke-interface {v5, v8}, Ljava/util/stream/Stream;->anyMatch(Ljava/util/function/Predicate;)Z

    move-result v5

    if-nez v5, :cond_3

    add-int/lit8 v5, v2, -0x1

    if-le v4, v5, :cond_2

    .line 152
    goto :goto_1

    .line 155
    :cond_2
    invoke-interface {p0, v4}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    .line 145
    :cond_3
    :goto_1
    add-int/lit8 v4, v4, -0x1

    goto :goto_0

    .line 138
    .end local v4    # "i":I
    :cond_4
    :goto_2
    return-void

    .line 158
    .end local v2    # "listSize":I
    .end local v3    # "currentActionButtonsListSize":I
    :cond_5
    return-void
.end method

.method public static HideHighBitrateResolution(Ljava/lang/String;)Z
    .locals 1
    .param p0, "originalValue"    # Ljava/lang/String;

    .line 180
    const-string v0, "Premium"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    return v0
.end method

.method public static HideLithoTemplate(Ljava/lang/String;)Z
    .locals 5
    .param p0, "templateTreeComponent"    # Ljava/lang/String;

    .line 385
    invoke-static {}, LuTools/uUtils;->GetVideoChannelOpen()Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    .line 388
    invoke-static {}, LuTools/uUtils;->GetVideoChannelOpen()Z

    move-result v0

    if-eqz v0, :cond_1

    .line 391
    invoke-static {}, LuTools/uUtils;->GetPlayerType()Ljava/lang/Enum;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object v0

    sget-object v2, LuTools/uBlocker;->playerMaximized:Ljava/util/AbstractMap$SimpleEntry;

    sget-object v3, LuTools/uUtils$Entries;->ANY:LuTools/uUtils$Entries;

    .line 390
    invoke-static {v0, v2, v3}, LuTools/uUtils;->SearchInSetCorasick(Ljava/lang/String;Ljava/util/AbstractMap$SimpleEntry;LuTools/uUtils$Entries;)Z

    move-result v0

    if-eqz v0, :cond_1

    :cond_0
    nop

    .line 398
    const-string v0, "post_"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 400
    return v1

    .line 403
    :cond_1
    const-string v0, "featured_channel_watermark_overlay"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_2

    .line 404
    return v1

    .line 408
    :cond_2
    sget-object v0, LuTools/uBlocker;->commentsComponentsFirst:Ljava/util/AbstractMap$SimpleEntry;

    sget-object v2, LuTools/uUtils$Entries;->ANY:LuTools/uUtils$Entries;

    invoke-static {p0, v0, v2}, LuTools/uUtils;->SearchInSetCorasick(Ljava/lang/String;Ljava/util/AbstractMap$SimpleEntry;LuTools/uUtils$Entries;)Z

    move-result v0

    if-nez v0, :cond_16

    sget-object v0, LuTools/uBlocker;->commentsComponentsSecond:Ljava/util/AbstractMap$SimpleEntry;

    sget-object v2, LuTools/uUtils$Entries;->ALL:LuTools/uUtils$Entries;

    .line 414
    invoke-static {p0, v0, v2}, LuTools/uUtils;->SearchInSetCorasick(Ljava/lang/String;Ljava/util/AbstractMap$SimpleEntry;LuTools/uUtils$Entries;)Z

    move-result v0

    if-eqz v0, :cond_3

    goto/16 :goto_4

    .line 424
    :cond_3
    sget-object v0, LuTools/uBlocker;->fullscreenVideoPlayerComponents:Ljava/util/AbstractMap$SimpleEntry;

    sget-object v2, LuTools/uUtils$Entries;->ALL:LuTools/uUtils$Entries;

    invoke-static {p0, v0, v2}, LuTools/uUtils;->SearchInSetCorasick(Ljava/lang/String;Ljava/util/AbstractMap$SimpleEntry;LuTools/uUtils$Entries;)Z

    move-result v0

    if-eqz v0, :cond_4

    .line 430
    return v1

    .line 434
    :cond_4
    invoke-static {}, LuTools/uUtils;->GetNavigationBarActionDown()Z

    move-result v0

    const/4 v2, 0x0

    if-eqz v0, :cond_5

    .line 436
    const-string v0, "account_header"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_5

    .line 438
    invoke-static {v1}, LuTools/uUtils;->SetAccountTabOpen(Z)V

    .line 440
    invoke-static {v2}, LuTools/uUtils;->SetNavigationBarActionDown(Z)V

    .line 443
    :cond_5
    sget-object v0, LuTools/uBlocker;->horizontalShelf:Ljava/util/AbstractMap$SimpleEntry;

    sget-object v3, LuTools/uUtils$Entries;->ANY:LuTools/uUtils$Entries;

    invoke-static {p0, v0, v3}, LuTools/uUtils;->SearchInSetCorasick(Ljava/lang/String;Ljava/util/AbstractMap$SimpleEntry;LuTools/uUtils$Entries;)Z

    move-result v0

    if-eqz v0, :cond_8

    .line 449
    invoke-static {}, LuTools/uUtils;->GetAccountTabOpen()Z

    move-result v0

    if-eqz v0, :cond_7

    .line 452
    invoke-static {}, LuTools/uUtils;->GetPlayerType()Ljava/lang/Enum;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object v0

    sget-object v3, LuTools/uBlocker;->playerMaximized:Ljava/util/AbstractMap$SimpleEntry;

    sget-object v4, LuTools/uUtils$Entries;->ANY:LuTools/uUtils$Entries;

    .line 451
    invoke-static {v0, v3, v4}, LuTools/uUtils;->SearchInSetCorasick(Ljava/lang/String;Ljava/util/AbstractMap$SimpleEntry;LuTools/uUtils$Entries;)Z

    move-result v0

    if-eqz v0, :cond_6

    goto :goto_0

    :cond_6
    move v1, v2

    goto :goto_1

    :cond_7
    :goto_0
    nop

    .line 449
    :goto_1
    return v1

    .line 459
    :cond_8
    invoke-static {}, LuTools/uUtils;->GetCommentsPanelOpen()Z

    move-result v0

    if-eqz v0, :cond_9

    .line 461
    const-string v0, "progress_bar"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_9

    .line 463
    return v1

    .line 467
    :cond_9
    const-string v0, "more_drawer."

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_b

    .line 468
    const-string v0, "divider"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_a

    .line 469
    sput-boolean v1, LuTools/uBlocker;->moreDrawerAppsAndInfo:Z

    .line 472
    :cond_a
    sget-boolean v0, LuTools/uBlocker;->moreDrawerAppsAndInfo:Z

    return v0

    .line 474
    :cond_b
    sput-boolean v2, LuTools/uBlocker;->moreDrawerAppsAndInfo:Z

    .line 478
    const-string v0, "video_metadata_carousel"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_e

    .line 479
    const-string v0, "|carousel_item."

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_d

    sget-object v0, LuTools/uBlocker;->openCommentsButtonComponents:Ljava/util/AbstractMap$SimpleEntry;

    sget-object v3, LuTools/uUtils$Entries;->ALL:LuTools/uUtils$Entries;

    .line 481
    invoke-static {p0, v0, v3}, LuTools/uUtils;->SearchInSetCorasick(Ljava/lang/String;Ljava/util/AbstractMap$SimpleEntry;LuTools/uUtils$Entries;)Z

    move-result v0

    if-eqz v0, :cond_c

    goto :goto_2

    :cond_c
    move v1, v2

    goto :goto_3

    :cond_d
    :goto_2
    nop

    .line 479
    :goto_3
    return v1

    .line 489
    :cond_e
    const-string v0, "quick_quality_sheet_content"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_f

    .line 490
    sput-boolean v1, LuTools/uBlocker;->quickQualityBottomSheet:Z

    .line 492
    return v2

    .line 496
    :cond_f
    invoke-static {}, LuTools/uUtils;->GetVideoChannelOpen()Z

    move-result v0

    if-eqz v0, :cond_10

    .line 497
    sget-object v0, LuTools/uBlocker;->shortVideoPreviewOverflowButton:Ljava/util/AbstractMap$SimpleEntry;

    sget-object v2, LuTools/uUtils$Entries;->ALL:LuTools/uUtils$Entries;

    invoke-static {p0, v0, v2}, LuTools/uUtils;->SearchInSetCorasick(Ljava/lang/String;Ljava/util/AbstractMap$SimpleEntry;LuTools/uUtils$Entries;)Z

    move-result v0

    if-eqz v0, :cond_10

    .line 503
    return v1

    .line 508
    :cond_10
    sget-object v0, LuTools/uBlocker;->sponsorShipPanelComponents:Ljava/util/AbstractMap$SimpleEntry;

    sget-object v2, LuTools/uUtils$Entries;->ALL:LuTools/uUtils$Entries;

    invoke-static {p0, v0, v2}, LuTools/uUtils;->SearchInSetCorasick(Ljava/lang/String;Ljava/util/AbstractMap$SimpleEntry;LuTools/uUtils$Entries;)Z

    move-result v0

    if-eqz v0, :cond_11

    .line 514
    return v1

    .line 518
    :cond_11
    sget-object v0, LuTools/uBlocker;->videoInformationPanelComponents:Ljava/util/AbstractMap$SimpleEntry;

    sget-object v2, LuTools/uUtils$Entries;->ALL:LuTools/uUtils$Entries;

    invoke-static {p0, v0, v2}, LuTools/uUtils;->SearchInSetCorasick(Ljava/lang/String;Ljava/util/AbstractMap$SimpleEntry;LuTools/uUtils$Entries;)Z

    move-result v0

    if-eqz v0, :cond_12

    .line 524
    return v1

    .line 528
    :cond_12
    const-string v0, "overflow_menu_item"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_13

    .line 531
    invoke-static {}, LuTools/uUtils;->GetProtoBufferComponents()Ljava/nio/ByteBuffer;

    move-result-object v0

    sget-object v2, LuTools/uBlocker;->videoOtherSettingsPanelComponent:Ljava/util/Set;

    sget-object v3, LuTools/uUtils$Entries;->ANY:LuTools/uUtils$Entries;

    .line 530
    invoke-static {v0, v2, v3}, LuTools/uUtils;->ByteBufferContainsString(Ljava/nio/ByteBuffer;Ljava/util/Set;LuTools/uUtils$Entries;)Z

    move-result v0

    if-eqz v0, :cond_13

    .line 536
    return v1

    .line 541
    :cond_13
    invoke-static {}, LuTools/uUtils;->GetProtoBufferComponents()Ljava/nio/ByteBuffer;

    move-result-object v0

    sget-object v2, LuTools/uBlocker;->videoLookupComponentsFirst:Ljava/util/Set;

    sget-object v3, LuTools/uUtils$Entries;->ANY:LuTools/uUtils$Entries;

    .line 540
    invoke-static {v0, v2, v3}, LuTools/uUtils;->ByteBufferContainsString(Ljava/nio/ByteBuffer;Ljava/util/Set;LuTools/uUtils$Entries;)Z

    move-result v0

    if-eqz v0, :cond_14

    .line 546
    return v1

    .line 549
    :cond_14
    const-string v0, "video_lockup_with_attachment"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_15

    .line 550
    sget-object v0, LuTools/uBlocker;->videoLookupComponentsSecond:Ljava/util/AbstractMap$SimpleEntry;

    sget-object v1, LuTools/uUtils$Entries;->ANY:LuTools/uUtils$Entries;

    invoke-static {p0, v0, v1}, LuTools/uUtils;->SearchInSetCorasick(Ljava/lang/String;Ljava/util/AbstractMap$SimpleEntry;LuTools/uUtils$Entries;)Z

    move-result v0

    return v0

    .line 558
    :cond_15
    sget-object v0, LuTools/uBlocker;->generalComponents:Ljava/util/AbstractMap$SimpleEntry;

    sget-object v1, LuTools/uUtils$Entries;->ANY:LuTools/uUtils$Entries;

    invoke-static {p0, v0, v1}, LuTools/uUtils;->SearchInSetCorasick(Ljava/lang/String;Ljava/util/AbstractMap$SimpleEntry;LuTools/uUtils$Entries;)Z

    move-result v0

    return v0

    .line 420
    :cond_16
    :goto_4
    return v1
.end method

.method public static HideLiveChatSubscribersShelf(Landroid/view/View;)V
    .locals 2
    .param p0, "view"    # Landroid/view/View;

    .line 567
    :try_start_0
    invoke-virtual {p0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v0

    new-instance v1, LuTools/uBlocker$$ExternalSyntheticLambda2;

    invoke-direct {v1, p0}, LuTools/uBlocker$$ExternalSyntheticLambda2;-><init>(Landroid/view/View;)V

    invoke-virtual {v0, v1}, Landroid/view/ViewTreeObserver;->addOnGlobalLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 573
    :catch_0
    move-exception v0

    :goto_0
    nop

    .line 574
    return-void
.end method

.method public static HideNavigationBarButtons(Landroid/view/View;)V
    .locals 2
    .param p0, "view"    # Landroid/view/View;

    .line 600
    :try_start_0
    invoke-static {}, LuTools/uUtils;->GetNavigationBarPivot()Ljava/lang/Enum;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object v0

    const-string v1, "TAB_SHORTS"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 601
    invoke-static {p0}, LuTools/uUtils;->HideView(Landroid/view/View;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 603
    :catch_0
    move-exception v0

    :cond_0
    :goto_0
    nop

    .line 604
    return-void
.end method

.method public static HideTabMeAccountButton(Landroid/view/View;Ljava/lang/Enum;)V
    .locals 4
    .param p0, "button"    # Landroid/view/View;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            "Ljava/lang/Enum<",
            "*>;)V"
        }
    .end annotation

    .line 584
    .local p1, "buttonName":Ljava/lang/Enum;, "Ljava/lang/Enum<*>;"
    :try_start_0
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    invoke-interface {v0}, Landroid/view/ViewParent;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    instance-of v1, v0, Landroid/view/ViewGroup;

    if-eqz v1, :cond_2

    check-cast v0, Landroid/view/ViewGroup;

    .line 585
    .local v0, "viewGroup":Landroid/view/ViewGroup;
    sget-object v1, LuTools/uBlocker;->hiddenTabMeAccountButtons:Ljava/util/Set;

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    .line 586
    .local v2, "hiddenTabMeAccountButton":Ljava/lang/String;
    invoke-virtual {p1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_1

    .line 587
    invoke-virtual {v0}, Landroid/view/ViewGroup;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v3

    instance-of v3, v3, Landroid/view/ViewGroup$MarginLayoutParams;

    if-eqz v3, :cond_0

    .line 588
    invoke-static {v0}, LuTools/uUtils;->HideViewGroupByMarginLayout(Landroid/view/ViewGroup;)V

    goto :goto_1

    .line 590
    :cond_0
    invoke-static {v0}, LuTools/uUtils;->HideViewGroupByLayoutParams(Landroid/view/ViewGroup;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 593
    .end local v2    # "hiddenTabMeAccountButton":Ljava/lang/String;
    :cond_1
    :goto_1
    goto :goto_0

    .line 595
    .end local v0    # "viewGroup":Landroid/view/ViewGroup;
    :catch_0
    move-exception v0

    :cond_2
    nop

    .line 596
    return-void
.end method

.method public static HideTopBarButtons(Landroid/view/View;)V
    .locals 3
    .param p0, "view"    # Landroid/view/View;

    .line 621
    :try_start_0
    invoke-static {}, LuTools/uUtils;->GetTopBarPivot()Ljava/lang/Enum;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object v0

    sget-object v1, LuTools/uBlocker;->topBarButtons:Ljava/util/AbstractMap$SimpleEntry;

    sget-object v2, LuTools/uUtils$Entries;->ANY:LuTools/uUtils$Entries;

    .line 620
    invoke-static {v0, v1, v2}, LuTools/uUtils;->SearchInSetCorasick(Ljava/lang/String;Ljava/util/AbstractMap$SimpleEntry;LuTools/uUtils$Entries;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 626
    invoke-static {p0}, LuTools/uUtils;->HideView(Landroid/view/View;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 628
    :catch_0
    move-exception v0

    :cond_0
    :goto_0
    nop

    .line 629
    return-void
.end method

.method public static HideVideoPreviewFlyoutButton(Ljava/lang/Enum;)Z
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Enum<",
            "*>;)Z"
        }
    .end annotation

    .line 170
    .local p0, "button":Ljava/lang/Enum;, "Ljava/lang/Enum<*>;"
    sget-object v0, LuTools/uBlocker;->hiddenVideoPreviewFlyoutButtons:Ljava/util/Set;

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    .line 171
    .local v1, "hiddenVideoPreviewFlyoutButton":Ljava/lang/String;
    invoke-virtual {p0}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    .line 172
    const/4 v0, 0x1

    return v0

    .line 174
    .end local v1    # "hiddenVideoPreviewFlyoutButton":Ljava/lang/String;
    :cond_0
    goto :goto_0

    .line 176
    :cond_1
    const/4 v0, 0x0

    return v0
.end method

.method public static OpenVideoChannel(Ljava/lang/String;)Z
    .locals 4
    .param p0, "videoID"    # Ljava/lang/String;

    .line 639
    sget-object v0, LuTools/uBlocker;->openVideoChannelThread:Ljava/lang/Thread;

    if-nez v0, :cond_0

    .line 640
    invoke-static {}, LuTools/uUtils;->GetCommentsPanelOpen()Z

    move-result v0

    if-nez v0, :cond_0

    invoke-static {}, LuTools/uUtils;->GetLithoActionDownDuration()J

    move-result-wide v0

    const-wide/16 v2, 0x3e8

    cmp-long v0, v0, v2

    if-ltz v0, :cond_0

    .line 641
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, LuTools/uBlocker$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0}, LuTools/uBlocker$$ExternalSyntheticLambda0;-><init>(Ljava/lang/String;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    sput-object v0, LuTools/uBlocker;->openVideoChannelThread:Ljava/lang/Thread;

    .line 687
    sget-object v0, LuTools/uBlocker;->openVideoChannelThread:Ljava/lang/Thread;

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 689
    const/4 v0, 0x1

    return v0

    .line 693
    :cond_0
    const/4 v0, 0x0

    return v0
.end method

.method public static OpenVideoResolutionsFlyout(Landroid/support/v7/widget/RecyclerView;)V
    .locals 2
    .param p0, "recyclerView"    # Landroid/support/v7/widget/RecyclerView;

    .line 698
    :try_start_0
    invoke-virtual {p0}, Landroid/support/v7/widget/RecyclerView;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v0

    new-instance v1, LuTools/uBlocker$$ExternalSyntheticLambda1;

    invoke-direct {v1, p0}, LuTools/uBlocker$$ExternalSyntheticLambda1;-><init>(Landroid/support/v7/widget/RecyclerView;)V

    invoke-virtual {v0, v1}, Landroid/view/ViewTreeObserver;->addOnDrawListener(Landroid/view/ViewTreeObserver$OnDrawListener;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 706
    :catch_0
    move-exception v0

    :goto_0
    nop

    .line 707
    return-void
.end method

.method public static OverrideTrackingUrl(Landroid/net/Uri;)Landroid/net/Uri;
    .locals 2
    .param p0, "trackingUrl"    # Landroid/net/Uri;

    .line 710
    invoke-virtual {p0}, Landroid/net/Uri;->buildUpon()Landroid/net/Uri$Builder;

    move-result-object v0

    const-string v1, "www.youtube.com"

    invoke-virtual {v0, v1}, Landroid/net/Uri$Builder;->authority(Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object v0

    invoke-virtual {v0}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    move-result-object v0

    return-object v0
.end method

.method public static ShortsPlayerBypassing(Ljava/lang/String;)Z
    .locals 5
    .param p0, "shortsVideoID"    # Ljava/lang/String;

    .line 715
    :try_start_0
    invoke-static {}, LuTools/uUtils;->GetMainActivity()Landroid/app/Activity;

    move-result-object v0

    .line 717
    .local v0, "context":Landroid/content/Context;
    new-instance v1, Landroid/content/Intent;

    const-string v2, "android.intent.action.VIEW"

    const-string v3, "https://www.youtube.com/watch?v=%s"

    filled-new-array {p0}, [Ljava/lang/Object;

    move-result-object v4

    .line 721
    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    .line 720
    invoke-static {v3}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v3

    invoke-direct {v1, v2, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 728
    .local v1, "videoPlayerIntent":Landroid/content/Intent;
    const/high16 v2, 0x10000000

    invoke-virtual {v1, v2}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    .line 729
    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 731
    invoke-virtual {v0, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 733
    const/4 v2, 0x1

    return v2

    .line 734
    .end local v0    # "context":Landroid/content/Context;
    .end local v1    # "videoPlayerIntent":Landroid/content/Intent;
    :catch_0
    move-exception v0

    .line 736
    const/4 v0, 0x0

    return v0
.end method

.method static synthetic lambda$HideActionButtons$0(Ljava/lang/String;)Z
    .locals 2
    .param p0, "s"    # Ljava/lang/String;

    .line 135
    sget-object v0, LuTools/uBlocker;->visibleActionButtons:Ljava/util/List;

    sget-object v1, LuTools/uBlocker;->visibleActionButtons:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/CharSequence;

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    return v0
.end method

.method static synthetic lambda$HideLiveChatSubscribersShelf$1(Landroid/view/View;)V
    .locals 3
    .param p0, "view"    # Landroid/view/View;

    .line 568
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    .line 569
    .local v0, "parent":Landroid/view/ViewParent;
    instance-of v1, v0, Landroid/support/v7/widget/RecyclerView;

    if-eqz v1, :cond_0

    .line 570
    move-object v1, v0

    check-cast v1, Landroid/support/v7/widget/RecyclerView;

    const/16 v2, 0x8

    invoke-virtual {v1, v2}, Landroid/support/v7/widget/RecyclerView;->setVisibility(I)V

    .line 572
    :cond_0
    return-void
.end method

.method static synthetic lambda$OpenVideoChannel$2(Ljava/lang/String;)V
    .locals 8
    .param p0, "videoID"    # Ljava/lang/String;

    .line 643
    const/4 v0, 0x0

    :try_start_0
    sget-object v1, LuTools/uBlocker;->openVideoChannelToastInProgress:Landroid/widget/Toast;

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    .line 645
    invoke-static {}, LuTools/uUtils;->GetMainActivity()Landroid/app/Activity;

    move-result-object v1

    .line 647
    .local v1, "context":Landroid/content/Context;
    new-instance v2, LuTools/VideoDetails/uVideoDetailsRequest;

    const-string v3, "channelID"

    invoke-direct {v2, p0, v0, v3}, LuTools/VideoDetails/uVideoDetailsRequest;-><init>(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)V

    .line 649
    invoke-virtual {v2}, LuTools/VideoDetails/uVideoDetailsRequest;->GetRequestedInfo()Ljava/lang/Object;

    move-result-object v2

    .line 652
    .local v2, "channelIDRequest":Ljava/lang/Object;
    instance-of v3, v2, Ljava/lang/String;

    if-eqz v3, :cond_0

    .line 654
    move-object v3, v2

    check-cast v3, Ljava/lang/String;

    goto :goto_0

    .line 656
    :cond_0
    const-string v3, ""

    :goto_0
    nop

    .line 658
    .local v3, "channelID":Ljava/lang/String;
    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_1

    .line 659
    new-instance v4, Landroid/content/Intent;

    const-string v5, "android.intent.action.VIEW"

    const-string v6, "%s%s"

    const-string v7, "https://www.youtube.com/channel/"

    filled-new-array {v7, v3}, [Ljava/lang/Object;

    move-result-object v7

    .line 663
    invoke-static {v6, v7}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v6

    .line 662
    invoke-static {v6}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v6

    invoke-direct {v4, v5, v6}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 671
    .local v4, "openLiveChannelIntent":Landroid/content/Intent;
    const/high16 v5, 0x10000000

    invoke-virtual {v4, v5}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 672
    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 674
    invoke-virtual {v1, v4}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 676
    sget-object v5, LuTools/uBlocker;->openVideoChannelToastInProgress:Landroid/widget/Toast;

    invoke-virtual {v5}, Landroid/widget/Toast;->cancel()V

    .line 677
    sget-object v5, LuTools/uBlocker;->openVideoChannelToastDone:Landroid/widget/Toast;

    invoke-virtual {v5}, Landroid/widget/Toast;->show()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 681
    .end local v1    # "context":Landroid/content/Context;
    .end local v2    # "channelIDRequest":Ljava/lang/Object;
    .end local v3    # "channelID":Ljava/lang/String;
    .end local v4    # "openLiveChannelIntent":Landroid/content/Intent;
    :cond_1
    goto :goto_1

    .line 679
    :catch_0
    move-exception v1

    .line 680
    .local v1, "ignore":Ljava/lang/Exception;
    sget-object v2, LuTools/uBlocker;->openVideoChannelToastError:Landroid/widget/Toast;

    invoke-virtual {v2}, Landroid/widget/Toast;->show()V

    .line 683
    .end local v1    # "ignore":Ljava/lang/Exception;
    :goto_1
    sget-object v1, LuTools/uBlocker;->openVideoChannelThread:Ljava/lang/Thread;

    invoke-virtual {v1}, Ljava/lang/Thread;->interrupt()V

    .line 684
    sput-object v0, LuTools/uBlocker;->openVideoChannelThread:Ljava/lang/Thread;

    .line 685
    return-void
.end method

.method static synthetic lambda$OpenVideoResolutionsFlyout$3(Landroid/support/v7/widget/RecyclerView;)V
    .locals 3
    .param p0, "recyclerView"    # Landroid/support/v7/widget/RecyclerView;

    .line 699
    sget-boolean v0, LuTools/uBlocker;->quickQualityBottomSheet:Z

    if-eqz v0, :cond_0

    .line 700
    const/4 v0, 0x0

    sput-boolean v0, LuTools/uBlocker;->quickQualityBottomSheet:Z

    .line 702
    invoke-virtual {p0}, Landroid/support/v7/widget/RecyclerView;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    invoke-interface {v1}, Landroid/view/ViewParent;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    invoke-interface {v1}, Landroid/view/ViewParent;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    check-cast v1, Landroid/view/ViewGroup;

    const/16 v2, 0x8

    invoke-virtual {v1, v2}, Landroid/view/ViewGroup;->setVisibility(I)V

    .line 703
    invoke-virtual {p0, v0}, Landroid/support/v7/widget/RecyclerView;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/view/ViewGroup;

    const/4 v1, 0x3

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/View;->performClick()Z

    .line 705
    :cond_0
    return-void
.end method
