.class public LuTools/uBlocker;
.super Ljava/lang/Object;
.source "uBlocker.java"


# static fields
.field private static final DARK_COLORS:Ljava/util/AbstractMap$SimpleEntry;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/AbstractMap$SimpleEntry<",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static final LIGHT_COLORS:Ljava/util/AbstractMap$SimpleEntry;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/AbstractMap$SimpleEntry<",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static final WHITE_COLOR:I = 0xffffff

.field private static final checkMicroGPackageToastError:Landroid/widget/Toast;

.field private static final commentsComponentsFirst:Ljava/util/AbstractMap$SimpleEntry;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/AbstractMap$SimpleEntry<",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static final commentsComponentsSecond:Ljava/util/AbstractMap$SimpleEntry;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/AbstractMap$SimpleEntry<",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static final generalComponents:Ljava/util/AbstractMap$SimpleEntry;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/AbstractMap$SimpleEntry<",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static final hiddenVideoPreviewFlyoutButtons:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static final horizontalShelf:Ljava/util/AbstractMap$SimpleEntry;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/AbstractMap$SimpleEntry<",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static final libraryNavButtonIndex:I = 0x4

.field private static moreDrawerAppsAndInfo:Z

.field private static final openCommentsButtonComponents:Ljava/util/AbstractMap$SimpleEntry;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/AbstractMap$SimpleEntry<",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static openVideoChannelThread:Ljava/lang/Thread;

.field private static final openVideoChannelToastDone:Landroid/widget/Toast;

.field private static final openVideoChannelToastError:Landroid/widget/Toast;

.field private static final openVideoChannelToastInProgress:Landroid/widget/Toast;

.field private static final playerMaximized:Ljava/util/AbstractMap$SimpleEntry;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/AbstractMap$SimpleEntry<",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static quickQualityBottomSheet:Z

.field private static final sponsorShipPanelComponents:Ljava/util/AbstractMap$SimpleEntry;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/AbstractMap$SimpleEntry<",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static final topBarButtons:Ljava/util/AbstractMap$SimpleEntry;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/AbstractMap$SimpleEntry<",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static final videoInformationPanelComponents:Ljava/util/AbstractMap$SimpleEntry;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/AbstractMap$SimpleEntry<",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static final videoLookupComponents:Ljava/util/AbstractMap$SimpleEntry;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/AbstractMap$SimpleEntry<",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static final videoOtherSettingsPanelComponent:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static final visibleActionButtons:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static synthetic $r8$lambda$40yWSUzeLiR0N6W93Rr05xn1FW4(Ljava/lang/String;Ljava/lang/CharSequence;)Z
    .locals 0

    invoke-virtual {p0, p1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p0

    return p0
.end method

.method static constructor <clinit>()V
    .locals 7

    .line 46
    new-instance v0, Ljava/util/AbstractMap$SimpleEntry;

    .line 49
    const-string v1, "-1"

    const-string v2, "-394759"

    const-string v3, "-83886081"

    invoke-static {v1, v2, v3}, Ljava/util/Set;->of(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v1

    const-string v2, "LIGHT_COLORS"

    invoke-direct {v0, v1, v2}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 47
    invoke-static {v0}, LuTools/uUtils;->InitializeNewBlockList(Ljava/util/AbstractMap$SimpleEntry;)Ljava/util/AbstractMap$SimpleEntry;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->LIGHT_COLORS:Ljava/util/AbstractMap$SimpleEntry;

    .line 58
    new-instance v0, Ljava/util/AbstractMap$SimpleEntry;

    .line 61
    const-string v1, "-14145496"

    const-string v2, "-14606047"

    const-string v3, "-15198184"

    const-string v4, "-15790321"

    const-string v5, "-98492127"

    invoke-static {v1, v2, v3, v4, v5}, Ljava/util/Set;->of(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v1

    const-string v2, "DARK_COLORS"

    invoke-direct {v0, v1, v2}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 59
    invoke-static {v0}, LuTools/uUtils;->InitializeNewBlockList(Ljava/util/AbstractMap$SimpleEntry;)Ljava/util/AbstractMap$SimpleEntry;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->DARK_COLORS:Ljava/util/AbstractMap$SimpleEntry;

    .line 86
    nop

    .line 87
    const-string v0, "Error: No MicroG Installed"

    invoke-static {v0}, LuTools/uUtils;->GetNewToast(Ljava/lang/String;)Landroid/widget/Toast;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->checkMicroGPackageToastError:Landroid/widget/Toast;

    .line 108
    const-string v0, "yt_outline_share"

    const-string v1, "addToPlaylistButtonViewModel"

    const-string v2, "segmentedLikeDislikeButtonViewModel"

    invoke-static {v2, v0, v1}, Ljava/util/List;->of(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->visibleActionButtons:Ljava/util/List;

    .line 160
    const-string v0, "OUTLINE_YOUTUBE_MUSIC"

    const-string v1, "QUEUE_PLAY_NEXT"

    const-string v2, "EXTERNAL_LINK"

    const-string v3, "FLAG"

    const-string v4, "OFFLINE_DOWNLOAD"

    invoke-static {v2, v3, v4, v0, v1}, Ljava/util/Set;->of(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->hiddenVideoPreviewFlyoutButtons:Ljava/util/Set;

    .line 182
    new-instance v0, Ljava/util/AbstractMap$SimpleEntry;

    .line 185
    const-string v1, "WATCH_WHILE_FULLSCREEN"

    const-string v2, "WATCH_WHILE_MAXIMIZED"

    invoke-static {v1, v2}, Ljava/util/Set;->of(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v1

    const-string v2, "horizontalShelfSecond"

    invoke-direct {v0, v1, v2}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 183
    invoke-static {v0}, LuTools/uUtils;->InitializeNewBlockList(Ljava/util/AbstractMap$SimpleEntry;)Ljava/util/AbstractMap$SimpleEntry;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->playerMaximized:Ljava/util/AbstractMap$SimpleEntry;

    .line 193
    new-instance v0, Ljava/util/AbstractMap$SimpleEntry;

    .line 196
    const-string v1, "composer_short_creation_button"

    const-string v2, "composer_timestamp_button"

    const-string v3, "sponsorships_comments"

    const-string v4, "super_thanks_button"

    const-string v5, "|CellType|ContainerType|ContainerType|ContainerType|ContainerType|ContainerType|"

    invoke-static {v1, v2, v3, v4, v5}, Ljava/util/Set;->of(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v1

    const-string v2, "commentsComponentsFirst"

    invoke-direct {v0, v1, v2}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 194
    invoke-static {v0}, LuTools/uUtils;->InitializeNewBlockList(Ljava/util/AbstractMap$SimpleEntry;)Ljava/util/AbstractMap$SimpleEntry;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->commentsComponentsFirst:Ljava/util/AbstractMap$SimpleEntry;

    .line 207
    new-instance v0, Ljava/util/AbstractMap$SimpleEntry;

    .line 210
    const-string v1, "leaderboard_item_action_content"

    const-string v2, "button"

    invoke-static {v1, v2}, Ljava/util/Set;->of(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v1

    const-string v3, "commentsComponentsSecond"

    invoke-direct {v0, v1, v3}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 208
    invoke-static {v0}, LuTools/uUtils;->InitializeNewBlockList(Ljava/util/AbstractMap$SimpleEntry;)Ljava/util/AbstractMap$SimpleEntry;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->commentsComponentsSecond:Ljava/util/AbstractMap$SimpleEntry;

    .line 218
    new-instance v0, Ljava/util/AbstractMap$SimpleEntry;

    .line 221
    const-string v1, "cell_divider"

    const-string v3, "horizontal_video_shelf"

    const-string v4, "horizontal_shelf."

    invoke-static {v1, v3, v4}, Ljava/util/Set;->of(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v1

    const-string v3, "horizontalShelf"

    invoke-direct {v0, v1, v3}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 219
    invoke-static {v0}, LuTools/uUtils;->InitializeNewBlockList(Ljava/util/AbstractMap$SimpleEntry;)Ljava/util/AbstractMap$SimpleEntry;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->horizontalShelf:Ljava/util/AbstractMap$SimpleEntry;

    .line 230
    new-instance v0, Ljava/util/AbstractMap$SimpleEntry;

    .line 233
    const-string v1, "carousel_header"

    const-string v3, "|ContainerType|ContainerType|ContainerType|"

    invoke-static {v1, v3}, Ljava/util/Set;->of(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v1

    const-string v3, "openCommentsButtonComponents"

    invoke-direct {v0, v1, v3}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 231
    invoke-static {v0}, LuTools/uUtils;->InitializeNewBlockList(Ljava/util/AbstractMap$SimpleEntry;)Ljava/util/AbstractMap$SimpleEntry;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->openCommentsButtonComponents:Ljava/util/AbstractMap$SimpleEntry;

    .line 241
    new-instance v0, Ljava/util/AbstractMap$SimpleEntry;

    .line 244
    const-string v1, "sponsorships_section_list_root"

    invoke-static {v1, v2}, Ljava/util/Set;->of(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v1

    const-string v3, "sponsorShipPanelComponents"

    invoke-direct {v0, v1, v3}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 242
    invoke-static {v0}, LuTools/uUtils;->InitializeNewBlockList(Ljava/util/AbstractMap$SimpleEntry;)Ljava/util/AbstractMap$SimpleEntry;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->sponsorShipPanelComponents:Ljava/util/AbstractMap$SimpleEntry;

    .line 252
    new-instance v0, Ljava/util/AbstractMap$SimpleEntry;

    .line 255
    const-string v1, "video_description_header"

    invoke-static {v1, v2}, Ljava/util/Set;->of(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v1

    const-string v2, "videoInformationPanelComponents"

    invoke-direct {v0, v1, v2}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 253
    invoke-static {v0}, LuTools/uUtils;->InitializeNewBlockList(Ljava/util/AbstractMap$SimpleEntry;)Ljava/util/AbstractMap$SimpleEntry;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->videoInformationPanelComponents:Ljava/util/AbstractMap$SimpleEntry;

    .line 263
    new-instance v0, Ljava/util/AbstractMap$SimpleEntry;

    .line 266
    const-string v1, "endorsement_header_footer"

    const-string v2, "expandable_metadata"

    const-string v3, "set_reminder_button"

    const-string v4, "slimline_survey_video_with_context"

    const-string v5, "snappy_horizontal_shelf"

    const-string v6, "video_metadata_carousel"

    invoke-static/range {v1 .. v6}, Ljava/util/Set;->of(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v1

    const-string v2, "videoLookupComponents"

    invoke-direct {v0, v1, v2}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 264
    invoke-static {v0}, LuTools/uUtils;->InitializeNewBlockList(Ljava/util/AbstractMap$SimpleEntry;)Ljava/util/AbstractMap$SimpleEntry;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->videoLookupComponents:Ljava/util/AbstractMap$SimpleEntry;

    .line 278
    nop

    .line 279
    const-string v0, "yt_outline_question_circle"

    const-string v1, "yt_outline_volume_stable"

    const-string v2, "yt_outline_youtube_music"

    invoke-static {v0, v1, v2}, Ljava/util/Set;->of(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->videoOtherSettingsPanelComponent:Ljava/util/Set;

    .line 284
    new-instance v0, Ljava/util/AbstractMap$SimpleEntry;

    const/16 v1, 0x38

    new-array v1, v1, [Ljava/lang/String;

    const-string v2, "banner_text_icon_buttoned_layout"

    const/4 v3, 0x0

    aput-object v2, v1, v3

    const/4 v2, 0x1

    const-string v4, "brand_video_"

    aput-object v4, v1, v2

    const/4 v2, 0x2

    const-string v4, "carousel_footered_"

    aput-object v4, v1, v2

    const/4 v2, 0x3

    const-string v4, "compact_landscape_image_layout"

    aput-object v4, v1, v2

    const/4 v2, 0x4

    const-string v4, "composite_concurrent_carousel_layout"

    aput-object v4, v1, v2

    const/4 v2, 0x5

    const-string v4, "full_width_"

    aput-object v4, v1, v2

    const/4 v2, 0x6

    const-string v4, "inline_injection_entrypoint_layout"

    aput-object v4, v1, v2

    const/4 v2, 0x7

    const-string v4, "landscape_image_wide_button_layout"

    aput-object v4, v1, v2

    const/16 v2, 0x8

    const-string v4, "square_image_layout"

    aput-object v4, v1, v2

    const/16 v2, 0x9

    const-string v4, "statement_banner"

    aput-object v4, v1, v2

    const/16 v2, 0xa

    const-string v4, "text_image_"

    aput-object v4, v1, v2

    const/16 v2, 0xb

    const-string v4, "video_display_"

    aput-object v4, v1, v2

    const/16 v2, 0xc

    const-string v4, "browsy_bar"

    aput-object v4, v1, v2

    const/16 v2, 0xd

    const-string v4, "cell_expandable_metadata"

    aput-object v4, v1, v2

    const/16 v2, 0xe

    const-string v4, "channel_guidelines_entry_banner"

    aput-object v4, v1, v2

    const/16 v2, 0xf

    const-string v4, "chips_shelf"

    aput-object v4, v1, v2

    const/16 v2, 0x10

    const-string v4, "community_guidelines"

    aput-object v4, v1, v2

    const/16 v2, 0x11

    const-string v4, "compact_tvfilm_item"

    aput-object v4, v1, v2

    const/16 v2, 0x12

    const-string v4, "emergency_onebox"

    aput-object v4, v1, v2

    const/16 v2, 0x13

    const-string v4, "expandable_list"

    aput-object v4, v1, v2

    const/16 v2, 0x14

    const-string v4, "expandable_section"

    aput-object v4, v1, v2

    const/16 v2, 0x15

    const-string v4, "feed_nudge"

    aput-object v4, v1, v2

    const/16 v2, 0x16

    const-string v4, "fullscreen_related_videos_entry_point"

    aput-object v4, v1, v2

    const/16 v2, 0x17

    const-string v4, "grid_channel_shelf"

    aput-object v4, v1, v2

    const/16 v2, 0x18

    const-string v4, "hero_carousel"

    aput-object v4, v1, v2

    const/16 v2, 0x19

    const-string v4, "horizontal_gaming_shelf"

    aput-object v4, v1, v2

    const/16 v2, 0x1a

    const-string v4, "horizontal_tile_shelf"

    aput-object v4, v1, v2

    const/16 v2, 0x1b

    const-string v4, "how_this_was_made_section"

    aput-object v4, v1, v2

    const/16 v2, 0x1c

    const-string v4, "image_shelf"

    aput-object v4, v1, v2

    const/16 v2, 0x1d

    const-string v4, "info_card_teaser_overlay"

    aput-object v4, v1, v2

    const/16 v2, 0x1e

    const-string v4, "infocards_section"

    aput-object v4, v1, v2

    const/16 v2, 0x1f

    const-string v4, "live_viewer_leaderboard_chat_entry_point"

    aput-object v4, v1, v2

    const/16 v2, 0x20

    const-string v4, "live_chat_sponsorships_new_member_announcement"

    aput-object v4, v1, v2

    const/16 v2, 0x21

    const-string v4, "live_chat_text_message_banner"

    aput-object v4, v1, v2

    const/16 v2, 0x22

    const-string v4, "live_chat_ticker_creator_goal_view_model"

    aput-object v4, v1, v2

    const/16 v2, 0x23

    const-string v4, "macro_markers_carousel"

    aput-object v4, v1, v2

    const/16 v2, 0x24

    const-string v4, "medical_panel"

    aput-object v4, v1, v2

    const/16 v2, 0x25

    const-string v4, "member_recognition_shelf"

    aput-object v4, v1, v2

    const/16 v2, 0x26

    const-string v4, "music_recap_banner"

    aput-object v4, v1, v2

    const/16 v2, 0x27

    const-string v4, "offer_module_root"

    aput-object v4, v1, v2

    const/16 v2, 0x28

    const-string v4, "paid_content_overlay"

    aput-object v4, v1, v2

    const/16 v2, 0x29

    const-string v4, "playlist_section"

    aput-object v4, v1, v2

    const/16 v2, 0x2a

    const-string v4, "product_carousel"

    aput-object v4, v1, v2

    const/16 v2, 0x2b

    const-string v4, "products_in_video_with_preview"

    aput-object v4, v1, v2

    const/16 v2, 0x2c

    const-string v4, "publisher_transparency_panel"

    aput-object v4, v1, v2

    const/16 v2, 0x2d

    const-string v4, "search_friction"

    aput-object v4, v1, v2

    const/16 v2, 0x2e

    const-string v4, "shelf_header"

    aput-object v4, v1, v2

    const/16 v2, 0x2f

    const-string v4, "shopping_description_shelf"

    aput-object v4, v1, v2

    const/16 v2, 0x30

    const-string v4, "shorts_shelf"

    aput-object v4, v1, v2

    const/16 v2, 0x31

    const-string v4, "single_item_information_panel"

    aput-object v4, v1, v2

    const/16 v2, 0x32

    const-string v4, "super_chat_item"

    aput-object v4, v1, v2

    const/16 v2, 0x33

    const-string v4, "timed_reaction"

    aput-object v4, v1, v2

    const/16 v2, 0x34

    const-string v4, "topic_with_thumbnail_view_model"

    aput-object v4, v1, v2

    const/16 v2, 0x35

    const-string v4, "transcript_section"

    aput-object v4, v1, v2

    const/16 v2, 0x36

    const-string v4, "video_attributes_section"

    aput-object v4, v1, v2

    const/16 v2, 0x37

    const-string v4, "|suggested_action."

    aput-object v4, v1, v2

    .line 287
    invoke-static {v1}, Ljava/util/Set;->of([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v1

    const-string v2, "generalComponents"

    invoke-direct {v0, v1, v2}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 285
    invoke-static {v0}, LuTools/uUtils;->InitializeNewBlockList(Ljava/util/AbstractMap$SimpleEntry;)Ljava/util/AbstractMap$SimpleEntry;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->generalComponents:Ljava/util/AbstractMap$SimpleEntry;

    .line 352
    sput-boolean v3, LuTools/uBlocker;->moreDrawerAppsAndInfo:Z

    .line 353
    sput-boolean v3, LuTools/uBlocker;->quickQualityBottomSheet:Z

    .line 534
    new-instance v0, Ljava/util/AbstractMap$SimpleEntry;

    .line 537
    const-string v1, "CREATION_ENTRY"

    const-string v2, "FAB_CAMERA"

    const-string v3, "TAB_ACTIVITY_CAIRO"

    invoke-static {v1, v2, v3}, Ljava/util/Set;->of(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v1

    const-string v2, "topbarButtons"

    invoke-direct {v0, v1, v2}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 535
    invoke-static {v0}, LuTools/uUtils;->InitializeNewBlockList(Ljava/util/AbstractMap$SimpleEntry;)Ljava/util/AbstractMap$SimpleEntry;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->topBarButtons:Ljava/util/AbstractMap$SimpleEntry;

    .line 559
    nop

    .line 560
    const-string v0, "Opening video channel..."

    invoke-static {v0}, LuTools/uUtils;->GetNewToast(Ljava/lang/String;)Landroid/widget/Toast;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->openVideoChannelToastInProgress:Landroid/widget/Toast;

    .line 561
    nop

    .line 562
    const-string v0, "Channel opened"

    invoke-static {v0}, LuTools/uUtils;->GetNewToast(Ljava/lang/String;)Landroid/widget/Toast;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->openVideoChannelToastDone:Landroid/widget/Toast;

    .line 563
    nop

    .line 564
    const-string v0, "Error: Failed to open video channel"

    invoke-static {v0}, LuTools/uUtils;->GetNewToast(Ljava/lang/String;)Landroid/widget/Toast;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->openVideoChannelToastError:Landroid/widget/Toast;

    .line 565
    const/4 v0, 0x0

    sput-object v0, LuTools/uBlocker;->openVideoChannelThread:Ljava/lang/Thread;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 45
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static ChangeLithoUIColor(I)I
    .locals 3
    .param p0, "originalValue"    # I

    .line 74
    nop

    .line 75
    invoke-static {p0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    .line 76
    invoke-static {}, LuTools/uUtils;->GetDarkTheme()Z

    move-result v1

    if-eqz v1, :cond_0

    sget-object v1, LuTools/uBlocker;->DARK_COLORS:Ljava/util/AbstractMap$SimpleEntry;

    goto :goto_0

    :cond_0
    sget-object v1, LuTools/uBlocker;->LIGHT_COLORS:Ljava/util/AbstractMap$SimpleEntry;

    :goto_0
    sget-object v2, LuTools/uUtils$Entries;->ANY:LuTools/uUtils$Entries;

    .line 74
    invoke-static {v0, v1, v2}, LuTools/uUtils;->SearchInSetCorasick(Ljava/lang/String;Ljava/util/AbstractMap$SimpleEntry;LuTools/uUtils$Entries;)Z

    move-result v0

    if-eqz v0, :cond_2

    .line 80
    invoke-static {}, LuTools/uUtils;->GetDarkTheme()Z

    move-result v0

    if-eqz v0, :cond_1

    const v0, -0xffffff

    goto :goto_1

    :cond_1
    const v0, 0xffffff

    :goto_1
    return v0

    .line 82
    :cond_2
    return p0
.end method

.method public static CheckMicroGPackage(Landroid/app/Activity;)V
    .locals 3
    .param p0, "activity"    # Landroid/app/Activity;

    .line 90
    nop

    .line 91
    :try_start_0
    invoke-virtual {p0}, Landroid/app/Activity;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const-string v1, "app.revanced.android.gms"

    .line 92
    const/4 v2, 0x1

    invoke-virtual {v0, v1, v2}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    .line 99
    goto :goto_0

    .line 97
    :catch_0
    move-exception v0

    .line 98
    .local v0, "exception":Landroid/content/pm/PackageManager$NameNotFoundException;
    sget-object v1, LuTools/uBlocker;->checkMicroGPackageToastError:Landroid/widget/Toast;

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    .line 100
    .end local v0    # "exception":Landroid/content/pm/PackageManager$NameNotFoundException;
    :goto_0
    return-void
.end method

.method public static DisableAutoPlayCountdown(Landroid/view/View;)V
    .locals 1
    .param p0, "view"    # Landroid/view/View;

    .line 104
    :try_start_0
    invoke-virtual {p0}, Landroid/view/View;->callOnClick()Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 105
    :goto_0
    goto :goto_1

    :catch_0
    move-exception v0

    goto :goto_0

    .line 106
    :goto_1
    return-void
.end method

.method public static HideActionButtons(Ljava/util/List;Ljava/lang/String;)V
    .locals 9
    .param p1, "identifier"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/Object;",
            ">;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 114
    .local p0, "list":Ljava/util/List;, "Ljava/util/List<Ljava/lang/Object;>;"
    const/4 v0, 0x0

    invoke-interface {p0, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    .line 116
    .local v0, "firstListElem":Ljava/lang/Object;
    invoke-static {}, LuTools/uUtils;->GetCurrentActionButtonsList()Ljava/util/List;

    move-result-object v1

    .line 118
    .local v1, "currentActionButtonsList":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    if-eqz p1, :cond_5

    .line 119
    const-string v2, "video_action_bar"

    invoke-virtual {p1, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_5

    if-eqz p0, :cond_5

    .line 121
    invoke-interface {p0}, Ljava/util/List;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_5

    .line 122
    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_5

    if-eqz v0, :cond_5

    .line 124
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    const-string v3, "LazilyConvertedElement"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_5

    .line 126
    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v2

    .line 127
    .local v2, "listSize":I
    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v3

    .line 129
    .local v3, "currentActionButtonsListSize":I
    const/4 v4, 0x3

    if-le v2, v4, :cond_4

    .line 131
    invoke-interface {v1}, Ljava/util/List;->stream()Ljava/util/stream/Stream;

    move-result-object v5

    new-instance v6, LuTools/uBlocker$$ExternalSyntheticLambda3;

    invoke-direct {v6}, LuTools/uBlocker$$ExternalSyntheticLambda3;-><init>()V

    .line 132
    invoke-interface {v5, v6}, Ljava/util/stream/Stream;->noneMatch(Ljava/util/function/Predicate;)Z

    move-result v5

    if-eqz v5, :cond_0

    goto :goto_2

    .line 141
    :cond_0
    sub-int v5, v2, v3

    const/4 v6, 0x1

    if-ne v5, v6, :cond_1

    .line 142
    const-string v5, "yt_outline_youtube_shorts_plus"

    invoke-interface {v1, v4, v5}, Ljava/util/List;->add(ILjava/lang/Object;)V

    .line 145
    :cond_1
    add-int/lit8 v4, v3, -0x1

    .local v4, "i":I
    :goto_0
    if-ltz v4, :cond_5

    .line 146
    if-le v4, v6, :cond_3

    sget-object v5, LuTools/uBlocker;->visibleActionButtons:Ljava/util/List;

    .line 148
    invoke-interface {v5}, Ljava/util/List;->stream()Ljava/util/stream/Stream;

    move-result-object v5

    invoke-interface {v1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    invoke-static {v7}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v8, LuTools/uBlocker$$ExternalSyntheticLambda4;

    invoke-direct {v8, v7}, LuTools/uBlocker$$ExternalSyntheticLambda4;-><init>(Ljava/lang/String;)V

    invoke-interface {v5, v8}, Ljava/util/stream/Stream;->anyMatch(Ljava/util/function/Predicate;)Z

    move-result v5

    if-nez v5, :cond_3

    add-int/lit8 v5, v2, -0x1

    if-le v4, v5, :cond_2

    .line 152
    goto :goto_1

    .line 155
    :cond_2
    invoke-interface {p0, v4}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    .line 145
    :cond_3
    :goto_1
    add-int/lit8 v4, v4, -0x1

    goto :goto_0

    .line 138
    .end local v4    # "i":I
    :cond_4
    :goto_2
    return-void

    .line 158
    .end local v2    # "listSize":I
    .end local v3    # "currentActionButtonsListSize":I
    :cond_5
    return-void
.end method

.method public static HideHighBitrateResolution(Ljava/lang/String;)Z
    .locals 1
    .param p0, "originalValue"    # Ljava/lang/String;

    .line 178
    const-string v0, "Premium"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    return v0
.end method

.method public static HideLithoTemplate(Ljava/lang/String;)Z
    .locals 5
    .param p0, "templateTreeComponent"    # Ljava/lang/String;

    .line 356
    invoke-static {}, LuTools/uUtils;->GetCommunityPostsAccessible()Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    .line 358
    invoke-static {}, LuTools/uUtils;->GetCommunityPostsAccessible()Z

    move-result v0

    if-eqz v0, :cond_1

    .line 361
    invoke-static {}, LuTools/uUtils;->GetPlayerType()Ljava/lang/Enum;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object v0

    sget-object v2, LuTools/uBlocker;->playerMaximized:Ljava/util/AbstractMap$SimpleEntry;

    sget-object v3, LuTools/uUtils$Entries;->ANY:LuTools/uUtils$Entries;

    .line 360
    invoke-static {v0, v2, v3}, LuTools/uUtils;->SearchInSetCorasick(Ljava/lang/String;Ljava/util/AbstractMap$SimpleEntry;LuTools/uUtils$Entries;)Z

    move-result v0

    if-eqz v0, :cond_1

    :cond_0
    nop

    .line 366
    const-string v0, "post_"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 368
    return v1

    .line 371
    :cond_1
    const-string v0, "featured_channel_watermark_overlay"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_2

    .line 372
    return v1

    .line 376
    :cond_2
    sget-object v0, LuTools/uBlocker;->commentsComponentsFirst:Ljava/util/AbstractMap$SimpleEntry;

    sget-object v2, LuTools/uUtils$Entries;->ANY:LuTools/uUtils$Entries;

    invoke-static {p0, v0, v2}, LuTools/uUtils;->SearchInSetCorasick(Ljava/lang/String;Ljava/util/AbstractMap$SimpleEntry;LuTools/uUtils$Entries;)Z

    move-result v0

    if-nez v0, :cond_13

    sget-object v0, LuTools/uBlocker;->commentsComponentsSecond:Ljava/util/AbstractMap$SimpleEntry;

    sget-object v2, LuTools/uUtils$Entries;->ALL:LuTools/uUtils$Entries;

    .line 382
    invoke-static {p0, v0, v2}, LuTools/uUtils;->SearchInSetCorasick(Ljava/lang/String;Ljava/util/AbstractMap$SimpleEntry;LuTools/uUtils$Entries;)Z

    move-result v0

    if-eqz v0, :cond_3

    goto/16 :goto_4

    .line 392
    :cond_3
    invoke-static {}, LuTools/uUtils;->GetNavigationBarActionDown()Z

    move-result v0

    const/4 v2, 0x0

    if-eqz v0, :cond_4

    .line 394
    const-string v0, "account_header"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_4

    .line 395
    invoke-static {v1}, LuTools/uUtils;->SetAccountTabOpen(Z)V

    .line 397
    invoke-static {v2}, LuTools/uUtils;->SetNavigationBarActionDown(Z)V

    .line 400
    :cond_4
    sget-object v0, LuTools/uBlocker;->horizontalShelf:Ljava/util/AbstractMap$SimpleEntry;

    sget-object v3, LuTools/uUtils$Entries;->ANY:LuTools/uUtils$Entries;

    invoke-static {p0, v0, v3}, LuTools/uUtils;->SearchInSetCorasick(Ljava/lang/String;Ljava/util/AbstractMap$SimpleEntry;LuTools/uUtils$Entries;)Z

    move-result v0

    if-eqz v0, :cond_7

    .line 406
    invoke-static {}, LuTools/uUtils;->GetAccountTabOpen()Z

    move-result v0

    if-eqz v0, :cond_6

    .line 409
    invoke-static {}, LuTools/uUtils;->GetPlayerType()Ljava/lang/Enum;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object v0

    sget-object v3, LuTools/uBlocker;->playerMaximized:Ljava/util/AbstractMap$SimpleEntry;

    sget-object v4, LuTools/uUtils$Entries;->ANY:LuTools/uUtils$Entries;

    .line 408
    invoke-static {v0, v3, v4}, LuTools/uUtils;->SearchInSetCorasick(Ljava/lang/String;Ljava/util/AbstractMap$SimpleEntry;LuTools/uUtils$Entries;)Z

    move-result v0

    if-eqz v0, :cond_5

    goto :goto_0

    :cond_5
    move v1, v2

    goto :goto_1

    :cond_6
    :goto_0
    nop

    .line 406
    :goto_1
    return v1

    .line 416
    :cond_7
    invoke-static {}, LuTools/uUtils;->GetCommentsPanelOpen()Z

    move-result v0

    if-eqz v0, :cond_8

    .line 418
    const-string v0, "progress_bar"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_8

    .line 420
    return v1

    .line 424
    :cond_8
    const-string v0, "more_drawer."

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_a

    .line 425
    const-string v0, "divider"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_9

    .line 426
    sput-boolean v1, LuTools/uBlocker;->moreDrawerAppsAndInfo:Z

    .line 429
    :cond_9
    sget-boolean v0, LuTools/uBlocker;->moreDrawerAppsAndInfo:Z

    return v0

    .line 431
    :cond_a
    sput-boolean v2, LuTools/uBlocker;->moreDrawerAppsAndInfo:Z

    .line 435
    const-string v0, "video_metadata_carousel"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_d

    .line 436
    const-string v0, "|carousel_item."

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_c

    sget-object v0, LuTools/uBlocker;->openCommentsButtonComponents:Ljava/util/AbstractMap$SimpleEntry;

    sget-object v3, LuTools/uUtils$Entries;->ALL:LuTools/uUtils$Entries;

    .line 438
    invoke-static {p0, v0, v3}, LuTools/uUtils;->SearchInSetCorasick(Ljava/lang/String;Ljava/util/AbstractMap$SimpleEntry;LuTools/uUtils$Entries;)Z

    move-result v0

    if-eqz v0, :cond_b

    goto :goto_2

    :cond_b
    move v1, v2

    goto :goto_3

    :cond_c
    :goto_2
    nop

    .line 436
    :goto_3
    return v1

    .line 446
    :cond_d
    const-string v0, "quick_quality_sheet_content"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_e

    .line 447
    sput-boolean v1, LuTools/uBlocker;->quickQualityBottomSheet:Z

    .line 449
    return v2

    .line 453
    :cond_e
    sget-object v0, LuTools/uBlocker;->sponsorShipPanelComponents:Ljava/util/AbstractMap$SimpleEntry;

    sget-object v2, LuTools/uUtils$Entries;->ALL:LuTools/uUtils$Entries;

    invoke-static {p0, v0, v2}, LuTools/uUtils;->SearchInSetCorasick(Ljava/lang/String;Ljava/util/AbstractMap$SimpleEntry;LuTools/uUtils$Entries;)Z

    move-result v0

    if-eqz v0, :cond_f

    .line 459
    return v1

    .line 463
    :cond_f
    sget-object v0, LuTools/uBlocker;->videoInformationPanelComponents:Ljava/util/AbstractMap$SimpleEntry;

    sget-object v2, LuTools/uUtils$Entries;->ALL:LuTools/uUtils$Entries;

    invoke-static {p0, v0, v2}, LuTools/uUtils;->SearchInSetCorasick(Ljava/lang/String;Ljava/util/AbstractMap$SimpleEntry;LuTools/uUtils$Entries;)Z

    move-result v0

    if-eqz v0, :cond_10

    .line 469
    return v1

    .line 473
    :cond_10
    const-string v0, "overflow_menu_item"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_11

    .line 476
    invoke-static {}, LuTools/uUtils;->GetProtoBufferComponents()Ljava/nio/ByteBuffer;

    move-result-object v0

    sget-object v2, LuTools/uBlocker;->videoOtherSettingsPanelComponent:Ljava/util/Set;

    sget-object v3, LuTools/uUtils$Entries;->ANY:LuTools/uUtils$Entries;

    .line 475
    invoke-static {v0, v2, v3}, LuTools/uUtils;->ByteBufferContainsString(Ljava/nio/ByteBuffer;Ljava/util/Set;LuTools/uUtils$Entries;)Z

    move-result v0

    if-eqz v0, :cond_11

    .line 481
    return v1

    .line 485
    :cond_11
    const-string v0, "video_lockup_with_attachment"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_12

    .line 486
    sget-object v0, LuTools/uBlocker;->videoLookupComponents:Ljava/util/AbstractMap$SimpleEntry;

    sget-object v1, LuTools/uUtils$Entries;->ANY:LuTools/uUtils$Entries;

    invoke-static {p0, v0, v1}, LuTools/uUtils;->SearchInSetCorasick(Ljava/lang/String;Ljava/util/AbstractMap$SimpleEntry;LuTools/uUtils$Entries;)Z

    move-result v0

    return v0

    .line 494
    :cond_12
    sget-object v0, LuTools/uBlocker;->generalComponents:Ljava/util/AbstractMap$SimpleEntry;

    sget-object v1, LuTools/uUtils$Entries;->ANY:LuTools/uUtils$Entries;

    invoke-static {p0, v0, v1}, LuTools/uUtils;->SearchInSetCorasick(Ljava/lang/String;Ljava/util/AbstractMap$SimpleEntry;LuTools/uUtils$Entries;)Z

    move-result v0

    return v0

    .line 388
    :cond_13
    :goto_4
    return v1
.end method

.method public static HideLiveChatSubscribersShelf(Landroid/view/View;)V
    .locals 2
    .param p0, "view"    # Landroid/view/View;

    .line 503
    :try_start_0
    invoke-virtual {p0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v0

    new-instance v1, LuTools/uBlocker$$ExternalSyntheticLambda2;

    invoke-direct {v1, p0}, LuTools/uBlocker$$ExternalSyntheticLambda2;-><init>(Landroid/view/View;)V

    invoke-virtual {v0, v1}, Landroid/view/ViewTreeObserver;->addOnGlobalLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 509
    :catch_0
    move-exception v0

    :goto_0
    nop

    .line 510
    return-void
.end method

.method public static HideNavigationBarButtons(Landroid/view/View;)V
    .locals 2
    .param p0, "view"    # Landroid/view/View;

    .line 528
    :try_start_0
    invoke-static {}, LuTools/uUtils;->GetNavigationBarPivot()Ljava/lang/Enum;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object v0

    const-string v1, "TAB_SHORTS"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 529
    invoke-static {p0}, LuTools/uUtils;->HideView(Landroid/view/View;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 531
    :catch_0
    move-exception v0

    :cond_0
    :goto_0
    nop

    .line 532
    return-void
.end method

.method public static HideTabMyAccountGetPremium(Landroid/view/View;Ljava/lang/CharSequence;)V
    .locals 3
    .param p0, "view"    # Landroid/view/View;
    .param p1, "charSequence"    # Ljava/lang/CharSequence;

    .line 514
    :try_start_0
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    invoke-interface {v0}, Landroid/view/ViewParent;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    instance-of v1, v0, Landroid/view/ViewGroup;

    if-eqz v1, :cond_1

    check-cast v0, Landroid/view/ViewGroup;

    .line 515
    .local v0, "viewGroup":Landroid/view/ViewGroup;
    invoke-interface {p1}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "Premium"

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_1

    .line 516
    invoke-virtual {v0}, Landroid/view/ViewGroup;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    instance-of v1, v1, Landroid/view/ViewGroup$MarginLayoutParams;

    if-eqz v1, :cond_0

    .line 517
    invoke-static {v0}, LuTools/uUtils;->HideViewGroupByMarginLayout(Landroid/view/ViewGroup;)V

    goto :goto_0

    .line 519
    :cond_0
    invoke-static {v0}, LuTools/uUtils;->HideViewGroupByLayoutParams(Landroid/view/ViewGroup;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 523
    .end local v0    # "viewGroup":Landroid/view/ViewGroup;
    :catch_0
    move-exception v0

    :cond_1
    :goto_0
    nop

    .line 524
    return-void
.end method

.method public static HideTopBarButtons(Landroid/view/View;)V
    .locals 3
    .param p0, "view"    # Landroid/view/View;

    .line 549
    :try_start_0
    invoke-static {}, LuTools/uUtils;->GetTopBarPivot()Ljava/lang/Enum;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object v0

    sget-object v1, LuTools/uBlocker;->topBarButtons:Ljava/util/AbstractMap$SimpleEntry;

    sget-object v2, LuTools/uUtils$Entries;->ANY:LuTools/uUtils$Entries;

    .line 548
    invoke-static {v0, v1, v2}, LuTools/uUtils;->SearchInSetCorasick(Ljava/lang/String;Ljava/util/AbstractMap$SimpleEntry;LuTools/uUtils$Entries;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 554
    invoke-static {p0}, LuTools/uUtils;->HideView(Landroid/view/View;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 556
    :catch_0
    move-exception v0

    :cond_0
    :goto_0
    nop

    .line 557
    return-void
.end method

.method public static HideVideoPreviewFlyoutButton(Ljava/lang/Enum;)Z
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Enum<",
            "*>;)Z"
        }
    .end annotation

    .line 168
    .local p0, "button":Ljava/lang/Enum;, "Ljava/lang/Enum<*>;"
    sget-object v0, LuTools/uBlocker;->hiddenVideoPreviewFlyoutButtons:Ljava/util/Set;

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    .line 169
    .local v1, "hiddenVideoPreviewFlyoutButton":Ljava/lang/String;
    invoke-virtual {p0}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    .line 170
    const/4 v0, 0x1

    return v0

    .line 172
    .end local v1    # "hiddenVideoPreviewFlyoutButton":Ljava/lang/String;
    :cond_0
    goto :goto_0

    .line 174
    :cond_1
    const/4 v0, 0x0

    return v0
.end method

.method public static OpenVideoChannel(Ljava/lang/String;)Z
    .locals 4
    .param p0, "videoID"    # Ljava/lang/String;

    .line 567
    sget-object v0, LuTools/uBlocker;->openVideoChannelThread:Ljava/lang/Thread;

    if-nez v0, :cond_0

    .line 568
    invoke-static {}, LuTools/uUtils;->GetCommentsPanelOpen()Z

    move-result v0

    if-nez v0, :cond_0

    invoke-static {}, LuTools/uUtils;->GetLithoActionDownDuration()J

    move-result-wide v0

    const-wide/16 v2, 0x3e8

    cmp-long v0, v0, v2

    if-ltz v0, :cond_0

    .line 569
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, LuTools/uBlocker$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0}, LuTools/uBlocker$$ExternalSyntheticLambda0;-><init>(Ljava/lang/String;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    sput-object v0, LuTools/uBlocker;->openVideoChannelThread:Ljava/lang/Thread;

    .line 615
    sget-object v0, LuTools/uBlocker;->openVideoChannelThread:Ljava/lang/Thread;

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 617
    const/4 v0, 0x1

    return v0

    .line 621
    :cond_0
    const/4 v0, 0x0

    return v0
.end method

.method public static OpenVideoResolutionsFlyout(Landroid/support/v7/widget/RecyclerView;)V
    .locals 2
    .param p0, "recyclerView"    # Landroid/support/v7/widget/RecyclerView;

    .line 626
    :try_start_0
    invoke-virtual {p0}, Landroid/support/v7/widget/RecyclerView;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v0

    new-instance v1, LuTools/uBlocker$$ExternalSyntheticLambda1;

    invoke-direct {v1, p0}, LuTools/uBlocker$$ExternalSyntheticLambda1;-><init>(Landroid/support/v7/widget/RecyclerView;)V

    invoke-virtual {v0, v1}, Landroid/view/ViewTreeObserver;->addOnDrawListener(Landroid/view/ViewTreeObserver$OnDrawListener;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 634
    :catch_0
    move-exception v0

    :goto_0
    nop

    .line 635
    return-void
.end method

.method public static OverrideTrackingUrl(Landroid/net/Uri;)Landroid/net/Uri;
    .locals 2
    .param p0, "trackingUrl"    # Landroid/net/Uri;

    .line 638
    invoke-virtual {p0}, Landroid/net/Uri;->buildUpon()Landroid/net/Uri$Builder;

    move-result-object v0

    const-string v1, "www.youtube.com"

    invoke-virtual {v0, v1}, Landroid/net/Uri$Builder;->authority(Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object v0

    invoke-virtual {v0}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    move-result-object v0

    return-object v0
.end method

.method public static ShortsPlayerBypassing(Ljava/lang/String;)Z
    .locals 5
    .param p0, "shortsVideoID"    # Ljava/lang/String;

    .line 643
    :try_start_0
    invoke-static {}, LuTools/uUtils;->GetMainActivity()Landroid/app/Activity;

    move-result-object v0

    .line 645
    .local v0, "context":Landroid/content/Context;
    new-instance v1, Landroid/content/Intent;

    const-string v2, "android.intent.action.VIEW"

    const-string v3, "https://www.youtube.com/watch?v=%s"

    filled-new-array {p0}, [Ljava/lang/Object;

    move-result-object v4

    .line 649
    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    .line 648
    invoke-static {v3}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v3

    invoke-direct {v1, v2, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 656
    .local v1, "videoPlayerIntent":Landroid/content/Intent;
    const/high16 v2, 0x10000000

    invoke-virtual {v1, v2}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    .line 657
    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 659
    invoke-virtual {v0, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 661
    const/4 v2, 0x1

    return v2

    .line 662
    .end local v0    # "context":Landroid/content/Context;
    .end local v1    # "videoPlayerIntent":Landroid/content/Intent;
    :catch_0
    move-exception v0

    .line 664
    const/4 v0, 0x0

    return v0
.end method

.method static synthetic lambda$HideActionButtons$0(Ljava/lang/String;)Z
    .locals 2
    .param p0, "s"    # Ljava/lang/String;

    .line 135
    sget-object v0, LuTools/uBlocker;->visibleActionButtons:Ljava/util/List;

    sget-object v1, LuTools/uBlocker;->visibleActionButtons:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/CharSequence;

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    return v0
.end method

.method static synthetic lambda$HideLiveChatSubscribersShelf$1(Landroid/view/View;)V
    .locals 3
    .param p0, "view"    # Landroid/view/View;

    .line 504
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    .line 505
    .local v0, "parent":Landroid/view/ViewParent;
    instance-of v1, v0, Landroid/support/v7/widget/RecyclerView;

    if-eqz v1, :cond_0

    .line 506
    move-object v1, v0

    check-cast v1, Landroid/support/v7/widget/RecyclerView;

    const/16 v2, 0x8

    invoke-virtual {v1, v2}, Landroid/support/v7/widget/RecyclerView;->setVisibility(I)V

    .line 508
    :cond_0
    return-void
.end method

.method static synthetic lambda$OpenVideoChannel$2(Ljava/lang/String;)V
    .locals 8
    .param p0, "videoID"    # Ljava/lang/String;

    .line 571
    const/4 v0, 0x0

    :try_start_0
    sget-object v1, LuTools/uBlocker;->openVideoChannelToastInProgress:Landroid/widget/Toast;

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    .line 573
    invoke-static {}, LuTools/uUtils;->GetMainActivity()Landroid/app/Activity;

    move-result-object v1

    .line 575
    .local v1, "context":Landroid/content/Context;
    new-instance v2, LuTools/VideoDetails/uVideoDetailsRequest;

    const-string v3, "channelID"

    invoke-direct {v2, p0, v0, v3}, LuTools/VideoDetails/uVideoDetailsRequest;-><init>(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)V

    .line 577
    invoke-virtual {v2}, LuTools/VideoDetails/uVideoDetailsRequest;->GetRequestedInfo()Ljava/lang/Object;

    move-result-object v2

    .line 580
    .local v2, "channelIDRequest":Ljava/lang/Object;
    instance-of v3, v2, Ljava/lang/String;

    if-eqz v3, :cond_0

    .line 582
    move-object v3, v2

    check-cast v3, Ljava/lang/String;

    goto :goto_0

    .line 584
    :cond_0
    const-string v3, ""

    :goto_0
    nop

    .line 586
    .local v3, "channelID":Ljava/lang/String;
    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_1

    .line 587
    new-instance v4, Landroid/content/Intent;

    const-string v5, "android.intent.action.VIEW"

    const-string v6, "%s%s"

    const-string v7, "https://www.youtube.com/channel/"

    filled-new-array {v7, v3}, [Ljava/lang/Object;

    move-result-object v7

    .line 591
    invoke-static {v6, v7}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v6

    .line 590
    invoke-static {v6}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v6

    invoke-direct {v4, v5, v6}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 599
    .local v4, "openLiveChannelIntent":Landroid/content/Intent;
    const/high16 v5, 0x10000000

    invoke-virtual {v4, v5}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 600
    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 602
    invoke-virtual {v1, v4}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 604
    sget-object v5, LuTools/uBlocker;->openVideoChannelToastInProgress:Landroid/widget/Toast;

    invoke-virtual {v5}, Landroid/widget/Toast;->cancel()V

    .line 605
    sget-object v5, LuTools/uBlocker;->openVideoChannelToastDone:Landroid/widget/Toast;

    invoke-virtual {v5}, Landroid/widget/Toast;->show()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 609
    .end local v1    # "context":Landroid/content/Context;
    .end local v2    # "channelIDRequest":Ljava/lang/Object;
    .end local v3    # "channelID":Ljava/lang/String;
    .end local v4    # "openLiveChannelIntent":Landroid/content/Intent;
    :cond_1
    goto :goto_1

    .line 607
    :catch_0
    move-exception v1

    .line 608
    .local v1, "ignore":Ljava/lang/Exception;
    sget-object v2, LuTools/uBlocker;->openVideoChannelToastError:Landroid/widget/Toast;

    invoke-virtual {v2}, Landroid/widget/Toast;->show()V

    .line 611
    .end local v1    # "ignore":Ljava/lang/Exception;
    :goto_1
    sget-object v1, LuTools/uBlocker;->openVideoChannelThread:Ljava/lang/Thread;

    invoke-virtual {v1}, Ljava/lang/Thread;->interrupt()V

    .line 612
    sput-object v0, LuTools/uBlocker;->openVideoChannelThread:Ljava/lang/Thread;

    .line 613
    return-void
.end method

.method static synthetic lambda$OpenVideoResolutionsFlyout$3(Landroid/support/v7/widget/RecyclerView;)V
    .locals 3
    .param p0, "recyclerView"    # Landroid/support/v7/widget/RecyclerView;

    .line 627
    sget-boolean v0, LuTools/uBlocker;->quickQualityBottomSheet:Z

    if-eqz v0, :cond_0

    .line 628
    const/4 v0, 0x0

    sput-boolean v0, LuTools/uBlocker;->quickQualityBottomSheet:Z

    .line 630
    invoke-virtual {p0}, Landroid/support/v7/widget/RecyclerView;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    invoke-interface {v1}, Landroid/view/ViewParent;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    invoke-interface {v1}, Landroid/view/ViewParent;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    check-cast v1, Landroid/view/ViewGroup;

    const/16 v2, 0x8

    invoke-virtual {v1, v2}, Landroid/view/ViewGroup;->setVisibility(I)V

    .line 631
    invoke-virtual {p0, v0}, Landroid/support/v7/widget/RecyclerView;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/view/ViewGroup;

    const/4 v1, 0x3

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/View;->performClick()Z

    .line 633
    :cond_0
    return-void
.end method
