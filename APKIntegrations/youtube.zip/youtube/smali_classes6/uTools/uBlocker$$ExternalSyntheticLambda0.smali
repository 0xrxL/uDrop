.class public final synthetic LuTools/uBlocker$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/ViewTreeObserver$OnDrawListener;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "LuTools/uBlocker;"
    method = "lambda$OpenVideoResolutionsFlyout$1"
    proto = "(Landroid/support/v7/widget/RecyclerView;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x13
    versionHash = "9aaf5f34c4c84da429ef7f8f6217a1817876f2618cfcf539aba3d7d5a0c703e0"
.end annotation


# instance fields
.field public final synthetic f$0:Landroid/support/v7/widget/RecyclerView;


# direct methods
.method public synthetic constructor <init>(Landroid/support/v7/widget/RecyclerView;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LuTools/uBlocker$$ExternalSyntheticLambda0;->f$0:Landroid/support/v7/widget/RecyclerView;

    return-void
.end method


# virtual methods
.method public final onDraw()V
    .locals 1

    .line 0
    iget-object v0, p0, LuTools/uBlocker$$ExternalSyntheticLambda0;->f$0:Landroid/support/v7/widget/RecyclerView;

    invoke-static {v0}, LuTools/uBlocker;->lambda$OpenVideoResolutionsFlyout$1(Landroid/support/v7/widget/RecyclerView;)V

    return-void
.end method
