.class public LuTools/uUtils$MakeToast;
.super Ljava/lang/Object;
.source "uUtils.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LuTools/uUtils;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "MakeToast"
.end annotation


# instance fields
.field private final handlerObj:Landroid/os/Handler;

.field private final message:Ljava/lang/String;

.field private toastObj:Landroid/widget/Toast;


# direct methods
.method public static synthetic $r8$lambda$KNeUye0CnX09J6_8zz9vnb3n8cw(LuTools/uUtils$MakeToast;)V
    .locals 0

    invoke-direct {p0}, LuTools/uUtils$MakeToast;->lambda$HideToast$1()V

    return-void
.end method

.method public static synthetic $r8$lambda$Mfum8d9uhrs8T9cD9pRbD_Xf7PY(LuTools/uUtils$MakeToast;)V
    .locals 0

    invoke-direct {p0}, LuTools/uUtils$MakeToast;->lambda$ShowToast$0()V

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .locals 2
    .param p1, "message"    # Ljava/lang/String;

    .line 57
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 55
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, LuTools/uUtils$MakeToast;->handlerObj:Landroid/os/Handler;

    .line 58
    iput-object p1, p0, LuTools/uUtils$MakeToast;->message:Ljava/lang/String;

    .line 59
    return-void
.end method

.method private synthetic lambda$HideToast$1()V
    .locals 1

    .line 73
    iget-object v0, p0, LuTools/uUtils$MakeToast;->toastObj:Landroid/widget/Toast;

    if-eqz v0, :cond_0

    .line 74
    iget-object v0, p0, LuTools/uUtils$MakeToast;->toastObj:Landroid/widget/Toast;

    invoke-virtual {v0}, Landroid/widget/Toast;->cancel()V

    .line 76
    :cond_0
    return-void
.end method

.method private synthetic lambda$ShowToast$0()V
    .locals 3

    .line 63
    iget-object v0, p0, LuTools/uUtils$MakeToast;->toastObj:Landroid/widget/Toast;

    if-nez v0, :cond_0

    .line 64
    invoke-static {}, LuTools/uUtils;->GetAppContext()Landroid/content/Context;

    move-result-object v0

    iget-object v1, p0, LuTools/uUtils$MakeToast;->message:Ljava/lang/String;

    const/4 v2, 0x1

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    iput-object v0, p0, LuTools/uUtils$MakeToast;->toastObj:Landroid/widget/Toast;

    .line 67
    :cond_0
    iget-object v0, p0, LuTools/uUtils$MakeToast;->toastObj:Landroid/widget/Toast;

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 68
    return-void
.end method


# virtual methods
.method public HideToast()V
    .locals 2

    .line 72
    iget-object v0, p0, LuTools/uUtils$MakeToast;->handlerObj:Landroid/os/Handler;

    new-instance v1, LuTools/uUtils$MakeToast$$ExternalSyntheticLambda1;

    invoke-direct {v1, p0}, LuTools/uUtils$MakeToast$$ExternalSyntheticLambda1;-><init>(LuTools/uUtils$MakeToast;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 77
    return-void
.end method

.method public ShowToast()V
    .locals 2

    .line 62
    iget-object v0, p0, LuTools/uUtils$MakeToast;->handlerObj:Landroid/os/Handler;

    new-instance v1, LuTools/uUtils$MakeToast$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0}, LuTools/uUtils$MakeToast$$ExternalSyntheticLambda0;-><init>(LuTools/uUtils$MakeToast;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 69
    return-void
.end method
