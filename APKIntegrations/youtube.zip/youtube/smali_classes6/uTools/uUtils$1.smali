.class LuTools/uUtils$1;
.super Ljava/util/Stack;
.source "uUtils.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LuTools/uUtils;->ClearAppCache()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/util/Stack<",
        "Ljava/io/File;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .locals 1

    .line 165
    invoke-direct {p0}, Ljava/util/Stack;-><init>()V

    .line 166
    invoke-static {}, LuTools/uUtils;->GetAppContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getCacheDir()Ljava/io/File;

    move-result-object v0

    invoke-virtual {p0, v0}, LuTools/uUtils$1;->push(Ljava/lang/Object;)Ljava/lang/Object;

    .line 167
    return-void
.end method
