.class LuTools/uUtils$1;
.super Ljava/util/Stack;
.source "uUtils.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LuTools/uUtils;->ClearAppCache()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/util/Stack<",
        "Ljava/io/File;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic val$cacheDir:Ljava/io/File;


# direct methods
.method constructor <init>(Ljava/io/File;)V
    .locals 0

    .line 140
    iput-object p1, p0, LuTools/uUtils$1;->val$cacheDir:Ljava/io/File;

    invoke-direct {p0}, Ljava/util/Stack;-><init>()V

    .line 141
    iget-object p1, p0, LuTools/uUtils$1;->val$cacheDir:Ljava/io/File;

    invoke-virtual {p0, p1}, LuTools/uUtils$1;->push(Ljava/lang/Object;)Ljava/lang/Object;

    .line 142
    return-void
.end method
