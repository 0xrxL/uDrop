.class public final Lcom/pkware/ahocorasick/StringAhoCorasick;
.super Lcom/pkware/ahocorasick/AhoCorasickBase;
.source "StringAhoCorasick.kt"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/pkware/ahocorasick/AhoCorasickBase<",
        "Ljava/lang/String;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nStringAhoCorasick.kt\nKotlin\n*S Kotlin\n*F\n+ 1 StringAhoCorasick.kt\ncom/pkware/ahocorasick/StringAhoCorasick\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,37:1\n1855#2,2:38\n*S KotlinDebug\n*F\n+ 1 StringAhoCorasick.kt\ncom/pkware/ahocorasick/StringAhoCorasick\n*L\n29#1:38,2\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u00006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\"\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u0002\n\u0002\u0008\u0003\n\u0002\u0010\u001c\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0008\n\u0002\u0008\u0003\u0018\u00002\u0008\u0012\u0004\u0012\u00020\u00020\u0001B\u0017\u0008\u0007\u0012\u000e\u0008\u0002\u0010\u0003\u001a\u0008\u0012\u0004\u0012\u00020\u00050\u0004\u00a2\u0006\u0002\u0010\u0006J\u000e\u0010\u0007\u001a\u00020\u00082\u0006\u0010\t\u001a\u00020\u0002J\u0014\u0010\n\u001a\u00020\u00082\u000c\u0010\u000b\u001a\u0008\u0012\u0004\u0012\u00020\u00020\u000cJ&\u0010\r\u001a\u0008\u0012\u0004\u0012\u00020\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u00102\u0006\u0010\u0012\u001a\u00020\u0002H\u0014\u00a8\u0006\u0013"
    }
    d2 = {
        "Lcom/pkware/ahocorasick/StringAhoCorasick;",
        "Lcom/pkware/ahocorasick/AhoCorasickBase;",
        "",
        "options",
        "",
        "Lcom/pkware/ahocorasick/AhoCorasickOption;",
        "(Ljava/util/Set;)V",
        "add",
        "",
        "string",
        "addAll",
        "strings",
        "",
        "generateResult",
        "Lcom/pkware/ahocorasick/AhoCorasickResult;",
        "index",
        "",
        "value",
        "input",
        "LowMemoryAhoCorasick"
    }
    k = 0x1
    mv = {
        0x1,
        0x9,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-direct {p0, v0, v1, v0}, Lcom/pkware/ahocorasick/StringAhoCorasick;-><init>(Ljava/util/Set;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    return-void
.end method

.method public constructor <init>(Ljava/util/Set;)V
    .locals 1
    .param p1, "options"    # Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Set<",
            "+",
            "Lcom/pkware/ahocorasick/AhoCorasickOption;",
            ">;)V"
        }
    .end annotation

    const-string v0, "options"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 19
    invoke-direct {p0, p1}, Lcom/pkware/ahocorasick/AhoCorasickBase;-><init>(Ljava/util/Set;)V

    .line 18
    return-void
.end method

.method public synthetic constructor <init>(Ljava/util/Set;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    .line 18
    and-int/lit8 p2, p2, 0x1

    if-eqz p2, :cond_0

    invoke-static {}, Lkotlin/collections/SetsKt;->emptySet()Ljava/util/Set;

    move-result-object p1

    :cond_0
    invoke-direct {p0, p1}, Lcom/pkware/ahocorasick/StringAhoCorasick;-><init>(Ljava/util/Set;)V

    .line 36
    return-void
.end method


# virtual methods
.method public final add(Ljava/lang/String;)V
    .locals 1
    .param p1, "string"    # Ljava/lang/String;

    const-string v0, "string"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 24
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    invoke-virtual {p0, p1, v0}, Lcom/pkware/ahocorasick/StringAhoCorasick;->addEntry(Ljava/lang/String;I)V

    return-void
.end method

.method public final addAll(Ljava/lang/Iterable;)V
    .locals 6
    .param p1, "strings"    # Ljava/lang/Iterable;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const-string v0, "strings"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 29
    move-object v0, p1

    .local v0, "$this$forEach$iv":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 38
    .local v1, "$i$f$forEach":I
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_0

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    .local v3, "element$iv":Ljava/lang/Object;
    move-object v4, v3

    check-cast v4, Ljava/lang/String;

    .local v4, "p0":Ljava/lang/String;
    const/4 v5, 0x0

    .line 29
    .local v5, "$i$a$-forEach-StringAhoCorasick$addAll$1":I
    invoke-virtual {p0, v4}, Lcom/pkware/ahocorasick/StringAhoCorasick;->add(Ljava/lang/String;)V

    .line 38
    .end local v4    # "p0":Ljava/lang/String;
    .end local v5    # "$i$a$-forEach-StringAhoCorasick$addAll$1":I
    nop

    .end local v3    # "element$iv":Ljava/lang/Object;
    goto :goto_0

    .line 39
    :cond_0
    nop

    .line 29
    .end local v0    # "$this$forEach$iv":Ljava/lang/Iterable;
    .end local v1    # "$i$f$forEach":I
    return-void
.end method

.method protected generateResult(IILjava/lang/String;)Lcom/pkware/ahocorasick/AhoCorasickResult;
    .locals 4
    .param p1, "index"    # I
    .param p2, "value"    # I
    .param p3, "input"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(II",
            "Ljava/lang/String;",
            ")",
            "Lcom/pkware/ahocorasick/AhoCorasickResult<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const-string v0, "input"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 33
    sub-int v0, p1, p2

    .line 34
    .local v0, "start":I
    new-instance v1, Lcom/pkware/ahocorasick/AhoCorasickResult;

    invoke-virtual {p3, v0, p1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v2

    const-string v3, "substring(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v1, v0, p1, v2}, Lcom/pkware/ahocorasick/AhoCorasickResult;-><init>(IILjava/lang/Object;)V

    return-object v1
.end method
