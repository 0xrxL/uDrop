.class public final Lcom/pkware/ahocorasick/DoubleArrayIntList;
.super Lcom/pkware/ahocorasick/SafeIndexable;
.source "DoubleArrayIntList.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/pkware/ahocorasick/DoubleArrayIntList$Companion;
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000.\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0008\n\u0002\u0008\u0002\n\u0002\u0010\u0011\n\u0002\u0010\u0015\n\u0002\u0008\u0008\n\u0002\u0010\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u000b\n\u0002\u0008\u0004\u0008\u0000\u0018\u0000 \u00162\u00020\u0001:\u0001\u0016B\u000f\u0012\u0008\u0008\u0002\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J\u0011\u0010\r\u001a\u00020\u00032\u0006\u0010\u000e\u001a\u00020\u0003H\u0096\u0002J\u0010\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u0003H\u0002J\u0018\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u000e\u001a\u00020\u00032\u0006\u0010\u0014\u001a\u00020\u0003H\u0016J\u0019\u0010\u0015\u001a\u00020\u00102\u0006\u0010\u000e\u001a\u00020\u00032\u0006\u0010\u0014\u001a\u00020\u0003H\u0096\u0002R\u0018\u0010\u0005\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00070\u0006X\u0082\u000e\u00a2\u0006\u0004\n\u0002\u0010\u0008R\u0014\u0010\t\u001a\u00020\u00038BX\u0082\u0004\u00a2\u0006\u0006\u001a\u0004\u0008\n\u0010\u000bR\u000e\u0010\u000c\u001a\u00020\u0003X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0017"
    }
    d2 = {
        "Lcom/pkware/ahocorasick/DoubleArrayIntList;",
        "Lcom/pkware/ahocorasick/SafeIndexable;",
        "defaultValue",
        "",
        "(I)V",
        "baseArray",
        "",
        "",
        "[[I",
        "internalSize",
        "getInternalSize",
        "()I",
        "populatedSubArrays",
        "get",
        "index",
        "resize",
        "",
        "wantedIndex",
        "safeSet",
        "",
        "value",
        "set",
        "Companion",
        "LowMemoryAhoCorasick"
    }
    k = 0x1
    mv = {
        0x1,
        0x9,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field private static final Companion:Lcom/pkware/ahocorasick/DoubleArrayIntList$Companion;

.field public static final SUBARRAY_BITS:I = 0xe
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final SUBARRAY_MASK:I = 0x3fff
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final SUBARRAY_SIZE:I = 0x4000
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field


# instance fields
.field private baseArray:[[I

.field private populatedSubArrays:I


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Lcom/pkware/ahocorasick/DoubleArrayIntList$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/pkware/ahocorasick/DoubleArrayIntList$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lcom/pkware/ahocorasick/DoubleArrayIntList;->Companion:Lcom/pkware/ahocorasick/DoubleArrayIntList$Companion;

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v0, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-direct {p0, v2, v0, v1}, Lcom/pkware/ahocorasick/DoubleArrayIntList;-><init>(IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    return-void
.end method

.method public constructor <init>(I)V
    .locals 7
    .param p1, "defaultValue"    # I

    .line 16
    invoke-direct {p0, p1}, Lcom/pkware/ahocorasick/SafeIndexable;-><init>(I)V

    .line 21
    const/4 v0, 0x1

    iput v0, p0, Lcom/pkware/ahocorasick/DoubleArrayIntList;->populatedSubArrays:I

    .line 29
    new-array v1, v0, [[I

    const/4 v2, 0x0

    move v3, v2

    :goto_0
    if-ge v3, v0, :cond_1

    const/16 v4, 0x4000

    new-array v5, v4, [I

    move v6, v2

    :goto_1
    if-ge v6, v4, :cond_0

    aput p1, v5, v6

    add-int/lit8 v6, v6, 0x1

    goto :goto_1

    :cond_0
    aput-object v5, v1, v3

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_1
    iput-object v1, p0, Lcom/pkware/ahocorasick/DoubleArrayIntList;->baseArray:[[I

    .line 14
    return-void
.end method

.method public synthetic constructor <init>(IILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    .line 14
    and-int/lit8 p2, p2, 0x1

    if-eqz p2, :cond_0

    .line 15
    sget-object p1, Lcom/pkware/ahocorasick/SafeIndexable;->Companion:Lcom/pkware/ahocorasick/SafeIndexable$Companion;

    invoke-virtual {p1}, Lcom/pkware/ahocorasick/SafeIndexable$Companion;->getDEFAULT_VALUE()I

    move-result p1

    .line 14
    :cond_0
    invoke-direct {p0, p1}, Lcom/pkware/ahocorasick/DoubleArrayIntList;-><init>(I)V

    .line 106
    return-void
.end method

.method private final getInternalSize()I
    .locals 1

    .line 34
    iget v0, p0, Lcom/pkware/ahocorasick/DoubleArrayIntList;->populatedSubArrays:I

    mul-int/lit16 v0, v0, 0x4000

    return v0
.end method

.method private final resize(I)V
    .locals 8
    .param p1, "wantedIndex"    # I

    .line 64
    iget-object v0, p0, Lcom/pkware/ahocorasick/DoubleArrayIntList;->baseArray:[[I

    check-cast v0, [Ljava/lang/Object;

    array-length v0, v0

    const/16 v1, 0x4000

    mul-int/2addr v0, v1

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-lt p1, v0, :cond_2

    .line 66
    invoke-static {p1}, Ljava/lang/Integer;->highestOneBit(I)I

    move-result v0

    shr-int/lit8 v0, v0, 0xd

    invoke-static {v3, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    .line 67
    .local v0, "newBaseSize":I
    new-array v4, v0, [[I

    move v5, v2

    :goto_0
    if-ge v5, v0, :cond_1

    .line 68
    iget-object v6, p0, Lcom/pkware/ahocorasick/DoubleArrayIntList;->baseArray:[[I

    check-cast v6, [Ljava/lang/Object;

    array-length v6, v6

    if-ge v5, v6, :cond_0

    iget-object v6, p0, Lcom/pkware/ahocorasick/DoubleArrayIntList;->baseArray:[[I

    aget-object v6, v6, v5

    goto :goto_1

    :cond_0
    const/4 v6, 0x0

    :goto_1
    aput-object v6, v4, v5

    add-int/lit8 v5, v5, 0x1

    .line 67
    goto :goto_0

    .line 71
    .local v4, "newBaseArray":[[I
    :cond_1
    iput-object v4, p0, Lcom/pkware/ahocorasick/DoubleArrayIntList;->baseArray:[[I

    .line 74
    .end local v0    # "newBaseSize":I
    .end local v4    # "newBaseArray":[[I
    :cond_2
    div-int/lit16 v0, p1, 0x4000

    add-int/2addr v0, v3

    .line 75
    .local v0, "newFilledSubArrays":I
    iget v3, p0, Lcom/pkware/ahocorasick/DoubleArrayIntList;->populatedSubArrays:I

    .local v3, "i":I
    :goto_2
    if-ge v3, v0, :cond_4

    .line 76
    iget-object v4, p0, Lcom/pkware/ahocorasick/DoubleArrayIntList;->baseArray:[[I

    new-array v5, v1, [I

    move v6, v2

    :goto_3
    if-ge v6, v1, :cond_3

    invoke-virtual {p0}, Lcom/pkware/ahocorasick/DoubleArrayIntList;->getDefaultValue()I

    move-result v7

    aput v7, v5, v6

    add-int/lit8 v6, v6, 0x1

    goto :goto_3

    :cond_3
    aput-object v5, v4, v3

    .line 75
    add-int/lit8 v3, v3, 0x1

    goto :goto_2

    .line 79
    .end local v3    # "i":I
    :cond_4
    iput v0, p0, Lcom/pkware/ahocorasick/DoubleArrayIntList;->populatedSubArrays:I

    .line 80
    return-void
.end method


# virtual methods
.method public get(I)I
    .locals 2
    .param p1, "index"    # I

    .line 36
    iget-object v0, p0, Lcom/pkware/ahocorasick/DoubleArrayIntList;->baseArray:[[I

    shr-int/lit8 v1, p1, 0xe

    aget-object v0, v0, v1

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    and-int/lit16 v1, p1, 0x3fff

    aget v0, v0, v1

    return v0
.end method

.method public safeSet(II)Z
    .locals 3
    .param p1, "index"    # I
    .param p2, "value"    # I

    .line 42
    invoke-direct {p0}, Lcom/pkware/ahocorasick/DoubleArrayIntList;->getInternalSize()I

    move-result v0

    if-lt p1, v0, :cond_0

    invoke-direct {p0, p1}, Lcom/pkware/ahocorasick/DoubleArrayIntList;->resize(I)V

    .line 44
    :cond_0
    invoke-virtual {p0, p1, p2}, Lcom/pkware/ahocorasick/DoubleArrayIntList;->set(II)V

    .line 45
    invoke-virtual {p0}, Lcom/pkware/ahocorasick/DoubleArrayIntList;->getSize()I

    move-result v0

    .line 46
    .local v0, "oldSize":I
    invoke-virtual {p0}, Lcom/pkware/ahocorasick/DoubleArrayIntList;->getSize()I

    move-result v1

    add-int/lit8 v2, p1, 0x1

    invoke-static {v1, v2}, Ljava/lang/Math;->max(II)I

    move-result v1

    invoke-virtual {p0, v1}, Lcom/pkware/ahocorasick/DoubleArrayIntList;->setSize(I)V

    .line 48
    if-lt p1, v0, :cond_1

    const/4 v1, 0x1

    goto :goto_0

    :cond_1
    const/4 v1, 0x0

    :goto_0
    return v1
.end method

.method public set(II)V
    .locals 2
    .param p1, "index"    # I
    .param p2, "value"    # I

    .line 38
    iget-object v0, p0, Lcom/pkware/ahocorasick/DoubleArrayIntList;->baseArray:[[I

    shr-int/lit8 v1, p1, 0xe

    aget-object v0, v0, v1

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    and-int/lit16 v1, p1, 0x3fff

    aput p2, v0, v1

    return-void
.end method
