.class public final Lcom/pkware/ahocorasick/UnboxedIntList;
.super Lcom/pkware/ahocorasick/SafeIndexable;
.source "UnboxedIntList.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/pkware/ahocorasick/UnboxedIntList$Companion;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nUnboxedIntList.kt\nKotlin\n*S Kotlin\n*F\n+ 1 UnboxedIntList.kt\ncom/pkware/ahocorasick/UnboxedIntList\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,116:1\n1#2:117\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000.\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\u0006\n\u0002\u0008\u0003\n\u0002\u0010\u0015\n\u0000\n\u0002\u0010\u0002\n\u0002\u0008\u0008\n\u0002\u0010\u000b\n\u0002\u0008\u0003\u0008\u0000\u0018\u0000 \u00162\u00020\u0001:\u0001\u0016B#\u0012\u0008\u0008\u0002\u0010\u0002\u001a\u00020\u0003\u0012\u0008\u0008\u0002\u0010\u0004\u001a\u00020\u0005\u0012\u0008\u0008\u0002\u0010\u0006\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0007J\u000e\u0010\n\u001a\u00020\u000b2\u0006\u0010\u000c\u001a\u00020\u0003J\u0006\u0010\r\u001a\u00020\u000bJ\u0011\u0010\u000e\u001a\u00020\u00032\u0006\u0010\u000f\u001a\u00020\u0003H\u0096\u0002J\u0006\u0010\u0010\u001a\u00020\u0003J\u0010\u0010\u0011\u001a\u00020\u000b2\u0006\u0010\u0012\u001a\u00020\u0003H\u0002J\u0018\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u000f\u001a\u00020\u00032\u0006\u0010\u000c\u001a\u00020\u0003H\u0016J\u0019\u0010\u0015\u001a\u00020\u000b2\u0006\u0010\u000f\u001a\u00020\u00032\u0006\u0010\u000c\u001a\u00020\u0003H\u0096\u0002R\u000e\u0010\u0008\u001a\u00020\tX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0017"
    }
    d2 = {
        "Lcom/pkware/ahocorasick/UnboxedIntList;",
        "Lcom/pkware/ahocorasick/SafeIndexable;",
        "initialCapacity",
        "",
        "expansionRate",
        "",
        "defaultValue",
        "(IDI)V",
        "array",
        "",
        "add",
        "",
        "value",
        "clear",
        "get",
        "index",
        "pop",
        "resize",
        "wantedIndex",
        "safeSet",
        "",
        "set",
        "Companion",
        "LowMemoryAhoCorasick"
    }
    k = 0x1
    mv = {
        0x1,
        0x9,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field private static final Companion:Lcom/pkware/ahocorasick/UnboxedIntList$Companion;

.field public static final DEFAULT_EXPANSION_RATE:D = 1.5
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field


# instance fields
.field private array:[I

.field private final expansionRate:D


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Lcom/pkware/ahocorasick/UnboxedIntList$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/pkware/ahocorasick/UnboxedIntList$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lcom/pkware/ahocorasick/UnboxedIntList;->Companion:Lcom/pkware/ahocorasick/UnboxedIntList$Companion;

    return-void
.end method

.method public constructor <init>()V
    .locals 7

    const/4 v5, 0x7

    const/4 v6, 0x0

    const/4 v1, 0x0

    const-wide/16 v2, 0x0

    const/4 v4, 0x0

    move-object v0, p0

    invoke-direct/range {v0 .. v6}, Lcom/pkware/ahocorasick/UnboxedIntList;-><init>(IDIILkotlin/jvm/internal/DefaultConstructorMarker;)V

    return-void
.end method

.method public constructor <init>(IDI)V
    .locals 6
    .param p1, "initialCapacity"    # I
    .param p2, "expansionRate"    # D
    .param p4, "defaultValue"    # I

    .line 27
    invoke-direct {p0, p4}, Lcom/pkware/ahocorasick/SafeIndexable;-><init>(I)V

    .line 25
    iput-wide p2, p0, Lcom/pkware/ahocorasick/UnboxedIntList;->expansionRate:D

    .line 29
    nop

    .line 30
    const/4 v0, 0x0

    const/4 v1, 0x1

    if-lt p1, v1, :cond_0

    move v2, v1

    goto :goto_0

    :cond_0
    move v2, v0

    :goto_0
    if-eqz v2, :cond_4

    .line 31
    iget-wide v2, p0, Lcom/pkware/ahocorasick/UnboxedIntList;->expansionRate:D

    const-wide/high16 v4, 0x3ff0000000000000L    # 1.0

    cmpl-double v2, v2, v4

    if-lez v2, :cond_1

    move v2, v1

    goto :goto_1

    :cond_1
    move v2, v0

    :goto_1
    if-eqz v2, :cond_3

    .line 32
    nop

    .line 39
    invoke-static {p1, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    new-array v2, v1, [I

    :goto_2
    if-ge v0, v1, :cond_2

    aput p4, v2, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_2

    :cond_2
    iput-object v2, p0, Lcom/pkware/ahocorasick/UnboxedIntList;->array:[I

    .line 23
    return-void

    .line 117
    :cond_3
    const/4 v0, 0x0

    .line 31
    .local v0, "$i$a$-require-UnboxedIntList$2":I
    nop

    .end local v0    # "$i$a$-require-UnboxedIntList$2":I
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Expansion rate must be strictly greater than 1.0!"

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 117
    :cond_4
    const/4 v0, 0x0

    .line 30
    .local v0, "$i$a$-require-UnboxedIntList$1":I
    nop

    .end local v0    # "$i$a$-require-UnboxedIntList$1":I
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Initial capacity must be at least one!"

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public synthetic constructor <init>(IDIILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    .line 23
    and-int/lit8 p6, p5, 0x1

    if-eqz p6, :cond_0

    .line 24
    const/16 p1, 0x10

    .line 23
    :cond_0
    and-int/lit8 p6, p5, 0x2

    if-eqz p6, :cond_1

    .line 25
    const-wide/high16 p2, 0x3ff8000000000000L    # 1.5

    .line 23
    :cond_1
    and-int/lit8 p5, p5, 0x4

    if-eqz p5, :cond_2

    .line 26
    sget-object p4, Lcom/pkware/ahocorasick/SafeIndexable;->Companion:Lcom/pkware/ahocorasick/SafeIndexable$Companion;

    invoke-virtual {p4}, Lcom/pkware/ahocorasick/SafeIndexable$Companion;->getDEFAULT_VALUE()I

    move-result p4

    .line 23
    :cond_2
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/pkware/ahocorasick/UnboxedIntList;-><init>(IDI)V

    .line 115
    return-void
.end method

.method private final resize(I)V
    .locals 5
    .param p1, "wantedIndex"    # I

    .line 97
    int-to-double v0, p1

    iget-wide v2, p0, Lcom/pkware/ahocorasick/UnboxedIntList;->expansionRate:D

    mul-double/2addr v0, v2

    invoke-static {v0, v1}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v0

    double-to-int v0, v0

    new-array v1, v0, [I

    const/4 v2, 0x0

    move v3, v2

    :goto_0
    if-ge v3, v0, :cond_0

    invoke-virtual {p0}, Lcom/pkware/ahocorasick/UnboxedIntList;->getDefaultValue()I

    move-result v4

    aput v4, v1, v3

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    .line 98
    .local v1, "newArray":[I
    :cond_0
    iget-object v0, p0, Lcom/pkware/ahocorasick/UnboxedIntList;->array:[I

    iget-object v3, p0, Lcom/pkware/ahocorasick/UnboxedIntList;->array:[I

    array-length v3, v3

    invoke-static {v0, v2, v1, v2, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 100
    iput-object v1, p0, Lcom/pkware/ahocorasick/UnboxedIntList;->array:[I

    .line 101
    return-void
.end method


# virtual methods
.method public final add(I)V
    .locals 3
    .param p1, "value"    # I

    .line 62
    invoke-virtual {p0}, Lcom/pkware/ahocorasick/UnboxedIntList;->getSize()I

    move-result v0

    iget-object v1, p0, Lcom/pkware/ahocorasick/UnboxedIntList;->array:[I

    array-length v1, v1

    if-ne v0, v1, :cond_0

    iget-object v0, p0, Lcom/pkware/ahocorasick/UnboxedIntList;->array:[I

    array-length v0, v0

    invoke-direct {p0, v0}, Lcom/pkware/ahocorasick/UnboxedIntList;->resize(I)V

    .line 63
    :cond_0
    iget-object v0, p0, Lcom/pkware/ahocorasick/UnboxedIntList;->array:[I

    invoke-virtual {p0}, Lcom/pkware/ahocorasick/UnboxedIntList;->getSize()I

    move-result v1

    add-int/lit8 v2, v1, 0x1

    invoke-virtual {p0, v2}, Lcom/pkware/ahocorasick/UnboxedIntList;->setSize(I)V

    aput p1, v0, v1

    .line 64
    return-void
.end method

.method public final clear()V
    .locals 1

    .line 83
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lcom/pkware/ahocorasick/UnboxedIntList;->setSize(I)V

    .line 84
    return-void
.end method

.method public get(I)I
    .locals 1
    .param p1, "index"    # I

    .line 41
    iget-object v0, p0, Lcom/pkware/ahocorasick/UnboxedIntList;->array:[I

    aget v0, v0, p1

    return v0
.end method

.method public final pop()I
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/util/NoSuchElementException;
        }
    .end annotation

    .line 74
    invoke-virtual {p0}, Lcom/pkware/ahocorasick/UnboxedIntList;->getSize()I

    move-result v0

    if-eqz v0, :cond_0

    .line 76
    iget-object v0, p0, Lcom/pkware/ahocorasick/UnboxedIntList;->array:[I

    invoke-virtual {p0}, Lcom/pkware/ahocorasick/UnboxedIntList;->getSize()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    invoke-virtual {p0, v1}, Lcom/pkware/ahocorasick/UnboxedIntList;->setSize(I)V

    invoke-virtual {p0}, Lcom/pkware/ahocorasick/UnboxedIntList;->getSize()I

    move-result v1

    aget v0, v0, v1

    return v0

    .line 74
    :cond_0
    new-instance v0, Ljava/util/NoSuchElementException;

    invoke-direct {v0}, Ljava/util/NoSuchElementException;-><init>()V

    throw v0
.end method

.method public safeSet(II)Z
    .locals 3
    .param p1, "index"    # I
    .param p2, "value"    # I

    .line 47
    iget-object v0, p0, Lcom/pkware/ahocorasick/UnboxedIntList;->array:[I

    array-length v0, v0

    if-lt p1, v0, :cond_0

    invoke-direct {p0, p1}, Lcom/pkware/ahocorasick/UnboxedIntList;->resize(I)V

    .line 49
    :cond_0
    iget-object v0, p0, Lcom/pkware/ahocorasick/UnboxedIntList;->array:[I

    aput p2, v0, p1

    .line 50
    invoke-virtual {p0}, Lcom/pkware/ahocorasick/UnboxedIntList;->getSize()I

    move-result v0

    .line 51
    .local v0, "oldSize":I
    invoke-virtual {p0}, Lcom/pkware/ahocorasick/UnboxedIntList;->getSize()I

    move-result v1

    add-int/lit8 v2, p1, 0x1

    invoke-static {v1, v2}, Ljava/lang/Math;->max(II)I

    move-result v1

    invoke-virtual {p0, v1}, Lcom/pkware/ahocorasick/UnboxedIntList;->setSize(I)V

    .line 53
    if-lt p1, v0, :cond_1

    const/4 v1, 0x1

    goto :goto_0

    :cond_1
    const/4 v1, 0x0

    :goto_0
    return v1
.end method

.method public set(II)V
    .locals 1
    .param p1, "index"    # I
    .param p2, "value"    # I

    .line 43
    iget-object v0, p0, Lcom/pkware/ahocorasick/UnboxedIntList;->array:[I

    aput p2, v0, p1

    return-void
.end method
