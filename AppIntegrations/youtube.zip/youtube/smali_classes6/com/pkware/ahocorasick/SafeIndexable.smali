.class public abstract Lcom/pkware/ahocorasick/SafeIndexable;
.super Ljava/lang/Object;
.source "SafeIndexable.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/pkware/ahocorasick/SafeIndexable$Companion;
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0008\n\u0002\u0008\u000b\n\u0002\u0010\u000b\n\u0002\u0008\u0002\n\u0002\u0010\u0002\n\u0002\u0008\u0002\u0008 \u0018\u0000 \u00132\u00020\u0001:\u0001\u0013B\u000f\u0012\u0008\u0008\u0002\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J\u0011\u0010\u000b\u001a\u00020\u00032\u0006\u0010\u000c\u001a\u00020\u0003H\u00a6\u0002J\u000e\u0010\r\u001a\u00020\u00032\u0006\u0010\u000c\u001a\u00020\u0003J\u0018\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u000c\u001a\u00020\u00032\u0006\u0010\u0010\u001a\u00020\u0003H&J\u0019\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u000c\u001a\u00020\u00032\u0006\u0010\u0010\u001a\u00020\u0003H\u00a6\u0002R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0005\u0010\u0006R$\u0010\u0008\u001a\u00020\u00032\u0006\u0010\u0007\u001a\u00020\u0003@DX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\t\u0010\u0006\"\u0004\u0008\n\u0010\u0004\u00a8\u0006\u0014"
    }
    d2 = {
        "Lcom/pkware/ahocorasick/SafeIndexable;",
        "",
        "defaultValue",
        "",
        "(I)V",
        "getDefaultValue",
        "()I",
        "<set-?>",
        "size",
        "getSize",
        "setSize",
        "get",
        "index",
        "safeGet",
        "safeSet",
        "",
        "value",
        "set",
        "",
        "Companion",
        "LowMemoryAhoCorasick"
    }
    k = 0x1
    mv = {
        0x1,
        0x9,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final Companion:Lcom/pkware/ahocorasick/SafeIndexable$Companion;

.field private static final DEFAULT_VALUE:I


# instance fields
.field private final defaultValue:I

.field private size:I


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Lcom/pkware/ahocorasick/SafeIndexable$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/pkware/ahocorasick/SafeIndexable$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lcom/pkware/ahocorasick/SafeIndexable;->Companion:Lcom/pkware/ahocorasick/SafeIndexable$Companion;

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v0, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-direct {p0, v2, v0, v1}, Lcom/pkware/ahocorasick/SafeIndexable;-><init>(IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    return-void
.end method

.method public constructor <init>(I)V
    .locals 0
    .param p1, "defaultValue"    # I

    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lcom/pkware/ahocorasick/SafeIndexable;->defaultValue:I

    return-void
.end method

.method public synthetic constructor <init>(IILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    .line 6
    and-int/lit8 p2, p2, 0x1

    if-eqz p2, :cond_0

    sget p1, Lcom/pkware/ahocorasick/SafeIndexable;->DEFAULT_VALUE:I

    :cond_0
    invoke-direct {p0, p1}, Lcom/pkware/ahocorasick/SafeIndexable;-><init>(I)V

    .line 53
    return-void
.end method

.method public static final synthetic access$getDEFAULT_VALUE$cp()I
    .locals 1

    .line 6
    sget v0, Lcom/pkware/ahocorasick/SafeIndexable;->DEFAULT_VALUE:I

    return v0
.end method

.method public static final getDEFAULT_VALUE()I
    .locals 1

    sget-object v0, Lcom/pkware/ahocorasick/SafeIndexable;->Companion:Lcom/pkware/ahocorasick/SafeIndexable$Companion;

    invoke-virtual {v0}, Lcom/pkware/ahocorasick/SafeIndexable$Companion;->getDEFAULT_VALUE()I

    move-result v0

    return v0
.end method


# virtual methods
.method public abstract get(I)I
.end method

.method public final getDefaultValue()I
    .locals 1

    .line 6
    iget v0, p0, Lcom/pkware/ahocorasick/SafeIndexable;->defaultValue:I

    return v0
.end method

.method public final getSize()I
    .locals 1

    .line 11
    iget v0, p0, Lcom/pkware/ahocorasick/SafeIndexable;->size:I

    return v0
.end method

.method public final safeGet(I)I
    .locals 1
    .param p1, "index"    # I

    .line 20
    iget v0, p0, Lcom/pkware/ahocorasick/SafeIndexable;->size:I

    if-lt p1, v0, :cond_0

    iget v0, p0, Lcom/pkware/ahocorasick/SafeIndexable;->defaultValue:I

    return v0

    .line 21
    :cond_0
    invoke-virtual {p0, p1}, Lcom/pkware/ahocorasick/SafeIndexable;->get(I)I

    move-result v0

    return v0
.end method

.method public abstract safeSet(II)Z
.end method

.method public abstract set(II)V
.end method

.method protected final setSize(I)V
    .locals 0
    .param p1, "<set-?>"    # I

    .line 12
    iput p1, p0, Lcom/pkware/ahocorasick/SafeIndexable;->size:I

    return-void
.end method
