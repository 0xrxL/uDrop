.class public abstract Lcom/pkware/ahocorasick/AhoCorasickBase;
.super Ljava/lang/Object;
.source "AhoCorasickBase.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/pkware/ahocorasick/AhoCorasickBase$AhoCorasickSpliterator;,
        Lcom/pkware/ahocorasick/AhoCorasickBase$Companion;,
        Lcom/pkware/ahocorasick/AhoCorasickBase$IntReference;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nAhoCorasickBase.kt\nKotlin\n*S Kotlin\n*F\n+ 1 AhoCorasickBase.kt\ncom/pkware/ahocorasick/AhoCorasickBase\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,946:1\n1#2:947\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000l\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\"\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u000b\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0010\u0008\n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\u0008\u001a\n\u0002\u0018\u0002\n\u0002\u0008\u000b\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0010\u000c\n\u0002\u0008\u0004\u0008&\u0018\u0000 O*\u0004\u0008\u0000\u0010\u00012\u00020\u0002:\u0003NOPB\u0017\u0008\u0007\u0012\u000e\u0008\u0002\u0010\u0003\u001a\u0008\u0012\u0004\u0012\u00020\u00050\u0004\u00a2\u0006\u0002\u0010\u0006J\u0018\u0010\u001b\u001a\u00020\u001c2\u0006\u0010\u001d\u001a\u00020\u001e2\u0006\u0010\u001f\u001a\u00020\u0014H\u0004J\u0018\u0010 \u001a\u00020\u001c2\u0006\u0010!\u001a\u00020\u00142\u0006\u0010\"\u001a\u00020\u0014H\u0002J\u0006\u0010#\u001a\u00020\u001cJ\u0010\u0010$\u001a\u00020\u00142\u0006\u0010%\u001a\u00020\u0014H\u0002J\u0018\u0010&\u001a\u00020\u00142\u0006\u0010\'\u001a\u00020\u00142\u0006\u0010(\u001a\u00020\u0014H\u0002J\u0010\u0010)\u001a\u00020\u00142\u0006\u0010%\u001a\u00020\u0014H\u0002J\u0018\u0010*\u001a\u00020\u000b2\u0006\u0010+\u001a\u00020\u00082\u0006\u0010,\u001a\u00020\u0014H\u0002J\u0008\u0010-\u001a\u00020\u001cH\u0002J\u000e\u0010.\u001a\u00020\u000b2\u0006\u0010/\u001a\u00020\u001eJ\u0018\u00100\u001a\u00020\u000b2\u0006\u00101\u001a\u00020\u00142\u0006\u00102\u001a\u00020\u0014H\u0002J\u0018\u00103\u001a\u00020\u00082\u0006\u00101\u001a\u00020\u00142\u0006\u00104\u001a\u00020\u0008H\u0002J\u0010\u00105\u001a\u00020\u00142\u0006\u0010(\u001a\u00020\u0014H\u0002J\u0010\u00106\u001a\u00020\u00142\u0006\u00107\u001a\u00020\u0008H\u0002J&\u00108\u001a\u0008\u0012\u0004\u0012\u00028\u0000092\u0006\u0010!\u001a\u00020\u00142\u0006\u0010\u001f\u001a\u00020\u00142\u0006\u0010:\u001a\u00020\u001eH$J \u0010;\u001a\u00020\u00142\u0006\u0010<\u001a\u00020\u00142\u0006\u0010=\u001a\u00020\u00142\u0006\u0010>\u001a\u00020\u0014H\u0002J\u001e\u0010?\u001a\u00020\u000b2\u000c\u0010@\u001a\u0008\u0012\u0004\u0012\u00028\u0000092\u0006\u0010A\u001a\u00020\u001eH\u0002J\u001e\u0010B\u001a\u00020\u000b2\u000c\u0010@\u001a\u0008\u0012\u0004\u0012\u00028\u0000092\u0006\u0010A\u001a\u00020\u001eH\u0002J\u0010\u0010C\u001a\u00020\u00142\u0006\u0010\u001d\u001a\u00020\u001eH\u0004J\u001a\u0010D\u001a\u000e\u0012\n\u0012\u0008\u0012\u0004\u0012\u00028\u0000090E2\u0006\u0010:\u001a\u00020\u001eJ\u001e\u0010F\u001a\u00020\u000b2\u000c\u0010@\u001a\u0008\u0012\u0004\u0012\u00028\u0000092\u0006\u0010A\u001a\u00020\u001eH\u0002J\u0018\u0010G\u001a\u00020\u001c2\u0006\u00101\u001a\u00020\u00142\u0006\u0010H\u001a\u00020IH\u0002J\u0018\u0010J\u001a\u00020\u00142\u0006\u0010H\u001a\u00020I2\u0006\u0010K\u001a\u00020IH\u0002J\u000c\u0010L\u001a\u00020M*\u00020MH\u0002J\u000c\u0010L\u001a\u00020\u001e*\u00020\u001eH\u0002R\u000e\u0010\u0007\u001a\u00020\u0008X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0008X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0011\u0010\n\u001a\u00020\u000b\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000c\u0010\rR\u000e\u0010\u000e\u001a\u00020\u000fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001e\u0010\u0011\u001a\u00020\u000b2\u0006\u0010\u0010\u001a\u00020\u000b@BX\u0086\u000e\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0011\u0010\rR\u0011\u0010\u0012\u001a\u00020\u000b\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0012\u0010\rR\u000e\u0010\u0013\u001a\u00020\u0014X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001e\u0010\u0015\u001a\u00020\u00142\u0006\u0010\u0010\u001a\u00020\u0014@BX\u0086\u000e\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0016\u0010\u0017R\u000e\u0010\u0018\u001a\u00020\u0014X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\u001aX\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006Q"
    }
    d2 = {
        "Lcom/pkware/ahocorasick/AhoCorasickBase;",
        "T",
        "",
        "options",
        "",
        "Lcom/pkware/ahocorasick/AhoCorasickOption;",
        "(Ljava/util/Set;)V",
        "childrenOffsetStore1",
        "Lcom/pkware/ahocorasick/UnboxedIntList;",
        "childrenOffsetStore2",
        "findOnlyWholeWords",
        "",
        "getFindOnlyWholeWords",
        "()Z",
        "indexCache",
        "Lcom/pkware/ahocorasick/IndexCache;",
        "<set-?>",
        "isBuilt",
        "isCaseSensitive",
        "multiChildCache",
        "",
        "nodes",
        "getNodes",
        "()I",
        "singleChildCache",
        "store",
        "Lcom/pkware/ahocorasick/AhoCorasickStore;",
        "addEntry",
        "",
        "key",
        "",
        "value",
        "addNode",
        "index",
        "parentIndex",
        "build",
        "calculateFailureIndex",
        "node",
        "calculateNextState",
        "startingNode",
        "offset",
        "calculatePrefixIndex",
        "canInsertOffsets",
        "relativeOffsets",
        "baseOffset",
        "constructFailStates",
        "contains",
        "entry",
        "containsChild",
        "parent",
        "childOffset",
        "determineChildOffsets",
        "childrenOffsetStore",
        "findOpenIndex",
        "findOpenIndexes",
        "offsets",
        "generateResult",
        "Lcom/pkware/ahocorasick/AhoCorasickResult;",
        "input",
        "handleBaseOffsetConflict",
        "originalParentIndex",
        "encroachingParentIndex",
        "wantedInsertion",
        "hasLeadingWhitespace",
        "result",
        "text",
        "hasTrailingWhitespace",
        "keyValue",
        "parse",
        "Ljava/util/stream/Stream;",
        "passesWhitespaceChecks",
        "prepareChildrenForProcessing",
        "lastQueuedNode",
        "Lcom/pkware/ahocorasick/AhoCorasickBase$IntReference;",
        "processRootChildren",
        "currentIndex",
        "normalize",
        "",
        "AhoCorasickSpliterator",
        "Companion",
        "IntReference",
        "LowMemoryAhoCorasick"
    }
    k = 0x1
    mv = {
        0x1,
        0x9,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field private static final Companion:Lcom/pkware/ahocorasick/AhoCorasickBase$Companion;

.field public static final ROOT_NODE:I
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field private static final WHITESPACE_REGEX:Lkotlin/text/Regex;


# instance fields
.field private final childrenOffsetStore1:Lcom/pkware/ahocorasick/UnboxedIntList;

.field private final childrenOffsetStore2:Lcom/pkware/ahocorasick/UnboxedIntList;

.field private final findOnlyWholeWords:Z

.field private final indexCache:Lcom/pkware/ahocorasick/IndexCache;

.field private isBuilt:Z

.field private final isCaseSensitive:Z

.field private multiChildCache:I

.field private nodes:I

.field private singleChildCache:I

.field private final store:Lcom/pkware/ahocorasick/AhoCorasickStore;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Lcom/pkware/ahocorasick/AhoCorasickBase$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/pkware/ahocorasick/AhoCorasickBase$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lcom/pkware/ahocorasick/AhoCorasickBase;->Companion:Lcom/pkware/ahocorasick/AhoCorasickBase$Companion;

    .line 938
    new-instance v0, Lkotlin/text/Regex;

    const-string v1, "\\s"

    invoke-direct {v0, v1}, Lkotlin/text/Regex;-><init>(Ljava/lang/String;)V

    sput-object v0, Lcom/pkware/ahocorasick/AhoCorasickBase;->WHITESPACE_REGEX:Lkotlin/text/Regex;

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-direct {p0, v0, v1, v0}, Lcom/pkware/ahocorasick/AhoCorasickBase;-><init>(Ljava/util/Set;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    return-void
.end method

.method public constructor <init>(Ljava/util/Set;)V
    .locals 12
    .param p1, "options"    # Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Set<",
            "+",
            "Lcom/pkware/ahocorasick/AhoCorasickOption;",
            ">;)V"
        }
    .end annotation

    const-string v0, "options"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 64
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 90
    const/4 v0, 0x1

    iput v0, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->singleChildCache:I

    .line 100
    iput v0, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->multiChildCache:I

    .line 114
    new-instance v1, Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-direct {v1}, Lcom/pkware/ahocorasick/AhoCorasickStore;-><init>()V

    iput-object v1, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    .line 121
    iput v0, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->nodes:I

    .line 129
    new-instance v2, Lcom/pkware/ahocorasick/UnboxedIntList;

    const/4 v7, 0x7

    const/4 v8, 0x0

    const/4 v3, 0x0

    const-wide/16 v4, 0x0

    const/4 v6, 0x0

    invoke-direct/range {v2 .. v8}, Lcom/pkware/ahocorasick/UnboxedIntList;-><init>(IDIILkotlin/jvm/internal/DefaultConstructorMarker;)V

    iput-object v2, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->childrenOffsetStore1:Lcom/pkware/ahocorasick/UnboxedIntList;

    .line 136
    new-instance v3, Lcom/pkware/ahocorasick/UnboxedIntList;

    const/4 v8, 0x7

    const/4 v9, 0x0

    const/4 v4, 0x0

    const-wide/16 v5, 0x0

    const/4 v7, 0x0

    invoke-direct/range {v3 .. v9}, Lcom/pkware/ahocorasick/UnboxedIntList;-><init>(IDIILkotlin/jvm/internal/DefaultConstructorMarker;)V

    iput-object v3, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->childrenOffsetStore2:Lcom/pkware/ahocorasick/UnboxedIntList;

    .line 142
    new-instance v4, Lcom/pkware/ahocorasick/IndexCache;

    iget-object v5, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    const/4 v8, 0x6

    const/4 v6, 0x0

    invoke-direct/range {v4 .. v9}, Lcom/pkware/ahocorasick/IndexCache;-><init>(Lcom/pkware/ahocorasick/AhoCorasickStore;IIILkotlin/jvm/internal/DefaultConstructorMarker;)V

    iput-object v4, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->indexCache:Lcom/pkware/ahocorasick/IndexCache;

    .line 144
    nop

    .line 150
    iget-object v5, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    const/high16 v10, -0x80000000

    const/high16 v11, -0x80000000

    const/4 v7, 0x1

    const/4 v8, 0x0

    const/high16 v9, -0x80000000

    invoke-virtual/range {v5 .. v11}, Lcom/pkware/ahocorasick/AhoCorasickStore;->synchronizedSafeSet(IIIIII)V

    .line 152
    sget-object v1, Lcom/pkware/ahocorasick/AhoCorasickOption;->CASE_INSENSITIVE:Lcom/pkware/ahocorasick/AhoCorasickOption;

    invoke-interface {p1, v1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v1

    xor-int/2addr v0, v1

    iput-boolean v0, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->isCaseSensitive:Z

    .line 153
    sget-object v0, Lcom/pkware/ahocorasick/AhoCorasickOption;->WHOLE_WORDS_ONLY:Lcom/pkware/ahocorasick/AhoCorasickOption;

    invoke-interface {p1, v0}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    iput-boolean v0, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->findOnlyWholeWords:Z

    .line 154
    nop

    .line 64
    return-void
.end method

.method public synthetic constructor <init>(Ljava/util/Set;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    .line 64
    and-int/lit8 p2, p2, 0x1

    if-eqz p2, :cond_0

    invoke-static {}, Lkotlin/collections/SetsKt;->emptySet()Ljava/util/Set;

    move-result-object p1

    :cond_0
    invoke-direct {p0, p1}, Lcom/pkware/ahocorasick/AhoCorasickBase;-><init>(Ljava/util/Set;)V

    .line 945
    return-void
.end method

.method public static final synthetic access$calculateNextState(Lcom/pkware/ahocorasick/AhoCorasickBase;II)I
    .locals 1
    .param p0, "$this"    # Lcom/pkware/ahocorasick/AhoCorasickBase;
    .param p1, "startingNode"    # I
    .param p2, "offset"    # I

    .line 64
    invoke-direct {p0, p1, p2}, Lcom/pkware/ahocorasick/AhoCorasickBase;->calculateNextState(II)I

    move-result v0

    return v0
.end method

.method public static final synthetic access$getStore$p(Lcom/pkware/ahocorasick/AhoCorasickBase;)Lcom/pkware/ahocorasick/AhoCorasickStore;
    .locals 1
    .param p0, "$this"    # Lcom/pkware/ahocorasick/AhoCorasickBase;

    .line 64
    iget-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    return-object v0
.end method

.method public static final synthetic access$getWHITESPACE_REGEX$cp()Lkotlin/text/Regex;
    .locals 1

    .line 64
    sget-object v0, Lcom/pkware/ahocorasick/AhoCorasickBase;->WHITESPACE_REGEX:Lkotlin/text/Regex;

    return-object v0
.end method

.method public static final synthetic access$normalize(Lcom/pkware/ahocorasick/AhoCorasickBase;C)C
    .locals 1
    .param p0, "$this"    # Lcom/pkware/ahocorasick/AhoCorasickBase;
    .param p1, "$receiver"    # C

    .line 64
    invoke-direct {p0, p1}, Lcom/pkware/ahocorasick/AhoCorasickBase;->normalize(C)C

    move-result v0

    return v0
.end method

.method public static final synthetic access$passesWhitespaceChecks(Lcom/pkware/ahocorasick/AhoCorasickBase;Lcom/pkware/ahocorasick/AhoCorasickResult;Ljava/lang/String;)Z
    .locals 1
    .param p0, "$this"    # Lcom/pkware/ahocorasick/AhoCorasickBase;
    .param p1, "result"    # Lcom/pkware/ahocorasick/AhoCorasickResult;
    .param p2, "text"    # Ljava/lang/String;

    .line 64
    invoke-direct {p0, p1, p2}, Lcom/pkware/ahocorasick/AhoCorasickBase;->passesWhitespaceChecks(Lcom/pkware/ahocorasick/AhoCorasickResult;Ljava/lang/String;)Z

    move-result v0

    return v0
.end method

.method private final addNode(II)V
    .locals 12
    .param p1, "index"    # I
    .param p2, "parentIndex"    # I

    .line 637
    iget v0, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->nodes:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->nodes:I

    .line 639
    iget-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v0, p2}, Lcom/pkware/ahocorasick/AhoCorasickStore;->getChildOffset(I)I

    move-result v0

    .line 640
    .local v0, "firstChildOffset":I
    iget-object v1, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v1, p2}, Lcom/pkware/ahocorasick/AhoCorasickStore;->getBaseOffset(I)I

    move-result v1

    sub-int v1, p1, v1

    .line 642
    .local v1, "currentNodeOffset":I
    move v2, v1

    .line 643
    .local v2, "siblingOffset":I
    const/high16 v3, -0x80000000

    if-ne v0, v3, :cond_0

    .line 646
    iget-object v3, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v3, p2, v1}, Lcom/pkware/ahocorasick/AhoCorasickStore;->setChildOffset(II)V

    move v10, v2

    goto :goto_0

    .line 650
    :cond_0
    iget-object v3, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v3, p2}, Lcom/pkware/ahocorasick/AhoCorasickStore;->getBaseOffset(I)I

    move-result v3

    add-int/2addr v3, v0

    .line 651
    .local v3, "firstChildIndex":I
    iget-object v4, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v4, v3}, Lcom/pkware/ahocorasick/AhoCorasickStore;->getNextSiblingOffset(I)I

    move-result v2

    .line 652
    iget-object v4, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v4, v3, v1}, Lcom/pkware/ahocorasick/AhoCorasickStore;->setNextSiblingOffset(II)V

    move v10, v2

    .line 655
    .end local v2    # "siblingOffset":I
    .end local v3    # "firstChildIndex":I
    .local v10, "siblingOffset":I
    :goto_0
    iget-object v5, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    .line 656
    nop

    .line 657
    nop

    .line 658
    nop

    .line 660
    nop

    .line 661
    nop

    .line 662
    nop

    .line 655
    const/high16 v7, -0x80000000

    const/high16 v9, -0x80000000

    const/high16 v11, -0x80000000

    move v6, p1

    move v8, p2

    .end local p1    # "index":I
    .end local p2    # "parentIndex":I
    .local v6, "index":I
    .local v8, "parentIndex":I
    invoke-virtual/range {v5 .. v11}, Lcom/pkware/ahocorasick/AhoCorasickStore;->synchronizedSafeSet(IIIIII)V

    .line 664
    return-void
.end method

.method private final calculateFailureIndex(I)I
    .locals 4
    .param p1, "node"    # I

    .line 742
    iget-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v0, p1}, Lcom/pkware/ahocorasick/AhoCorasickStore;->getParent(I)I

    move-result v0

    .line 743
    .local v0, "parent":I
    iget-object v1, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v1, v0}, Lcom/pkware/ahocorasick/AhoCorasickStore;->getBaseOffset(I)I

    move-result v1

    sub-int v1, p1, v1

    .line 744
    .local v1, "nodeOffset":I
    iget-object v2, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v2, v0}, Lcom/pkware/ahocorasick/AhoCorasickStore;->getFailureIndex(I)I

    move-result v2

    .line 747
    .local v2, "childFailureIndex":I
    :goto_0
    if-eqz v2, :cond_0

    invoke-direct {p0, v2, v1}, Lcom/pkware/ahocorasick/AhoCorasickBase;->containsChild(II)Z

    move-result v3

    if-nez v3, :cond_0

    .line 748
    iget-object v3, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v3, v2}, Lcom/pkware/ahocorasick/AhoCorasickStore;->getFailureIndex(I)I

    move-result v2

    goto :goto_0

    .line 752
    :cond_0
    invoke-direct {p0, v2, v1}, Lcom/pkware/ahocorasick/AhoCorasickBase;->containsChild(II)Z

    move-result v3

    if-eqz v3, :cond_1

    .line 753
    iget-object v3, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v3, v2}, Lcom/pkware/ahocorasick/AhoCorasickStore;->getBaseOffset(I)I

    move-result v3

    add-int v2, v3, v1

    .line 756
    :cond_1
    return v2
.end method

.method private final calculateNextState(II)I
    .locals 6
    .param p1, "startingNode"    # I
    .param p2, "offset"    # I

    .line 416
    move v0, p1

    .line 418
    .local v0, "currentNode":I
    iget-object v1, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v1, v0}, Lcom/pkware/ahocorasick/AhoCorasickStore;->getBaseOffset(I)I

    move-result v1

    add-int/2addr v1, p2

    .line 419
    .local v1, "childNode":I
    iget-object v2, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v2, v1}, Lcom/pkware/ahocorasick/AhoCorasickStore;->safeGetParent(I)I

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-ne v2, v0, :cond_0

    move v2, v3

    goto :goto_0

    :cond_0
    move v2, v4

    .line 421
    .local v2, "hasValidChild":Z
    :goto_0
    if-nez v2, :cond_2

    if-eqz v0, :cond_2

    .line 423
    iget-object v5, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v5, v0}, Lcom/pkware/ahocorasick/AhoCorasickStore;->getFailureIndex(I)I

    move-result v0

    .line 424
    iget-object v5, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v5, v0}, Lcom/pkware/ahocorasick/AhoCorasickStore;->getBaseOffset(I)I

    move-result v5

    add-int v1, v5, p2

    .line 425
    iget-object v5, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v5, v1}, Lcom/pkware/ahocorasick/AhoCorasickStore;->safeGetParent(I)I

    move-result v5

    if-ne v5, v0, :cond_1

    move v5, v3

    goto :goto_1

    :cond_1
    move v5, v4

    :goto_1
    move v2, v5

    goto :goto_0

    .line 429
    :cond_2
    if-eqz v2, :cond_3

    move v4, v1

    :cond_3
    return v4
.end method

.method private final calculatePrefixIndex(I)I
    .locals 3
    .param p1, "node"    # I

    .line 785
    iget-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v0, p1}, Lcom/pkware/ahocorasick/AhoCorasickStore;->getFailureIndex(I)I

    move-result v0

    .line 787
    .local v0, "failureIndex":I
    iget-object v1, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v1, v0}, Lcom/pkware/ahocorasick/AhoCorasickStore;->getValue(I)I

    move-result v1

    const/high16 v2, -0x80000000

    if-eq v1, v2, :cond_0

    return v0

    .line 788
    :cond_0
    iget-object v1, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v1, v0}, Lcom/pkware/ahocorasick/AhoCorasickStore;->getPrefixIndex(I)I

    move-result v1

    return v1
.end method

.method private final canInsertOffsets(Lcom/pkware/ahocorasick/UnboxedIntList;I)Z
    .locals 4
    .param p1, "relativeOffsets"    # Lcom/pkware/ahocorasick/UnboxedIntList;
    .param p2, "baseOffset"    # I

    .line 398
    const/4 v0, 0x0

    .local v0, "i":I
    invoke-virtual {p1}, Lcom/pkware/ahocorasick/UnboxedIntList;->getSize()I

    move-result v1

    :goto_0
    if-ge v0, v1, :cond_1

    .line 399
    iget-object v2, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {p1, v0}, Lcom/pkware/ahocorasick/UnboxedIntList;->get(I)I

    move-result v3

    add-int/2addr v3, p2

    invoke-virtual {v2, v3}, Lcom/pkware/ahocorasick/AhoCorasickStore;->safeGetParent(I)I

    move-result v2

    const/high16 v3, -0x80000000

    if-eq v2, v3, :cond_0

    const/4 v1, 0x0

    return v1

    .line 398
    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 402
    .end local v0    # "i":I
    :cond_1
    const/4 v0, 0x1

    return v0
.end method

.method private final constructFailStates()V
    .locals 9

    .line 353
    iget v0, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->nodes:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    return-void

    .line 356
    :cond_0
    new-instance v0, Lcom/pkware/ahocorasick/AhoCorasickBase$IntReference;

    const/4 v2, 0x0

    invoke-direct {v0, v2}, Lcom/pkware/ahocorasick/AhoCorasickBase$IntReference;-><init>(I)V

    .line 358
    .local v0, "lastQueuedNode":Lcom/pkware/ahocorasick/AhoCorasickBase$IntReference;
    invoke-direct {p0, v2, v0}, Lcom/pkware/ahocorasick/AhoCorasickBase;->prepareChildrenForProcessing(ILcom/pkware/ahocorasick/AhoCorasickBase$IntReference;)V

    .line 359
    new-instance v3, Lcom/pkware/ahocorasick/AhoCorasickBase$IntReference;

    iget-object v4, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v4, v2}, Lcom/pkware/ahocorasick/AhoCorasickStore;->getQueueIndex(I)I

    move-result v4

    invoke-direct {v3, v4}, Lcom/pkware/ahocorasick/AhoCorasickBase$IntReference;-><init>(I)V

    .line 360
    .local v3, "currentNode":Lcom/pkware/ahocorasick/AhoCorasickBase$IntReference;
    invoke-direct {p0, v0, v3}, Lcom/pkware/ahocorasick/AhoCorasickBase;->processRootChildren(Lcom/pkware/ahocorasick/AhoCorasickBase$IntReference;Lcom/pkware/ahocorasick/AhoCorasickBase$IntReference;)I

    move-result v4

    .line 363
    .local v4, "rootChildren":I
    iget-object v5, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v5, v2, v2}, Lcom/pkware/ahocorasick/AhoCorasickStore;->setFailureIndex(II)V

    .line 364
    iget-object v5, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    const/high16 v6, -0x80000000

    invoke-virtual {v5, v2, v6}, Lcom/pkware/ahocorasick/AhoCorasickStore;->setPrefixIndex(II)V

    .line 368
    const/4 v2, 0x0

    .local v2, "i":I
    iget v5, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->nodes:I

    sub-int/2addr v5, v1

    sub-int/2addr v5, v4

    :goto_0
    if-ge v2, v5, :cond_1

    .line 371
    invoke-virtual {v3}, Lcom/pkware/ahocorasick/AhoCorasickBase$IntReference;->getValue()I

    move-result v1

    invoke-direct {p0, v1, v0}, Lcom/pkware/ahocorasick/AhoCorasickBase;->prepareChildrenForProcessing(ILcom/pkware/ahocorasick/AhoCorasickBase$IntReference;)V

    .line 375
    iget-object v1, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v3}, Lcom/pkware/ahocorasick/AhoCorasickBase$IntReference;->getValue()I

    move-result v6

    invoke-virtual {v1, v6}, Lcom/pkware/ahocorasick/AhoCorasickStore;->getQueueIndex(I)I

    move-result v1

    .line 376
    .local v1, "nextIndex":I
    iget-object v6, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v3}, Lcom/pkware/ahocorasick/AhoCorasickBase$IntReference;->getValue()I

    move-result v7

    invoke-virtual {v3}, Lcom/pkware/ahocorasick/AhoCorasickBase$IntReference;->getValue()I

    move-result v8

    invoke-direct {p0, v8}, Lcom/pkware/ahocorasick/AhoCorasickBase;->calculateFailureIndex(I)I

    move-result v8

    invoke-virtual {v6, v7, v8}, Lcom/pkware/ahocorasick/AhoCorasickStore;->setFailureIndex(II)V

    .line 377
    iget-object v6, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v3}, Lcom/pkware/ahocorasick/AhoCorasickBase$IntReference;->getValue()I

    move-result v7

    invoke-virtual {v3}, Lcom/pkware/ahocorasick/AhoCorasickBase$IntReference;->getValue()I

    move-result v8

    invoke-direct {p0, v8}, Lcom/pkware/ahocorasick/AhoCorasickBase;->calculatePrefixIndex(I)I

    move-result v8

    invoke-virtual {v6, v7, v8}, Lcom/pkware/ahocorasick/AhoCorasickStore;->setPrefixIndex(II)V

    .line 379
    invoke-virtual {v3, v1}, Lcom/pkware/ahocorasick/AhoCorasickBase$IntReference;->setValue(I)V

    .line 368
    .end local v1    # "nextIndex":I
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    .line 381
    .end local v2    # "i":I
    :cond_1
    return-void
.end method

.method private final containsChild(II)Z
    .locals 2
    .param p1, "parent"    # I
    .param p2, "childOffset"    # I

    .line 325
    iget-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    iget-object v1, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v1, p1}, Lcom/pkware/ahocorasick/AhoCorasickStore;->getBaseOffset(I)I

    move-result v1

    add-int/2addr v1, p2

    invoke-virtual {v0, v1}, Lcom/pkware/ahocorasick/AhoCorasickStore;->safeGetParent(I)I

    move-result v0

    if-ne v0, p1, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method private final determineChildOffsets(ILcom/pkware/ahocorasick/UnboxedIntList;)Lcom/pkware/ahocorasick/UnboxedIntList;
    .locals 6
    .param p1, "parent"    # I
    .param p2, "childrenOffsetStore"    # Lcom/pkware/ahocorasick/UnboxedIntList;

    .line 683
    invoke-virtual {p2}, Lcom/pkware/ahocorasick/UnboxedIntList;->clear()V

    .line 684
    iget-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v0, p1}, Lcom/pkware/ahocorasick/AhoCorasickStore;->getChildOffset(I)I

    move-result v0

    .line 687
    .local v0, "firstChildOffset":I
    const/high16 v1, -0x80000000

    if-ne v0, v1, :cond_0

    return-object p2

    .line 690
    :cond_0
    iget-object v1, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v1, p1}, Lcom/pkware/ahocorasick/AhoCorasickStore;->getBaseOffset(I)I

    move-result v1

    .line 691
    .local v1, "parentBaseOffset":I
    iget-object v2, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    add-int v3, v1, v0

    invoke-virtual {v2, v3}, Lcom/pkware/ahocorasick/AhoCorasickStore;->getNextSiblingOffset(I)I

    move-result v2

    .line 692
    .local v2, "initialOffset":I
    move v3, v2

    .line 696
    .local v3, "currentOffset":I
    :cond_1
    add-int v4, v1, v3

    .line 697
    .local v4, "nextIndex":I
    invoke-virtual {p2, v3}, Lcom/pkware/ahocorasick/UnboxedIntList;->add(I)V

    .line 698
    iget-object v5, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v5, v4}, Lcom/pkware/ahocorasick/AhoCorasickStore;->getNextSiblingOffset(I)I

    move-result v3

    .line 699
    .end local v4    # "nextIndex":I
    if-ne v3, v2, :cond_1

    .line 701
    return-object p2
.end method

.method private final findOpenIndex(I)I
    .locals 3
    .param p1, "offset"    # I

    .line 500
    iget-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->indexCache:Lcom/pkware/ahocorasick/IndexCache;

    invoke-virtual {v0, p1}, Lcom/pkware/ahocorasick/IndexCache;->popIndex(I)I

    move-result v0

    .line 501
    .local v0, "cacheIndex":I
    if-eqz v0, :cond_0

    return v0

    .line 508
    :cond_0
    iget v1, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->singleChildCache:I

    add-int/lit8 v2, p1, -0x1

    invoke-static {v1, v2}, Ljava/lang/Math;->max(II)I

    move-result v1

    iput v1, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->singleChildCache:I

    .line 511
    :cond_1
    iget-object v1, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    iget v2, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->singleChildCache:I

    add-int/lit8 v2, v2, 0x1

    iput v2, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->singleChildCache:I

    iget v2, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->singleChildCache:I

    invoke-virtual {v1, v2}, Lcom/pkware/ahocorasick/AhoCorasickStore;->safeGetParent(I)I

    move-result v1

    const/high16 v2, -0x80000000

    if-ne v1, v2, :cond_1

    .line 513
    iget v1, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->singleChildCache:I

    return v1
.end method

.method private final findOpenIndexes(Lcom/pkware/ahocorasick/UnboxedIntList;)I
    .locals 3
    .param p1, "offsets"    # Lcom/pkware/ahocorasick/UnboxedIntList;

    .line 475
    invoke-virtual {p1}, Lcom/pkware/ahocorasick/UnboxedIntList;->getSize()I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Lcom/pkware/ahocorasick/UnboxedIntList;->get(I)I

    move-result v1

    invoke-direct {p0, v1}, Lcom/pkware/ahocorasick/AhoCorasickBase;->findOpenIndex(I)I

    move-result v1

    invoke-virtual {p1, v0}, Lcom/pkware/ahocorasick/UnboxedIntList;->get(I)I

    move-result v0

    sub-int/2addr v1, v0

    return v1

    .line 478
    :cond_0
    iget v0, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->singleChildCache:I

    iget v2, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->multiChildCache:I

    invoke-static {v0, v2}, Ljava/lang/Math;->max(II)I

    move-result v0

    iput v0, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->multiChildCache:I

    .line 480
    :cond_1
    iget v0, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->multiChildCache:I

    add-int/2addr v0, v1

    iput v0, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->multiChildCache:I

    iget v0, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->multiChildCache:I

    invoke-direct {p0, p1, v0}, Lcom/pkware/ahocorasick/AhoCorasickBase;->canInsertOffsets(Lcom/pkware/ahocorasick/UnboxedIntList;I)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 482
    iget v0, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->multiChildCache:I

    return v0
.end method

.method private final handleBaseOffsetConflict(III)I
    .locals 22
    .param p1, "originalParentIndex"    # I
    .param p2, "encroachingParentIndex"    # I
    .param p3, "wantedInsertion"    # I

    .line 546
    move-object/from16 v0, p0

    move/from16 v1, p1

    move/from16 v2, p2

    move/from16 v3, p3

    iget-object v4, v0, Lcom/pkware/ahocorasick/AhoCorasickBase;->childrenOffsetStore1:Lcom/pkware/ahocorasick/UnboxedIntList;

    invoke-direct {v0, v1, v4}, Lcom/pkware/ahocorasick/AhoCorasickBase;->determineChildOffsets(ILcom/pkware/ahocorasick/UnboxedIntList;)Lcom/pkware/ahocorasick/UnboxedIntList;

    move-result-object v4

    .line 547
    .local v4, "originalChildren":Lcom/pkware/ahocorasick/UnboxedIntList;
    iget-object v5, v0, Lcom/pkware/ahocorasick/AhoCorasickBase;->childrenOffsetStore2:Lcom/pkware/ahocorasick/UnboxedIntList;

    invoke-direct {v0, v2, v5}, Lcom/pkware/ahocorasick/AhoCorasickBase;->determineChildOffsets(ILcom/pkware/ahocorasick/UnboxedIntList;)Lcom/pkware/ahocorasick/UnboxedIntList;

    move-result-object v5

    .line 548
    .local v5, "encroachingChildren":Lcom/pkware/ahocorasick/UnboxedIntList;
    invoke-virtual {v5, v3}, Lcom/pkware/ahocorasick/UnboxedIntList;->add(I)V

    .line 550
    if-nez v3, :cond_0

    iget-object v6, v0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v6, v2}, Lcom/pkware/ahocorasick/AhoCorasickStore;->getBaseOffset(I)I

    move-result v6

    if-nez v6, :cond_0

    const/4 v6, 0x1

    goto :goto_0

    :cond_0
    const/4 v6, 0x0

    .line 557
    .local v6, "wouldMoveRoot":Z
    :goto_0
    invoke-virtual {v5}, Lcom/pkware/ahocorasick/UnboxedIntList;->getSize()I

    move-result v7

    invoke-virtual {v4}, Lcom/pkware/ahocorasick/UnboxedIntList;->getSize()I

    move-result v8

    if-le v7, v8, :cond_2

    if-eqz v6, :cond_1

    goto :goto_1

    .line 560
    :cond_1
    move v7, v1

    goto :goto_2

    .line 558
    :cond_2
    :goto_1
    move v7, v2

    .line 557
    :goto_2
    move v11, v7

    .line 563
    .local v11, "toMoveParent":I
    if-ne v11, v1, :cond_3

    move-object v7, v4

    goto :goto_3

    :cond_3
    move-object v7, v5

    .line 566
    .local v7, "toMoveChildren":Lcom/pkware/ahocorasick/UnboxedIntList;
    :goto_3
    invoke-direct {v0, v7}, Lcom/pkware/ahocorasick/AhoCorasickBase;->findOpenIndexes(Lcom/pkware/ahocorasick/UnboxedIntList;)I

    move-result v15

    .line 570
    .local v15, "postMoveBaseOffset":I
    if-ne v11, v1, :cond_4

    move-object v8, v5

    goto :goto_4

    :cond_4
    move-object v8, v4

    .line 575
    .local v8, "unusedStore":Lcom/pkware/ahocorasick/UnboxedIntList;
    :goto_4
    invoke-virtual {v5}, Lcom/pkware/ahocorasick/UnboxedIntList;->pop()I

    .line 577
    const/4 v9, 0x0

    .local v9, "childIndex":I
    invoke-virtual {v7}, Lcom/pkware/ahocorasick/UnboxedIntList;->getSize()I

    move-result v10

    :goto_5
    if-ge v9, v10, :cond_7

    .line 579
    invoke-virtual {v7, v9}, Lcom/pkware/ahocorasick/UnboxedIntList;->get(I)I

    move-result v16

    .line 580
    .local v16, "offset":I
    iget-object v13, v0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v13, v11}, Lcom/pkware/ahocorasick/AhoCorasickStore;->getBaseOffset(I)I

    move-result v13

    add-int v13, v13, v16

    .line 581
    .local v13, "previousChildIndex":I
    move v14, v9

    .end local v9    # "childIndex":I
    .local v14, "childIndex":I
    add-int v9, v15, v16

    .line 584
    .local v9, "newChildIndex":I
    invoke-direct {v0, v13, v8}, Lcom/pkware/ahocorasick/AhoCorasickBase;->determineChildOffsets(ILcom/pkware/ahocorasick/UnboxedIntList;)Lcom/pkware/ahocorasick/UnboxedIntList;

    move-result-object v3

    .line 585
    .local v3, "childChildren":Lcom/pkware/ahocorasick/UnboxedIntList;
    const/16 v17, 0x0

    .local v17, "childChildIndex":I
    invoke-virtual {v3}, Lcom/pkware/ahocorasick/UnboxedIntList;->getSize()I

    move-result v12

    move-object/from16 v19, v4

    move/from16 v4, v17

    .end local v17    # "childChildIndex":I
    .local v4, "childChildIndex":I
    .local v19, "originalChildren":Lcom/pkware/ahocorasick/UnboxedIntList;
    :goto_6
    if-ge v4, v12, :cond_5

    .line 586
    move-object/from16 v17, v5

    .end local v5    # "encroachingChildren":Lcom/pkware/ahocorasick/UnboxedIntList;
    .local v17, "encroachingChildren":Lcom/pkware/ahocorasick/UnboxedIntList;
    iget-object v5, v0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    move/from16 v20, v6

    .end local v6    # "wouldMoveRoot":Z
    .local v20, "wouldMoveRoot":Z
    iget-object v6, v0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v6, v13}, Lcom/pkware/ahocorasick/AhoCorasickStore;->getBaseOffset(I)I

    move-result v6

    invoke-virtual {v3, v4}, Lcom/pkware/ahocorasick/UnboxedIntList;->get(I)I

    move-result v21

    add-int v6, v6, v21

    invoke-virtual {v5, v6, v9}, Lcom/pkware/ahocorasick/AhoCorasickStore;->setParent(II)V

    .line 585
    add-int/lit8 v4, v4, 0x1

    move-object/from16 v5, v17

    move/from16 v6, v20

    goto :goto_6

    .end local v17    # "encroachingChildren":Lcom/pkware/ahocorasick/UnboxedIntList;
    .end local v20    # "wouldMoveRoot":Z
    .restart local v5    # "encroachingChildren":Lcom/pkware/ahocorasick/UnboxedIntList;
    .restart local v6    # "wouldMoveRoot":Z
    :cond_5
    move-object/from16 v17, v5

    move/from16 v20, v6

    .line 590
    .end local v4    # "childChildIndex":I
    .end local v5    # "encroachingChildren":Lcom/pkware/ahocorasick/UnboxedIntList;
    .end local v6    # "wouldMoveRoot":Z
    .restart local v17    # "encroachingChildren":Lcom/pkware/ahocorasick/UnboxedIntList;
    .restart local v20    # "wouldMoveRoot":Z
    move-object v4, v8

    .end local v8    # "unusedStore":Lcom/pkware/ahocorasick/UnboxedIntList;
    .local v4, "unusedStore":Lcom/pkware/ahocorasick/UnboxedIntList;
    iget-object v8, v0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    .line 591
    nop

    .line 592
    iget-object v5, v0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v5, v13}, Lcom/pkware/ahocorasick/AhoCorasickStore;->getBaseOffset(I)I

    move-result v5

    .line 593
    nop

    .line 594
    iget-object v6, v0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v6, v13}, Lcom/pkware/ahocorasick/AhoCorasickStore;->getValue(I)I

    move-result v12

    .line 595
    iget-object v6, v0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v6, v13}, Lcom/pkware/ahocorasick/AhoCorasickStore;->getNextSiblingOffset(I)I

    move-result v6

    .line 596
    move-object/from16 v21, v3

    .end local v3    # "childChildren":Lcom/pkware/ahocorasick/UnboxedIntList;
    .local v21, "childChildren":Lcom/pkware/ahocorasick/UnboxedIntList;
    iget-object v3, v0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v3, v13}, Lcom/pkware/ahocorasick/AhoCorasickStore;->getChildOffset(I)I

    move-result v3

    .line 590
    move/from16 v18, v13

    move v13, v6

    move/from16 v6, v18

    move/from16 v18, v10

    move v10, v5

    move v5, v14

    move v14, v3

    const/high16 v3, -0x80000000

    .end local v13    # "previousChildIndex":I
    .end local v14    # "childIndex":I
    .local v5, "childIndex":I
    .local v6, "previousChildIndex":I
    invoke-virtual/range {v8 .. v14}, Lcom/pkware/ahocorasick/AhoCorasickStore;->synchronizedSafeSet(IIIIII)V

    .line 600
    iget-object v8, v0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v8, v6, v3}, Lcom/pkware/ahocorasick/AhoCorasickStore;->setParent(II)V

    .line 601
    iget v3, v0, Lcom/pkware/ahocorasick/AhoCorasickBase;->singleChildCache:I

    if-ge v6, v3, :cond_6

    iget-object v3, v0, Lcom/pkware/ahocorasick/AhoCorasickBase;->indexCache:Lcom/pkware/ahocorasick/IndexCache;

    invoke-virtual {v3, v6}, Lcom/pkware/ahocorasick/IndexCache;->add(I)Z

    .line 577
    .end local v6    # "previousChildIndex":I
    .end local v9    # "newChildIndex":I
    .end local v16    # "offset":I
    .end local v21    # "childChildren":Lcom/pkware/ahocorasick/UnboxedIntList;
    :cond_6
    add-int/lit8 v9, v5, 0x1

    move/from16 v3, p3

    move-object v8, v4

    move-object/from16 v5, v17

    move/from16 v10, v18

    move-object/from16 v4, v19

    move/from16 v6, v20

    .end local v5    # "childIndex":I
    .local v9, "childIndex":I
    goto/16 :goto_5

    .end local v17    # "encroachingChildren":Lcom/pkware/ahocorasick/UnboxedIntList;
    .end local v19    # "originalChildren":Lcom/pkware/ahocorasick/UnboxedIntList;
    .end local v20    # "wouldMoveRoot":Z
    .local v4, "originalChildren":Lcom/pkware/ahocorasick/UnboxedIntList;
    .local v5, "encroachingChildren":Lcom/pkware/ahocorasick/UnboxedIntList;
    .local v6, "wouldMoveRoot":Z
    .restart local v8    # "unusedStore":Lcom/pkware/ahocorasick/UnboxedIntList;
    :cond_7
    move-object/from16 v19, v4

    move-object/from16 v17, v5

    move/from16 v20, v6

    move-object v4, v8

    move v5, v9

    const/high16 v3, -0x80000000

    .line 608
    .end local v5    # "encroachingChildren":Lcom/pkware/ahocorasick/UnboxedIntList;
    .end local v6    # "wouldMoveRoot":Z
    .end local v8    # "unusedStore":Lcom/pkware/ahocorasick/UnboxedIntList;
    .end local v9    # "childIndex":I
    .local v4, "unusedStore":Lcom/pkware/ahocorasick/UnboxedIntList;
    .restart local v17    # "encroachingChildren":Lcom/pkware/ahocorasick/UnboxedIntList;
    .restart local v19    # "originalChildren":Lcom/pkware/ahocorasick/UnboxedIntList;
    .restart local v20    # "wouldMoveRoot":Z
    const/4 v5, 0x0

    .line 609
    .local v5, "encroachingParentOffset":I
    iget-object v6, v0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v6, v2}, Lcom/pkware/ahocorasick/AhoCorasickStore;->getParent(I)I

    move-result v6

    if-ne v6, v3, :cond_8

    .line 610
    iget-object v3, v0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v3, v1}, Lcom/pkware/ahocorasick/AhoCorasickStore;->getBaseOffset(I)I

    move-result v3

    sub-int v5, v15, v3

    .line 613
    :cond_8
    iget-object v3, v0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v3, v11, v15}, Lcom/pkware/ahocorasick/AhoCorasickStore;->setBaseOffset(II)V

    .line 615
    add-int v3, v2, v5

    return v3
.end method

.method private final hasLeadingWhitespace(Lcom/pkware/ahocorasick/AhoCorasickResult;Ljava/lang/String;)Z
    .locals 3
    .param p1, "result"    # Lcom/pkware/ahocorasick/AhoCorasickResult;
    .param p2, "text"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/pkware/ahocorasick/AhoCorasickResult<",
            "TT;>;",
            "Ljava/lang/String;",
            ")Z"
        }
    .end annotation

    .line 461
    invoke-virtual {p1}, Lcom/pkware/ahocorasick/AhoCorasickResult;->getStart()I

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_1

    sget-object v0, Lcom/pkware/ahocorasick/AhoCorasickBase;->WHITESPACE_REGEX:Lkotlin/text/Regex;

    invoke-virtual {p1}, Lcom/pkware/ahocorasick/AhoCorasickResult;->getStart()I

    move-result v2

    sub-int/2addr v2, v1

    invoke-virtual {p2, v2}, Ljava/lang/String;->charAt(I)C

    move-result v2

    invoke-static {v2}, Ljava/lang/String;->valueOf(C)Ljava/lang/String;

    move-result-object v2

    check-cast v2, Ljava/lang/CharSequence;

    invoke-virtual {v0, v2}, Lkotlin/text/Regex;->matches(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :cond_1
    :goto_0
    return v1
.end method

.method private final hasTrailingWhitespace(Lcom/pkware/ahocorasick/AhoCorasickResult;Ljava/lang/String;)Z
    .locals 2
    .param p1, "result"    # Lcom/pkware/ahocorasick/AhoCorasickResult;
    .param p2, "text"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/pkware/ahocorasick/AhoCorasickResult<",
            "TT;>;",
            "Ljava/lang/String;",
            ")Z"
        }
    .end annotation

    .line 451
    invoke-virtual {p1}, Lcom/pkware/ahocorasick/AhoCorasickResult;->getEnd()I

    move-result v0

    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result v1

    if-eq v0, v1, :cond_1

    sget-object v0, Lcom/pkware/ahocorasick/AhoCorasickBase;->WHITESPACE_REGEX:Lkotlin/text/Regex;

    invoke-virtual {p1}, Lcom/pkware/ahocorasick/AhoCorasickResult;->getEnd()I

    move-result v1

    invoke-virtual {p2, v1}, Ljava/lang/String;->charAt(I)C

    move-result v1

    invoke-static {v1}, Ljava/lang/String;->valueOf(C)Ljava/lang/String;

    move-result-object v1

    check-cast v1, Ljava/lang/CharSequence;

    invoke-virtual {v0, v1}, Lkotlin/text/Regex;->matches(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v0, 0x1

    :goto_1
    return v0
.end method

.method private final normalize(C)C
    .locals 1
    .param p1, "$this$normalize"    # C

    .line 926
    iget-boolean v0, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->isCaseSensitive:Z

    if-eqz v0, :cond_0

    move v0, p1

    goto :goto_0

    :cond_0
    invoke-static {p1}, Ljava/lang/Character;->toLowerCase(C)C

    move-result v0

    :goto_0
    return v0
.end method

.method private final normalize(Ljava/lang/String;)Ljava/lang/String;
    .locals 4
    .param p1, "$this$normalize"    # Ljava/lang/String;

    .line 915
    iget-boolean v0, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->isCaseSensitive:Z

    if-eqz v0, :cond_0

    return-object p1

    .line 917
    :cond_0
    invoke-virtual {p1}, Ljava/lang/String;->toCharArray()[C

    move-result-object v0

    const-string v1, "toCharArray(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 918
    .local v0, "characters":[C
    const/4 v1, 0x0

    .local v1, "i":I
    array-length v2, v0

    :goto_0
    if-ge v1, v2, :cond_1

    aget-char v3, v0, v1

    invoke-static {v3}, Ljava/lang/Character;->toLowerCase(C)C

    move-result v3

    aput-char v3, v0, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 920
    .end local v1    # "i":I
    :cond_1
    new-instance v1, Ljava/lang/String;

    invoke-direct {v1, v0}, Ljava/lang/String;-><init>([C)V

    return-object v1
.end method

.method private final passesWhitespaceChecks(Lcom/pkware/ahocorasick/AhoCorasickResult;Ljava/lang/String;)Z
    .locals 1
    .param p1, "result"    # Lcom/pkware/ahocorasick/AhoCorasickResult;
    .param p2, "text"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/pkware/ahocorasick/AhoCorasickResult<",
            "TT;>;",
            "Ljava/lang/String;",
            ")Z"
        }
    .end annotation

    .line 441
    invoke-direct {p0, p1, p2}, Lcom/pkware/ahocorasick/AhoCorasickBase;->hasLeadingWhitespace(Lcom/pkware/ahocorasick/AhoCorasickResult;Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-direct {p0, p1, p2}, Lcom/pkware/ahocorasick/AhoCorasickBase;->hasTrailingWhitespace(Lcom/pkware/ahocorasick/AhoCorasickResult;Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method private final prepareChildrenForProcessing(ILcom/pkware/ahocorasick/AhoCorasickBase$IntReference;)V
    .locals 7
    .param p1, "parent"    # I
    .param p2, "lastQueuedNode"    # Lcom/pkware/ahocorasick/AhoCorasickBase$IntReference;

    .line 807
    iget-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->childrenOffsetStore1:Lcom/pkware/ahocorasick/UnboxedIntList;

    invoke-direct {p0, p1, v0}, Lcom/pkware/ahocorasick/AhoCorasickBase;->determineChildOffsets(ILcom/pkware/ahocorasick/UnboxedIntList;)Lcom/pkware/ahocorasick/UnboxedIntList;

    move-result-object v0

    .line 809
    .local v0, "rootChildOffsets":Lcom/pkware/ahocorasick/UnboxedIntList;
    const/4 v1, 0x0

    .local v1, "childIndex":I
    invoke-virtual {v0}, Lcom/pkware/ahocorasick/UnboxedIntList;->getSize()I

    move-result v2

    :goto_0
    const/high16 v3, -0x80000000

    if-ge v1, v2, :cond_1

    .line 811
    iget-object v4, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v4, p1}, Lcom/pkware/ahocorasick/AhoCorasickStore;->getBaseOffset(I)I

    move-result v4

    invoke-virtual {v0, v1}, Lcom/pkware/ahocorasick/UnboxedIntList;->get(I)I

    move-result v5

    add-int/2addr v4, v5

    .line 812
    .local v4, "child":I
    iget-object v5, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {p2}, Lcom/pkware/ahocorasick/AhoCorasickBase$IntReference;->getValue()I

    move-result v6

    invoke-virtual {v5, v6, v4}, Lcom/pkware/ahocorasick/AhoCorasickStore;->setQueueIndex(II)V

    .line 813
    invoke-virtual {p2, v4}, Lcom/pkware/ahocorasick/AhoCorasickBase$IntReference;->setValue(I)V

    .line 820
    iget-object v5, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v5, v4}, Lcom/pkware/ahocorasick/AhoCorasickStore;->getBaseOffset(I)I

    move-result v5

    if-ne v5, v3, :cond_0

    iget-object v3, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    const/4 v5, 0x0

    invoke-virtual {v3, v4, v5}, Lcom/pkware/ahocorasick/AhoCorasickStore;->setBaseOffset(II)V

    .line 809
    .end local v4    # "child":I
    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 824
    .end local v1    # "childIndex":I
    :cond_1
    iget-object v1, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {p2}, Lcom/pkware/ahocorasick/AhoCorasickBase$IntReference;->getValue()I

    move-result v2

    invoke-virtual {v1, v2, v3}, Lcom/pkware/ahocorasick/AhoCorasickStore;->setQueueIndex(II)V

    .line 825
    return-void
.end method

.method private final processRootChildren(Lcom/pkware/ahocorasick/AhoCorasickBase$IntReference;Lcom/pkware/ahocorasick/AhoCorasickBase$IntReference;)I
    .locals 6
    .param p1, "lastQueuedNode"    # Lcom/pkware/ahocorasick/AhoCorasickBase$IntReference;
    .param p2, "currentIndex"    # Lcom/pkware/ahocorasick/AhoCorasickBase$IntReference;

    .line 839
    const/4 v0, 0x0

    .line 841
    .local v0, "rootChildren":I
    :goto_0
    invoke-virtual {p2}, Lcom/pkware/ahocorasick/AhoCorasickBase$IntReference;->getValue()I

    move-result v1

    const/high16 v2, -0x80000000

    if-eq v1, v2, :cond_0

    iget-object v1, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {p2}, Lcom/pkware/ahocorasick/AhoCorasickBase$IntReference;->getValue()I

    move-result v3

    invoke-virtual {v1, v3}, Lcom/pkware/ahocorasick/AhoCorasickStore;->getParent(I)I

    move-result v1

    if-nez v1, :cond_0

    .line 843
    invoke-virtual {p2}, Lcom/pkware/ahocorasick/AhoCorasickBase$IntReference;->getValue()I

    move-result v1

    invoke-direct {p0, v1, p1}, Lcom/pkware/ahocorasick/AhoCorasickBase;->prepareChildrenForProcessing(ILcom/pkware/ahocorasick/AhoCorasickBase$IntReference;)V

    .line 844
    iget-object v1, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {p2}, Lcom/pkware/ahocorasick/AhoCorasickBase$IntReference;->getValue()I

    move-result v3

    invoke-virtual {v1, v3}, Lcom/pkware/ahocorasick/AhoCorasickStore;->getQueueIndex(I)I

    move-result v1

    .line 845
    .local v1, "nextIndex":I
    iget-object v3, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {p2}, Lcom/pkware/ahocorasick/AhoCorasickBase$IntReference;->getValue()I

    move-result v4

    const/4 v5, 0x0

    invoke-virtual {v3, v4, v5}, Lcom/pkware/ahocorasick/AhoCorasickStore;->setFailureIndex(II)V

    .line 846
    iget-object v3, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {p2}, Lcom/pkware/ahocorasick/AhoCorasickBase$IntReference;->getValue()I

    move-result v4

    invoke-virtual {v3, v4, v2}, Lcom/pkware/ahocorasick/AhoCorasickStore;->setPrefixIndex(II)V

    .line 847
    invoke-virtual {p2, v1}, Lcom/pkware/ahocorasick/AhoCorasickBase$IntReference;->setValue(I)V

    .line 848
    nop

    .end local v1    # "nextIndex":I
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 851
    :cond_0
    return v0
.end method


# virtual methods
.method protected final declared-synchronized addEntry(Ljava/lang/String;I)V
    .locals 9
    .param p1, "key"    # Ljava/lang/String;
    .param p2, "value"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalArgumentException;,
            Ljava/lang/IllegalStateException;
        }
    .end annotation

    monitor-enter p0

    :try_start_0
    const-string v0, "key"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 279
    iget-boolean v0, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->isBuilt:Z

    if-nez v0, :cond_6

    .line 280
    move-object v0, p1

    check-cast v0, Ljava/lang/CharSequence;

    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    move-result v0

    const/4 v1, 0x0

    if-lez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    move v0, v1

    :goto_0
    if-eqz v0, :cond_5

    .line 282
    invoke-direct {p0, p1}, Lcom/pkware/ahocorasick/AhoCorasickBase;->normalize(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 284
    .local v0, "normalizedKey":Ljava/lang/String;
    const/4 v2, 0x0

    .line 287
    .local v2, "currentNode":I
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v3

    :goto_1
    if-ge v1, v3, :cond_4

    invoke-virtual {v0, v1}, Ljava/lang/String;->charAt(I)C

    move-result v4

    .line 289
    .local v4, "character":C
    move v5, v4

    .line 292
    .local v5, "characterOffset":I
    iget-object v6, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v6, v2}, Lcom/pkware/ahocorasick/AhoCorasickStore;->getBaseOffset(I)I

    move-result v6

    const/high16 v7, -0x80000000

    if-ne v6, v7, :cond_1

    .line 293
    iget-object v6, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-direct {p0, v5}, Lcom/pkware/ahocorasick/AhoCorasickBase;->findOpenIndex(I)I

    move-result v8

    sub-int/2addr v8, v5

    invoke-virtual {v6, v2, v8}, Lcom/pkware/ahocorasick/AhoCorasickStore;->setBaseOffset(II)V

    .line 296
    .end local p0    # "this":Lcom/pkware/ahocorasick/AhoCorasickBase;
    :cond_1
    iget-object v6, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v6, v2}, Lcom/pkware/ahocorasick/AhoCorasickStore;->getBaseOffset(I)I

    move-result v6

    add-int/2addr v6, v5

    .line 297
    .local v6, "nextNode":I
    iget-object v8, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v8, v6}, Lcom/pkware/ahocorasick/AhoCorasickStore;->safeGetParent(I)I

    move-result v8

    .line 301
    .local v8, "nextParentValue":I
    if-eq v8, v2, :cond_3

    .line 305
    if-eq v8, v7, :cond_2

    .line 306
    invoke-direct {p0, v8, v2, v5}, Lcom/pkware/ahocorasick/AhoCorasickBase;->handleBaseOffsetConflict(III)I

    move-result v7

    .line 307
    .end local v2    # "currentNode":I
    .local v7, "currentNode":I
    iget-object v2, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v2, v7}, Lcom/pkware/ahocorasick/AhoCorasickStore;->getBaseOffset(I)I

    move-result v2

    add-int/2addr v2, v5

    move v6, v2

    move v2, v7

    .line 310
    .end local v7    # "currentNode":I
    .restart local v2    # "currentNode":I
    :cond_2
    invoke-direct {p0, v6, v2}, Lcom/pkware/ahocorasick/AhoCorasickBase;->addNode(II)V

    .line 313
    :cond_3
    move v2, v6

    .line 287
    .end local v4    # "character":C
    .end local v5    # "characterOffset":I
    .end local v6    # "nextNode":I
    .end local v8    # "nextParentValue":I
    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    .line 316
    :cond_4
    iget-object v1, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v1, v2, p2}, Lcom/pkware/ahocorasick/AhoCorasickStore;->setValue(II)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 317
    monitor-exit p0

    return-void

    .line 947
    .end local v0    # "normalizedKey":Ljava/lang/String;
    .end local v2    # "currentNode":I
    :cond_5
    const/4 v0, 0x0

    .line 280
    .local v0, "$i$a$-require-AhoCorasickBase$addEntry$2":I
    :try_start_1
    const-string v1, "Key can not be empty!"

    .end local v0    # "$i$a$-require-AhoCorasickBase$addEntry$2":I
    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 947
    :cond_6
    const/4 v0, 0x0

    .line 279
    .local v0, "$i$a$-check-AhoCorasickBase$addEntry$1":I
    const-string v1, "Can\'t add entries after `build` has been called!"

    .end local v0    # "$i$a$-check-AhoCorasickBase$addEntry$1":I
    new-instance v0, Ljava/lang/IllegalStateException;

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 278
    .end local p1    # "key":Ljava/lang/String;
    .end local p2    # "value":I
    :catchall_0
    move-exception p1

    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method

.method public final declared-synchronized build()V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalStateException;
        }
    .end annotation

    monitor-enter p0

    .line 188
    :try_start_0
    iget-boolean v0, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->isBuilt:Z

    if-nez v0, :cond_0

    .line 190
    iget-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v0}, Lcom/pkware/ahocorasick/AhoCorasickStore;->buildRuntimeStructures()V

    .line 191
    invoke-direct {p0}, Lcom/pkware/ahocorasick/AhoCorasickBase;->constructFailStates()V

    .line 192
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->isBuilt:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 193
    monitor-exit p0

    return-void

    .line 947
    .end local p0    # "this":Lcom/pkware/ahocorasick/AhoCorasickBase;
    :cond_0
    const/4 v0, 0x0

    .line 188
    .local v0, "$i$a$-check-AhoCorasickBase$build$1":I
    :try_start_1
    const-string v1, "PkAhoCorasick can only be built once!"

    .end local v0    # "$i$a$-check-AhoCorasickBase$build$1":I
    new-instance v0, Ljava/lang/IllegalStateException;

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 187
    :catchall_0
    move-exception v0

    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method

.method public final contains(Ljava/lang/String;)Z
    .locals 2
    .param p1, "entry"    # Ljava/lang/String;

    const-string v0, "entry"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 231
    invoke-virtual {p0, p1}, Lcom/pkware/ahocorasick/AhoCorasickBase;->keyValue(Ljava/lang/String;)I

    move-result v0

    const/high16 v1, -0x80000000

    if-eq v0, v1, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method protected abstract generateResult(IILjava/lang/String;)Lcom/pkware/ahocorasick/AhoCorasickResult;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(II",
            "Ljava/lang/String;",
            ")",
            "Lcom/pkware/ahocorasick/AhoCorasickResult<",
            "TT;>;"
        }
    .end annotation
.end method

.method public final getFindOnlyWholeWords()Z
    .locals 1

    .line 77
    iget-boolean v0, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->findOnlyWholeWords:Z

    return v0
.end method

.method public final getNodes()I
    .locals 1

    .line 121
    iget v0, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->nodes:I

    return v0
.end method

.method public final isBuilt()Z
    .locals 1

    .line 105
    iget-boolean v0, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->isBuilt:Z

    return v0
.end method

.method public final isCaseSensitive()Z
    .locals 1

    .line 69
    iget-boolean v0, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->isCaseSensitive:Z

    return v0
.end method

.method protected final keyValue(Ljava/lang/String;)I
    .locals 7
    .param p1, "key"    # Ljava/lang/String;

    const-string v0, "key"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 241
    invoke-direct {p0, p1}, Lcom/pkware/ahocorasick/AhoCorasickBase;->normalize(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 243
    .local v0, "normalizedKey":Ljava/lang/String;
    const/4 v1, 0x0

    .line 244
    .local v1, "currentNode":I
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v2

    const/4 v3, 0x0

    :goto_0
    if-ge v3, v2, :cond_1

    invoke-virtual {v0, v3}, Ljava/lang/String;->charAt(I)C

    move-result v4

    .line 246
    .local v4, "character":C
    iget-object v5, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v5, v1}, Lcom/pkware/ahocorasick/AhoCorasickStore;->getBaseOffset(I)I

    move-result v5

    add-int/2addr v5, v4

    .line 247
    .local v5, "nextNode":I
    iget-object v6, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v6, v5}, Lcom/pkware/ahocorasick/AhoCorasickStore;->safeGetParent(I)I

    move-result v6

    if-eq v6, v1, :cond_0

    const/high16 v2, -0x80000000

    return v2

    .line 248
    :cond_0
    move v1, v5

    .line 244
    .end local v4    # "character":C
    .end local v5    # "nextNode":I
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    .line 251
    :cond_1
    iget-object v2, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v2, v1}, Lcom/pkware/ahocorasick/AhoCorasickStore;->getValue(I)I

    move-result v2

    return v2
.end method

.method public final parse(Ljava/lang/String;)Ljava/util/stream/Stream;
    .locals 2
    .param p1, "input"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/stream/Stream<",
            "Lcom/pkware/ahocorasick/AhoCorasickResult<",
            "TT;>;>;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalStateException;
        }
    .end annotation

    const-string v0, "input"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 220
    iget-boolean v0, p0, Lcom/pkware/ahocorasick/AhoCorasickBase;->isBuilt:Z

    if-eqz v0, :cond_0

    .line 222
    new-instance v0, Lcom/pkware/ahocorasick/AhoCorasickBase$AhoCorasickSpliterator;

    invoke-direct {v0, p0, p1}, Lcom/pkware/ahocorasick/AhoCorasickBase$AhoCorasickSpliterator;-><init>(Lcom/pkware/ahocorasick/AhoCorasickBase;Ljava/lang/String;)V

    check-cast v0, Ljava/util/Spliterator;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Ljava/util/stream/StreamSupport;->stream(Ljava/util/Spliterator;Z)Ljava/util/stream/Stream;

    move-result-object v0

    const-string v1, "stream(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v0

    .line 947
    :cond_0
    const/4 v0, 0x0

    .line 220
    .local v0, "$i$a$-check-AhoCorasickBase$parse$1":I
    nop

    .end local v0    # "$i$a$-check-AhoCorasickBase$parse$1":I
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "\'build\' must be called before parsing text!"

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method
