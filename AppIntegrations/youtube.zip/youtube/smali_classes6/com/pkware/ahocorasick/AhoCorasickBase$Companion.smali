.class final Lcom/pkware/ahocorasick/AhoCorasickBase$Companion;
.super Ljava/lang/Object;
.source "AhoCorasickBase.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/pkware/ahocorasick/AhoCorasickBase;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "Companion"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0002\n\u0002\u0010\u0008\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\u0008\u0082\u0003\u0018\u00002\u00020\u0001B\u0007\u0008\u0002\u00a2\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u0011\u0010\u0005\u001a\u00020\u0006\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0007\u0010\u0008\u00a8\u0006\t"
    }
    d2 = {
        "Lcom/pkware/ahocorasick/AhoCorasickBase$Companion;",
        "",
        "()V",
        "ROOT_NODE",
        "",
        "WHITESPACE_REGEX",
        "Lkotlin/text/Regex;",
        "getWHITESPACE_REGEX",
        "()Lkotlin/text/Regex;",
        "LowMemoryAhoCorasick"
    }
    k = 0x1
    mv = {
        0x1,
        0x9,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 928
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    invoke-direct {p0}, Lcom/pkware/ahocorasick/AhoCorasickBase$Companion;-><init>()V

    return-void
.end method


# virtual methods
.method public final getWHITESPACE_REGEX()Lkotlin/text/Regex;
    .locals 1

    .line 938
    # getter for: Lcom/pkware/ahocorasick/AhoCorasickBase;->WHITESPACE_REGEX:Lkotlin/text/Regex;
    invoke-static {}, Lcom/pkware/ahocorasick/AhoCorasickBase;->access$getWHITESPACE_REGEX$cp()Lkotlin/text/Regex;

    move-result-object v0

    return-object v0
.end method
