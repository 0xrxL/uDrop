.class public final Lcom/pkware/ahocorasick/IndexCache;
.super Ljava/lang/Object;
.source "IndexCache.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/pkware/ahocorasick/IndexCache$Companion;
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0008\n\u0002\u0008\u0003\n\u0002\u0010\u0015\n\u0002\u0008\u0008\n\u0002\u0010\u000b\n\u0002\u0008\t\n\u0002\u0010\u0002\n\u0002\u0008\u0007\u0008\u0000\u0018\u0000 \"2\u00020\u0001:\u0001\"B!\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0008\u0008\u0002\u0010\u0004\u001a\u00020\u0005\u0012\u0008\u0008\u0002\u0010\u0006\u001a\u00020\u0005\u00a2\u0006\u0002\u0010\u0007J\u000e\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u0005J\u0010\u0010\u0014\u001a\u00020\u00052\u0006\u0010\u0015\u001a\u00020\u0005H\u0002J\u0010\u0010\u0016\u001a\u00020\u00052\u0006\u0010\u0015\u001a\u00020\u0005H\u0002J\u0010\u0010\u0017\u001a\u00020\u00052\u0006\u0010\u0015\u001a\u00020\u0005H\u0002J\u0010\u0010\u0018\u001a\u00020\u00052\u0006\u0010\u0015\u001a\u00020\u0005H\u0002J\u000e\u0010\u0019\u001a\u00020\u00052\u0006\u0010\u001a\u001a\u00020\u0005J\u0010\u0010\u001b\u001a\u00020\u001c2\u0006\u0010\u0015\u001a\u00020\u0005H\u0002J\u0010\u0010\u001d\u001a\u00020\u001c2\u0006\u0010\u0015\u001a\u00020\u0005H\u0002J\u0018\u0010\u001e\u001a\u00020\u001c2\u0006\u0010\u0015\u001a\u00020\u00052\u0006\u0010\u001f\u001a\u00020\u0005H\u0002J\u0018\u0010 \u001a\u00020\u001c2\u0006\u0010\u0015\u001a\u00020\u00052\u0006\u0010\u001f\u001a\u00020\u0005H\u0002J\u0018\u0010!\u001a\u00020\u001c2\u0006\u0010\u0015\u001a\u00020\u00052\u0006\u0010\u001f\u001a\u00020\u0005H\u0002R\u000e\u0010\u0008\u001a\u00020\tX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0005X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0011\u0010\u000b\u001a\u00020\u00058F\u00a2\u0006\u0006\u001a\u0004\u0008\u000c\u0010\rR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u0005X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0005X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\tX\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006#"
    }
    d2 = {
        "Lcom/pkware/ahocorasick/IndexCache;",
        "",
        "store",
        "Lcom/pkware/ahocorasick/AhoCorasickStore;",
        "maxSize",
        "",
        "failureTolerance",
        "(Lcom/pkware/ahocorasick/AhoCorasickStore;II)V",
        "cacheData",
        "",
        "head",
        "size",
        "getSize",
        "()I",
        "tail",
        "unusedCacheSize",
        "unusedQueue",
        "add",
        "",
        "index",
        "getNextIndex",
        "nodeIndex",
        "getPreviousIndex",
        "getValue",
        "incrementMisses",
        "popIndex",
        "offset",
        "removeNode",
        "",
        "resetMisses",
        "setNextIndex",
        "value",
        "setPreviousIndex",
        "setValue",
        "Companion",
        "LowMemoryAhoCorasick"
    }
    k = 0x1
    mv = {
        0x1,
        0x9,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field private static final Companion:Lcom/pkware/ahocorasick/IndexCache$Companion;

.field public static final MISSES_OFFSET:I = 0x2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final NULL_ENTRY:I = -0x80000000
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final PREVIOUS_OFFSET:I = 0x1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final VALUES_PER_NODE:I = 0x4
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final VALUE_OFFSET:I = 0x3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field


# instance fields
.field private final cacheData:[I

.field private final failureTolerance:I

.field private head:I

.field private final maxSize:I

.field private final store:Lcom/pkware/ahocorasick/AhoCorasickStore;

.field private tail:I

.field private unusedCacheSize:I

.field private final unusedQueue:[I


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Lcom/pkware/ahocorasick/IndexCache$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/pkware/ahocorasick/IndexCache$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lcom/pkware/ahocorasick/IndexCache;->Companion:Lcom/pkware/ahocorasick/IndexCache$Companion;

    return-void
.end method

.method public constructor <init>(Lcom/pkware/ahocorasick/AhoCorasickStore;II)V
    .locals 4
    .param p1, "store"    # Lcom/pkware/ahocorasick/AhoCorasickStore;
    .param p2, "maxSize"    # I
    .param p3, "failureTolerance"    # I

    const-string v0, "store"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 24
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 25
    iput-object p1, p0, Lcom/pkware/ahocorasick/IndexCache;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    .line 26
    iput p2, p0, Lcom/pkware/ahocorasick/IndexCache;->maxSize:I

    .line 27
    iput p3, p0, Lcom/pkware/ahocorasick/IndexCache;->failureTolerance:I

    .line 38
    iget v0, p0, Lcom/pkware/ahocorasick/IndexCache;->maxSize:I

    mul-int/lit8 v0, v0, 0x4

    new-array v0, v0, [I

    iput-object v0, p0, Lcom/pkware/ahocorasick/IndexCache;->cacheData:[I

    .line 47
    iget v0, p0, Lcom/pkware/ahocorasick/IndexCache;->maxSize:I

    new-array v1, v0, [I

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v0, :cond_0

    mul-int/lit8 v3, v2, 0x4

    aput v3, v1, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    iput-object v1, p0, Lcom/pkware/ahocorasick/IndexCache;->unusedQueue:[I

    .line 52
    iget v0, p0, Lcom/pkware/ahocorasick/IndexCache;->maxSize:I

    iput v0, p0, Lcom/pkware/ahocorasick/IndexCache;->unusedCacheSize:I

    .line 57
    const/high16 v0, -0x80000000

    iput v0, p0, Lcom/pkware/ahocorasick/IndexCache;->head:I

    .line 64
    iput v0, p0, Lcom/pkware/ahocorasick/IndexCache;->tail:I

    .line 24
    return-void
.end method

.method public synthetic constructor <init>(Lcom/pkware/ahocorasick/AhoCorasickStore;IIILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    .line 24
    and-int/lit8 p5, p4, 0x2

    if-eqz p5, :cond_0

    .line 26
    const/16 p2, 0x80

    .line 24
    :cond_0
    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_1

    .line 27
    const/16 p3, 0xa

    .line 24
    :cond_1
    invoke-direct {p0, p1, p2, p3}, Lcom/pkware/ahocorasick/IndexCache;-><init>(Lcom/pkware/ahocorasick/AhoCorasickStore;II)V

    .line 226
    return-void
.end method

.method private final getNextIndex(I)I
    .locals 1
    .param p1, "nodeIndex"    # I

    .line 161
    iget-object v0, p0, Lcom/pkware/ahocorasick/IndexCache;->cacheData:[I

    aget v0, v0, p1

    return v0
.end method

.method private final getPreviousIndex(I)I
    .locals 2
    .param p1, "nodeIndex"    # I

    .line 156
    iget-object v0, p0, Lcom/pkware/ahocorasick/IndexCache;->cacheData:[I

    add-int/lit8 v1, p1, 0x1

    aget v0, v0, v1

    return v0
.end method

.method private final getValue(I)I
    .locals 2
    .param p1, "nodeIndex"    # I

    .line 166
    iget-object v0, p0, Lcom/pkware/ahocorasick/IndexCache;->cacheData:[I

    add-int/lit8 v1, p1, 0x3

    aget v0, v0, v1

    return v0
.end method

.method private final incrementMisses(I)I
    .locals 3
    .param p1, "nodeIndex"    # I

    .line 197
    iget-object v0, p0, Lcom/pkware/ahocorasick/IndexCache;->cacheData:[I

    add-int/lit8 v1, p1, 0x2

    aget v2, v0, v1

    add-int/lit8 v2, v2, 0x1

    aput v2, v0, v1

    aget v0, v0, v1

    return v0
.end method

.method private final removeNode(I)V
    .locals 5
    .param p1, "nodeIndex"    # I

    .line 141
    invoke-direct {p0, p1}, Lcom/pkware/ahocorasick/IndexCache;->getNextIndex(I)I

    move-result v0

    .line 142
    .local v0, "nextNodeIndex":I
    invoke-direct {p0, p1}, Lcom/pkware/ahocorasick/IndexCache;->getPreviousIndex(I)I

    move-result v1

    .line 144
    .local v1, "previousNodeIndex":I
    iget v2, p0, Lcom/pkware/ahocorasick/IndexCache;->head:I

    invoke-direct {p0, v2}, Lcom/pkware/ahocorasick/IndexCache;->getNextIndex(I)I

    move-result v2

    if-ne v2, v0, :cond_0

    iput v0, p0, Lcom/pkware/ahocorasick/IndexCache;->head:I

    .line 145
    :cond_0
    iget v2, p0, Lcom/pkware/ahocorasick/IndexCache;->tail:I

    invoke-direct {p0, v2}, Lcom/pkware/ahocorasick/IndexCache;->getPreviousIndex(I)I

    move-result v2

    if-ne v2, v1, :cond_1

    iput v1, p0, Lcom/pkware/ahocorasick/IndexCache;->tail:I

    .line 147
    :cond_1
    const/high16 v2, -0x80000000

    if-eq v1, v2, :cond_2

    invoke-direct {p0, v1, v0}, Lcom/pkware/ahocorasick/IndexCache;->setNextIndex(II)V

    .line 148
    :cond_2
    if-eq v0, v2, :cond_3

    invoke-direct {p0, v0, v1}, Lcom/pkware/ahocorasick/IndexCache;->setPreviousIndex(II)V

    .line 150
    :cond_3
    iget-object v2, p0, Lcom/pkware/ahocorasick/IndexCache;->unusedQueue:[I

    iget v3, p0, Lcom/pkware/ahocorasick/IndexCache;->unusedCacheSize:I

    add-int/lit8 v4, v3, 0x1

    iput v4, p0, Lcom/pkware/ahocorasick/IndexCache;->unusedCacheSize:I

    aput p1, v2, v3

    .line 151
    return-void
.end method

.method private final resetMisses(I)V
    .locals 3
    .param p1, "nodeIndex"    # I

    .line 190
    iget-object v0, p0, Lcom/pkware/ahocorasick/IndexCache;->cacheData:[I

    add-int/lit8 v1, p1, 0x2

    const/4 v2, 0x0

    aput v2, v0, v1

    return-void
.end method

.method private final setNextIndex(II)V
    .locals 1
    .param p1, "nodeIndex"    # I
    .param p2, "value"    # I

    .line 180
    iget-object v0, p0, Lcom/pkware/ahocorasick/IndexCache;->cacheData:[I

    aput p2, v0, p1

    return-void
.end method

.method private final setPreviousIndex(II)V
    .locals 2
    .param p1, "nodeIndex"    # I
    .param p2, "value"    # I

    .line 173
    iget-object v0, p0, Lcom/pkware/ahocorasick/IndexCache;->cacheData:[I

    add-int/lit8 v1, p1, 0x1

    aput p2, v0, v1

    return-void
.end method

.method private final setValue(II)V
    .locals 2
    .param p1, "nodeIndex"    # I
    .param p2, "value"    # I

    .line 185
    iget-object v0, p0, Lcom/pkware/ahocorasick/IndexCache;->cacheData:[I

    add-int/lit8 v1, p1, 0x3

    aput p2, v0, v1

    return-void
.end method


# virtual methods
.method public final add(I)Z
    .locals 4
    .param p1, "index"    # I

    .line 79
    iget v0, p0, Lcom/pkware/ahocorasick/IndexCache;->unusedCacheSize:I

    if-nez v0, :cond_0

    const/4 v0, 0x0

    return v0

    .line 81
    :cond_0
    iget-object v0, p0, Lcom/pkware/ahocorasick/IndexCache;->unusedQueue:[I

    iget v1, p0, Lcom/pkware/ahocorasick/IndexCache;->unusedCacheSize:I

    add-int/lit8 v1, v1, -0x1

    iput v1, p0, Lcom/pkware/ahocorasick/IndexCache;->unusedCacheSize:I

    iget v1, p0, Lcom/pkware/ahocorasick/IndexCache;->unusedCacheSize:I

    aget v0, v0, v1

    .line 83
    .local v0, "newIndex":I
    invoke-direct {p0, v0, p1}, Lcom/pkware/ahocorasick/IndexCache;->setValue(II)V

    .line 84
    invoke-direct {p0, v0}, Lcom/pkware/ahocorasick/IndexCache;->resetMisses(I)V

    .line 86
    invoke-virtual {p0}, Lcom/pkware/ahocorasick/IndexCache;->getSize()I

    move-result v1

    const/high16 v2, -0x80000000

    const/4 v3, 0x1

    if-ne v1, v3, :cond_1

    .line 87
    iput v0, p0, Lcom/pkware/ahocorasick/IndexCache;->head:I

    .line 88
    invoke-direct {p0, v0, v2}, Lcom/pkware/ahocorasick/IndexCache;->setPreviousIndex(II)V

    goto :goto_0

    .line 90
    :cond_1
    iget v1, p0, Lcom/pkware/ahocorasick/IndexCache;->tail:I

    invoke-direct {p0, v0, v1}, Lcom/pkware/ahocorasick/IndexCache;->setPreviousIndex(II)V

    .line 91
    iget v1, p0, Lcom/pkware/ahocorasick/IndexCache;->tail:I

    invoke-direct {p0, v1, v0}, Lcom/pkware/ahocorasick/IndexCache;->setNextIndex(II)V

    .line 94
    :goto_0
    invoke-direct {p0, v0, v2}, Lcom/pkware/ahocorasick/IndexCache;->setNextIndex(II)V

    .line 95
    iput v0, p0, Lcom/pkware/ahocorasick/IndexCache;->tail:I

    .line 96
    return v3
.end method

.method public final getSize()I
    .locals 2

    .line 69
    iget v0, p0, Lcom/pkware/ahocorasick/IndexCache;->maxSize:I

    iget v1, p0, Lcom/pkware/ahocorasick/IndexCache;->unusedCacheSize:I

    sub-int/2addr v0, v1

    return v0
.end method

.method public final popIndex(I)I
    .locals 4
    .param p1, "offset"    # I

    .line 111
    iget v0, p0, Lcom/pkware/ahocorasick/IndexCache;->head:I

    .line 112
    .local v0, "currentNodeIndex":I
    :goto_0
    const/high16 v1, -0x80000000

    if-eq v0, v1, :cond_3

    .line 114
    invoke-direct {p0, v0}, Lcom/pkware/ahocorasick/IndexCache;->getValue(I)I

    move-result v2

    .line 116
    .local v2, "nodeValue":I
    iget-object v3, p0, Lcom/pkware/ahocorasick/IndexCache;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;

    invoke-virtual {v3, v2}, Lcom/pkware/ahocorasick/AhoCorasickStore;->getParent(I)I

    move-result v3

    if-eq v3, v1, :cond_0

    .line 117
    invoke-direct {p0, v0}, Lcom/pkware/ahocorasick/IndexCache;->removeNode(I)V

    goto :goto_1

    .line 118
    :cond_0
    if-lt v2, p1, :cond_1

    .line 119
    invoke-direct {p0, v0}, Lcom/pkware/ahocorasick/IndexCache;->removeNode(I)V

    .line 120
    return v2

    .line 121
    :cond_1
    invoke-direct {p0, v0}, Lcom/pkware/ahocorasick/IndexCache;->incrementMisses(I)I

    move-result v1

    iget v3, p0, Lcom/pkware/ahocorasick/IndexCache;->failureTolerance:I

    if-ne v1, v3, :cond_2

    .line 123
    invoke-direct {p0, v0}, Lcom/pkware/ahocorasick/IndexCache;->removeNode(I)V

    .line 126
    :cond_2
    :goto_1
    invoke-direct {p0, v0}, Lcom/pkware/ahocorasick/IndexCache;->getNextIndex(I)I

    move-result v0

    .end local v2    # "nodeValue":I
    goto :goto_0

    .line 129
    :cond_3
    const/4 v1, 0x0

    return v1
.end method
