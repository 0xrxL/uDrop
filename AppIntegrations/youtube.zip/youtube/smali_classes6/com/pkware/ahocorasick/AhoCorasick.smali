.class public Lcom/pkware/ahocorasick/AhoCorasick;
.super Lcom/pkware/ahocorasick/AhoCorasickBase;
.source "AhoCorasick.kt"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lcom/pkware/ahocorasick/AhoCorasickBase<",
        "TT;>;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nAhoCorasick.kt\nKotlin\n*S Kotlin\n*F\n+ 1 AhoCorasick.kt\ncom/pkware/ahocorasick/AhoCorasick\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,108:1\n1#2:109\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000L\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\"\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0008\n\u0002\u0008\u0002\n\u0002\u0010\u000b\n\u0002\u0008\u0005\u0008\u0016\u0018\u0000*\u0004\u0008\u0000\u0010\u00012\u0008\u0012\u0004\u0012\u0002H\u00010\u0002B\u0017\u0008\u0007\u0012\u000e\u0008\u0002\u0010\u0003\u001a\u0008\u0012\u0004\u0012\u00020\u00050\u0004\u00a2\u0006\u0002\u0010\u0006J\u001b\u0010\u000c\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00028\u0000\u00a2\u0006\u0002\u0010\u0011J&\u0010\u0012\u001a\u0008\u0012\u0004\u0012\u00028\u00000\u00132\u0006\u0010\u0014\u001a\u00020\u00152\u0006\u0010\u0010\u001a\u00020\u00152\u0006\u0010\u0016\u001a\u00020\u000fH\u0014J%\u0010\u0017\u001a\u00020\u00182\u0006\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00028\u00002\u0008\u0008\u0002\u0010\u0019\u001a\u00020\u0018\u00a2\u0006\u0002\u0010\u001aJ\u0015\u0010\u001b\u001a\u0004\u0018\u00018\u00002\u0006\u0010\u000e\u001a\u00020\u000f\u00a2\u0006\u0002\u0010\u001cR\u000e\u0010\u0007\u001a\u00020\u0008X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001e\u0010\t\u001a\u0012\u0012\u0004\u0012\u00028\u00000\nj\u0008\u0012\u0004\u0012\u00028\u0000`\u000bX\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u001d"
    }
    d2 = {
        "Lcom/pkware/ahocorasick/AhoCorasick;",
        "T",
        "Lcom/pkware/ahocorasick/AhoCorasickBase;",
        "options",
        "",
        "Lcom/pkware/ahocorasick/AhoCorasickOption;",
        "(Ljava/util/Set;)V",
        "keyLengths",
        "Lcom/pkware/ahocorasick/UnboxedIntList;",
        "storedValues",
        "Ljava/util/ArrayList;",
        "Lkotlin/collections/ArrayList;",
        "add",
        "",
        "key",
        "",
        "value",
        "(Ljava/lang/String;Ljava/lang/Object;)V",
        "generateResult",
        "Lcom/pkware/ahocorasick/AhoCorasickResult;",
        "index",
        "",
        "input",
        "replace",
        "",
        "insertOnFail",
        "(Ljava/lang/String;Ljava/lang/Object;Z)Z",
        "valueOf",
        "(Ljava/lang/String;)Ljava/lang/Object;",
        "LowMemoryAhoCorasick"
    }
    k = 0x1
    mv = {
        0x1,
        0x9,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final keyLengths:Lcom/pkware/ahocorasick/UnboxedIntList;

.field private final storedValues:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "TT;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-direct {p0, v0, v1, v0}, Lcom/pkware/ahocorasick/AhoCorasick;-><init>(Ljava/util/Set;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    return-void
.end method

.method public constructor <init>(Ljava/util/Set;)V
    .locals 8
    .param p1, "options"    # Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Set<",
            "+",
            "Lcom/pkware/ahocorasick/AhoCorasickOption;",
            ">;)V"
        }
    .end annotation

    const-string v0, "options"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 20
    invoke-direct {p0, p1}, Lcom/pkware/ahocorasick/AhoCorasickBase;-><init>(Ljava/util/Set;)V

    .line 30
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasick;->storedValues:Ljava/util/ArrayList;

    .line 40
    new-instance v1, Lcom/pkware/ahocorasick/UnboxedIntList;

    const/4 v6, 0x5

    const/4 v7, 0x0

    const/4 v2, 0x0

    const-wide/high16 v3, 0x3ff4000000000000L    # 1.25

    const/4 v5, 0x0

    invoke-direct/range {v1 .. v7}, Lcom/pkware/ahocorasick/UnboxedIntList;-><init>(IDIILkotlin/jvm/internal/DefaultConstructorMarker;)V

    iput-object v1, p0, Lcom/pkware/ahocorasick/AhoCorasick;->keyLengths:Lcom/pkware/ahocorasick/UnboxedIntList;

    .line 19
    return-void
.end method

.method public synthetic constructor <init>(Ljava/util/Set;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    .line 19
    and-int/lit8 p2, p2, 0x1

    if-eqz p2, :cond_0

    invoke-static {}, Lkotlin/collections/SetsKt;->emptySet()Ljava/util/Set;

    move-result-object p1

    :cond_0
    invoke-direct {p0, p1}, Lcom/pkware/ahocorasick/AhoCorasick;-><init>(Ljava/util/Set;)V

    .line 107
    return-void
.end method

.method public static synthetic replace$default(Lcom/pkware/ahocorasick/AhoCorasick;Ljava/lang/String;Ljava/lang/Object;ZILjava/lang/Object;)Z
    .locals 0

    .line 88
    if-nez p5, :cond_1

    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_0

    const/4 p3, 0x0

    :cond_0
    invoke-virtual {p0, p1, p2, p3}, Lcom/pkware/ahocorasick/AhoCorasick;->replace(Ljava/lang/String;Ljava/lang/Object;Z)Z

    move-result p0

    return p0

    :cond_1
    new-instance p0, Ljava/lang/UnsupportedOperationException;

    const-string p1, "Super calls with default arguments not supported in this target, function: replace"

    invoke-direct {p0, p1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p0
.end method


# virtual methods
.method public final add(Ljava/lang/String;Ljava/lang/Object;)V
    .locals 2
    .param p1, "key"    # Ljava/lang/String;
    .param p2, "value"    # Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "TT;)V"
        }
    .end annotation

    const-string v0, "key"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 65
    iget-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasick;->storedValues:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    invoke-virtual {p0, p1, v0}, Lcom/pkware/ahocorasick/AhoCorasick;->addEntry(Ljava/lang/String;I)V

    .line 66
    iget-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasick;->storedValues:Ljava/util/ArrayList;

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 67
    iget-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasick;->keyLengths:Lcom/pkware/ahocorasick/UnboxedIntList;

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v1

    invoke-virtual {v0, v1}, Lcom/pkware/ahocorasick/UnboxedIntList;->add(I)V

    .line 68
    return-void
.end method

.method protected generateResult(IILjava/lang/String;)Lcom/pkware/ahocorasick/AhoCorasickResult;
    .locals 3
    .param p1, "index"    # I
    .param p2, "value"    # I
    .param p3, "input"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(II",
            "Ljava/lang/String;",
            ")",
            "Lcom/pkware/ahocorasick/AhoCorasickResult<",
            "TT;>;"
        }
    .end annotation

    const-string v0, "input"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 106
    new-instance v0, Lcom/pkware/ahocorasick/AhoCorasickResult;

    iget-object v1, p0, Lcom/pkware/ahocorasick/AhoCorasick;->keyLengths:Lcom/pkware/ahocorasick/UnboxedIntList;

    invoke-virtual {v1, p2}, Lcom/pkware/ahocorasick/UnboxedIntList;->get(I)I

    move-result v1

    sub-int v1, p1, v1

    iget-object v2, p0, Lcom/pkware/ahocorasick/AhoCorasick;->storedValues:Ljava/util/ArrayList;

    invoke-virtual {v2, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    invoke-direct {v0, v1, p1, v2}, Lcom/pkware/ahocorasick/AhoCorasickResult;-><init>(IILjava/lang/Object;)V

    return-object v0
.end method

.method public final replace(Ljava/lang/String;Ljava/lang/Object;Z)Z
    .locals 2
    .param p1, "key"    # Ljava/lang/String;
    .param p2, "value"    # Ljava/lang/Object;
    .param p3, "insertOnFail"    # Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "TT;Z)Z"
        }
    .end annotation

    const-string v0, "key"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 91
    invoke-virtual {p0}, Lcom/pkware/ahocorasick/AhoCorasick;->isBuilt()Z

    move-result v0

    if-nez v0, :cond_2

    .line 93
    invoke-virtual {p0, p1}, Lcom/pkware/ahocorasick/AhoCorasick;->keyValue(Ljava/lang/String;)I

    move-result v0

    .line 95
    .local v0, "keyValue":I
    const/high16 v1, -0x80000000

    if-eq v0, v1, :cond_0

    .line 96
    iget-object v1, p0, Lcom/pkware/ahocorasick/AhoCorasick;->storedValues:Ljava/util/ArrayList;

    invoke-virtual {v1, v0, p2}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 97
    const/4 v1, 0x1

    return v1

    .line 98
    :cond_0
    if-eqz p3, :cond_1

    .line 99
    invoke-virtual {p0, p1, p2}, Lcom/pkware/ahocorasick/AhoCorasick;->add(Ljava/lang/String;Ljava/lang/Object;)V

    .line 102
    :cond_1
    const/4 v1, 0x0

    return v1

    .line 109
    .end local v0    # "keyValue":I
    :cond_2
    const/4 v0, 0x0

    .line 91
    .local v0, "$i$a$-check-AhoCorasick$replace$1":I
    nop

    .end local v0    # "$i$a$-check-AhoCorasick$replace$1":I
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "Can\'t modify entries after \'build\' has been called."

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final valueOf(Ljava/lang/String;)Ljava/lang/Object;
    .locals 2
    .param p1, "key"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")TT;"
        }
    .end annotation

    const-string v0, "key"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 49
    iget-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasick;->storedValues:Ljava/util/ArrayList;

    check-cast v0, Ljava/util/List;

    invoke-virtual {p0, p1}, Lcom/pkware/ahocorasick/AhoCorasick;->keyValue(Ljava/lang/String;)I

    move-result v1

    invoke-static {v0, v1}, Lkotlin/collections/CollectionsKt;->getOrNull(Ljava/util/List;I)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method
