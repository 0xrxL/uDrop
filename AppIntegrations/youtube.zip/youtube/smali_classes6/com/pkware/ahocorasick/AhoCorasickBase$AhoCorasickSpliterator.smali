.class final Lcom/pkware/ahocorasick/AhoCorasickBase$AhoCorasickSpliterator;
.super Ljava/util/Spliterators$AbstractSpliterator;
.source "AhoCorasickBase.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/pkware/ahocorasick/AhoCorasickBase;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "AhoCorasickSpliterator"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/util/Spliterators$AbstractSpliterator<",
        "Lcom/pkware/ahocorasick/AhoCorasickResult<",
        "TT;>;>;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000*\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\u0008\u0002\n\u0002\u0010\u0008\n\u0002\u0008\u000b\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\u0008\u0082\u0004\u0018\u00002\u000e\u0012\n\u0012\u0008\u0012\u0004\u0012\u00028\u00000\u00020\u0001B\r\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u00a2\u0006\u0002\u0010\u0005J\u001e\u0010\u0012\u001a\u00020\u00132\u0014\u0010\u0014\u001a\u0010\u0012\u000c\u0008\u0000\u0012\u0008\u0012\u0004\u0012\u00028\u00000\u00020\u0015H\u0016R\u001a\u0010\u0006\u001a\u00020\u0007X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u0008\u0010\t\"\u0004\u0008\n\u0010\u000bR\u001a\u0010\u000c\u001a\u00020\u0007X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\r\u0010\t\"\u0004\u0008\u000e\u0010\u000bR\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u000f\u001a\u00020\u0007X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u0010\u0010\t\"\u0004\u0008\u0011\u0010\u000b\u00a8\u0006\u0016"
    }
    d2 = {
        "Lcom/pkware/ahocorasick/AhoCorasickBase$AhoCorasickSpliterator;",
        "Ljava/util/Spliterators$AbstractSpliterator;",
        "Lcom/pkware/ahocorasick/AhoCorasickResult;",
        "input",
        "",
        "(Lcom/pkware/ahocorasick/AhoCorasickBase;Ljava/lang/String;)V",
        "currentInputIndex",
        "",
        "getCurrentInputIndex",
        "()I",
        "setCurrentInputIndex",
        "(I)V",
        "currentNode",
        "getCurrentNode",
        "setCurrentNode",
        "nextNode",
        "getNextNode",
        "setNextNode",
        "tryAdvance",
        "",
        "action",
        "Ljava/util/function/Consumer;",
        "LowMemoryAhoCorasick"
    }
    k = 0x1
    mv = {
        0x1,
        0x9,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private currentInputIndex:I

.field private currentNode:I

.field private final input:Ljava/lang/String;

.field private nextNode:I

.field final synthetic this$0:Lcom/pkware/ahocorasick/AhoCorasickBase;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/pkware/ahocorasick/AhoCorasickBase<",
            "TT;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lcom/pkware/ahocorasick/AhoCorasickBase;Ljava/lang/String;)V
    .locals 3
    .param p1, "this$0"    # Lcom/pkware/ahocorasick/AhoCorasickBase;
    .param p2, "input"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    const-string v0, "input"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 857
    iput-object p1, p0, Lcom/pkware/ahocorasick/AhoCorasickBase$AhoCorasickSpliterator;->this$0:Lcom/pkware/ahocorasick/AhoCorasickBase;

    .line 858
    const-wide v0, 0x7fffffffffffffffL

    const/16 v2, 0x501

    invoke-direct {p0, v0, v1, v2}, Ljava/util/Spliterators$AbstractSpliterator;-><init>(JI)V

    .line 857
    iput-object p2, p0, Lcom/pkware/ahocorasick/AhoCorasickBase$AhoCorasickSpliterator;->input:Ljava/lang/String;

    .line 874
    const/high16 v0, -0x80000000

    iput v0, p0, Lcom/pkware/ahocorasick/AhoCorasickBase$AhoCorasickSpliterator;->nextNode:I

    .line 857
    return-void
.end method


# virtual methods
.method public final getCurrentInputIndex()I
    .locals 1

    .line 872
    iget v0, p0, Lcom/pkware/ahocorasick/AhoCorasickBase$AhoCorasickSpliterator;->currentInputIndex:I

    return v0
.end method

.method public final getCurrentNode()I
    .locals 1

    .line 865
    iget v0, p0, Lcom/pkware/ahocorasick/AhoCorasickBase$AhoCorasickSpliterator;->currentNode:I

    return v0
.end method

.method public final getNextNode()I
    .locals 1

    .line 874
    iget v0, p0, Lcom/pkware/ahocorasick/AhoCorasickBase$AhoCorasickSpliterator;->nextNode:I

    return v0
.end method

.method public final setCurrentInputIndex(I)V
    .locals 0
    .param p1, "<set-?>"    # I

    .line 872
    iput p1, p0, Lcom/pkware/ahocorasick/AhoCorasickBase$AhoCorasickSpliterator;->currentInputIndex:I

    return-void
.end method

.method public final setCurrentNode(I)V
    .locals 0
    .param p1, "<set-?>"    # I

    .line 865
    iput p1, p0, Lcom/pkware/ahocorasick/AhoCorasickBase$AhoCorasickSpliterator;->currentNode:I

    return-void
.end method

.method public final setNextNode(I)V
    .locals 0
    .param p1, "<set-?>"    # I

    .line 874
    iput p1, p0, Lcom/pkware/ahocorasick/AhoCorasickBase$AhoCorasickSpliterator;->nextNode:I

    return-void
.end method

.method public tryAdvance(Ljava/util/function/Consumer;)Z
    .locals 8
    .param p1, "action"    # Ljava/util/function/Consumer;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/function/Consumer<",
            "-",
            "Lcom/pkware/ahocorasick/AhoCorasickResult<",
            "TT;>;>;)Z"
        }
    .end annotation

    const-string v0, "action"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 878
    :cond_0
    :goto_0
    iget v0, p0, Lcom/pkware/ahocorasick/AhoCorasickBase$AhoCorasickSpliterator;->currentInputIndex:I

    iget-object v1, p0, Lcom/pkware/ahocorasick/AhoCorasickBase$AhoCorasickSpliterator;->input:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v1

    const/high16 v2, -0x80000000

    if-lt v0, v1, :cond_2

    iget v0, p0, Lcom/pkware/ahocorasick/AhoCorasickBase$AhoCorasickSpliterator;->nextNode:I

    if-eq v0, v2, :cond_1

    goto :goto_1

    .line 902
    :cond_1
    const/4 v0, 0x0

    return v0

    .line 880
    :cond_2
    :goto_1
    const/4 v0, 0x0

    .line 881
    .local v0, "nextValue":I
    iget v1, p0, Lcom/pkware/ahocorasick/AhoCorasickBase$AhoCorasickSpliterator;->nextNode:I

    if-ne v1, v2, :cond_3

    .line 882
    iget-object v1, p0, Lcom/pkware/ahocorasick/AhoCorasickBase$AhoCorasickSpliterator;->this$0:Lcom/pkware/ahocorasick/AhoCorasickBase;

    iget v3, p0, Lcom/pkware/ahocorasick/AhoCorasickBase$AhoCorasickSpliterator;->currentNode:I

    iget-object v4, p0, Lcom/pkware/ahocorasick/AhoCorasickBase$AhoCorasickSpliterator;->this$0:Lcom/pkware/ahocorasick/AhoCorasickBase;

    iget-object v5, p0, Lcom/pkware/ahocorasick/AhoCorasickBase$AhoCorasickSpliterator;->input:Ljava/lang/String;

    iget v6, p0, Lcom/pkware/ahocorasick/AhoCorasickBase$AhoCorasickSpliterator;->currentInputIndex:I

    add-int/lit8 v7, v6, 0x1

    iput v7, p0, Lcom/pkware/ahocorasick/AhoCorasickBase$AhoCorasickSpliterator;->currentInputIndex:I

    invoke-virtual {v5, v6}, Ljava/lang/String;->charAt(I)C

    move-result v5

    # invokes: Lcom/pkware/ahocorasick/AhoCorasickBase;->normalize(C)C
    invoke-static {v4, v5}, Lcom/pkware/ahocorasick/AhoCorasickBase;->access$normalize(Lcom/pkware/ahocorasick/AhoCorasickBase;C)C

    move-result v4

    # invokes: Lcom/pkware/ahocorasick/AhoCorasickBase;->calculateNextState(II)I
    invoke-static {v1, v3, v4}, Lcom/pkware/ahocorasick/AhoCorasickBase;->access$calculateNextState(Lcom/pkware/ahocorasick/AhoCorasickBase;II)I

    move-result v1

    iput v1, p0, Lcom/pkware/ahocorasick/AhoCorasickBase$AhoCorasickSpliterator;->currentNode:I

    .line 883
    iget-object v1, p0, Lcom/pkware/ahocorasick/AhoCorasickBase$AhoCorasickSpliterator;->this$0:Lcom/pkware/ahocorasick/AhoCorasickBase;

    # getter for: Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;
    invoke-static {v1}, Lcom/pkware/ahocorasick/AhoCorasickBase;->access$getStore$p(Lcom/pkware/ahocorasick/AhoCorasickBase;)Lcom/pkware/ahocorasick/AhoCorasickStore;

    move-result-object v1

    iget v3, p0, Lcom/pkware/ahocorasick/AhoCorasickBase$AhoCorasickSpliterator;->currentNode:I

    invoke-virtual {v1, v3}, Lcom/pkware/ahocorasick/AhoCorasickStore;->getPrefixIndex(I)I

    move-result v1

    iput v1, p0, Lcom/pkware/ahocorasick/AhoCorasickBase$AhoCorasickSpliterator;->nextNode:I

    .line 884
    iget-object v1, p0, Lcom/pkware/ahocorasick/AhoCorasickBase$AhoCorasickSpliterator;->this$0:Lcom/pkware/ahocorasick/AhoCorasickBase;

    # getter for: Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;
    invoke-static {v1}, Lcom/pkware/ahocorasick/AhoCorasickBase;->access$getStore$p(Lcom/pkware/ahocorasick/AhoCorasickBase;)Lcom/pkware/ahocorasick/AhoCorasickStore;

    move-result-object v1

    iget v3, p0, Lcom/pkware/ahocorasick/AhoCorasickBase$AhoCorasickSpliterator;->currentNode:I

    invoke-virtual {v1, v3}, Lcom/pkware/ahocorasick/AhoCorasickStore;->getValue(I)I

    move-result v0

    .line 887
    if-ne v0, v2, :cond_4

    goto :goto_0

    .line 891
    :cond_3
    iget-object v1, p0, Lcom/pkware/ahocorasick/AhoCorasickBase$AhoCorasickSpliterator;->this$0:Lcom/pkware/ahocorasick/AhoCorasickBase;

    # getter for: Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;
    invoke-static {v1}, Lcom/pkware/ahocorasick/AhoCorasickBase;->access$getStore$p(Lcom/pkware/ahocorasick/AhoCorasickBase;)Lcom/pkware/ahocorasick/AhoCorasickStore;

    move-result-object v1

    iget v2, p0, Lcom/pkware/ahocorasick/AhoCorasickBase$AhoCorasickSpliterator;->nextNode:I

    invoke-virtual {v1, v2}, Lcom/pkware/ahocorasick/AhoCorasickStore;->getValue(I)I

    move-result v0

    .line 892
    iget-object v1, p0, Lcom/pkware/ahocorasick/AhoCorasickBase$AhoCorasickSpliterator;->this$0:Lcom/pkware/ahocorasick/AhoCorasickBase;

    # getter for: Lcom/pkware/ahocorasick/AhoCorasickBase;->store:Lcom/pkware/ahocorasick/AhoCorasickStore;
    invoke-static {v1}, Lcom/pkware/ahocorasick/AhoCorasickBase;->access$getStore$p(Lcom/pkware/ahocorasick/AhoCorasickBase;)Lcom/pkware/ahocorasick/AhoCorasickStore;

    move-result-object v1

    iget v2, p0, Lcom/pkware/ahocorasick/AhoCorasickBase$AhoCorasickSpliterator;->nextNode:I

    invoke-virtual {v1, v2}, Lcom/pkware/ahocorasick/AhoCorasickStore;->getPrefixIndex(I)I

    move-result v1

    iput v1, p0, Lcom/pkware/ahocorasick/AhoCorasickBase$AhoCorasickSpliterator;->nextNode:I

    .line 895
    :cond_4
    iget-object v1, p0, Lcom/pkware/ahocorasick/AhoCorasickBase$AhoCorasickSpliterator;->this$0:Lcom/pkware/ahocorasick/AhoCorasickBase;

    iget v2, p0, Lcom/pkware/ahocorasick/AhoCorasickBase$AhoCorasickSpliterator;->currentInputIndex:I

    iget-object v3, p0, Lcom/pkware/ahocorasick/AhoCorasickBase$AhoCorasickSpliterator;->input:Ljava/lang/String;

    invoke-virtual {v1, v2, v0, v3}, Lcom/pkware/ahocorasick/AhoCorasickBase;->generateResult(IILjava/lang/String;)Lcom/pkware/ahocorasick/AhoCorasickResult;

    move-result-object v1

    .line 896
    .local v1, "result":Lcom/pkware/ahocorasick/AhoCorasickResult;
    iget-object v2, p0, Lcom/pkware/ahocorasick/AhoCorasickBase$AhoCorasickSpliterator;->this$0:Lcom/pkware/ahocorasick/AhoCorasickBase;

    invoke-virtual {v2}, Lcom/pkware/ahocorasick/AhoCorasickBase;->getFindOnlyWholeWords()Z

    move-result v2

    if-eqz v2, :cond_5

    iget-object v2, p0, Lcom/pkware/ahocorasick/AhoCorasickBase$AhoCorasickSpliterator;->this$0:Lcom/pkware/ahocorasick/AhoCorasickBase;

    iget-object v3, p0, Lcom/pkware/ahocorasick/AhoCorasickBase$AhoCorasickSpliterator;->input:Ljava/lang/String;

    # invokes: Lcom/pkware/ahocorasick/AhoCorasickBase;->passesWhitespaceChecks(Lcom/pkware/ahocorasick/AhoCorasickResult;Ljava/lang/String;)Z
    invoke-static {v2, v1, v3}, Lcom/pkware/ahocorasick/AhoCorasickBase;->access$passesWhitespaceChecks(Lcom/pkware/ahocorasick/AhoCorasickBase;Lcom/pkware/ahocorasick/AhoCorasickResult;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_0

    .line 897
    :cond_5
    invoke-interface {p1, v1}, Ljava/util/function/Consumer;->accept(Ljava/lang/Object;)V

    .line 898
    const/4 v2, 0x1

    return v2
.end method
