.class public final enum Lcom/pkware/ahocorasick/AhoCorasickOption;
.super Ljava/lang/Enum;
.source "AhoCorasickOption.kt"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/pkware/ahocorasick/AhoCorasickOption;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u000c\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\u0008\u0004\u0008\u0086\u0081\u0002\u0018\u00002\u0008\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\u0008\u0002\u00a2\u0006\u0002\u0010\u0002j\u0002\u0008\u0003j\u0002\u0008\u0004\u00a8\u0006\u0005"
    }
    d2 = {
        "Lcom/pkware/ahocorasick/AhoCorasickOption;",
        "",
        "(Ljava/lang/String;I)V",
        "CASE_INSENSITIVE",
        "WHOLE_WORDS_ONLY",
        "LowMemoryAhoCorasick"
    }
    k = 0x1
    mv = {
        0x1,
        0x9,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field private static final synthetic $ENTRIES:Lkotlin/enums/EnumEntries;

.field private static final synthetic $VALUES:[Lcom/pkware/ahocorasick/AhoCorasickOption;

.field public static final enum CASE_INSENSITIVE:Lcom/pkware/ahocorasick/AhoCorasickOption;

.field public static final enum WHOLE_WORDS_ONLY:Lcom/pkware/ahocorasick/AhoCorasickOption;


# direct methods
.method private static final synthetic $values()[Lcom/pkware/ahocorasick/AhoCorasickOption;
    .locals 2

    sget-object v0, Lcom/pkware/ahocorasick/AhoCorasickOption;->CASE_INSENSITIVE:Lcom/pkware/ahocorasick/AhoCorasickOption;

    sget-object v1, Lcom/pkware/ahocorasick/AhoCorasickOption;->WHOLE_WORDS_ONLY:Lcom/pkware/ahocorasick/AhoCorasickOption;

    filled-new-array {v0, v1}, [Lcom/pkware/ahocorasick/AhoCorasickOption;

    move-result-object v0

    return-object v0
.end method

.method static constructor <clinit>()V
    .locals 3

    .line 13
    new-instance v0, Lcom/pkware/ahocorasick/AhoCorasickOption;

    const-string v1, "CASE_INSENSITIVE"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Lcom/pkware/ahocorasick/AhoCorasickOption;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/pkware/ahocorasick/AhoCorasickOption;->CASE_INSENSITIVE:Lcom/pkware/ahocorasick/AhoCorasickOption;

    .line 22
    new-instance v0, Lcom/pkware/ahocorasick/AhoCorasickOption;

    const-string v1, "WHOLE_WORDS_ONLY"

    const/4 v2, 0x1

    invoke-direct {v0, v1, v2}, Lcom/pkware/ahocorasick/AhoCorasickOption;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/pkware/ahocorasick/AhoCorasickOption;->WHOLE_WORDS_ONLY:Lcom/pkware/ahocorasick/AhoCorasickOption;

    invoke-static {}, Lcom/pkware/ahocorasick/AhoCorasickOption;->$values()[Lcom/pkware/ahocorasick/AhoCorasickOption;

    move-result-object v0

    sput-object v0, Lcom/pkware/ahocorasick/AhoCorasickOption;->$VALUES:[Lcom/pkware/ahocorasick/AhoCorasickOption;

    sget-object v0, Lcom/pkware/ahocorasick/AhoCorasickOption;->$VALUES:[Lcom/pkware/ahocorasick/AhoCorasickOption;

    check-cast v0, [Ljava/lang/Enum;

    invoke-static {v0}, Lkotlin/enums/EnumEntriesKt;->enumEntries([Ljava/lang/Enum;)Lkotlin/enums/EnumEntries;

    move-result-object v0

    sput-object v0, Lcom/pkware/ahocorasick/AhoCorasickOption;->$ENTRIES:Lkotlin/enums/EnumEntries;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 0
    .param p1, "$enum$name"    # Ljava/lang/String;
    .param p2, "$enum$ordinal"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 6
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method public static getEntries()Lkotlin/enums/EnumEntries;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/enums/EnumEntries<",
            "Lcom/pkware/ahocorasick/AhoCorasickOption;",
            ">;"
        }
    .end annotation

    sget-object v0, Lcom/pkware/ahocorasick/AhoCorasickOption;->$ENTRIES:Lkotlin/enums/EnumEntries;

    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/pkware/ahocorasick/AhoCorasickOption;
    .locals 1

    const-class v0, Lcom/pkware/ahocorasick/AhoCorasickOption;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v0

    check-cast v0, Lcom/pkware/ahocorasick/AhoCorasickOption;

    return-object v0
.end method

.method public static values()[Lcom/pkware/ahocorasick/AhoCorasickOption;
    .locals 1

    sget-object v0, Lcom/pkware/ahocorasick/AhoCorasickOption;->$VALUES:[Lcom/pkware/ahocorasick/AhoCorasickOption;

    invoke-virtual {v0}, [Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/pkware/ahocorasick/AhoCorasickOption;

    return-object v0
.end method
