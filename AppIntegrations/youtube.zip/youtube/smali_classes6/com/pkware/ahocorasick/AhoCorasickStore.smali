.class public final Lcom/pkware/ahocorasick/AhoCorasickStore;
.super Ljava/lang/Object;
.source "AhoCorasickStore.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/pkware/ahocorasick/AhoCorasickStore$Companion;
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0008\n\u0002\u0008\u0018\n\u0002\u0018\u0002\n\u0002\u0008\u0002\u0008\u0000\u0018\u0000 &2\u00020\u0001:\u0001&B\u0005\u00a2\u0006\u0002\u0010\u0002J\u0006\u0010\t\u001a\u00020\nJ\u000e\u0010\u000b\u001a\u00020\u000c2\u0006\u0010\r\u001a\u00020\u000cJ\u000e\u0010\u000e\u001a\u00020\u000c2\u0006\u0010\r\u001a\u00020\u000cJ\u000e\u0010\u000f\u001a\u00020\u000c2\u0006\u0010\r\u001a\u00020\u000cJ\u000e\u0010\u0010\u001a\u00020\u000c2\u0006\u0010\r\u001a\u00020\u000cJ\u000e\u0010\u0011\u001a\u00020\u000c2\u0006\u0010\r\u001a\u00020\u000cJ\u000e\u0010\u0012\u001a\u00020\u000c2\u0006\u0010\r\u001a\u00020\u000cJ\u000e\u0010\u0013\u001a\u00020\u000c2\u0006\u0010\r\u001a\u00020\u000cJ\u000e\u0010\u0014\u001a\u00020\u000c2\u0006\u0010\r\u001a\u00020\u000cJ\u000e\u0010\u0015\u001a\u00020\u000c2\u0006\u0010\r\u001a\u00020\u000cJ\u0016\u0010\u0016\u001a\u00020\n2\u0006\u0010\r\u001a\u00020\u000c2\u0006\u0010\u0017\u001a\u00020\u000cJ\u0016\u0010\u0018\u001a\u00020\n2\u0006\u0010\r\u001a\u00020\u000c2\u0006\u0010\u0017\u001a\u00020\u000cJ\u0016\u0010\u0019\u001a\u00020\n2\u0006\u0010\r\u001a\u00020\u000c2\u0006\u0010\u0017\u001a\u00020\u000cJ\u0016\u0010\u001a\u001a\u00020\n2\u0006\u0010\r\u001a\u00020\u000c2\u0006\u0010\u0017\u001a\u00020\u000cJ\u0016\u0010\u001b\u001a\u00020\n2\u0006\u0010\r\u001a\u00020\u000c2\u0006\u0010\u0017\u001a\u00020\u000cJ\u0016\u0010\u001c\u001a\u00020\n2\u0006\u0010\r\u001a\u00020\u000c2\u0006\u0010\u0017\u001a\u00020\u000cJ\u0016\u0010\u001d\u001a\u00020\n2\u0006\u0010\r\u001a\u00020\u000c2\u0006\u0010\u0017\u001a\u00020\u000cJ\u0016\u0010\u001e\u001a\u00020\n2\u0006\u0010\r\u001a\u00020\u000c2\u0006\u0010\u0017\u001a\u00020\u000cJ6\u0010\u001f\u001a\u00020\n2\u0006\u0010\r\u001a\u00020\u000c2\u0006\u0010 \u001a\u00020\u000c2\u0006\u0010!\u001a\u00020\u000c2\u0006\u0010\u0017\u001a\u00020\u000c2\u0006\u0010\"\u001a\u00020\u000c2\u0006\u0010#\u001a\u00020\u000cJ\u000c\u0010$\u001a\u00020%*\u00020\u0004H\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0008\u001a\u00020\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\'"
    }
    d2 = {
        "Lcom/pkware/ahocorasick/AhoCorasickStore;",
        "",
        "()V",
        "baseOffsets",
        "Lcom/pkware/ahocorasick/SafeIndexable;",
        "parents",
        "store1",
        "store2",
        "values",
        "buildRuntimeStructures",
        "",
        "getBaseOffset",
        "",
        "index",
        "getChildOffset",
        "getFailureIndex",
        "getNextSiblingOffset",
        "getParent",
        "getPrefixIndex",
        "getQueueIndex",
        "getValue",
        "safeGetParent",
        "setBaseOffset",
        "value",
        "setChildOffset",
        "setFailureIndex",
        "setNextSiblingOffset",
        "setParent",
        "setPrefixIndex",
        "setQueueIndex",
        "setValue",
        "synchronizedSafeSet",
        "baseOffset",
        "parent",
        "nextSibling",
        "childOffset",
        "toIntList",
        "Lcom/pkware/ahocorasick/UnboxedIntList;",
        "Companion",
        "LowMemoryAhoCorasick"
    }
    k = 0x1
    mv = {
        0x1,
        0x9,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final Companion:Lcom/pkware/ahocorasick/AhoCorasickStore$Companion;

.field public static final RESERVED_VALUE:I = -0x80000000


# instance fields
.field private baseOffsets:Lcom/pkware/ahocorasick/SafeIndexable;

.field private parents:Lcom/pkware/ahocorasick/SafeIndexable;

.field private store1:Lcom/pkware/ahocorasick/SafeIndexable;

.field private store2:Lcom/pkware/ahocorasick/SafeIndexable;

.field private values:Lcom/pkware/ahocorasick/SafeIndexable;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Lcom/pkware/ahocorasick/AhoCorasickStore$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/pkware/ahocorasick/AhoCorasickStore$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lcom/pkware/ahocorasick/AhoCorasickStore;->Companion:Lcom/pkware/ahocorasick/AhoCorasickStore$Companion;

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 18
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 23
    new-instance v0, Lcom/pkware/ahocorasick/DoubleArrayIntList;

    const/high16 v1, -0x80000000

    invoke-direct {v0, v1}, Lcom/pkware/ahocorasick/DoubleArrayIntList;-><init>(I)V

    check-cast v0, Lcom/pkware/ahocorasick/SafeIndexable;

    iput-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasickStore;->baseOffsets:Lcom/pkware/ahocorasick/SafeIndexable;

    .line 28
    new-instance v0, Lcom/pkware/ahocorasick/DoubleArrayIntList;

    invoke-direct {v0, v1}, Lcom/pkware/ahocorasick/DoubleArrayIntList;-><init>(I)V

    check-cast v0, Lcom/pkware/ahocorasick/SafeIndexable;

    iput-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasickStore;->parents:Lcom/pkware/ahocorasick/SafeIndexable;

    .line 33
    new-instance v0, Lcom/pkware/ahocorasick/DoubleArrayIntList;

    invoke-direct {v0, v1}, Lcom/pkware/ahocorasick/DoubleArrayIntList;-><init>(I)V

    check-cast v0, Lcom/pkware/ahocorasick/SafeIndexable;

    iput-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasickStore;->values:Lcom/pkware/ahocorasick/SafeIndexable;

    .line 39
    new-instance v0, Lcom/pkware/ahocorasick/DoubleArrayIntList;

    invoke-direct {v0, v1}, Lcom/pkware/ahocorasick/DoubleArrayIntList;-><init>(I)V

    check-cast v0, Lcom/pkware/ahocorasick/SafeIndexable;

    iput-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasickStore;->store1:Lcom/pkware/ahocorasick/SafeIndexable;

    .line 45
    new-instance v0, Lcom/pkware/ahocorasick/DoubleArrayIntList;

    invoke-direct {v0, v1}, Lcom/pkware/ahocorasick/DoubleArrayIntList;-><init>(I)V

    check-cast v0, Lcom/pkware/ahocorasick/SafeIndexable;

    iput-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasickStore;->store2:Lcom/pkware/ahocorasick/SafeIndexable;

    .line 18
    return-void
.end method

.method private final toIntList(Lcom/pkware/ahocorasick/SafeIndexable;)Lcom/pkware/ahocorasick/UnboxedIntList;
    .locals 7
    .param p1, "$this$toIntList"    # Lcom/pkware/ahocorasick/SafeIndexable;

    .line 241
    new-instance v0, Lcom/pkware/ahocorasick/UnboxedIntList;

    invoke-virtual {p1}, Lcom/pkware/ahocorasick/SafeIndexable;->getSize()I

    move-result v1

    invoke-virtual {p1}, Lcom/pkware/ahocorasick/SafeIndexable;->getDefaultValue()I

    move-result v4

    const/4 v5, 0x2

    const/4 v6, 0x0

    const-wide/16 v2, 0x0

    invoke-direct/range {v0 .. v6}, Lcom/pkware/ahocorasick/UnboxedIntList;-><init>(IDIILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 244
    .local v0, "intList":Lcom/pkware/ahocorasick/UnboxedIntList;
    invoke-virtual {p1}, Lcom/pkware/ahocorasick/SafeIndexable;->getSize()I

    move-result v1

    if-eqz v1, :cond_0

    invoke-virtual {p1}, Lcom/pkware/ahocorasick/SafeIndexable;->getSize()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    invoke-virtual {p1}, Lcom/pkware/ahocorasick/SafeIndexable;->getSize()I

    move-result v2

    add-int/lit8 v2, v2, -0x1

    invoke-virtual {p1, v2}, Lcom/pkware/ahocorasick/SafeIndexable;->get(I)I

    move-result v2

    invoke-virtual {v0, v1, v2}, Lcom/pkware/ahocorasick/UnboxedIntList;->safeSet(II)Z

    .line 246
    :cond_0
    const/4 v1, 0x0

    .local v1, "i":I
    invoke-virtual {p1}, Lcom/pkware/ahocorasick/SafeIndexable;->getSize()I

    move-result v2

    add-int/lit8 v2, v2, -0x1

    :goto_0
    if-ge v1, v2, :cond_1

    invoke-virtual {p1, v1}, Lcom/pkware/ahocorasick/SafeIndexable;->get(I)I

    move-result v3

    invoke-virtual {v0, v1, v3}, Lcom/pkware/ahocorasick/UnboxedIntList;->set(II)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 248
    .end local v1    # "i":I
    :cond_1
    return-object v0
.end method


# virtual methods
.method public final buildRuntimeStructures()V
    .locals 1

    .line 227
    iget-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasickStore;->baseOffsets:Lcom/pkware/ahocorasick/SafeIndexable;

    invoke-direct {p0, v0}, Lcom/pkware/ahocorasick/AhoCorasickStore;->toIntList(Lcom/pkware/ahocorasick/SafeIndexable;)Lcom/pkware/ahocorasick/UnboxedIntList;

    move-result-object v0

    check-cast v0, Lcom/pkware/ahocorasick/SafeIndexable;

    iput-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasickStore;->baseOffsets:Lcom/pkware/ahocorasick/SafeIndexable;

    .line 228
    iget-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasickStore;->parents:Lcom/pkware/ahocorasick/SafeIndexable;

    invoke-direct {p0, v0}, Lcom/pkware/ahocorasick/AhoCorasickStore;->toIntList(Lcom/pkware/ahocorasick/SafeIndexable;)Lcom/pkware/ahocorasick/UnboxedIntList;

    move-result-object v0

    check-cast v0, Lcom/pkware/ahocorasick/SafeIndexable;

    iput-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasickStore;->parents:Lcom/pkware/ahocorasick/SafeIndexable;

    .line 229
    iget-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasickStore;->values:Lcom/pkware/ahocorasick/SafeIndexable;

    invoke-direct {p0, v0}, Lcom/pkware/ahocorasick/AhoCorasickStore;->toIntList(Lcom/pkware/ahocorasick/SafeIndexable;)Lcom/pkware/ahocorasick/UnboxedIntList;

    move-result-object v0

    check-cast v0, Lcom/pkware/ahocorasick/SafeIndexable;

    iput-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasickStore;->values:Lcom/pkware/ahocorasick/SafeIndexable;

    .line 230
    iget-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasickStore;->store1:Lcom/pkware/ahocorasick/SafeIndexable;

    invoke-direct {p0, v0}, Lcom/pkware/ahocorasick/AhoCorasickStore;->toIntList(Lcom/pkware/ahocorasick/SafeIndexable;)Lcom/pkware/ahocorasick/UnboxedIntList;

    move-result-object v0

    check-cast v0, Lcom/pkware/ahocorasick/SafeIndexable;

    iput-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasickStore;->store1:Lcom/pkware/ahocorasick/SafeIndexable;

    .line 231
    iget-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasickStore;->store2:Lcom/pkware/ahocorasick/SafeIndexable;

    invoke-direct {p0, v0}, Lcom/pkware/ahocorasick/AhoCorasickStore;->toIntList(Lcom/pkware/ahocorasick/SafeIndexable;)Lcom/pkware/ahocorasick/UnboxedIntList;

    move-result-object v0

    check-cast v0, Lcom/pkware/ahocorasick/SafeIndexable;

    iput-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasickStore;->store2:Lcom/pkware/ahocorasick/SafeIndexable;

    .line 232
    return-void
.end method

.method public final getBaseOffset(I)I
    .locals 1
    .param p1, "index"    # I

    .line 114
    iget-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasickStore;->baseOffsets:Lcom/pkware/ahocorasick/SafeIndexable;

    invoke-virtual {v0, p1}, Lcom/pkware/ahocorasick/SafeIndexable;->get(I)I

    move-result v0

    return v0
.end method

.method public final getChildOffset(I)I
    .locals 1
    .param p1, "index"    # I

    .line 163
    iget-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasickStore;->store2:Lcom/pkware/ahocorasick/SafeIndexable;

    invoke-virtual {v0, p1}, Lcom/pkware/ahocorasick/SafeIndexable;->get(I)I

    move-result v0

    return v0
.end method

.method public final getFailureIndex(I)I
    .locals 1
    .param p1, "index"    # I

    .line 155
    iget-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasickStore;->store1:Lcom/pkware/ahocorasick/SafeIndexable;

    invoke-virtual {v0, p1}, Lcom/pkware/ahocorasick/SafeIndexable;->get(I)I

    move-result v0

    return v0
.end method

.method public final getNextSiblingOffset(I)I
    .locals 1
    .param p1, "index"    # I

    .line 145
    iget-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasickStore;->store1:Lcom/pkware/ahocorasick/SafeIndexable;

    invoke-virtual {v0, p1}, Lcom/pkware/ahocorasick/SafeIndexable;->get(I)I

    move-result v0

    return v0
.end method

.method public final getParent(I)I
    .locals 1
    .param p1, "index"    # I

    .line 122
    iget-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasickStore;->parents:Lcom/pkware/ahocorasick/SafeIndexable;

    invoke-virtual {v0, p1}, Lcom/pkware/ahocorasick/SafeIndexable;->get(I)I

    move-result v0

    return v0
.end method

.method public final getPrefixIndex(I)I
    .locals 1
    .param p1, "index"    # I

    .line 179
    iget-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasickStore;->store2:Lcom/pkware/ahocorasick/SafeIndexable;

    invoke-virtual {v0, p1}, Lcom/pkware/ahocorasick/SafeIndexable;->get(I)I

    move-result v0

    return v0
.end method

.method public final getQueueIndex(I)I
    .locals 1
    .param p1, "index"    # I

    .line 171
    iget-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasickStore;->store1:Lcom/pkware/ahocorasick/SafeIndexable;

    invoke-virtual {v0, p1}, Lcom/pkware/ahocorasick/SafeIndexable;->get(I)I

    move-result v0

    return v0
.end method

.method public final getValue(I)I
    .locals 1
    .param p1, "index"    # I

    .line 137
    iget-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasickStore;->values:Lcom/pkware/ahocorasick/SafeIndexable;

    invoke-virtual {v0, p1}, Lcom/pkware/ahocorasick/SafeIndexable;->get(I)I

    move-result v0

    return v0
.end method

.method public final safeGetParent(I)I
    .locals 1
    .param p1, "index"    # I

    .line 129
    iget-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasickStore;->parents:Lcom/pkware/ahocorasick/SafeIndexable;

    invoke-virtual {v0, p1}, Lcom/pkware/ahocorasick/SafeIndexable;->safeGet(I)I

    move-result v0

    return v0
.end method

.method public final setBaseOffset(II)V
    .locals 1
    .param p1, "index"    # I
    .param p2, "value"    # I

    .line 52
    iget-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasickStore;->baseOffsets:Lcom/pkware/ahocorasick/SafeIndexable;

    invoke-virtual {v0, p1, p2}, Lcom/pkware/ahocorasick/SafeIndexable;->set(II)V

    return-void
.end method

.method public final setChildOffset(II)V
    .locals 1
    .param p1, "index"    # I
    .param p2, "value"    # I

    .line 91
    iget-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasickStore;->store2:Lcom/pkware/ahocorasick/SafeIndexable;

    invoke-virtual {v0, p1, p2}, Lcom/pkware/ahocorasick/SafeIndexable;->set(II)V

    return-void
.end method

.method public final setFailureIndex(II)V
    .locals 1
    .param p1, "index"    # I
    .param p2, "value"    # I

    .line 83
    iget-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasickStore;->store1:Lcom/pkware/ahocorasick/SafeIndexable;

    invoke-virtual {v0, p1, p2}, Lcom/pkware/ahocorasick/SafeIndexable;->set(II)V

    return-void
.end method

.method public final setNextSiblingOffset(II)V
    .locals 1
    .param p1, "index"    # I
    .param p2, "value"    # I

    .line 74
    iget-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasickStore;->store1:Lcom/pkware/ahocorasick/SafeIndexable;

    invoke-virtual {v0, p1, p2}, Lcom/pkware/ahocorasick/SafeIndexable;->set(II)V

    return-void
.end method

.method public final setParent(II)V
    .locals 1
    .param p1, "index"    # I
    .param p2, "value"    # I

    .line 59
    iget-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasickStore;->parents:Lcom/pkware/ahocorasick/SafeIndexable;

    invoke-virtual {v0, p1, p2}, Lcom/pkware/ahocorasick/SafeIndexable;->set(II)V

    return-void
.end method

.method public final setPrefixIndex(II)V
    .locals 1
    .param p1, "index"    # I
    .param p2, "value"    # I

    .line 106
    iget-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasickStore;->store2:Lcom/pkware/ahocorasick/SafeIndexable;

    invoke-virtual {v0, p1, p2}, Lcom/pkware/ahocorasick/SafeIndexable;->set(II)V

    return-void
.end method

.method public final setQueueIndex(II)V
    .locals 1
    .param p1, "index"    # I
    .param p2, "value"    # I

    .line 99
    iget-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasickStore;->store1:Lcom/pkware/ahocorasick/SafeIndexable;

    invoke-virtual {v0, p1, p2}, Lcom/pkware/ahocorasick/SafeIndexable;->set(II)V

    return-void
.end method

.method public final setValue(II)V
    .locals 1
    .param p1, "index"    # I
    .param p2, "value"    # I

    .line 66
    iget-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasickStore;->values:Lcom/pkware/ahocorasick/SafeIndexable;

    invoke-virtual {v0, p1, p2}, Lcom/pkware/ahocorasick/SafeIndexable;->set(II)V

    return-void
.end method

.method public final synchronizedSafeSet(IIIIII)V
    .locals 1
    .param p1, "index"    # I
    .param p2, "baseOffset"    # I
    .param p3, "parent"    # I
    .param p4, "value"    # I
    .param p5, "nextSibling"    # I
    .param p6, "childOffset"    # I

    .line 200
    iget-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasickStore;->baseOffsets:Lcom/pkware/ahocorasick/SafeIndexable;

    invoke-virtual {v0, p1, p2}, Lcom/pkware/ahocorasick/SafeIndexable;->safeSet(II)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 201
    iget-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasickStore;->parents:Lcom/pkware/ahocorasick/SafeIndexable;

    invoke-virtual {v0, p1, p3}, Lcom/pkware/ahocorasick/SafeIndexable;->safeSet(II)Z

    .line 202
    iget-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasickStore;->values:Lcom/pkware/ahocorasick/SafeIndexable;

    invoke-virtual {v0, p1, p4}, Lcom/pkware/ahocorasick/SafeIndexable;->safeSet(II)Z

    .line 203
    iget-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasickStore;->store1:Lcom/pkware/ahocorasick/SafeIndexable;

    invoke-virtual {v0, p1, p5}, Lcom/pkware/ahocorasick/SafeIndexable;->safeSet(II)Z

    .line 204
    iget-object v0, p0, Lcom/pkware/ahocorasick/AhoCorasickStore;->store2:Lcom/pkware/ahocorasick/SafeIndexable;

    invoke-virtual {v0, p1, p6}, Lcom/pkware/ahocorasick/SafeIndexable;->safeSet(II)Z

    goto :goto_0

    .line 206
    :cond_0
    invoke-virtual {p0, p1, p3}, Lcom/pkware/ahocorasick/AhoCorasickStore;->setParent(II)V

    .line 207
    invoke-virtual {p0, p1, p4}, Lcom/pkware/ahocorasick/AhoCorasickStore;->setValue(II)V

    .line 208
    invoke-virtual {p0, p1, p5}, Lcom/pkware/ahocorasick/AhoCorasickStore;->setNextSiblingOffset(II)V

    .line 209
    invoke-virtual {p0, p1, p6}, Lcom/pkware/ahocorasick/AhoCorasickStore;->setChildOffset(II)V

    .line 211
    :goto_0
    return-void
.end method
