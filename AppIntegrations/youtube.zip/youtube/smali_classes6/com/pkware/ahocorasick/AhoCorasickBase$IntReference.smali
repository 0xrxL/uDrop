.class final Lcom/pkware/ahocorasick/AhoCorasickBase$IntReference;
.super Ljava/lang/Object;
.source "AhoCorasickBase.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/pkware/ahocorasick/AhoCorasickBase;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "IntReference"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0008\n\u0002\u0008\u0005\u0008\u0002\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004R\u001a\u0010\u0002\u001a\u00020\u0003X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u0005\u0010\u0006\"\u0004\u0008\u0007\u0010\u0004\u00a8\u0006\u0008"
    }
    d2 = {
        "Lcom/pkware/ahocorasick/AhoCorasickBase$IntReference;",
        "",
        "value",
        "",
        "(I)V",
        "getValue",
        "()I",
        "setValue",
        "LowMemoryAhoCorasick"
    }
    k = 0x1
    mv = {
        0x1,
        0x9,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private value:I


# direct methods
.method public constructor <init>(I)V
    .locals 0
    .param p1, "value"    # I

    .line 944
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lcom/pkware/ahocorasick/AhoCorasickBase$IntReference;->value:I

    return-void
.end method


# virtual methods
.method public final getValue()I
    .locals 1

    .line 944
    iget v0, p0, Lcom/pkware/ahocorasick/AhoCorasickBase$IntReference;->value:I

    return v0
.end method

.method public final setValue(I)V
    .locals 0
    .param p1, "<set-?>"    # I

    .line 944
    iput p1, p0, Lcom/pkware/ahocorasick/AhoCorasickBase$IntReference;->value:I

    return-void
.end method
