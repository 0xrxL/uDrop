.class public final enum LuTools/uUtils$entries;
.super Ljava/lang/Enum;
.source "uUtils.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LuTools/uUtils;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "entries"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "LuTools/uUtils$entries;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[LuTools/uUtils$entries;

.field public static final enum ALL:LuTools/uUtils$entries;

.field public static final enum ANY:LuTools/uUtils$entries;


# direct methods
.method private static synthetic $values()[LuTools/uUtils$entries;
    .locals 2

    .line 42
    sget-object v0, LuTools/uUtils$entries;->ANY:LuTools/uUtils$entries;

    sget-object v1, LuTools/uUtils$entries;->ALL:LuTools/uUtils$entries;

    filled-new-array {v0, v1}, [LuTools/uUtils$entries;

    move-result-object v0

    return-object v0
.end method

.method static constructor <clinit>()V
    .locals 3

    .line 43
    new-instance v0, LuTools/uUtils$entries;

    const-string v1, "ANY"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, LuTools/uUtils$entries;-><init>(Ljava/lang/String;I)V

    sput-object v0, LuTools/uUtils$entries;->ANY:LuTools/uUtils$entries;

    .line 44
    new-instance v0, LuTools/uUtils$entries;

    const-string v1, "ALL"

    const/4 v2, 0x1

    invoke-direct {v0, v1, v2}, LuTools/uUtils$entries;-><init>(Ljava/lang/String;I)V

    sput-object v0, LuTools/uUtils$entries;->ALL:LuTools/uUtils$entries;

    .line 42
    invoke-static {}, LuTools/uUtils$entries;->$values()[LuTools/uUtils$entries;

    move-result-object v0

    sput-object v0, LuTools/uUtils$entries;->$VALUES:[LuTools/uUtils$entries;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 0
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            null,
            null
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 42
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)LuTools/uUtils$entries;
    .locals 1
    .param p0, "name"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            null
        }
    .end annotation

    .line 42
    const-class v0, LuTools/uUtils$entries;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v0

    check-cast v0, LuTools/uUtils$entries;

    return-object v0
.end method

.method public static values()[LuTools/uUtils$entries;
    .locals 1

    .line 42
    sget-object v0, LuTools/uUtils$entries;->$VALUES:[LuTools/uUtils$entries;

    invoke-virtual {v0}, [LuTools/uUtils$entries;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [LuTools/uUtils$entries;

    return-object v0
.end method
