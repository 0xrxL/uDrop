.class public LuTools/VideoDetails/uVideoDetailsRequest;
.super Ljava/lang/Object;
.source "uVideoDetailsRequest.java"


# static fields
.field private static final Cache:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "LuTools/VideoDetails/uVideoDetailsRequest;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final future:Ljava/util/concurrent/Future;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/Future<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private videoID:Ljava/lang/String;


# direct methods
.method public static synthetic $r8$lambda$N78LXxngQ87bP8BJhSc5dUEKRPc(LuTools/VideoDetails/uVideoDetailsRequest;)Ljava/lang/String;
    .locals 0

    invoke-direct {p0}, LuTools/VideoDetails/uVideoDetailsRequest;->lambda$new$0()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static constructor <clinit>()V
    .locals 2

    .line 37
    new-instance v0, LuTools/VideoDetails/uVideoDetailsRequest$1;

    const/16 v1, 0x64

    invoke-direct {v0, v1}, LuTools/VideoDetails/uVideoDetailsRequest$1;-><init>(I)V

    invoke-static {v0}, Ljava/util/Collections;->synchronizedMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object v0

    sput-object v0, LuTools/VideoDetails/uVideoDetailsRequest;->Cache:Ljava/util/Map;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .locals 1
    .param p1, "videoID"    # Ljava/lang/String;

    .line 29
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 33
    new-instance v0, LuTools/VideoDetails/uVideoDetailsRequest$$ExternalSyntheticLambda0;

    invoke-direct {v0, p0}, LuTools/VideoDetails/uVideoDetailsRequest$$ExternalSyntheticLambda0;-><init>(LuTools/VideoDetails/uVideoDetailsRequest;)V

    invoke-static {v0}, LuTools/uUtils;->SubmitOnBackgroundThread(Ljava/util/concurrent/Callable;)Ljava/util/concurrent/Future;

    move-result-object v0

    iput-object v0, p0, LuTools/VideoDetails/uVideoDetailsRequest;->future:Ljava/util/concurrent/Future;

    .line 30
    iput-object p1, p0, LuTools/VideoDetails/uVideoDetailsRequest;->videoID:Ljava/lang/String;

    .line 31
    return-void
.end method

.method private Fetch(Ljava/lang/String;)Ljava/lang/String;
    .locals 7
    .param p1, "videoID"    # Ljava/lang/String;

    .line 47
    invoke-static {}, LuTools/VideoDetails/uWebClientType;->values()[LuTools/VideoDetails/uWebClientType;

    move-result-object v0

    array-length v1, v0

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v1, :cond_1

    aget-object v3, v0, v2

    .line 48
    .local v3, "webClientType":LuTools/VideoDetails/uWebClientType;
    invoke-direct {p0, v3, p1}, LuTools/VideoDetails/uVideoDetailsRequest;->Send(LuTools/VideoDetails/uWebClientType;Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v4

    .line 50
    .local v4, "videoDetailsJson":Lorg/json/JSONObject;
    if-eqz v4, :cond_0

    .line 52
    :try_start_0
    const-string v5, "videoDetails"

    .line 53
    invoke-virtual {v4, v5}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v5

    const-string v6, "channelId"

    .line 54
    invoke-virtual {v5, v6}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 52
    return-object v0

    .line 55
    :catch_0
    move-exception v5

    .line 47
    .end local v3    # "webClientType":LuTools/VideoDetails/uWebClientType;
    .end local v4    # "videoDetailsJson":Lorg/json/JSONObject;
    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    .line 59
    :cond_1
    const/4 v0, 0x0

    return-object v0
.end method

.method public static GetRequestForVideoID(Ljava/lang/String;)LuTools/VideoDetails/uVideoDetailsRequest;
    .locals 2
    .param p0, "videoID"    # Ljava/lang/String;

    .line 75
    sget-object v0, LuTools/VideoDetails/uVideoDetailsRequest;->Cache:Ljava/util/Map;

    monitor-enter v0

    .line 76
    :try_start_0
    sget-object v1, LuTools/VideoDetails/uVideoDetailsRequest;->Cache:Ljava/util/Map;

    invoke-interface {v1, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LuTools/VideoDetails/uVideoDetailsRequest;

    monitor-exit v0

    return-object v1

    .line 77
    :catchall_0
    move-exception v1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v1
.end method

.method private Send(LuTools/VideoDetails/uWebClientType;Ljava/lang/String;)Lorg/json/JSONObject;
    .locals 5
    .param p1, "webClientType"    # LuTools/VideoDetails/uWebClientType;
    .param p2, "videoID"    # Ljava/lang/String;

    .line 82
    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 83
    invoke-static {p2}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 86
    :try_start_0
    sget-object v0, LuTools/uStreamSpoofing/uPlayerRoutes;->GET_VIDEO_DETAILS:LuTools/uStreamSpoofing/uRoute$CompiledRoute;

    invoke-static {v0, p1}, LuTools/uStreamSpoofing/uPlayerRoutes;->GetVideoDetailsResponseConnectionFromRoute(LuTools/uStreamSpoofing/uRoute$CompiledRoute;LuTools/VideoDetails/uWebClientType;)Ljava/net/HttpURLConnection;

    move-result-object v0

    .line 91
    .local v0, "connection":Ljava/net/HttpURLConnection;
    const/16 v1, 0x2710

    .line 92
    .local v1, "HTTP_TIMEOUT_MILLISECONDS":I
    invoke-virtual {v0, v1}, Ljava/net/HttpURLConnection;->setConnectTimeout(I)V

    .line 93
    invoke-virtual {v0, v1}, Ljava/net/HttpURLConnection;->setReadTimeout(I)V

    .line 95
    invoke-static {p1, p2}, LuTools/uStreamSpoofing/uPlayerRoutes;->CreateWebInnertubeBody(LuTools/VideoDetails/uWebClientType;Ljava/lang/String;)[B

    move-result-object v2

    .line 96
    .local v2, "requestBody":[B
    array-length v3, v2

    invoke-virtual {v0, v3}, Ljava/net/HttpURLConnection;->setFixedLengthStreamingMode(I)V

    .line 97
    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/io/OutputStream;->write([B)V

    .line 99
    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v3

    .line 100
    .local v3, "responseCode":I
    const/16 v4, 0xc8

    if-ne v3, v4, :cond_0

    .line 101
    invoke-static {v0}, LuTools/uStreamSpoofing/uRequester;->parseJSONObject(Ljava/net/HttpURLConnection;)Lorg/json/JSONObject;

    move-result-object v4
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v4

    .line 100
    .end local v0    # "connection":Ljava/net/HttpURLConnection;
    .end local v1    # "HTTP_TIMEOUT_MILLISECONDS":I
    .end local v2    # "requestBody":[B
    .end local v3    # "responseCode":I
    :cond_0
    goto :goto_0

    .line 103
    :catch_0
    move-exception v0

    :goto_0
    nop

    .line 105
    const/4 v0, 0x0

    return-object v0
.end method

.method public static SetFetchRequest(Ljava/lang/String;)V
    .locals 2
    .param p0, "videoID"    # Ljava/lang/String;

    .line 63
    sget-object v0, LuTools/VideoDetails/uVideoDetailsRequest;->Cache:Ljava/util/Map;

    new-instance v1, LuTools/VideoDetails/uVideoDetailsRequest;

    invoke-direct {v1, p0}, LuTools/VideoDetails/uVideoDetailsRequest;-><init>(Ljava/lang/String;)V

    invoke-interface {v0, p0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 64
    return-void
.end method

.method private synthetic lambda$new$0()Ljava/lang/String;
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 34
    iget-object v0, p0, LuTools/VideoDetails/uVideoDetailsRequest;->videoID:Ljava/lang/String;

    invoke-direct {p0, v0}, LuTools/VideoDetails/uVideoDetailsRequest;->Fetch(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method


# virtual methods
.method public GetChannelID()Ljava/lang/String;
    .locals 4

    .line 68
    :try_start_0
    iget-object v0, p0, LuTools/VideoDetails/uVideoDetailsRequest;->future:Ljava/util/concurrent/Future;

    sget-object v1, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v2, 0x4e20

    invoke-interface {v0, v2, v3, v1}, Ljava/util/concurrent/Future;->get(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;
    :try_end_0
    .catch Ljava/util/concurrent/TimeoutException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    .line 69
    :catch_0
    move-exception v0

    .line 71
    const/4 v0, 0x0

    return-object v0
.end method
