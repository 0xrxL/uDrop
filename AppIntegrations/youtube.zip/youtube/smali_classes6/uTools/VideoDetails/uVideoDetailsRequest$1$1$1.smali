.class LuTools/VideoDetails/uVideoDetailsRequest$1$1$1;
.super Lorg/json/JSONObject;
.source "uVideoDetailsRequest.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LuTools/VideoDetails/uVideoDetailsRequest$1$1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$2:LuTools/VideoDetails/uVideoDetailsRequest$1$1;


# direct methods
.method constructor <init>(LuTools/VideoDetails/uVideoDetailsRequest$1$1;)V
    .locals 2
    .param p1, "this$2"    # LuTools/VideoDetails/uVideoDetailsRequest$1$1;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lorg/json/JSONException;
        }
    .end annotation

    .line 67
    iput-object p1, p0, LuTools/VideoDetails/uVideoDetailsRequest$1$1$1;->this$2:LuTools/VideoDetails/uVideoDetailsRequest$1$1;

    invoke-direct {p0}, Lorg/json/JSONObject;-><init>()V

    .line 68
    iget-object v0, p0, LuTools/VideoDetails/uVideoDetailsRequest$1$1$1;->this$2:LuTools/VideoDetails/uVideoDetailsRequest$1$1;

    iget-object v0, v0, LuTools/VideoDetails/uVideoDetailsRequest$1$1;->this$1:LuTools/VideoDetails/uVideoDetailsRequest$1;

    iget-object v0, v0, LuTools/VideoDetails/uVideoDetailsRequest$1;->val$webClientType:LuTools/VideoDetails/uWebClientType;

    invoke-virtual {v0}, LuTools/VideoDetails/uWebClientType;->name()Ljava/lang/String;

    move-result-object v0

    const-string v1, "clientName"

    invoke-virtual {p0, v1, v0}, LuTools/VideoDetails/uVideoDetailsRequest$1$1$1;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 69
    iget-object v0, p0, LuTools/VideoDetails/uVideoDetailsRequest$1$1$1;->this$2:LuTools/VideoDetails/uVideoDetailsRequest$1$1;

    iget-object v0, v0, LuTools/VideoDetails/uVideoDetailsRequest$1$1;->this$1:LuTools/VideoDetails/uVideoDetailsRequest$1;

    iget-object v0, v0, LuTools/VideoDetails/uVideoDetailsRequest$1;->val$webClientType:LuTools/VideoDetails/uWebClientType;

    iget-object v0, v0, LuTools/VideoDetails/uWebClientType;->clientVersion:Ljava/lang/String;

    const-string v1, "clientVersion"

    invoke-virtual {p0, v1, v0}, LuTools/VideoDetails/uVideoDetailsRequest$1$1$1;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 67
    return-void
.end method
