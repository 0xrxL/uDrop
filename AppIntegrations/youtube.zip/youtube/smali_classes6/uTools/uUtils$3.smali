.class LuTools/uUtils$3;
.super Ljava/util/HashSet;
.source "uUtils.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LuTools/uUtils;->SearchInSetCorasick(Ljava/lang/String;Ljava/util/AbstractMap$SimpleEntry;LuTools/uUtils$entries;)Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/util/HashSet<",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic val$foundResults:Ljava/util/List;


# direct methods
.method constructor <init>(Ljava/util/List;)V
    .locals 2

    .line 253
    iput-object p1, p0, LuTools/uUtils$3;->val$foundResults:Ljava/util/List;

    invoke-direct {p0}, Ljava/util/HashSet;-><init>()V

    .line 254
    iget-object p1, p0, LuTools/uUtils$3;->val$foundResults:Ljava/util/List;

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Hit;

    .line 255
    .local v0, "hit":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Hit;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Hit<Ljava/lang/String;>;"
    iget-object v1, v0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Hit;->value:Ljava/lang/Object;

    invoke-virtual {p0, v1}, LuTools/uUtils$3;->add(Ljava/lang/Object;)Z

    .line 256
    .end local v0    # "hit":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Hit;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Hit<Ljava/lang/String;>;"
    goto :goto_0

    .line 253
    :cond_0
    return-void
.end method
