.class public final enum LuTools/uStreamSpoofing/uClientType;
.super Ljava/lang/Enum;
.source "uClientType.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "LuTools/uStreamSpoofing/uClientType;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[LuTools/uStreamSpoofing/uClientType;

.field public static final enum ANDROID_CREATOR:LuTools/uStreamSpoofing/uClientType;

.field public static final enum ANDROID_UNPLUGGED:LuTools/uStreamSpoofing/uClientType;

.field public static final enum ANDROID_VR:LuTools/uStreamSpoofing/uClientType;


# instance fields
.field public final androidSDKVersion:Ljava/lang/String;

.field public final clientID:I

.field public final clientVersion:Ljava/lang/String;

.field public final cronetVersion:Ljava/lang/String;

.field public final defaultLocale:Ljava/util/Locale;

.field public final deviceModel:Ljava/lang/String;

.field public final gmsCoreVersionCode:Ljava/lang/String;

.field public final osBrand:Ljava/lang/String;

.field public final osBuildID:Ljava/lang/String;

.field public final osName:Ljava/lang/String;

.field public final osVersion:Ljava/lang/String;

.field public final userAgent:Ljava/lang/String;


# direct methods
.method private static synthetic $values()[LuTools/uStreamSpoofing/uClientType;
    .locals 3

    .line 9
    sget-object v0, LuTools/uStreamSpoofing/uClientType;->ANDROID_CREATOR:LuTools/uStreamSpoofing/uClientType;

    sget-object v1, LuTools/uStreamSpoofing/uClientType;->ANDROID_UNPLUGGED:LuTools/uStreamSpoofing/uClientType;

    sget-object v2, LuTools/uStreamSpoofing/uClientType;->ANDROID_VR:LuTools/uStreamSpoofing/uClientType;

    filled-new-array {v0, v1, v2}, [LuTools/uStreamSpoofing/uClientType;

    move-result-object v0

    return-object v0
.end method

.method static constructor <clinit>()V
    .locals 29

    .line 10
    new-instance v14, LuTools/uStreamSpoofing/uClientType;

    const-string v12, "Android"

    const-string v13, "15"

    const-string v1, "ANDROID_CREATOR"

    const/4 v2, 0x0

    const-string v3, "35"

    const/16 v4, 0xe

    const-string v5, "com.google.android.apps.youtube.creator"

    const-string v6, "25.08.100"

    const-string v7, "135.0.7037.2"

    const-string v8, "Pixel 9 Pro Fold"

    const-string v9, "244738035"

    const-string v10, "Google"

    const-string v11, "AP3A.241005.015.A2"

    move-object v0, v14

    invoke-direct/range {v0 .. v13}, LuTools/uStreamSpoofing/uClientType;-><init>(Ljava/lang/String;ILjava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    sput-object v14, LuTools/uStreamSpoofing/uClientType;->ANDROID_CREATOR:LuTools/uStreamSpoofing/uClientType;

    .line 23
    new-instance v0, LuTools/uStreamSpoofing/uClientType;

    const-string v27, "Android"

    const-string v28, "14"

    const-string v16, "ANDROID_UNPLUGGED"

    const/16 v17, 0x1

    const-string v18, "34"

    const/16 v19, 0x1d

    const-string v20, "com.google.android.apps.youtube.unplugged"

    const-string v21, "9.08.0"

    const-string v22, "135.0.7037.2"

    const-string v23, "Google TV Streamer"

    const-string v24, "244336107"

    const-string v25, "Google"

    const-string v26, "UTT3.240625.001.K5"

    move-object v15, v0

    invoke-direct/range {v15 .. v28}, LuTools/uStreamSpoofing/uClientType;-><init>(Ljava/lang/String;ILjava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    sput-object v0, LuTools/uStreamSpoofing/uClientType;->ANDROID_UNPLUGGED:LuTools/uStreamSpoofing/uClientType;

    .line 36
    new-instance v0, LuTools/uStreamSpoofing/uClientType;

    const-string v13, "Android"

    const-string v14, "14"

    const-string v2, "ANDROID_VR"

    const/4 v3, 0x2

    const-string v4, "34"

    const/16 v5, 0x1c

    const-string v6, "com.google.android.apps.youtube.vr.pico"

    const-string v7, "1.62.27"

    const-string v8, "135.0.7037.2"

    const-string v9, "A9210"

    const/4 v10, 0x0

    const-string v11, "Pico"

    const-string v12, "UKQ1.240321.001"

    move-object v1, v0

    invoke-direct/range {v1 .. v14}, LuTools/uStreamSpoofing/uClientType;-><init>(Ljava/lang/String;ILjava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    sput-object v0, LuTools/uStreamSpoofing/uClientType;->ANDROID_VR:LuTools/uStreamSpoofing/uClientType;

    .line 9
    invoke-static {}, LuTools/uStreamSpoofing/uClientType;->$values()[LuTools/uStreamSpoofing/uClientType;

    move-result-object v0

    sput-object v0, LuTools/uStreamSpoofing/uClientType;->$VALUES:[LuTools/uStreamSpoofing/uClientType;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;ILjava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 16
    .param p3, "androidSDKVersion"    # Ljava/lang/String;
    .param p4, "clientID"    # I
    .param p5, "clientPackageName"    # Ljava/lang/String;
    .param p6, "clientVersion"    # Ljava/lang/String;
    .param p7, "cronetVersion"    # Ljava/lang/String;
    .param p8, "deviceModel"    # Ljava/lang/String;
    .param p9, "gmsCoreVersionCode"    # Ljava/lang/String;
    .param p10, "osBrand"    # Ljava/lang/String;
    .param p11, "osBuildID"    # Ljava/lang/String;
    .param p12, "osName"    # Ljava/lang/String;
    .param p13, "osVersion"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "I",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 68
    move-object/from16 v0, p0

    invoke-direct/range {p0 .. p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 69
    move-object/from16 v1, p3

    iput-object v1, v0, LuTools/uStreamSpoofing/uClientType;->androidSDKVersion:Ljava/lang/String;

    .line 70
    move/from16 v2, p4

    iput v2, v0, LuTools/uStreamSpoofing/uClientType;->clientID:I

    .line 71
    move-object/from16 v10, p6

    iput-object v10, v0, LuTools/uStreamSpoofing/uClientType;->clientVersion:Ljava/lang/String;

    .line 72
    move-object/from16 v11, p7

    iput-object v11, v0, LuTools/uStreamSpoofing/uClientType;->cronetVersion:Ljava/lang/String;

    .line 73
    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v3

    iput-object v3, v0, LuTools/uStreamSpoofing/uClientType;->defaultLocale:Ljava/util/Locale;

    .line 74
    move-object/from16 v12, p8

    iput-object v12, v0, LuTools/uStreamSpoofing/uClientType;->deviceModel:Ljava/lang/String;

    .line 75
    move-object/from16 v13, p9

    iput-object v13, v0, LuTools/uStreamSpoofing/uClientType;->gmsCoreVersionCode:Ljava/lang/String;

    .line 76
    move-object/from16 v14, p10

    iput-object v14, v0, LuTools/uStreamSpoofing/uClientType;->osBrand:Ljava/lang/String;

    .line 77
    move-object/from16 v15, p11

    iput-object v15, v0, LuTools/uStreamSpoofing/uClientType;->osBuildID:Ljava/lang/String;

    .line 78
    move-object/from16 v9, p12

    iput-object v9, v0, LuTools/uStreamSpoofing/uClientType;->osName:Ljava/lang/String;

    .line 79
    move-object/from16 v8, p13

    iput-object v8, v0, LuTools/uStreamSpoofing/uClientType;->osVersion:Ljava/lang/String;

    .line 80
    iget-object v6, v0, LuTools/uStreamSpoofing/uClientType;->defaultLocale:Ljava/util/Locale;

    move-object/from16 v3, p5

    move-object/from16 v4, p6

    move-object/from16 v5, p13

    move-object/from16 v7, p8

    move-object/from16 v8, p11

    move-object/from16 v9, p7

    filled-new-array/range {v3 .. v9}, [Ljava/lang/Object;

    move-result-object v3

    .line 81
    const-string v4, "%s/%s (Linux; U; Android %s; %s; %s; Build/%s; Cronet/%s)"

    invoke-static {v4, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    iput-object v3, v0, LuTools/uStreamSpoofing/uClientType;->userAgent:Ljava/lang/String;

    .line 92
    return-void
.end method

.method public static valueOf(Ljava/lang/String;)LuTools/uStreamSpoofing/uClientType;
    .locals 1
    .param p0, "name"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            null
        }
    .end annotation

    .line 9
    const-class v0, LuTools/uStreamSpoofing/uClientType;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v0

    check-cast v0, LuTools/uStreamSpoofing/uClientType;

    return-object v0
.end method

.method public static values()[LuTools/uStreamSpoofing/uClientType;
    .locals 1

    .line 9
    sget-object v0, LuTools/uStreamSpoofing/uClientType;->$VALUES:[LuTools/uStreamSpoofing/uClientType;

    invoke-virtual {v0}, [LuTools/uStreamSpoofing/uClientType;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [LuTools/uStreamSpoofing/uClientType;

    return-object v0
.end method
