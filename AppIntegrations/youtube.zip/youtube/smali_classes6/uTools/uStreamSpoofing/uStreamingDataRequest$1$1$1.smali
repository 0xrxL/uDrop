.class LuTools/uStreamSpoofing/uStreamingDataRequest$1$1$1;
.super Lorg/json/JSONObject;
.source "uStreamingDataRequest.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$2:LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;


# direct methods
.method constructor <init>(LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;)V
    .locals 2
    .param p1, "this$2"    # LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lorg/json/JSONException;
        }
    .end annotation

    .line 95
    iput-object p1, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1$1;->this$2:LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;

    invoke-direct {p0}, Lorg/json/JSONObject;-><init>()V

    .line 96
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1$1;->this$2:LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;

    iget-object v0, v0, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;->this$1:LuTools/uStreamSpoofing/uStreamingDataRequest$1;

    iget-object v0, v0, LuTools/uStreamSpoofing/uStreamingDataRequest$1;->val$clientType:LuTools/uStreamSpoofing/uClientType;

    invoke-virtual {v0}, LuTools/uStreamSpoofing/uClientType;->name()Ljava/lang/String;

    move-result-object v0

    const-string v1, "clientName"

    invoke-virtual {p0, v1, v0}, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1$1;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 97
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1$1;->this$2:LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;

    iget-object v0, v0, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;->this$1:LuTools/uStreamSpoofing/uStreamingDataRequest$1;

    iget-object v0, v0, LuTools/uStreamSpoofing/uStreamingDataRequest$1;->val$clientType:LuTools/uStreamSpoofing/uClientType;

    iget-object v0, v0, LuTools/uStreamSpoofing/uClientType;->clientVersion:Ljava/lang/String;

    const-string v1, "clientVersion"

    invoke-virtual {p0, v1, v0}, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1$1;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 98
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1$1;->this$2:LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;

    iget-object v0, v0, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;->this$1:LuTools/uStreamSpoofing/uStreamingDataRequest$1;

    iget-object v0, v0, LuTools/uStreamSpoofing/uStreamingDataRequest$1;->val$clientType:LuTools/uStreamSpoofing/uClientType;

    iget-object v0, v0, LuTools/uStreamSpoofing/uClientType;->osBrand:Ljava/lang/String;

    const-string v1, "deviceMake"

    invoke-virtual {p0, v1, v0}, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1$1;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 99
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1$1;->this$2:LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;

    iget-object v0, v0, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;->this$1:LuTools/uStreamSpoofing/uStreamingDataRequest$1;

    iget-object v0, v0, LuTools/uStreamSpoofing/uStreamingDataRequest$1;->val$clientType:LuTools/uStreamSpoofing/uClientType;

    iget-object v0, v0, LuTools/uStreamSpoofing/uClientType;->deviceModel:Ljava/lang/String;

    const-string v1, "deviceModel"

    invoke-virtual {p0, v1, v0}, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1$1;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 100
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1$1;->this$2:LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;

    iget-object v0, v0, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;->this$1:LuTools/uStreamSpoofing/uStreamingDataRequest$1;

    iget-object v0, v0, LuTools/uStreamSpoofing/uStreamingDataRequest$1;->val$clientType:LuTools/uStreamSpoofing/uClientType;

    iget-object v0, v0, LuTools/uStreamSpoofing/uClientType;->defaultLocale:Ljava/util/Locale;

    invoke-virtual {v0}, Ljava/util/Locale;->getLanguage()Ljava/lang/String;

    move-result-object v0

    const-string v1, "hl"

    invoke-virtual {p0, v1, v0}, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1$1;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 101
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1$1;->this$2:LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;

    iget-object v0, v0, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;->this$1:LuTools/uStreamSpoofing/uStreamingDataRequest$1;

    iget-object v0, v0, LuTools/uStreamSpoofing/uStreamingDataRequest$1;->val$clientType:LuTools/uStreamSpoofing/uClientType;

    iget-object v0, v0, LuTools/uStreamSpoofing/uClientType;->defaultLocale:Ljava/util/Locale;

    invoke-virtual {v0}, Ljava/util/Locale;->getCountry()Ljava/lang/String;

    move-result-object v0

    const-string v1, "gl"

    invoke-virtual {p0, v1, v0}, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1$1;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 102
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1$1;->this$2:LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;

    iget-object v0, v0, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;->this$1:LuTools/uStreamSpoofing/uStreamingDataRequest$1;

    iget-object v0, v0, LuTools/uStreamSpoofing/uStreamingDataRequest$1;->val$clientType:LuTools/uStreamSpoofing/uClientType;

    iget-object v0, v0, LuTools/uStreamSpoofing/uClientType;->osName:Ljava/lang/String;

    const-string v1, "osName"

    invoke-virtual {p0, v1, v0}, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1$1;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 103
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1$1;->this$2:LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;

    iget-object v0, v0, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;->this$1:LuTools/uStreamSpoofing/uStreamingDataRequest$1;

    iget-object v0, v0, LuTools/uStreamSpoofing/uStreamingDataRequest$1;->val$clientType:LuTools/uStreamSpoofing/uClientType;

    iget-object v0, v0, LuTools/uStreamSpoofing/uClientType;->osVersion:Ljava/lang/String;

    const-string v1, "osVersion"

    invoke-virtual {p0, v1, v0}, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1$1;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 104
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1$1;->this$2:LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;

    iget-object v0, v0, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;->this$1:LuTools/uStreamSpoofing/uStreamingDataRequest$1;

    iget-object v0, v0, LuTools/uStreamSpoofing/uStreamingDataRequest$1;->val$clientType:LuTools/uStreamSpoofing/uClientType;

    iget-object v0, v0, LuTools/uStreamSpoofing/uClientType;->androidSDKVersion:Ljava/lang/String;

    if-eqz v0, :cond_0

    .line 105
    iget-object v0, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1$1;->this$2:LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;

    iget-object v0, v0, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;->this$1:LuTools/uStreamSpoofing/uStreamingDataRequest$1;

    iget-object v0, v0, LuTools/uStreamSpoofing/uStreamingDataRequest$1;->val$clientType:LuTools/uStreamSpoofing/uClientType;

    iget-object v0, v0, LuTools/uStreamSpoofing/uClientType;->androidSDKVersion:Ljava/lang/String;

    const-string v1, "androidSdkVersion"

    invoke-virtual {p0, v1, v0}, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1$1;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 95
    :cond_0
    return-void
.end method
