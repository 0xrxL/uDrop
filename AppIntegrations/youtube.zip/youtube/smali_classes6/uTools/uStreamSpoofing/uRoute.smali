.class public LuTools/uStreamSpoofing/uRoute;
.super Ljava/lang/Object;
.source "uRoute.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LuTools/uStreamSpoofing/uRoute$Method;,
        LuTools/uStreamSpoofing/uRoute$CompiledRoute;
    }
.end annotation


# instance fields
.field private final method:LuTools/uStreamSpoofing/uRoute$Method;

.field private final paramCount:I

.field private final route:Ljava/lang/String;


# direct methods
.method static bridge synthetic -$$Nest$fgetmethod(LuTools/uStreamSpoofing/uRoute;)LuTools/uStreamSpoofing/uRoute$Method;
    .locals 0

    iget-object p0, p0, LuTools/uStreamSpoofing/uRoute;->method:LuTools/uStreamSpoofing/uRoute$Method;

    return-object p0
.end method

.method public constructor <init>(LuTools/uStreamSpoofing/uRoute$Method;Ljava/lang/String;)V
    .locals 3
    .param p1, "method"    # LuTools/uStreamSpoofing/uRoute$Method;
    .param p2, "route"    # Ljava/lang/String;

    .line 12
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 13
    iput-object p1, p0, LuTools/uStreamSpoofing/uRoute;->method:LuTools/uStreamSpoofing/uRoute$Method;

    .line 14
    iput-object p2, p0, LuTools/uStreamSpoofing/uRoute;->route:Ljava/lang/String;

    .line 15
    invoke-virtual {p2}, Ljava/lang/String;->toCharArray()[C

    move-result-object v0

    invoke-static {v0}, Ljava/util/Collections;->singleton(Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v0

    const/16 v1, 0x7b

    invoke-static {v1}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v1

    invoke-static {v0, v1}, Ljava/util/Collections;->frequency(Ljava/util/Collection;Ljava/lang/Object;)I

    move-result v0

    iput v0, p0, LuTools/uStreamSpoofing/uRoute;->paramCount:I

    .line 17
    iget v0, p0, LuTools/uStreamSpoofing/uRoute;->paramCount:I

    invoke-virtual {p2}, Ljava/lang/String;->toCharArray()[C

    move-result-object v1

    invoke-static {v1}, Ljava/util/Collections;->singleton(Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v1

    const/16 v2, 0x7d

    invoke-static {v2}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v2

    invoke-static {v1, v2}, Ljava/util/Collections;->frequency(Ljava/util/Collection;Ljava/lang/Object;)I

    move-result v1

    if-ne v0, v1, :cond_0

    .line 20
    return-void

    .line 18
    :cond_0
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Not enough parameters"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method


# virtual methods
.method public varargs Compile([Ljava/lang/String;)LuTools/uStreamSpoofing/uRoute$CompiledRoute;
    .locals 7
    .param p1, "params"    # [Ljava/lang/String;

    .line 23
    array-length v0, p1

    iget v1, p0, LuTools/uStreamSpoofing/uRoute;->paramCount:I

    if-ne v0, v1, :cond_1

    .line 35
    new-instance v0, Ljava/lang/StringBuilder;

    iget-object v1, p0, LuTools/uStreamSpoofing/uRoute;->route:Ljava/lang/String;

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 36
    .local v0, "compiledRoute":Ljava/lang/StringBuilder;
    array-length v1, p1

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v1, :cond_0

    aget-object v3, p1, v2

    .line 37
    .local v3, "param":Ljava/lang/String;
    const-string v4, "{"

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->indexOf(Ljava/lang/String;)I

    move-result v4

    .line 38
    .local v4, "paramStart":I
    const-string v5, "}"

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->indexOf(Ljava/lang/String;)I

    move-result v5

    .line 40
    .local v5, "paramEnd":I
    add-int/lit8 v6, v5, 0x1

    invoke-virtual {v0, v4, v6, v3}, Ljava/lang/StringBuilder;->replace(IILjava/lang/String;)Ljava/lang/StringBuilder;

    .line 36
    .end local v3    # "param":Ljava/lang/String;
    .end local v4    # "paramStart":I
    .end local v5    # "paramEnd":I
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    .line 43
    :cond_0
    new-instance v1, LuTools/uStreamSpoofing/uRoute$CompiledRoute;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x0

    invoke-direct {v1, p0, v2, v3}, LuTools/uStreamSpoofing/uRoute$CompiledRoute;-><init>(LuTools/uStreamSpoofing/uRoute;Ljava/lang/String;LuTools/uStreamSpoofing/uRoute-IA;)V

    return-object v1

    .line 24
    .end local v0    # "compiledRoute":Ljava/lang/StringBuilder;
    :cond_1
    new-instance v0, Ljava/lang/IllegalArgumentException;

    iget-object v1, p0, LuTools/uStreamSpoofing/uRoute;->route:Ljava/lang/String;

    iget v2, p0, LuTools/uStreamSpoofing/uRoute;->paramCount:I

    .line 29
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    array-length v3, p1

    .line 30
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    filled-new-array {v1, v2, v3}, [Ljava/lang/Object;

    move-result-object v1

    .line 25
    const-string v2, "Error compiling route [%s], incorrect amount of parameters provided. Expected: %s, provided: %s"

    invoke-static {v2, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method
