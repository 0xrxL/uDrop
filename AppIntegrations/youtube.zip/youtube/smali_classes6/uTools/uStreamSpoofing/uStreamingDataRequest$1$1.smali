.class LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;
.super Lorg/json/JSONObject;
.source "uStreamingDataRequest.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LuTools/uStreamSpoofing/uStreamingDataRequest$1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:LuTools/uStreamSpoofing/uStreamingDataRequest$1;


# direct methods
.method constructor <init>(LuTools/uStreamSpoofing/uStreamingDataRequest$1;)V
    .locals 2
    .param p1, "this$1"    # LuTools/uStreamSpoofing/uStreamingDataRequest$1;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lorg/json/JSONException;
        }
    .end annotation

    .line 91
    iput-object p1, p0, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;->this$1:LuTools/uStreamSpoofing/uStreamingDataRequest$1;

    invoke-direct {p0}, Lorg/json/JSONObject;-><init>()V

    .line 92
    new-instance v0, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1$1;

    invoke-direct {v0, p0}, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1$1;-><init>(LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;)V

    const-string v1, "client"

    invoke-virtual {p0, v1, v0}, LuTools/uStreamSpoofing/uStreamingDataRequest$1$1;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 91
    return-void
.end method
