.class public LuTools/uBlocker;
.super Ljava/lang/Object;
.source "uBlocker.java"


# static fields
.field private static final DARK_COLORS:Ljava/util/AbstractMap$SimpleEntry;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/AbstractMap$SimpleEntry<",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static final LIGHT_COLORS:Ljava/util/AbstractMap$SimpleEntry;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/AbstractMap$SimpleEntry<",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static final WHITE_COLOR:I = 0xffffff

.field public static captionsButton:Z = false

.field private static final checkMicroGPackageToastError:Landroid/widget/Toast;

.field private static final commentsComponents:Ljava/util/AbstractMap$SimpleEntry;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/AbstractMap$SimpleEntry<",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field public static currentNavBarIndex:I = 0x0

.field private static final generalComponents:Ljava/util/AbstractMap$SimpleEntry;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/AbstractMap$SimpleEntry<",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field public static hideWelcomeAndRules:Z = false

.field private static final horizontalShelfFirst:Ljava/util/AbstractMap$SimpleEntry;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/AbstractMap$SimpleEntry<",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static final horizontalShelfSecond:Ljava/util/AbstractMap$SimpleEntry;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/AbstractMap$SimpleEntry<",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static final libraryNavButtonIndex:I = 0x4

.field private static moreDrawerAppsAndInfo:Z

.field public static navigationBarPivot:Ljava/lang/Enum;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Enum<",
            "*>;"
        }
    .end annotation
.end field

.field private static final openCommentsButtonComponents:Ljava/util/AbstractMap$SimpleEntry;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/AbstractMap$SimpleEntry<",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static openVideoChannelThread:Ljava/lang/Thread;

.field private static final openVideoChannelToastDone:Landroid/widget/Toast;

.field private static final openVideoChannelToastError:Landroid/widget/Toast;

.field private static final openVideoChannelToastInProgress:Landroid/widget/Toast;

.field private static preferredQuality:Ljava/lang/Integer;

.field public static protoBufferComponents:Ljava/nio/ByteBuffer;

.field private static qualityNeedsUpdating:Z

.field private static quickQualityBottomSheet:Z

.field private static final sponsorShipPanelComponents:Ljava/util/AbstractMap$SimpleEntry;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/AbstractMap$SimpleEntry<",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field public static topBarPivot:Ljava/lang/Enum;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Enum<",
            "*>;"
        }
    .end annotation
.end field

.field private static final topbarButtons:Ljava/util/AbstractMap$SimpleEntry;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/AbstractMap$SimpleEntry<",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static final videoInformationPanelComponents:Ljava/util/AbstractMap$SimpleEntry;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/AbstractMap$SimpleEntry<",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static final videoLookupComponents:Ljava/util/AbstractMap$SimpleEntry;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/AbstractMap$SimpleEntry<",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static final videoOtherSettingsPanelComponent:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static videoQualities:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 8

    .line 45
    const/4 v0, 0x0

    sput-boolean v0, LuTools/uBlocker;->captionsButton:Z

    .line 47
    new-instance v1, Ljava/util/AbstractMap$SimpleEntry;

    .line 50
    const-string v2, "-1"

    const-string v3, "-394759"

    const-string v4, "-83886081"

    invoke-static {v2, v3, v4}, Ljava/util/Set;->of(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v2

    const-string v3, "LIGHT_COLORS"

    invoke-direct {v1, v2, v3}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 48
    invoke-static {v1}, LuTools/uUtils;->InitializeNewBlockList(Ljava/util/AbstractMap$SimpleEntry;)Ljava/util/AbstractMap$SimpleEntry;

    move-result-object v1

    sput-object v1, LuTools/uBlocker;->LIGHT_COLORS:Ljava/util/AbstractMap$SimpleEntry;

    .line 59
    new-instance v1, Ljava/util/AbstractMap$SimpleEntry;

    .line 62
    const-string v2, "-14145496"

    const-string v3, "-14606047"

    const-string v4, "-15198184"

    const-string v5, "-15790321"

    const-string v6, "-98492127"

    invoke-static {v2, v3, v4, v5, v6}, Ljava/util/Set;->of(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v2

    const-string v3, "DARK_COLORS"

    invoke-direct {v1, v2, v3}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 60
    invoke-static {v1}, LuTools/uUtils;->InitializeNewBlockList(Ljava/util/AbstractMap$SimpleEntry;)Ljava/util/AbstractMap$SimpleEntry;

    move-result-object v1

    sput-object v1, LuTools/uBlocker;->DARK_COLORS:Ljava/util/AbstractMap$SimpleEntry;

    .line 87
    nop

    .line 88
    const-string v1, "Error: No MicroG Installed"

    invoke-static {v1}, LuTools/uUtils;->GetNewToast(Ljava/lang/String;)Landroid/widget/Toast;

    move-result-object v1

    sput-object v1, LuTools/uBlocker;->checkMicroGPackageToastError:Landroid/widget/Toast;

    .line 113
    new-instance v1, Ljava/util/AbstractMap$SimpleEntry;

    .line 116
    const-string v2, "composer_short_creation_button"

    const-string v3, "composer_timestamp_button"

    const-string v4, "super_thanks_button"

    const-string v5, "|CellType|ContainerType|ContainerType|ContainerType|ContainerType|ContainerType|"

    invoke-static {v2, v3, v4, v5}, Ljava/util/Set;->of(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v2

    const-string v3, "commentsComponents"

    invoke-direct {v1, v2, v3}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 114
    invoke-static {v1}, LuTools/uUtils;->InitializeNewBlockList(Ljava/util/AbstractMap$SimpleEntry;)Ljava/util/AbstractMap$SimpleEntry;

    move-result-object v1

    sput-object v1, LuTools/uBlocker;->commentsComponents:Ljava/util/AbstractMap$SimpleEntry;

    .line 126
    new-instance v1, Ljava/util/AbstractMap$SimpleEntry;

    .line 129
    const-string v2, "cell_divider"

    const-string v3, "horizontal_video_shelf"

    const-string v4, "horizontal_shelf."

    invoke-static {v2, v3, v4}, Ljava/util/Set;->of(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v2

    const-string v3, "horizontalShelfFirst"

    invoke-direct {v1, v2, v3}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 127
    invoke-static {v1}, LuTools/uUtils;->InitializeNewBlockList(Ljava/util/AbstractMap$SimpleEntry;)Ljava/util/AbstractMap$SimpleEntry;

    move-result-object v1

    sput-object v1, LuTools/uBlocker;->horizontalShelfFirst:Ljava/util/AbstractMap$SimpleEntry;

    .line 138
    new-instance v1, Ljava/util/AbstractMap$SimpleEntry;

    .line 141
    const-string v2, "WATCH_WHILE_FULLSCREEN"

    const-string v3, "WATCH_WHILE_MAXIMIZED"

    invoke-static {v2, v3}, Ljava/util/Set;->of(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v2

    const-string v3, "horizontalShelfSecond"

    invoke-direct {v1, v2, v3}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 139
    invoke-static {v1}, LuTools/uUtils;->InitializeNewBlockList(Ljava/util/AbstractMap$SimpleEntry;)Ljava/util/AbstractMap$SimpleEntry;

    move-result-object v1

    sput-object v1, LuTools/uBlocker;->horizontalShelfSecond:Ljava/util/AbstractMap$SimpleEntry;

    .line 149
    new-instance v1, Ljava/util/AbstractMap$SimpleEntry;

    .line 152
    const-string v2, "carousel_header"

    const-string v3, "|ContainerType|ContainerType|ContainerType|"

    invoke-static {v2, v3}, Ljava/util/Set;->of(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v2

    const-string v3, "openCommentsButtonComponents"

    invoke-direct {v1, v2, v3}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 150
    invoke-static {v1}, LuTools/uUtils;->InitializeNewBlockList(Ljava/util/AbstractMap$SimpleEntry;)Ljava/util/AbstractMap$SimpleEntry;

    move-result-object v1

    sput-object v1, LuTools/uBlocker;->openCommentsButtonComponents:Ljava/util/AbstractMap$SimpleEntry;

    .line 160
    new-instance v1, Ljava/util/AbstractMap$SimpleEntry;

    .line 163
    const-string v2, "sponsorships_section_list_root"

    const-string v3, "button"

    invoke-static {v2, v3}, Ljava/util/Set;->of(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v2

    const-string v4, "sponsorShipPanelComponents"

    invoke-direct {v1, v2, v4}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 161
    invoke-static {v1}, LuTools/uUtils;->InitializeNewBlockList(Ljava/util/AbstractMap$SimpleEntry;)Ljava/util/AbstractMap$SimpleEntry;

    move-result-object v1

    sput-object v1, LuTools/uBlocker;->sponsorShipPanelComponents:Ljava/util/AbstractMap$SimpleEntry;

    .line 171
    new-instance v1, Ljava/util/AbstractMap$SimpleEntry;

    .line 174
    const-string v2, "video_description_header"

    invoke-static {v2, v3}, Ljava/util/Set;->of(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v2

    const-string v3, "videoInformationPanelComponents"

    invoke-direct {v1, v2, v3}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 172
    invoke-static {v1}, LuTools/uUtils;->InitializeNewBlockList(Ljava/util/AbstractMap$SimpleEntry;)Ljava/util/AbstractMap$SimpleEntry;

    move-result-object v1

    sput-object v1, LuTools/uBlocker;->videoInformationPanelComponents:Ljava/util/AbstractMap$SimpleEntry;

    .line 182
    new-instance v1, Ljava/util/AbstractMap$SimpleEntry;

    .line 185
    const-string v2, "endorsement_header_footer"

    const-string v3, "expandable_metadata"

    const-string v4, "set_reminder_button"

    const-string v5, "slimline_survey_video_with_context"

    const-string v6, "snappy_horizontal_shelf"

    const-string v7, "video_metadata_carousel"

    invoke-static/range {v2 .. v7}, Ljava/util/Set;->of(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v2

    const-string v3, "videoLookupComponents"

    invoke-direct {v1, v2, v3}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 183
    invoke-static {v1}, LuTools/uUtils;->InitializeNewBlockList(Ljava/util/AbstractMap$SimpleEntry;)Ljava/util/AbstractMap$SimpleEntry;

    move-result-object v1

    sput-object v1, LuTools/uBlocker;->videoLookupComponents:Ljava/util/AbstractMap$SimpleEntry;

    .line 197
    nop

    .line 198
    const-string v1, "yt_outline_question_circle"

    const-string v2, "yt_outline_volume_stable"

    const-string v3, "yt_outline_youtube_music"

    invoke-static {v1, v2, v3}, Ljava/util/Set;->of(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v1

    sput-object v1, LuTools/uBlocker;->videoOtherSettingsPanelComponent:Ljava/util/Set;

    .line 203
    new-instance v1, Ljava/util/AbstractMap$SimpleEntry;

    const/16 v2, 0x37

    new-array v2, v2, [Ljava/lang/String;

    const-string v3, "banner_text_icon_buttoned_layout"

    aput-object v3, v2, v0

    const/4 v3, 0x1

    const-string v4, "brand_video_"

    aput-object v4, v2, v3

    const/4 v3, 0x2

    const-string v4, "carousel_footered_"

    aput-object v4, v2, v3

    const/4 v3, 0x3

    const-string v4, "compact_landscape_image_layout"

    aput-object v4, v2, v3

    const/4 v3, 0x4

    const-string v4, "composite_concurrent_carousel_layout"

    aput-object v4, v2, v3

    const/4 v3, 0x5

    const-string v4, "full_width_"

    aput-object v4, v2, v3

    const/4 v3, 0x6

    const-string v4, "inline_injection_entrypoint_layout"

    aput-object v4, v2, v3

    const/4 v3, 0x7

    const-string v4, "landscape_image_wide_button_layout"

    aput-object v4, v2, v3

    const/16 v3, 0x8

    const-string v4, "square_image_layout"

    aput-object v4, v2, v3

    const/16 v3, 0x9

    const-string v4, "statement_banner"

    aput-object v4, v2, v3

    const/16 v3, 0xa

    const-string v4, "text_image_"

    aput-object v4, v2, v3

    const/16 v3, 0xb

    const-string v4, "video_display_"

    aput-object v4, v2, v3

    const/16 v3, 0xc

    const-string v4, "browsy_bar"

    aput-object v4, v2, v3

    const/16 v3, 0xd

    const-string v4, "cell_expandable_metadata"

    aput-object v4, v2, v3

    const/16 v3, 0xe

    const-string v4, "channel_guidelines_entry_banner"

    aput-object v4, v2, v3

    const/16 v3, 0xf

    const-string v4, "chips_shelf"

    aput-object v4, v2, v3

    const/16 v3, 0x10

    const-string v4, "community_guidelines"

    aput-object v4, v2, v3

    const/16 v3, 0x11

    const-string v4, "compact_tvfilm_item"

    aput-object v4, v2, v3

    const/16 v3, 0x12

    const-string v4, "emergency_onebox"

    aput-object v4, v2, v3

    const/16 v3, 0x13

    const-string v4, "expandable_list"

    aput-object v4, v2, v3

    const/16 v3, 0x14

    const-string v4, "expandable_section"

    aput-object v4, v2, v3

    const/16 v3, 0x15

    const-string v4, "feed_nudge"

    aput-object v4, v2, v3

    const/16 v3, 0x16

    const-string v4, "fullscreen_related_videos_entry_point"

    aput-object v4, v2, v3

    const/16 v3, 0x17

    const-string v4, "grid_channel_shelf"

    aput-object v4, v2, v3

    const/16 v3, 0x18

    const-string v4, "hero_carousel"

    aput-object v4, v2, v3

    const/16 v3, 0x19

    const-string v4, "horizontal_gaming_shelf"

    aput-object v4, v2, v3

    const/16 v3, 0x1a

    const-string v4, "horizontal_tile_shelf"

    aput-object v4, v2, v3

    const/16 v3, 0x1b

    const-string v4, "image_shelf"

    aput-object v4, v2, v3

    const/16 v3, 0x1c

    const-string v4, "images_post_"

    aput-object v4, v2, v3

    const/16 v3, 0x1d

    const-string v4, "info_card_teaser_overlay"

    aput-object v4, v2, v3

    const/16 v3, 0x1e

    const-string v4, "infocards_section"

    aput-object v4, v2, v3

    const/16 v3, 0x1f

    const-string v4, "live_chat_sponsorships_new_member_announcement"

    aput-object v4, v2, v3

    const/16 v3, 0x20

    const-string v4, "live_chat_text_message_banner"

    aput-object v4, v2, v3

    const/16 v3, 0x21

    const-string v4, "live_chat_ticker_creator_goal_view_model"

    aput-object v4, v2, v3

    const/16 v3, 0x22

    const-string v4, "macro_markers_carousel"

    aput-object v4, v2, v3

    const/16 v3, 0x23

    const-string v4, "medical_panel"

    aput-object v4, v2, v3

    const/16 v3, 0x24

    const-string v4, "member_recognition_shelf"

    aput-object v4, v2, v3

    const/16 v3, 0x25

    const-string v4, "music_recap_banner"

    aput-object v4, v2, v3

    const/16 v3, 0x26

    const-string v4, "offer_module_root"

    aput-object v4, v2, v3

    const/16 v3, 0x27

    const-string v4, "paid_content_overlay"

    aput-object v4, v2, v3

    const/16 v3, 0x28

    const-string v4, "playlist_section"

    aput-object v4, v2, v3

    const/16 v3, 0x29

    const-string v4, "post_"

    aput-object v4, v2, v3

    const/16 v3, 0x2a

    const-string v4, "product_carousel"

    aput-object v4, v2, v3

    const/16 v3, 0x2b

    const-string v4, "products_in_video_with_preview"

    aput-object v4, v2, v3

    const/16 v3, 0x2c

    const-string v4, "publisher_transparency_panel"

    aput-object v4, v2, v3

    const/16 v3, 0x2d

    const-string v4, "search_friction"

    aput-object v4, v2, v3

    const/16 v3, 0x2e

    const-string v4, "shelf_header"

    aput-object v4, v2, v3

    const/16 v3, 0x2f

    const-string v4, "shorts_shelf"

    aput-object v4, v2, v3

    const/16 v3, 0x30

    const-string v4, "single_item_information_panel"

    aput-object v4, v2, v3

    const/16 v3, 0x31

    const-string v4, "super_chat_item"

    aput-object v4, v2, v3

    const/16 v3, 0x32

    const-string v4, "timed_reaction"

    aput-object v4, v2, v3

    const/16 v3, 0x33

    const-string v4, "topic_with_thumbnail_view_model"

    aput-object v4, v2, v3

    const/16 v3, 0x34

    const-string v4, "transcript_section"

    aput-object v4, v2, v3

    const/16 v3, 0x35

    const-string v4, "video_attributes_section"

    aput-object v4, v2, v3

    const/16 v3, 0x36

    const-string v4, "|suggested_action."

    aput-object v4, v2, v3

    .line 206
    invoke-static {v2}, Ljava/util/Set;->of([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v2

    const-string v3, "generalComponents"

    invoke-direct {v1, v2, v3}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 204
    invoke-static {v1}, LuTools/uUtils;->InitializeNewBlockList(Ljava/util/AbstractMap$SimpleEntry;)Ljava/util/AbstractMap$SimpleEntry;

    move-result-object v1

    sput-object v1, LuTools/uBlocker;->generalComponents:Ljava/util/AbstractMap$SimpleEntry;

    .line 269
    sput v0, LuTools/uBlocker;->currentNavBarIndex:I

    .line 271
    sput-boolean v0, LuTools/uBlocker;->moreDrawerAppsAndInfo:Z

    .line 272
    sput-boolean v0, LuTools/uBlocker;->quickQualityBottomSheet:Z

    .line 400
    sput-boolean v0, LuTools/uBlocker;->hideWelcomeAndRules:Z

    .line 436
    sget-object v0, LuTools/uUtils$EnumInitialization;->NONE:LuTools/uUtils$EnumInitialization;

    sput-object v0, LuTools/uBlocker;->navigationBarPivot:Ljava/lang/Enum;

    .line 445
    new-instance v0, Ljava/util/AbstractMap$SimpleEntry;

    .line 448
    const-string v1, "CREATION_ENTRY"

    const-string v2, "FAB_CAMERA"

    const-string v3, "TAB_ACTIVITY_CAIRO"

    invoke-static {v1, v2, v3}, Ljava/util/Set;->of(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v1

    const-string v2, "topbarButtons"

    invoke-direct {v0, v1, v2}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 446
    invoke-static {v0}, LuTools/uUtils;->InitializeNewBlockList(Ljava/util/AbstractMap$SimpleEntry;)Ljava/util/AbstractMap$SimpleEntry;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->topbarButtons:Ljava/util/AbstractMap$SimpleEntry;

    .line 457
    sget-object v0, LuTools/uUtils$EnumInitialization;->NONE:LuTools/uUtils$EnumInitialization;

    sput-object v0, LuTools/uBlocker;->topBarPivot:Ljava/lang/Enum;

    .line 471
    nop

    .line 472
    const-string v0, "Opening video channel..."

    invoke-static {v0}, LuTools/uUtils;->GetNewToast(Ljava/lang/String;)Landroid/widget/Toast;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->openVideoChannelToastInProgress:Landroid/widget/Toast;

    .line 473
    nop

    .line 474
    const-string v0, "Channel opened"

    invoke-static {v0}, LuTools/uUtils;->GetNewToast(Ljava/lang/String;)Landroid/widget/Toast;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->openVideoChannelToastDone:Landroid/widget/Toast;

    .line 475
    nop

    .line 476
    const-string v0, "Error: Failed to open video channel"

    invoke-static {v0}, LuTools/uUtils;->GetNewToast(Ljava/lang/String;)Landroid/widget/Toast;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->openVideoChannelToastError:Landroid/widget/Toast;

    .line 477
    const/4 v0, 0x0

    sput-object v0, LuTools/uBlocker;->openVideoChannelThread:Ljava/lang/Thread;

    .line 549
    const/16 v0, 0x438

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->preferredQuality:Ljava/lang/Integer;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 44
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static ChangeLithoUIColor(I)I
    .locals 3
    .param p0, "originalValue"    # I

    .line 75
    nop

    .line 76
    invoke-static {p0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    .line 77
    invoke-static {}, LuTools/uUtils;->CheckDarkTheme()Z

    move-result v1

    if-eqz v1, :cond_0

    sget-object v1, LuTools/uBlocker;->DARK_COLORS:Ljava/util/AbstractMap$SimpleEntry;

    goto :goto_0

    :cond_0
    sget-object v1, LuTools/uBlocker;->LIGHT_COLORS:Ljava/util/AbstractMap$SimpleEntry;

    :goto_0
    sget-object v2, LuTools/uUtils$entries;->ANY:LuTools/uUtils$entries;

    .line 75
    invoke-static {v0, v1, v2}, LuTools/uUtils;->SearchInSetCorasick(Ljava/lang/String;Ljava/util/AbstractMap$SimpleEntry;LuTools/uUtils$entries;)Z

    move-result v0

    if-eqz v0, :cond_2

    .line 81
    invoke-static {}, LuTools/uUtils;->CheckDarkTheme()Z

    move-result v0

    if-eqz v0, :cond_1

    const v0, -0xffffff

    goto :goto_1

    :cond_1
    const v0, 0xffffff

    :goto_1
    return v0

    .line 83
    :cond_2
    return p0
.end method

.method public static CheckMicroGPackage(Landroid/app/Activity;)V
    .locals 3
    .param p0, "activity"    # Landroid/app/Activity;

    .line 91
    nop

    .line 92
    :try_start_0
    invoke-virtual {p0}, Landroid/app/Activity;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const-string v1, "app.revanced.android.gms"

    .line 93
    const/4 v2, 0x1

    invoke-virtual {v0, v1, v2}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    .line 100
    goto :goto_0

    .line 98
    :catch_0
    move-exception v0

    .line 99
    .local v0, "exception":Landroid/content/pm/PackageManager$NameNotFoundException;
    sget-object v1, LuTools/uBlocker;->checkMicroGPackageToastError:Landroid/widget/Toast;

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    .line 101
    .end local v0    # "exception":Landroid/content/pm/PackageManager$NameNotFoundException;
    :goto_0
    return-void
.end method

.method public static DisableAutoPlayCountdown(Landroid/view/View;)V
    .locals 1
    .param p0, "view"    # Landroid/view/View;

    .line 105
    :try_start_0
    invoke-virtual {p0}, Landroid/view/View;->callOnClick()Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 106
    :goto_0
    goto :goto_1

    :catch_0
    move-exception v0

    goto :goto_0

    .line 107
    :goto_1
    return-void
.end method

.method public static HideHighBitrateResolution(Ljava/lang/String;)Z
    .locals 1
    .param p0, "originalValue"    # Ljava/lang/String;

    .line 110
    const-string v0, "Premium"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    return v0
.end method

.method public static HideLithoTemplate(Ljava/lang/String;)Z
    .locals 5
    .param p0, "templateTreeComponent"    # Ljava/lang/String;

    .line 276
    const-string v0, "featured_channel_watermark_overlay"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    .line 277
    return v1

    .line 281
    :cond_0
    const-string v0, "comment"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_2

    .line 282
    const-string v0, "composer"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 283
    sget-object v0, LuTools/uBlocker;->commentsComponents:Ljava/util/AbstractMap$SimpleEntry;

    sget-object v1, LuTools/uUtils$entries;->ANY:LuTools/uUtils$entries;

    invoke-static {p0, v0, v1}, LuTools/uUtils;->SearchInSetCorasick(Ljava/lang/String;Ljava/util/AbstractMap$SimpleEntry;LuTools/uUtils$entries;)Z

    move-result v0

    return v0

    .line 289
    :cond_1
    const-string v0, "sponsorships_comments"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    return v0

    .line 294
    :cond_2
    const-string v0, "account_header"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-eqz v0, :cond_3

    .line 295
    sput v2, LuTools/uBlocker;->currentNavBarIndex:I

    .line 297
    return v3

    .line 299
    :cond_3
    sget-object v0, LuTools/uBlocker;->horizontalShelfFirst:Ljava/util/AbstractMap$SimpleEntry;

    sget-object v4, LuTools/uUtils$entries;->ANY:LuTools/uUtils$entries;

    invoke-static {p0, v0, v4}, LuTools/uUtils;->SearchInSetCorasick(Ljava/lang/String;Ljava/util/AbstractMap$SimpleEntry;LuTools/uUtils$entries;)Z

    move-result v0

    if-eqz v0, :cond_6

    .line 305
    sget-object v0, LuTools/uBlocker;->horizontalShelfSecond:Ljava/util/AbstractMap$SimpleEntry;

    sget-object v4, LuTools/uUtils$entries;->ANY:LuTools/uUtils$entries;

    invoke-static {p0, v0, v4}, LuTools/uUtils;->SearchInSetCorasick(Ljava/lang/String;Ljava/util/AbstractMap$SimpleEntry;LuTools/uUtils$entries;)Z

    move-result v0

    if-eqz v0, :cond_4

    .line 311
    sput v3, LuTools/uBlocker;->currentNavBarIndex:I

    .line 314
    :cond_4
    sget v0, LuTools/uBlocker;->currentNavBarIndex:I

    if-eq v0, v2, :cond_5

    goto :goto_0

    :cond_5
    move v1, v3

    :goto_0
    return v1

    .line 319
    :cond_6
    sget-boolean v0, LuTools/uUtils;->isCommentsOrLiveChatPanelOpen:Z

    if-eqz v0, :cond_7

    .line 320
    const-string v0, "progress_bar"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_7

    .line 321
    return v1

    .line 325
    :cond_7
    const-string v0, "more_drawer."

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_9

    .line 326
    const-string v0, "divider"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_8

    .line 327
    sput-boolean v1, LuTools/uBlocker;->moreDrawerAppsAndInfo:Z

    .line 330
    :cond_8
    sget-boolean v0, LuTools/uBlocker;->moreDrawerAppsAndInfo:Z

    return v0

    .line 332
    :cond_9
    sput-boolean v3, LuTools/uBlocker;->moreDrawerAppsAndInfo:Z

    .line 336
    const-string v0, "video_metadata_carousel"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_c

    .line 337
    const-string v0, "|carousel_item."

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_b

    sget-object v0, LuTools/uBlocker;->openCommentsButtonComponents:Ljava/util/AbstractMap$SimpleEntry;

    sget-object v2, LuTools/uUtils$entries;->ALL:LuTools/uUtils$entries;

    .line 338
    invoke-static {p0, v0, v2}, LuTools/uUtils;->SearchInSetCorasick(Ljava/lang/String;Ljava/util/AbstractMap$SimpleEntry;LuTools/uUtils$entries;)Z

    move-result v0

    if-eqz v0, :cond_a

    goto :goto_1

    :cond_a
    move v1, v3

    goto :goto_2

    :cond_b
    :goto_1
    nop

    .line 337
    :goto_2
    return v1

    .line 346
    :cond_c
    const-string v0, "quick_quality_sheet_content"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_d

    .line 347
    sput-boolean v1, LuTools/uBlocker;->quickQualityBottomSheet:Z

    .line 349
    return v3

    .line 353
    :cond_d
    sget-object v0, LuTools/uBlocker;->sponsorShipPanelComponents:Ljava/util/AbstractMap$SimpleEntry;

    sget-object v2, LuTools/uUtils$entries;->ALL:LuTools/uUtils$entries;

    invoke-static {p0, v0, v2}, LuTools/uUtils;->SearchInSetCorasick(Ljava/lang/String;Ljava/util/AbstractMap$SimpleEntry;LuTools/uUtils$entries;)Z

    move-result v0

    if-eqz v0, :cond_e

    .line 359
    return v1

    .line 363
    :cond_e
    sget-object v0, LuTools/uBlocker;->videoInformationPanelComponents:Ljava/util/AbstractMap$SimpleEntry;

    sget-object v2, LuTools/uUtils$entries;->ALL:LuTools/uUtils$entries;

    invoke-static {p0, v0, v2}, LuTools/uUtils;->SearchInSetCorasick(Ljava/lang/String;Ljava/util/AbstractMap$SimpleEntry;LuTools/uUtils$entries;)Z

    move-result v0

    if-eqz v0, :cond_f

    .line 369
    return v1

    .line 373
    :cond_f
    const-string v0, "overflow_menu_item"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_10

    sget-object v0, LuTools/uBlocker;->protoBufferComponents:Ljava/nio/ByteBuffer;

    sget-object v2, LuTools/uBlocker;->videoOtherSettingsPanelComponent:Ljava/util/Set;

    sget-object v3, LuTools/uUtils$entries;->ANY:LuTools/uUtils$entries;

    .line 374
    invoke-static {v0, v2, v3}, LuTools/uUtils;->ByteBufferContainsString(Ljava/nio/ByteBuffer;Ljava/util/Set;LuTools/uUtils$entries;)Z

    move-result v0

    if-eqz v0, :cond_10

    .line 379
    return v1

    .line 383
    :cond_10
    const-string v0, "video_lockup_with_attachment"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_11

    .line 384
    sget-object v0, LuTools/uBlocker;->videoLookupComponents:Ljava/util/AbstractMap$SimpleEntry;

    sget-object v1, LuTools/uUtils$entries;->ANY:LuTools/uUtils$entries;

    invoke-static {p0, v0, v1}, LuTools/uUtils;->SearchInSetCorasick(Ljava/lang/String;Ljava/util/AbstractMap$SimpleEntry;LuTools/uUtils$entries;)Z

    move-result v0

    return v0

    .line 392
    :cond_11
    sget-object v0, LuTools/uBlocker;->generalComponents:Ljava/util/AbstractMap$SimpleEntry;

    sget-object v1, LuTools/uUtils$entries;->ANY:LuTools/uUtils$entries;

    invoke-static {p0, v0, v1}, LuTools/uUtils;->SearchInSetCorasick(Ljava/lang/String;Ljava/util/AbstractMap$SimpleEntry;LuTools/uUtils$entries;)Z

    move-result v0

    return v0
.end method

.method public static HideLiveChatSubscribersShelf(Landroid/view/View;)V
    .locals 2
    .param p0, "view"    # Landroid/view/View;

    .line 413
    :try_start_0
    invoke-virtual {p0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v0

    new-instance v1, LuTools/uBlocker$$ExternalSyntheticLambda2;

    invoke-direct {v1, p0}, LuTools/uBlocker$$ExternalSyntheticLambda2;-><init>(Landroid/view/View;)V

    invoke-virtual {v0, v1}, Landroid/view/ViewTreeObserver;->addOnGlobalLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 419
    :catch_0
    move-exception v0

    :goto_0
    nop

    .line 420
    return-void
.end method

.method public static HideLiveChatWelcomeAndRulesNotice(Landroid/view/View;)V
    .locals 1
    .param p0, "view"    # Landroid/view/View;

    .line 403
    :try_start_0
    sget-boolean v0, LuTools/uBlocker;->hideWelcomeAndRules:Z

    if-eqz v0, :cond_0

    .line 404
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    invoke-static {v0}, LuTools/uUtils;->HideViewByLinearLayoutParams(Landroid/view/View;)V

    .line 406
    const/4 v0, 0x0

    sput-boolean v0, LuTools/uBlocker;->hideWelcomeAndRules:Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 408
    :catch_0
    move-exception v0

    :cond_0
    :goto_0
    nop

    .line 409
    return-void
.end method

.method public static HideNavigationbarButtons(Landroid/view/View;)V
    .locals 2
    .param p0, "view"    # Landroid/view/View;

    .line 439
    :try_start_0
    sget-object v0, LuTools/uBlocker;->navigationBarPivot:Ljava/lang/Enum;

    invoke-virtual {v0}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object v0

    const-string v1, "TAB_SHORTS"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 440
    invoke-static {p0}, LuTools/uUtils;->HideView(Landroid/view/View;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 442
    :catch_0
    move-exception v0

    :cond_0
    :goto_0
    nop

    .line 443
    return-void
.end method

.method public static HideTabMyAccountGetPremium(Landroid/view/View;Ljava/lang/CharSequence;)V
    .locals 3
    .param p0, "view"    # Landroid/view/View;
    .param p1, "charSequence"    # Ljava/lang/CharSequence;

    .line 424
    :try_start_0
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    invoke-interface {v0}, Landroid/view/ViewParent;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    instance-of v1, v0, Landroid/view/ViewGroup;

    if-eqz v1, :cond_1

    check-cast v0, Landroid/view/ViewGroup;

    .line 425
    .local v0, "viewGroup":Landroid/view/ViewGroup;
    invoke-interface {p1}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "Premium"

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_1

    .line 426
    invoke-virtual {v0}, Landroid/view/ViewGroup;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    instance-of v1, v1, Landroid/view/ViewGroup$MarginLayoutParams;

    if-eqz v1, :cond_0

    .line 427
    invoke-static {v0}, LuTools/uUtils;->HideViewGroupByMarginLayout(Landroid/view/ViewGroup;)V

    goto :goto_0

    .line 429
    :cond_0
    invoke-static {v0}, LuTools/uUtils;->HideViewGroupByLayoutParams(Landroid/view/ViewGroup;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 433
    .end local v0    # "viewGroup":Landroid/view/ViewGroup;
    :catch_0
    move-exception v0

    :cond_1
    :goto_0
    nop

    .line 434
    return-void
.end method

.method public static HideTopbarButtons(Landroid/view/View;)V
    .locals 3
    .param p0, "view"    # Landroid/view/View;

    .line 460
    :try_start_0
    sget-object v0, LuTools/uBlocker;->topBarPivot:Ljava/lang/Enum;

    .line 461
    invoke-virtual {v0}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object v0

    sget-object v1, LuTools/uBlocker;->topbarButtons:Ljava/util/AbstractMap$SimpleEntry;

    sget-object v2, LuTools/uUtils$entries;->ANY:LuTools/uUtils$entries;

    .line 460
    invoke-static {v0, v1, v2}, LuTools/uUtils;->SearchInSetCorasick(Ljava/lang/String;Ljava/util/AbstractMap$SimpleEntry;LuTools/uUtils$entries;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 466
    invoke-static {p0}, LuTools/uUtils;->HideView(Landroid/view/View;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 468
    :catch_0
    move-exception v0

    :cond_0
    :goto_0
    nop

    .line 469
    return-void
.end method

.method public static OpenVideoChannel(Ljava/lang/String;)Z
    .locals 4
    .param p0, "videoID"    # Ljava/lang/String;

    .line 479
    sget-object v0, LuTools/uBlocker;->openVideoChannelThread:Ljava/lang/Thread;

    if-nez v0, :cond_0

    .line 480
    sget-boolean v0, LuTools/uUtils;->isCommentsOrLiveChatPanelOpen:Z

    if-nez v0, :cond_0

    sget-wide v0, LuTools/uUtils;->lithoActionDownDuration:J

    const-wide/16 v2, 0x3e8

    cmp-long v0, v0, v2

    if-ltz v0, :cond_0

    .line 481
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, LuTools/uBlocker$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0}, LuTools/uBlocker$$ExternalSyntheticLambda0;-><init>(Ljava/lang/String;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    sput-object v0, LuTools/uBlocker;->openVideoChannelThread:Ljava/lang/Thread;

    .line 523
    sget-object v0, LuTools/uBlocker;->openVideoChannelThread:Ljava/lang/Thread;

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 525
    const/4 v0, 0x1

    return v0

    .line 529
    :cond_0
    const/4 v0, 0x0

    return v0
.end method

.method public static OpenVideoResolutionsFlyout(Landroid/support/v7/widget/RecyclerView;)V
    .locals 2
    .param p0, "recyclerView"    # Landroid/support/v7/widget/RecyclerView;

    .line 534
    :try_start_0
    invoke-virtual {p0}, Landroid/support/v7/widget/RecyclerView;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v0

    new-instance v1, LuTools/uBlocker$$ExternalSyntheticLambda1;

    invoke-direct {v1, p0}, LuTools/uBlocker$$ExternalSyntheticLambda1;-><init>(Landroid/support/v7/widget/RecyclerView;)V

    invoke-virtual {v0, v1}, Landroid/view/ViewTreeObserver;->addOnDrawListener(Landroid/view/ViewTreeObserver$OnDrawListener;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 542
    :catch_0
    move-exception v0

    :goto_0
    nop

    .line 543
    return-void
.end method

.method public static OverrideTrackingUrl(Landroid/net/Uri;)Landroid/net/Uri;
    .locals 2
    .param p0, "trackingUrl"    # Landroid/net/Uri;

    .line 546
    invoke-virtual {p0}, Landroid/net/Uri;->buildUpon()Landroid/net/Uri$Builder;

    move-result-object v0

    const-string v1, "www.youtube.com"

    invoke-virtual {v0, v1}, Landroid/net/Uri$Builder;->authority(Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object v0

    invoke-virtual {v0}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    move-result-object v0

    return-object v0
.end method

.method public static SetPreferredVideoQuality([Ljava/lang/Object;ILjava/lang/Object;Ljava/lang/String;)I
    .locals 11
    .param p0, "qualities"    # [Ljava/lang/Object;
    .param p1, "originalQualityIndex"    # I
    .param p2, "qInterface"    # Ljava/lang/Object;
    .param p3, "qIndexMethod"    # Ljava/lang/String;

    .line 560
    :try_start_0
    sget-object v0, LuTools/uBlocker;->videoQualities:Ljava/util/List;

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    sget-object v0, LuTools/uBlocker;->videoQualities:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    array-length v3, p0

    if-eq v0, v3, :cond_4

    .line 561
    :cond_0
    new-instance v0, Ljava/util/ArrayList;

    array-length v3, p0

    invoke-direct {v0, v3}, Ljava/util/ArrayList;-><init>(I)V

    sput-object v0, LuTools/uBlocker;->videoQualities:Ljava/util/List;

    .line 563
    array-length v0, p0

    move v3, v2

    :goto_0
    if-ge v3, v0, :cond_3

    aget-object v4, p0, v3

    .line 564
    .local v4, "streamQuality":Ljava/lang/Object;
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Class;->getFields()[Ljava/lang/reflect/Field;

    move-result-object v5

    array-length v6, v5

    move v7, v2

    :goto_1
    if-ge v7, v6, :cond_2

    aget-object v8, v5, v7

    .line 565
    .local v8, "field":Ljava/lang/reflect/Field;
    invoke-virtual {v8}, Ljava/lang/reflect/Field;->getType()Ljava/lang/Class;

    move-result-object v9

    sget-object v10, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    invoke-virtual {v9, v10}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v9

    if-eqz v9, :cond_1

    .line 566
    invoke-virtual {v8}, Ljava/lang/reflect/Field;->getName()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/String;->length()I

    move-result v9

    const/4 v10, 0x2

    if-gt v9, v10, :cond_1

    .line 567
    sget-object v9, LuTools/uBlocker;->videoQualities:Ljava/util/List;

    invoke-virtual {v8, v4}, Ljava/lang/reflect/Field;->getInt(Ljava/lang/Object;)I

    move-result v10

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-interface {v9, v10}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 564
    .end local v8    # "field":Ljava/lang/reflect/Field;
    :cond_1
    add-int/lit8 v7, v7, 0x1

    goto :goto_1

    .line 563
    .end local v4    # "streamQuality":Ljava/lang/Object;
    :cond_2
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    .line 572
    :cond_3
    sput-boolean v1, LuTools/uBlocker;->qualityNeedsUpdating:Z

    .line 575
    :cond_4
    sget-boolean v0, LuTools/uBlocker;->qualityNeedsUpdating:Z

    if-nez v0, :cond_5

    .line 576
    return p1

    .line 578
    :cond_5
    sput-boolean v2, LuTools/uBlocker;->qualityNeedsUpdating:Z

    .line 580
    sget-object v0, LuTools/uBlocker;->videoQualities:Ljava/util/List;

    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    .line 581
    .local v0, "qualityToUse":I
    const/4 v3, 0x0

    .line 582
    .local v3, "qualityIndexToUse":I
    const/4 v4, 0x0

    .line 583
    .local v4, "i":I
    sget-object v5, LuTools/uBlocker;->videoQualities:Ljava/util/List;

    invoke-interface {v5}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_2
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_7

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/Integer;

    .line 584
    .local v6, "quality":Ljava/lang/Integer;
    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    move-result v7

    sget-object v8, LuTools/uBlocker;->preferredQuality:Ljava/lang/Integer;

    invoke-virtual {v8}, Ljava/lang/Integer;->intValue()I

    move-result v8

    if-gt v7, v8, :cond_6

    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    move-result v7

    if-ge v0, v7, :cond_6

    .line 585
    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    move-result v7

    .line 586
    .end local v0    # "qualityToUse":I
    .local v7, "qualityToUse":I
    move v0, v4

    move v3, v0

    move v0, v7

    .line 589
    .end local v7    # "qualityToUse":I
    .restart local v0    # "qualityToUse":I
    :cond_6
    nop

    .end local v6    # "quality":Ljava/lang/Integer;
    add-int/lit8 v4, v4, 0x1

    .line 590
    goto :goto_2

    .line 592
    :cond_7
    nop

    .line 593
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v5

    new-array v1, v1, [Ljava/lang/Class;

    sget-object v6, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    aput-object v6, v1, v2

    .line 594
    invoke-virtual {v5, p3, v1}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    .line 595
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    filled-new-array {v2}, [Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v1, p2, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 597
    return v3

    .line 598
    .end local v0    # "qualityToUse":I
    .end local v3    # "qualityIndexToUse":I
    .end local v4    # "i":I
    :catch_0
    move-exception v0

    .line 599
    .local v0, "ex":Ljava/lang/Exception;
    return p1
.end method

.method public static SetPreferredVideoQualityClear()V
    .locals 1

    .line 554
    const/4 v0, 0x1

    sput-boolean v0, LuTools/uBlocker;->qualityNeedsUpdating:Z

    .line 556
    const/4 v0, 0x0

    sput-object v0, LuTools/uBlocker;->videoQualities:Ljava/util/List;

    .line 557
    return-void
.end method

.method public static SetSelectedFlyoutQuality(I)V
    .locals 1
    .param p0, "selectedQuality"    # I

    .line 603
    if-lez p0, :cond_0

    .line 604
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->preferredQuality:Ljava/lang/Integer;

    .line 606
    :cond_0
    return-void
.end method

.method public static ShortsPlayerBypassing(Ljava/lang/String;)Z
    .locals 5
    .param p0, "shortsVideoID"    # Ljava/lang/String;

    .line 610
    :try_start_0
    invoke-static {}, LuTools/uUtils;->GetMainActivityContext()Landroid/content/Context;

    move-result-object v0

    .line 612
    .local v0, "context":Landroid/content/Context;
    new-instance v1, Landroid/content/Intent;

    const-string v2, "android.intent.action.VIEW"

    const-string v3, "https://www.youtube.com/watch?v=%s"

    filled-new-array {p0}, [Ljava/lang/Object;

    move-result-object v4

    .line 616
    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    .line 615
    invoke-static {v3}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v3

    invoke-direct {v1, v2, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 623
    .local v1, "videoPlayerIntent":Landroid/content/Intent;
    const/high16 v2, 0x10000000

    invoke-virtual {v1, v2}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    .line 624
    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 626
    invoke-virtual {v0, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 628
    const/4 v2, 0x1

    return v2

    .line 629
    .end local v0    # "context":Landroid/content/Context;
    .end local v1    # "videoPlayerIntent":Landroid/content/Intent;
    :catch_0
    move-exception v0

    .line 631
    const/4 v0, 0x0

    return v0
.end method

.method static synthetic lambda$HideLiveChatSubscribersShelf$0(Landroid/view/View;)V
    .locals 3
    .param p0, "view"    # Landroid/view/View;

    .line 414
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    .line 415
    .local v0, "parent":Landroid/view/ViewParent;
    instance-of v1, v0, Landroid/support/v7/widget/RecyclerView;

    if-eqz v1, :cond_0

    .line 416
    move-object v1, v0

    check-cast v1, Landroid/support/v7/widget/RecyclerView;

    const/16 v2, 0x8

    invoke-virtual {v1, v2}, Landroid/support/v7/widget/RecyclerView;->setVisibility(I)V

    .line 418
    :cond_0
    return-void
.end method

.method static synthetic lambda$OpenVideoChannel$1(Ljava/lang/String;)V
    .locals 7
    .param p0, "videoID"    # Ljava/lang/String;

    .line 483
    :try_start_0
    sget-object v0, LuTools/uBlocker;->openVideoChannelToastInProgress:Landroid/widget/Toast;

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 485
    invoke-static {}, LuTools/uUtils;->GetMainActivityContext()Landroid/content/Context;

    move-result-object v0

    .line 487
    .local v0, "context":Landroid/content/Context;
    invoke-static {p0}, LuTools/VideoDetails/uVideoDetailsRequest;->SetFetchRequest(Ljava/lang/String;)V

    .line 488
    invoke-static {p0}, LuTools/VideoDetails/uVideoDetailsRequest;->GetRequestForVideoID(Ljava/lang/String;)LuTools/VideoDetails/uVideoDetailsRequest;

    move-result-object v1

    .line 490
    .local v1, "videoIDRequest":LuTools/VideoDetails/uVideoDetailsRequest;
    if-eqz v1, :cond_0

    .line 491
    invoke-virtual {v1}, LuTools/VideoDetails/uVideoDetailsRequest;->GetChannelID()Ljava/lang/String;

    move-result-object v2

    .line 493
    .local v2, "channelID":Ljava/lang/String;
    if-eqz v2, :cond_0

    .line 494
    new-instance v3, Landroid/content/Intent;

    const-string v4, "android.intent.action.VIEW"

    const-string v5, "%s%s"

    const-string v6, "https://www.youtube.com/channel/"

    filled-new-array {v6, v2}, [Ljava/lang/Object;

    move-result-object v6

    .line 498
    invoke-static {v5, v6}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    .line 497
    invoke-static {v5}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v5

    invoke-direct {v3, v4, v5}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 506
    .local v3, "openLiveChannelIntent":Landroid/content/Intent;
    const/high16 v4, 0x10000000

    invoke-virtual {v3, v4}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 507
    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 509
    invoke-virtual {v0, v3}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 511
    sget-object v4, LuTools/uBlocker;->openVideoChannelToastInProgress:Landroid/widget/Toast;

    invoke-virtual {v4}, Landroid/widget/Toast;->cancel()V

    .line 512
    sget-object v4, LuTools/uBlocker;->openVideoChannelToastDone:Landroid/widget/Toast;

    invoke-virtual {v4}, Landroid/widget/Toast;->show()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 517
    .end local v0    # "context":Landroid/content/Context;
    .end local v1    # "videoIDRequest":LuTools/VideoDetails/uVideoDetailsRequest;
    .end local v2    # "channelID":Ljava/lang/String;
    .end local v3    # "openLiveChannelIntent":Landroid/content/Intent;
    :cond_0
    goto :goto_0

    .line 515
    :catch_0
    move-exception v0

    .line 516
    .local v0, "ignore":Ljava/lang/Exception;
    sget-object v1, LuTools/uBlocker;->openVideoChannelToastError:Landroid/widget/Toast;

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    .line 519
    .end local v0    # "ignore":Ljava/lang/Exception;
    :goto_0
    sget-object v0, LuTools/uBlocker;->openVideoChannelThread:Ljava/lang/Thread;

    invoke-virtual {v0}, Ljava/lang/Thread;->interrupt()V

    .line 520
    const/4 v0, 0x0

    sput-object v0, LuTools/uBlocker;->openVideoChannelThread:Ljava/lang/Thread;

    .line 521
    return-void
.end method

.method static synthetic lambda$OpenVideoResolutionsFlyout$2(Landroid/support/v7/widget/RecyclerView;)V
    .locals 3
    .param p0, "recyclerView"    # Landroid/support/v7/widget/RecyclerView;

    .line 535
    sget-boolean v0, LuTools/uBlocker;->quickQualityBottomSheet:Z

    if-eqz v0, :cond_0

    .line 536
    const/4 v0, 0x0

    sput-boolean v0, LuTools/uBlocker;->quickQualityBottomSheet:Z

    .line 538
    invoke-virtual {p0}, Landroid/support/v7/widget/RecyclerView;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    invoke-interface {v1}, Landroid/view/ViewParent;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    invoke-interface {v1}, Landroid/view/ViewParent;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    check-cast v1, Landroid/view/ViewGroup;

    const/16 v2, 0x8

    invoke-virtual {v1, v2}, Landroid/view/ViewGroup;->setVisibility(I)V

    .line 539
    invoke-virtual {p0, v0}, Landroid/support/v7/widget/RecyclerView;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/view/ViewGroup;

    const/4 v1, 0x3

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/View;->performClick()Z

    .line 541
    :cond_0
    return-void
.end method
