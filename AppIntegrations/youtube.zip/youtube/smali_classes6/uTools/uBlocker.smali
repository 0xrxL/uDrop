.class public LuTools/uBlocker;
.super Ljava/lang/Object;
.source "uBlocker.java"


# static fields
.field private static final WHITE_COLOR:I = 0xffffff

.field public static captionsButton:Z = false

.field private static final checkMicroGPackageToastError:Landroid/widget/Toast;

.field public static currentNavBarIndex:I = 0x0

.field public static hideWelcomeAndRules:Z = false

.field private static final libraryNavButtonIndex:I = 0x4

.field private static moreDrawerAppsAndInfo:Z

.field public static navigationBarPivot:Ljava/lang/Enum;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Enum<",
            "*>;"
        }
    .end annotation
.end field

.field private static openVideoChannelThread:Ljava/lang/Thread;

.field private static final openVideoChannelToastDone:Landroid/widget/Toast;

.field private static final openVideoChannelToastError:Landroid/widget/Toast;

.field private static final openVideoChannelToastInProgress:Landroid/widget/Toast;

.field private static preferredQuality:Ljava/lang/Integer;

.field public static protoBufferComponents:Ljava/nio/ByteBuffer;

.field private static qualityNeedsUpdating:Z

.field private static quickQualityBottomSheet:Z

.field public static topBarPivot:Ljava/lang/Enum;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Enum<",
            "*>;"
        }
    .end annotation
.end field

.field private static videoQualities:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static synthetic $r8$lambda$40yWSUzeLiR0N6W93Rr05xn1FW4(Ljava/lang/String;Ljava/lang/CharSequence;)Z
    .locals 0

    invoke-virtual {p0, p1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p0

    return p0
.end method

.method public static synthetic $r8$lambda$7lpm9zkoZuDoAjfOA0iYE2U94XQ(Ljava/lang/String;Ljava/lang/Object;)Z
    .locals 0

    invoke-virtual {p0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    return p0
.end method

.method static constructor <clinit>()V
    .locals 2

    .line 42
    const/4 v0, 0x0

    sput-boolean v0, LuTools/uBlocker;->captionsButton:Z

    .line 73
    nop

    .line 74
    const-string v1, "Error: No MicroG Installed"

    invoke-static {v1}, LuTools/uUtils;->GetNewToast(Ljava/lang/String;)Landroid/widget/Toast;

    move-result-object v1

    sput-object v1, LuTools/uBlocker;->checkMicroGPackageToastError:Landroid/widget/Toast;

    .line 99
    sput v0, LuTools/uBlocker;->currentNavBarIndex:I

    .line 101
    sput-boolean v0, LuTools/uBlocker;->moreDrawerAppsAndInfo:Z

    .line 102
    sput-boolean v0, LuTools/uBlocker;->quickQualityBottomSheet:Z

    .line 103
    invoke-static {v0}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    move-result-object v1

    sput-object v1, LuTools/uBlocker;->protoBufferComponents:Ljava/nio/ByteBuffer;

    .line 324
    sput-boolean v0, LuTools/uBlocker;->hideWelcomeAndRules:Z

    .line 363
    sget-object v0, LuTools/uUtils$EnumInitialization;->NONE:LuTools/uUtils$EnumInitialization;

    sput-object v0, LuTools/uBlocker;->navigationBarPivot:Ljava/lang/Enum;

    .line 378
    sget-object v0, LuTools/uUtils$EnumInitialization;->NONE:LuTools/uUtils$EnumInitialization;

    sput-object v0, LuTools/uBlocker;->topBarPivot:Ljava/lang/Enum;

    .line 391
    nop

    .line 392
    const-string v0, "Opening video channel..."

    invoke-static {v0}, LuTools/uUtils;->GetNewToast(Ljava/lang/String;)Landroid/widget/Toast;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->openVideoChannelToastInProgress:Landroid/widget/Toast;

    .line 393
    nop

    .line 394
    const-string v0, "Channel opened"

    invoke-static {v0}, LuTools/uUtils;->GetNewToast(Ljava/lang/String;)Landroid/widget/Toast;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->openVideoChannelToastDone:Landroid/widget/Toast;

    .line 395
    nop

    .line 396
    const-string v0, "Error: Failed to open video channel"

    invoke-static {v0}, LuTools/uUtils;->GetNewToast(Ljava/lang/String;)Landroid/widget/Toast;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->openVideoChannelToastError:Landroid/widget/Toast;

    .line 397
    const/4 v0, 0x0

    sput-object v0, LuTools/uBlocker;->openVideoChannelThread:Ljava/lang/Thread;

    .line 486
    const/16 v0, 0x438

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->preferredQuality:Ljava/lang/Integer;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 41
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static declared-synchronized ChangeLithoUIColor(I)I
    .locals 7
    .param p0, "originalValue"    # I

    const-class v0, LuTools/uBlocker;

    monitor-enter v0

    .line 46
    :try_start_0
    invoke-static {}, LuTools/uUtils;->CheckDarkTheme()Z

    move-result v1

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-eqz v1, :cond_0

    .line 48
    const/4 v1, 0x5

    new-array v1, v1, [Ljava/lang/Integer;

    .line 49
    const v6, -0xd7d7d8

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    aput-object v6, v1, v4

    .line 50
    const v4, -0xdededf

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v1, v3

    .line 51
    const v3, -0xe7e7e8

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    aput-object v3, v1, v2

    .line 52
    const v2, -0xf0f0f1

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    aput-object v2, v1, v5

    .line 53
    const v2, -0x5dededf

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v3, 0x4

    aput-object v2, v1, v3

    .line 48
    invoke-static {v1}, Ljava/util/stream/Stream;->of([Ljava/lang/Object;)Ljava/util/stream/Stream;

    move-result-object v1

    goto :goto_0

    .line 56
    :cond_0
    new-array v1, v5, [Ljava/lang/Integer;

    .line 57
    const/4 v5, -0x1

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    aput-object v5, v1, v4

    .line 58
    const v4, -0x60607

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v1, v3

    .line 59
    const v3, -0x5000001

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    aput-object v3, v1, v2

    .line 56
    invoke-static {v1}, Ljava/util/stream/Stream;->of([Ljava/lang/Object;)Ljava/util/stream/Stream;

    move-result-object v1

    :goto_0
    new-instance v2, LuTools/uBlocker$$ExternalSyntheticLambda2;

    invoke-direct {v2, p0}, LuTools/uBlocker$$ExternalSyntheticLambda2;-><init>(I)V

    .line 62
    invoke-interface {v1, v2}, Ljava/util/stream/Stream;->anyMatch(Ljava/util/function/Predicate;)Z

    move-result v1

    if-eqz v1, :cond_2

    .line 64
    invoke-static {}, LuTools/uUtils;->CheckDarkTheme()Z

    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz v1, :cond_1

    .line 66
    const v1, -0xffffff

    goto :goto_1

    .line 68
    :cond_1
    const v1, 0xffffff

    goto :goto_1

    .line 70
    :cond_2
    move v1, p0

    .line 46
    :goto_1
    monitor-exit v0

    return v1

    .line 45
    .end local p0    # "originalValue":I
    :catchall_0
    move-exception p0

    :try_start_1
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p0
.end method

.method public static CheckMicroGPackage(Landroid/app/Activity;)V
    .locals 3
    .param p0, "activity"    # Landroid/app/Activity;

    .line 77
    nop

    .line 78
    :try_start_0
    invoke-virtual {p0}, Landroid/app/Activity;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const-string v1, "app.revanced.android.gms"

    .line 79
    const/4 v2, 0x1

    invoke-virtual {v0, v1, v2}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    .line 86
    goto :goto_0

    .line 84
    :catch_0
    move-exception v0

    .line 85
    .local v0, "exception":Landroid/content/pm/PackageManager$NameNotFoundException;
    sget-object v1, LuTools/uBlocker;->checkMicroGPackageToastError:Landroid/widget/Toast;

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    .line 87
    .end local v0    # "exception":Landroid/content/pm/PackageManager$NameNotFoundException;
    :goto_0
    return-void
.end method

.method public static DisableAutoPlayCountdown(Landroid/view/View;)V
    .locals 1
    .param p0, "view"    # Landroid/view/View;

    .line 91
    :try_start_0
    invoke-virtual {p0}, Landroid/view/View;->callOnClick()Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 92
    :goto_0
    goto :goto_1

    :catch_0
    move-exception v0

    goto :goto_0

    .line 93
    :goto_1
    return-void
.end method

.method public static HideHighBitrateResolution(Ljava/lang/String;)Z
    .locals 1
    .param p0, "originalValue"    # Ljava/lang/String;

    .line 96
    const-string v0, "Premium"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    return v0
.end method

.method public static declared-synchronized HideLithoTemplate(Ljava/lang/StringBuilder;)Z
    .locals 11
    .param p0, "templateTreeComponents"    # Ljava/lang/StringBuilder;

    const-class v0, LuTools/uBlocker;

    monitor-enter v0

    .line 105
    :try_start_0
    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 108
    .local v1, "strTemplateTreeComponents":Ljava/lang/String;
    const-string v2, "page_header"

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_0

    sget-object v2, LuTools/uBlocker;->protoBufferComponents:Ljava/nio/ByteBuffer;

    const-string v4, "header_store_button"

    .line 109
    invoke-static {v2, v4}, LuTools/uUtils;->ByteBufferContainsString(Ljava/nio/ByteBuffer;Ljava/lang/String;)Z

    move-result v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz v2, :cond_0

    .line 110
    monitor-exit v0

    return v3

    .line 114
    :cond_0
    :try_start_1
    const-string v2, "comment"

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v4, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x0

    if-eqz v2, :cond_2

    .line 115
    const-string v2, "composer"

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_1

    .line 116
    new-array v2, v5, [Ljava/lang/String;

    const-string v5, "composer_short_creation_button"

    aput-object v5, v2, v7

    const-string v5, "composer_timestamp_button"

    aput-object v5, v2, v3

    const-string v3, "super_thanks_button"

    aput-object v3, v2, v6

    const-string v3, "|CellType|ContainerType|ContainerType|ContainerType|ContainerType|ContainerType|"

    aput-object v3, v2, v4

    invoke-static {v2}, Ljava/util/stream/Stream;->of([Ljava/lang/Object;)Ljava/util/stream/Stream;

    move-result-object v2

    .line 122
    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v3, LuTools/uBlocker$$ExternalSyntheticLambda0;

    invoke-direct {v3, v1}, LuTools/uBlocker$$ExternalSyntheticLambda0;-><init>(Ljava/lang/String;)V

    invoke-interface {v2, v3}, Ljava/util/stream/Stream;->anyMatch(Ljava/util/function/Predicate;)Z

    move-result v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 116
    monitor-exit v0

    return v2

    .line 124
    :cond_1
    :try_start_2
    const-string v2, "sponsorships_comments"

    invoke-static {v2}, Ljava/util/stream/Stream;->of(Ljava/lang/Object;)Ljava/util/stream/Stream;

    move-result-object v2

    .line 127
    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v3, LuTools/uBlocker$$ExternalSyntheticLambda0;

    invoke-direct {v3, v1}, LuTools/uBlocker$$ExternalSyntheticLambda0;-><init>(Ljava/lang/String;)V

    invoke-interface {v2, v3}, Ljava/util/stream/Stream;->anyMatch(Ljava/util/function/Predicate;)Z

    move-result v2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 124
    monitor-exit v0

    return v2

    .line 132
    :cond_2
    :try_start_3
    const-string v2, "account_header"

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_3

    .line 133
    sput v5, LuTools/uBlocker;->currentNavBarIndex:I
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 135
    monitor-exit v0

    return v7

    .line 136
    :cond_3
    :try_start_4
    new-array v2, v4, [Ljava/lang/String;

    const-string v8, "cell_divider"

    aput-object v8, v2, v7

    const-string v8, "horizontal_video_shelf"

    aput-object v8, v2, v3

    const-string v8, "horizontal_shelf."

    aput-object v8, v2, v6

    invoke-static {v2}, Ljava/util/stream/Stream;->of([Ljava/lang/Object;)Ljava/util/stream/Stream;

    move-result-object v2

    .line 141
    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v8, LuTools/uBlocker$$ExternalSyntheticLambda0;

    invoke-direct {v8, v1}, LuTools/uBlocker$$ExternalSyntheticLambda0;-><init>(Ljava/lang/String;)V

    invoke-interface {v2, v8}, Ljava/util/stream/Stream;->anyMatch(Ljava/util/function/Predicate;)Z

    move-result v2

    if-eqz v2, :cond_6

    .line 142
    new-array v2, v6, [Ljava/lang/String;

    const-string v4, "WATCH_WHILE_FULLSCREEN"

    aput-object v4, v2, v7

    const-string v4, "WATCH_WHILE_MAXIMIZED"

    aput-object v4, v2, v3

    invoke-static {v2}, Ljava/util/stream/Stream;->of([Ljava/lang/Object;)Ljava/util/stream/Stream;

    move-result-object v2

    .line 146
    invoke-static {}, LuTools/uUtils;->GetPlayerType()Ljava/lang/Enum;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v6, LuTools/uBlocker$$ExternalSyntheticLambda5;

    invoke-direct {v6, v4}, LuTools/uBlocker$$ExternalSyntheticLambda5;-><init>(Ljava/lang/String;)V

    invoke-interface {v2, v6}, Ljava/util/stream/Stream;->anyMatch(Ljava/util/function/Predicate;)Z

    move-result v2

    if-eqz v2, :cond_4

    .line 147
    sput v7, LuTools/uBlocker;->currentNavBarIndex:I

    .line 150
    :cond_4
    sget v2, LuTools/uBlocker;->currentNavBarIndex:I
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    if-eq v2, v5, :cond_5

    goto :goto_0

    :cond_5
    move v3, v7

    :goto_0
    monitor-exit v0

    return v3

    .line 154
    :cond_6
    :try_start_5
    sget-boolean v2, LuTools/uUtils;->isCommentsOrLiveChatPanelOpen:Z

    if-eqz v2, :cond_7

    .line 155
    const-string v2, "progress_bar"

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    if-eqz v2, :cond_7

    .line 156
    monitor-exit v0

    return v3

    .line 161
    :cond_7
    :try_start_6
    const-string v2, "more_drawer."

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_9

    .line 162
    const-string v2, "divider"

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_8

    .line 163
    sput-boolean v3, LuTools/uBlocker;->moreDrawerAppsAndInfo:Z

    .line 166
    :cond_8
    sget-boolean v2, LuTools/uBlocker;->moreDrawerAppsAndInfo:Z
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    monitor-exit v0

    return v2

    .line 168
    :cond_9
    :try_start_7
    sput-boolean v7, LuTools/uBlocker;->moreDrawerAppsAndInfo:Z

    .line 172
    const-string v2, "video_metadata_carousel"

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_c

    .line 173
    const-string v2, "|carousel_item."

    invoke-static {v2}, Ljava/util/stream/Stream;->of(Ljava/lang/Object;)Ljava/util/stream/Stream;

    move-result-object v2

    .line 176
    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v4, LuTools/uBlocker$$ExternalSyntheticLambda0;

    invoke-direct {v4, v1}, LuTools/uBlocker$$ExternalSyntheticLambda0;-><init>(Ljava/lang/String;)V

    invoke-interface {v2, v4}, Ljava/util/stream/Stream;->anyMatch(Ljava/util/function/Predicate;)Z

    move-result v2

    if-nez v2, :cond_b

    new-array v2, v6, [Ljava/lang/String;

    const-string v4, "carousel_header"

    aput-object v4, v2, v7

    const-string v4, "|ContainerType|ContainerType|ContainerType|"

    aput-object v4, v2, v3

    .line 180
    invoke-static {v2}, Ljava/util/stream/Stream;->of([Ljava/lang/Object;)Ljava/util/stream/Stream;

    move-result-object v2

    .line 184
    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v4, LuTools/uBlocker$$ExternalSyntheticLambda0;

    invoke-direct {v4, v1}, LuTools/uBlocker$$ExternalSyntheticLambda0;-><init>(Ljava/lang/String;)V

    invoke-interface {v2, v4}, Ljava/util/stream/Stream;->allMatch(Ljava/util/function/Predicate;)Z

    move-result v2
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_0

    if-eqz v2, :cond_a

    goto :goto_1

    :cond_a
    move v3, v7

    goto :goto_2

    :cond_b
    :goto_1
    nop

    .line 173
    :goto_2
    monitor-exit v0

    return v3

    .line 188
    :cond_c
    :try_start_8
    const-string v2, "quick_quality_sheet_content"

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_d

    .line 189
    sput-boolean v3, LuTools/uBlocker;->quickQualityBottomSheet:Z
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_0

    .line 191
    monitor-exit v0

    return v7

    .line 195
    :cond_d
    :try_start_9
    new-array v2, v6, [Ljava/lang/String;

    const-string v8, "sponsorships_section_list_root"

    aput-object v8, v2, v7

    const-string v8, "button"

    aput-object v8, v2, v3

    invoke-static {v2}, Ljava/util/stream/Stream;->of([Ljava/lang/Object;)Ljava/util/stream/Stream;

    move-result-object v2

    .line 199
    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v8, LuTools/uBlocker$$ExternalSyntheticLambda0;

    invoke-direct {v8, v1}, LuTools/uBlocker$$ExternalSyntheticLambda0;-><init>(Ljava/lang/String;)V

    invoke-interface {v2, v8}, Ljava/util/stream/Stream;->allMatch(Ljava/util/function/Predicate;)Z

    move-result v2
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_0

    if-eqz v2, :cond_e

    .line 200
    monitor-exit v0

    return v3

    .line 204
    :cond_e
    :try_start_a
    new-array v2, v6, [Ljava/lang/String;

    const-string v8, "video_description_header"

    aput-object v8, v2, v7

    const-string v8, "button"

    aput-object v8, v2, v3

    invoke-static {v2}, Ljava/util/stream/Stream;->of([Ljava/lang/Object;)Ljava/util/stream/Stream;

    move-result-object v2

    .line 208
    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v8, LuTools/uBlocker$$ExternalSyntheticLambda0;

    invoke-direct {v8, v1}, LuTools/uBlocker$$ExternalSyntheticLambda0;-><init>(Ljava/lang/String;)V

    invoke-interface {v2, v8}, Ljava/util/stream/Stream;->allMatch(Ljava/util/function/Predicate;)Z

    move-result v2
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_0

    if-eqz v2, :cond_f

    .line 209
    monitor-exit v0

    return v3

    .line 213
    :cond_f
    :try_start_b
    const-string v2, "overflow_menu_item"

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_10

    sget-object v2, LuTools/uBlocker;->protoBufferComponents:Ljava/nio/ByteBuffer;

    const-string v8, "yt_outline_volume_stable"

    .line 214
    invoke-static {v2, v8}, LuTools/uUtils;->ByteBufferContainsString(Ljava/nio/ByteBuffer;Ljava/lang/String;)Z

    move-result v2
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_0

    if-eqz v2, :cond_10

    .line 215
    monitor-exit v0

    return v3

    .line 219
    :cond_10
    :try_start_c
    const-string v2, "video_lockup_with_attachment"

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v8, 0x5

    const/4 v9, 0x6

    if-eqz v2, :cond_11

    .line 220
    new-array v2, v9, [Ljava/lang/String;

    const-string v9, "endorsement_header_footer"

    aput-object v9, v2, v7

    const-string v7, "expandable_metadata"

    aput-object v7, v2, v3

    const-string v3, "set_reminder_button"

    aput-object v3, v2, v6

    const-string v3, "slimline_survey_video_with_context"

    aput-object v3, v2, v4

    const-string v3, "snappy_horizontal_shelf"

    aput-object v3, v2, v5

    const-string v3, "video_metadata_carousel"

    aput-object v3, v2, v8

    invoke-static {v2}, Ljava/util/stream/Stream;->of([Ljava/lang/Object;)Ljava/util/stream/Stream;

    move-result-object v2

    .line 228
    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v3, LuTools/uBlocker$$ExternalSyntheticLambda0;

    invoke-direct {v3, v1}, LuTools/uBlocker$$ExternalSyntheticLambda0;-><init>(Ljava/lang/String;)V

    invoke-interface {v2, v3}, Ljava/util/stream/Stream;->anyMatch(Ljava/util/function/Predicate;)Z

    move-result v2
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_0

    .line 220
    monitor-exit v0

    return v2

    .line 233
    :cond_11
    const/16 v2, 0x46

    :try_start_d
    new-array v2, v2, [Ljava/lang/String;

    const-string v10, "banner_text_icon_buttoned_layout"

    aput-object v10, v2, v7

    const-string v7, "brand_video_"

    aput-object v7, v2, v3

    const-string v3, "carousel_footered_"

    aput-object v3, v2, v6

    const-string v3, "compact_landscape_image_layout"

    aput-object v3, v2, v4

    const-string v3, "composite_concurrent_carousel_layout"

    aput-object v3, v2, v5

    const-string v3, "full_width_"

    aput-object v3, v2, v8

    const-string v3, "inline_injection_entrypoint_layout"

    aput-object v3, v2, v9

    const-string v3, "landscape_image_wide_button_layout"

    const/4 v4, 0x7

    aput-object v3, v2, v4

    const-string v3, "square_image_layout"

    const/16 v4, 0x8

    aput-object v3, v2, v4

    const-string v3, "statement_banner"

    const/16 v4, 0x9

    aput-object v3, v2, v4

    const-string v3, "text_image_"

    const/16 v4, 0xa

    aput-object v3, v2, v4

    const-string v3, "video_display_"

    const/16 v4, 0xb

    aput-object v3, v2, v4

    const-string v3, "browsy_bar"

    const/16 v4, 0xc

    aput-object v3, v2, v4

    const-string v3, "cell_expandable_metadata"

    const/16 v4, 0xd

    aput-object v3, v2, v4

    const-string v3, "channel_guidelines_entry_banner"

    const/16 v4, 0xe

    aput-object v3, v2, v4

    const-string v3, "chips_shelf"

    const/16 v4, 0xf

    aput-object v3, v2, v4

    const-string v3, "community_guidelines"

    const/16 v4, 0x10

    aput-object v3, v2, v4

    const-string v3, "compact_tvfilm_item"

    const/16 v4, 0x11

    aput-object v3, v2, v4

    const-string v3, "emergency_onebox"

    const/16 v4, 0x12

    aput-object v3, v2, v4

    const-string v3, "expandable_list"

    const/16 v4, 0x13

    aput-object v3, v2, v4

    const-string v3, "expandable_section"

    const/16 v4, 0x14

    aput-object v3, v2, v4

    const-string v3, "featured_channel_watermark_overlay"

    const/16 v4, 0x15

    aput-object v3, v2, v4

    const-string v3, "feed_nudge"

    const/16 v4, 0x16

    aput-object v3, v2, v4

    const-string v3, "fullscreen_related_videos_entry_point"

    const/16 v4, 0x17

    aput-object v3, v2, v4

    const-string v3, "grid_channel_shelf"

    const/16 v4, 0x18

    aput-object v3, v2, v4

    const-string v3, "hero_carousel"

    const/16 v4, 0x19

    aput-object v3, v2, v4

    const-string v3, "horizontal_gaming_shelf"

    const/16 v4, 0x1a

    aput-object v3, v2, v4

    const-string v3, "horizontal_tile_shelf"

    const/16 v4, 0x1b

    aput-object v3, v2, v4

    const-string v3, "image_shelf"

    const/16 v4, 0x1c

    aput-object v3, v2, v4

    const-string v3, "images_post_root"

    const/16 v4, 0x1d

    aput-object v3, v2, v4

    const-string v3, "images_post_root_slim"

    const/16 v4, 0x1e

    aput-object v3, v2, v4

    const-string v3, "images_post_slim"

    const/16 v4, 0x1f

    aput-object v3, v2, v4

    const-string v3, "info_card_teaser_overlay"

    const/16 v4, 0x20

    aput-object v3, v2, v4

    const-string v3, "infocards_section"

    const/16 v4, 0x21

    aput-object v3, v2, v4

    const-string v3, "live_chat_sponsorships_new_member_announcement"

    const/16 v4, 0x22

    aput-object v3, v2, v4

    const-string v3, "live_chat_text_message_banner"

    const/16 v4, 0x23

    aput-object v3, v2, v4

    const-string v3, "live_chat_ticker_creator_goal_view_model"

    const/16 v4, 0x24

    aput-object v3, v2, v4

    const-string v3, "macro_markers_carousel"

    const/16 v4, 0x25

    aput-object v3, v2, v4

    const-string v3, "medical_panel"

    const/16 v4, 0x26

    aput-object v3, v2, v4

    const-string v3, "member_recognition_shelf"

    const/16 v4, 0x27

    aput-object v3, v2, v4

    const-string v3, "music_recap_banner"

    const/16 v4, 0x28

    aput-object v3, v2, v4

    const-string v3, "offer_module_root"

    const/16 v4, 0x29

    aput-object v3, v2, v4

    const-string v3, "paid_content_overlay"

    const/16 v4, 0x2a

    aput-object v3, v2, v4

    const-string v3, "playlist_section"

    const/16 v4, 0x2b

    aput-object v3, v2, v4

    const-string v3, "poll_post_root"

    const/16 v4, 0x2c

    aput-object v3, v2, v4

    const-string v3, "post_base_wrapper"

    const/16 v4, 0x2d

    aput-object v3, v2, v4

    const-string v3, "post_shelf_slim"

    const/16 v4, 0x2e

    aput-object v3, v2, v4

    const-string v3, "product_carousel"

    const/16 v4, 0x2f

    aput-object v3, v2, v4

    const-string v3, "products_in_video_with_preview"

    const/16 v4, 0x30

    aput-object v3, v2, v4

    const-string v3, "publisher_transparency_panel"

    const/16 v4, 0x31

    aput-object v3, v2, v4

    const-string v3, "reel_multi_format_link"

    const/16 v4, 0x32

    aput-object v3, v2, v4

    const-string v3, "reel_pivot_button"

    const/16 v4, 0x33

    aput-object v3, v2, v4

    const-string v3, "reel_player_disclosure"

    const/16 v4, 0x34

    aput-object v3, v2, v4

    const-string v3, "reel_sound_metadata"

    const/16 v4, 0x35

    aput-object v3, v2, v4

    const-string v3, "search_friction"

    const/16 v4, 0x36

    aput-object v3, v2, v4

    const-string v3, "sfv_audio_item"

    const/16 v4, 0x37

    aput-object v3, v2, v4

    const-string v3, "shelf_header"

    const/16 v4, 0x38

    aput-object v3, v2, v4

    const-string v3, "shorts_info_panel_overview"

    const/16 v4, 0x39

    aput-object v3, v2, v4

    const-string v3, "shorts_paused_state"

    const/16 v4, 0x3a

    aput-object v3, v2, v4

    const-string v3, "shorts_shelf"

    const/16 v4, 0x3b

    aput-object v3, v2, v4

    const-string v3, "single_item_information_panel"

    const/16 v4, 0x3c

    aput-object v3, v2, v4

    const-string v3, "super_chat_item"

    const/16 v4, 0x3d

    aput-object v3, v2, v4

    const-string v3, "text_post_root"

    const/16 v4, 0x3e

    aput-object v3, v2, v4

    const-string v3, "text_post_root_slim"

    const/16 v4, 0x3f

    aput-object v3, v2, v4

    const-string v3, "timed_reaction"

    const/16 v4, 0x40

    aput-object v3, v2, v4

    const-string v3, "topic_with_thumbnail_view_model"

    const/16 v4, 0x41

    aput-object v3, v2, v4

    const-string v3, "transcript_section"

    const/16 v4, 0x42

    aput-object v3, v2, v4

    const-string v3, "video_attributes_section"

    const/16 v4, 0x43

    aput-object v3, v2, v4

    const-string v3, "videos_post_root"

    const/16 v4, 0x44

    aput-object v3, v2, v4

    const-string v3, "|suggested_action."

    const/16 v4, 0x45

    aput-object v3, v2, v4

    invoke-static {v2}, Ljava/util/stream/Stream;->of([Ljava/lang/Object;)Ljava/util/stream/Stream;

    move-result-object v2

    .line 321
    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v3, LuTools/uBlocker$$ExternalSyntheticLambda0;

    invoke-direct {v3, v1}, LuTools/uBlocker$$ExternalSyntheticLambda0;-><init>(Ljava/lang/String;)V

    invoke-interface {v2, v3}, Ljava/util/stream/Stream;->anyMatch(Ljava/util/function/Predicate;)Z

    move-result v2
    :try_end_d
    .catchall {:try_start_d .. :try_end_d} :catchall_0

    .line 233
    monitor-exit v0

    return v2

    .line 104
    .end local v1    # "strTemplateTreeComponents":Ljava/lang/String;
    .end local p0    # "templateTreeComponents":Ljava/lang/StringBuilder;
    :catchall_0
    move-exception p0

    :try_start_e
    monitor-exit v0
    :try_end_e
    .catchall {:try_start_e .. :try_end_e} :catchall_0

    throw p0
.end method

.method public static HideLiveChatSubscribersShelf(Landroid/view/View;)V
    .locals 2
    .param p0, "view"    # Landroid/view/View;

    .line 338
    invoke-virtual {p0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v0

    new-instance v1, LuTools/uBlocker$$ExternalSyntheticLambda4;

    invoke-direct {v1, p0}, LuTools/uBlocker$$ExternalSyntheticLambda4;-><init>(Landroid/view/View;)V

    invoke-virtual {v0, v1}, Landroid/view/ViewTreeObserver;->addOnGlobalLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    .line 347
    return-void
.end method

.method public static HideLiveChatWelcomeAndRulesNotice(Landroid/view/View;)V
    .locals 2
    .param p0, "view"    # Landroid/view/View;

    .line 326
    sget-boolean v0, LuTools/uBlocker;->hideWelcomeAndRules:Z

    if-eqz v0, :cond_0

    .line 327
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    .line 330
    .local v0, "viewParent":Landroid/view/ViewParent;
    :try_start_0
    move-object v1, v0

    check-cast v1, Landroid/view/View;

    invoke-static {v1}, LuTools/uUtils;->HideViewByLinearLayoutParams(Landroid/view/View;)V

    .line 332
    const/4 v1, 0x0

    sput-boolean v1, LuTools/uBlocker;->hideWelcomeAndRules:Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 333
    :catch_0
    move-exception v1

    :goto_0
    nop

    .line 335
    .end local v0    # "viewParent":Landroid/view/ViewParent;
    :cond_0
    return-void
.end method

.method public static HideNavigationbarButtons(Landroid/view/View;)V
    .locals 3
    .param p0, "view"    # Landroid/view/View;

    .line 366
    :try_start_0
    const-string v0, "TAB_SHORTS"

    invoke-static {v0}, Ljava/util/stream/Stream;->of(Ljava/lang/Object;)Ljava/util/stream/Stream;

    move-result-object v0

    sget-object v1, LuTools/uBlocker;->navigationBarPivot:Ljava/lang/Enum;

    .line 368
    invoke-virtual {v1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v2, LuTools/uBlocker$$ExternalSyntheticLambda0;

    invoke-direct {v2, v1}, LuTools/uBlocker$$ExternalSyntheticLambda0;-><init>(Ljava/lang/String;)V

    invoke-interface {v0, v2}, Ljava/util/stream/Stream;->anyMatch(Ljava/util/function/Predicate;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 369
    invoke-static {p0}, LuTools/uUtils;->HideView(Landroid/view/View;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 371
    :catch_0
    move-exception v0

    :cond_0
    :goto_0
    nop

    .line 372
    return-void
.end method

.method public static HideSearchTrendingSuggestions(Ljava/lang/String;)Z
    .locals 1
    .param p0, "str"    # Ljava/lang/String;

    .line 375
    invoke-virtual {p0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    return v0
.end method

.method public static HideTabMyAccountGetPremium(Landroid/view/View;Ljava/lang/CharSequence;)V
    .locals 3
    .param p0, "view"    # Landroid/view/View;
    .param p1, "charSequence"    # Ljava/lang/CharSequence;

    .line 351
    :try_start_0
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    invoke-interface {v0}, Landroid/view/ViewParent;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    instance-of v1, v0, Landroid/view/ViewGroup;

    if-eqz v1, :cond_1

    check-cast v0, Landroid/view/ViewGroup;

    .line 352
    .local v0, "viewGroup":Landroid/view/ViewGroup;
    invoke-interface {p1}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "Premium"

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_1

    .line 353
    invoke-virtual {v0}, Landroid/view/ViewGroup;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    instance-of v1, v1, Landroid/view/ViewGroup$MarginLayoutParams;

    if-eqz v1, :cond_0

    .line 354
    invoke-static {v0}, LuTools/uUtils;->HideViewGroupByMarginLayout(Landroid/view/ViewGroup;)V

    goto :goto_0

    .line 356
    :cond_0
    invoke-static {v0}, LuTools/uUtils;->HideViewGroupByLayoutParams(Landroid/view/ViewGroup;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 360
    .end local v0    # "viewGroup":Landroid/view/ViewGroup;
    :catch_0
    move-exception v0

    :cond_1
    :goto_0
    nop

    .line 361
    return-void
.end method

.method public static HideTopbarButtons(Landroid/view/View;)V
    .locals 3
    .param p0, "view"    # Landroid/view/View;

    .line 381
    const/4 v0, 0x3

    :try_start_0
    new-array v0, v0, [Ljava/lang/String;

    const-string v1, "CREATION_ENTRY"

    const/4 v2, 0x0

    aput-object v1, v0, v2

    const-string v1, "FAB_CAMERA"

    const/4 v2, 0x1

    aput-object v1, v0, v2

    const-string v1, "TAB_ACTIVITY_CAIRO"

    const/4 v2, 0x2

    aput-object v1, v0, v2

    invoke-static {v0}, Ljava/util/stream/Stream;->of([Ljava/lang/Object;)Ljava/util/stream/Stream;

    move-result-object v0

    sget-object v1, LuTools/uBlocker;->topBarPivot:Ljava/lang/Enum;

    .line 385
    invoke-virtual {v1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v2, LuTools/uBlocker$$ExternalSyntheticLambda0;

    invoke-direct {v2, v1}, LuTools/uBlocker$$ExternalSyntheticLambda0;-><init>(Ljava/lang/String;)V

    invoke-interface {v0, v2}, Ljava/util/stream/Stream;->anyMatch(Ljava/util/function/Predicate;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 386
    invoke-static {p0}, LuTools/uUtils;->HideView(Landroid/view/View;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 388
    :catch_0
    move-exception v0

    :cond_0
    :goto_0
    nop

    .line 389
    return-void
.end method

.method public static OpenVideoChannel(Ljava/lang/String;)Z
    .locals 4
    .param p0, "videoID"    # Ljava/lang/String;

    .line 399
    sget-object v0, LuTools/uBlocker;->openVideoChannelThread:Ljava/lang/Thread;

    if-nez v0, :cond_0

    .line 400
    sget-boolean v0, LuTools/uUtils;->isCommentsOrLiveChatPanelOpen:Z

    if-nez v0, :cond_0

    sget-wide v0, LuTools/uUtils;->lithoActionDownDuration:J

    const-wide/16 v2, 0x3e8

    cmp-long v0, v0, v2

    if-ltz v0, :cond_0

    .line 401
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, LuTools/uBlocker$$ExternalSyntheticLambda1;

    invoke-direct {v1, p0}, LuTools/uBlocker$$ExternalSyntheticLambda1;-><init>(Ljava/lang/String;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    sput-object v0, LuTools/uBlocker;->openVideoChannelThread:Ljava/lang/Thread;

    .line 460
    sget-object v0, LuTools/uBlocker;->openVideoChannelThread:Ljava/lang/Thread;

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 462
    const/4 v0, 0x1

    return v0

    .line 466
    :cond_0
    const/4 v0, 0x0

    return v0
.end method

.method public static OpenVideoResolutionsFlyout(Landroid/support/v7/widget/RecyclerView;)V
    .locals 2
    .param p0, "recyclerView"    # Landroid/support/v7/widget/RecyclerView;

    .line 470
    invoke-virtual {p0}, Landroid/support/v7/widget/RecyclerView;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v0

    new-instance v1, LuTools/uBlocker$$ExternalSyntheticLambda3;

    invoke-direct {v1, p0}, LuTools/uBlocker$$ExternalSyntheticLambda3;-><init>(Landroid/support/v7/widget/RecyclerView;)V

    invoke-virtual {v0, v1}, Landroid/view/ViewTreeObserver;->addOnDrawListener(Landroid/view/ViewTreeObserver$OnDrawListener;)V

    .line 480
    return-void
.end method

.method public static OverrideTrackingUrl(Landroid/net/Uri;)Landroid/net/Uri;
    .locals 2
    .param p0, "trackingUrl"    # Landroid/net/Uri;

    .line 483
    invoke-virtual {p0}, Landroid/net/Uri;->buildUpon()Landroid/net/Uri$Builder;

    move-result-object v0

    const-string v1, "www.youtube.com"

    invoke-virtual {v0, v1}, Landroid/net/Uri$Builder;->authority(Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object v0

    invoke-virtual {v0}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    move-result-object v0

    return-object v0
.end method

.method public static SetPreferredVideoQuality([Ljava/lang/Object;ILjava/lang/Object;Ljava/lang/String;)I
    .locals 11
    .param p0, "qualities"    # [Ljava/lang/Object;
    .param p1, "originalQualityIndex"    # I
    .param p2, "qInterface"    # Ljava/lang/Object;
    .param p3, "qIndexMethod"    # Ljava/lang/String;

    .line 497
    :try_start_0
    sget-object v0, LuTools/uBlocker;->videoQualities:Ljava/util/List;

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    sget-object v0, LuTools/uBlocker;->videoQualities:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    array-length v3, p0

    if-eq v0, v3, :cond_4

    .line 498
    :cond_0
    new-instance v0, Ljava/util/ArrayList;

    array-length v3, p0

    invoke-direct {v0, v3}, Ljava/util/ArrayList;-><init>(I)V

    sput-object v0, LuTools/uBlocker;->videoQualities:Ljava/util/List;

    .line 500
    array-length v0, p0

    move v3, v2

    :goto_0
    if-ge v3, v0, :cond_3

    aget-object v4, p0, v3

    .line 501
    .local v4, "streamQuality":Ljava/lang/Object;
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Class;->getFields()[Ljava/lang/reflect/Field;

    move-result-object v5

    array-length v6, v5

    move v7, v2

    :goto_1
    if-ge v7, v6, :cond_2

    aget-object v8, v5, v7

    .line 502
    .local v8, "field":Ljava/lang/reflect/Field;
    invoke-virtual {v8}, Ljava/lang/reflect/Field;->getType()Ljava/lang/Class;

    move-result-object v9

    sget-object v10, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    invoke-virtual {v9, v10}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v9

    if-eqz v9, :cond_1

    .line 503
    invoke-virtual {v8}, Ljava/lang/reflect/Field;->getName()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/String;->length()I

    move-result v9

    const/4 v10, 0x2

    if-gt v9, v10, :cond_1

    .line 504
    sget-object v9, LuTools/uBlocker;->videoQualities:Ljava/util/List;

    invoke-virtual {v8, v4}, Ljava/lang/reflect/Field;->getInt(Ljava/lang/Object;)I

    move-result v10

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-interface {v9, v10}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 501
    .end local v8    # "field":Ljava/lang/reflect/Field;
    :cond_1
    add-int/lit8 v7, v7, 0x1

    goto :goto_1

    .line 500
    .end local v4    # "streamQuality":Ljava/lang/Object;
    :cond_2
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    .line 509
    :cond_3
    sput-boolean v1, LuTools/uBlocker;->qualityNeedsUpdating:Z

    .line 512
    :cond_4
    sget-boolean v0, LuTools/uBlocker;->qualityNeedsUpdating:Z

    if-nez v0, :cond_5

    .line 513
    return p1

    .line 515
    :cond_5
    sput-boolean v2, LuTools/uBlocker;->qualityNeedsUpdating:Z

    .line 517
    sget-object v0, LuTools/uBlocker;->videoQualities:Ljava/util/List;

    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    .line 518
    .local v0, "qualityToUse":I
    const/4 v3, 0x0

    .line 519
    .local v3, "qualityIndexToUse":I
    const/4 v4, 0x0

    .line 520
    .local v4, "i":I
    sget-object v5, LuTools/uBlocker;->videoQualities:Ljava/util/List;

    invoke-interface {v5}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_2
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_7

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/Integer;

    .line 521
    .local v6, "quality":Ljava/lang/Integer;
    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    move-result v7

    sget-object v8, LuTools/uBlocker;->preferredQuality:Ljava/lang/Integer;

    invoke-virtual {v8}, Ljava/lang/Integer;->intValue()I

    move-result v8

    if-gt v7, v8, :cond_6

    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    move-result v7

    if-ge v0, v7, :cond_6

    .line 522
    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    move-result v7

    .line 523
    .end local v0    # "qualityToUse":I
    .local v7, "qualityToUse":I
    move v0, v4

    move v3, v0

    move v0, v7

    .line 526
    .end local v7    # "qualityToUse":I
    .restart local v0    # "qualityToUse":I
    :cond_6
    nop

    .end local v6    # "quality":Ljava/lang/Integer;
    add-int/lit8 v4, v4, 0x1

    .line 527
    goto :goto_2

    .line 529
    :cond_7
    nop

    .line 530
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v5

    new-array v1, v1, [Ljava/lang/Class;

    sget-object v6, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    aput-object v6, v1, v2

    .line 531
    invoke-virtual {v5, p3, v1}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    .line 532
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    filled-new-array {v2}, [Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v1, p2, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 534
    return v3

    .line 535
    .end local v0    # "qualityToUse":I
    .end local v3    # "qualityIndexToUse":I
    .end local v4    # "i":I
    :catch_0
    move-exception v0

    .line 536
    .local v0, "ex":Ljava/lang/Exception;
    return p1
.end method

.method public static SetPreferredVideoQualityClear()V
    .locals 1

    .line 491
    const/4 v0, 0x1

    sput-boolean v0, LuTools/uBlocker;->qualityNeedsUpdating:Z

    .line 493
    const/4 v0, 0x0

    sput-object v0, LuTools/uBlocker;->videoQualities:Ljava/util/List;

    .line 494
    return-void
.end method

.method public static SetSelectedFlyoutQuality(I)V
    .locals 1
    .param p0, "selectedQuality"    # I

    .line 540
    if-lez p0, :cond_0

    .line 541
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    sput-object v0, LuTools/uBlocker;->preferredQuality:Ljava/lang/Integer;

    .line 543
    :cond_0
    return-void
.end method

.method public static ShortsPlayerBypassing(Ljava/lang/String;)Z
    .locals 6
    .param p0, "shortsVideoID"    # Ljava/lang/String;

    .line 546
    sget v0, LuTools/uBlocker;->currentNavBarIndex:I

    const/4 v1, 0x1

    if-eq v0, v1, :cond_0

    .line 548
    :try_start_0
    invoke-static {}, LuTools/uUtils;->GetMainActivityContext()Landroid/content/Context;

    move-result-object v0

    .line 550
    .local v0, "context":Landroid/content/Context;
    new-instance v2, Landroid/content/Intent;

    const-string v3, "android.intent.action.VIEW"

    const-string v4, "https://www.youtube.com/watch?v=%s"

    filled-new-array {p0}, [Ljava/lang/Object;

    move-result-object v5

    .line 554
    invoke-static {v4, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    .line 553
    invoke-static {v4}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v4

    invoke-direct {v2, v3, v4}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 561
    .local v2, "videoPlayerIntent":Landroid/content/Intent;
    const/high16 v3, 0x10000000

    invoke-virtual {v2, v3}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 562
    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 564
    invoke-virtual {v0, v2}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 566
    return v1

    .line 567
    .end local v0    # "context":Landroid/content/Context;
    .end local v2    # "videoPlayerIntent":Landroid/content/Intent;
    :catch_0
    move-exception v0

    .line 570
    :cond_0
    const/4 v0, 0x0

    return v0
.end method

.method static synthetic lambda$ChangeLithoUIColor$0(ILjava/lang/Integer;)Z
    .locals 1
    .param p0, "originalValue"    # I
    .param p1, "val"    # Ljava/lang/Integer;

    .line 62
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/Integer;->equals(Ljava/lang/Object;)Z

    move-result v0

    return v0
.end method

.method static synthetic lambda$HideLiveChatSubscribersShelf$1(Landroid/view/View;)V
    .locals 3
    .param p0, "view"    # Landroid/view/View;

    .line 339
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    .line 342
    .local v0, "parent":Landroid/view/ViewParent;
    :try_start_0
    instance-of v1, v0, Landroid/support/v7/widget/RecyclerView;

    if-eqz v1, :cond_0

    .line 343
    move-object v1, v0

    check-cast v1, Landroid/support/v7/widget/RecyclerView;

    const/16 v2, 0x8

    invoke-virtual {v1, v2}, Landroid/support/v7/widget/RecyclerView;->setVisibility(I)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 345
    :catch_0
    move-exception v1

    :cond_0
    :goto_0
    nop

    .line 346
    return-void
.end method

.method static synthetic lambda$OpenVideoChannel$2(Ljava/lang/String;)V
    .locals 8
    .param p0, "videoID"    # Ljava/lang/String;

    .line 405
    nop

    :cond_0
    :goto_0
    const/4 v0, 0x0

    :try_start_0
    sget-object v1, LuTools/uBlocker;->openVideoChannelThread:Ljava/lang/Thread;

    invoke-virtual {v1}, Ljava/lang/Thread;->isInterrupted()Z

    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-nez v1, :cond_3

    .line 407
    :try_start_1
    sget-object v1, LuTools/uBlocker;->openVideoChannelToastInProgress:Landroid/widget/Toast;

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    .line 409
    invoke-static {}, LuTools/uUtils;->GetMainActivityContext()Landroid/content/Context;

    move-result-object v1

    .line 411
    .local v1, "context":Landroid/content/Context;
    invoke-static {p0}, LuTools/VideoDetails/uVideoDetailsRequest;->SetFetchRequest(Ljava/lang/String;)V

    .line 412
    invoke-static {p0}, LuTools/VideoDetails/uVideoDetailsRequest;->GetRequestForVideoID(Ljava/lang/String;)LuTools/VideoDetails/uVideoDetailsRequest;

    move-result-object v2

    .line 414
    .local v2, "videoIDRequest":LuTools/VideoDetails/uVideoDetailsRequest;
    if-eqz v2, :cond_2

    .line 415
    invoke-virtual {v2}, LuTools/VideoDetails/uVideoDetailsRequest;->GetChannelID()Ljava/lang/String;

    move-result-object v3

    .line 417
    .local v3, "channelID":Ljava/lang/String;
    if-eqz v3, :cond_1

    .line 418
    new-instance v4, Landroid/content/Intent;

    const-string v5, "android.intent.action.VIEW"

    const-string v6, "%s%s"

    const-string v7, "https://www.youtube.com/channel/"

    filled-new-array {v7, v3}, [Ljava/lang/Object;

    move-result-object v7

    .line 422
    invoke-static {v6, v7}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v6

    .line 421
    invoke-static {v6}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v6

    invoke-direct {v4, v5, v6}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 430
    .local v4, "openLiveChannelIntent":Landroid/content/Intent;
    const/high16 v5, 0x10000000

    invoke-virtual {v4, v5}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 431
    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 433
    invoke-virtual {v1, v4}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 435
    sget-object v5, LuTools/uBlocker;->openVideoChannelToastInProgress:Landroid/widget/Toast;

    invoke-virtual {v5}, Landroid/widget/Toast;->cancel()V

    .line 436
    sget-object v5, LuTools/uBlocker;->openVideoChannelToastDone:Landroid/widget/Toast;

    invoke-virtual {v5}, Landroid/widget/Toast;->show()V

    .line 438
    const/4 v4, 0x1

    .line 439
    .local v4, "stopVideoChannelThread":Z
    nop

    .line 442
    .end local v3    # "channelID":Ljava/lang/String;
    nop

    .line 449
    .end local v1    # "context":Landroid/content/Context;
    .end local v2    # "videoIDRequest":LuTools/VideoDetails/uVideoDetailsRequest;
    goto :goto_1

    .line 440
    .end local v4    # "stopVideoChannelThread":Z
    .restart local v1    # "context":Landroid/content/Context;
    .restart local v2    # "videoIDRequest":LuTools/VideoDetails/uVideoDetailsRequest;
    .restart local v3    # "channelID":Ljava/lang/String;
    :cond_1
    new-instance v4, Ljava/lang/IllegalArgumentException;

    invoke-direct {v4}, Ljava/lang/IllegalArgumentException;-><init>()V

    .end local p0    # "videoID":Ljava/lang/String;
    throw v4

    .line 443
    .end local v3    # "channelID":Ljava/lang/String;
    .restart local p0    # "videoID":Ljava/lang/String;
    :cond_2
    new-instance v3, Ljava/lang/IllegalArgumentException;

    invoke-direct {v3}, Ljava/lang/IllegalArgumentException;-><init>()V

    .end local p0    # "videoID":Ljava/lang/String;
    throw v3
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 445
    .end local v1    # "context":Landroid/content/Context;
    .end local v2    # "videoIDRequest":LuTools/VideoDetails/uVideoDetailsRequest;
    .restart local p0    # "videoID":Ljava/lang/String;
    :catch_0
    move-exception v1

    .line 446
    .local v1, "ignore":Ljava/lang/Exception;
    :try_start_2
    sget-object v2, LuTools/uBlocker;->openVideoChannelToastError:Landroid/widget/Toast;

    invoke-virtual {v2}, Landroid/widget/Toast;->show()V

    .line 448
    const/4 v4, 0x1

    .line 451
    .end local v1    # "ignore":Ljava/lang/Exception;
    .restart local v4    # "stopVideoChannelThread":Z
    :goto_1
    if-eqz v4, :cond_0

    .line 452
    sget-object v1, LuTools/uBlocker;->openVideoChannelThread:Ljava/lang/Thread;

    invoke-virtual {v1}, Ljava/lang/Thread;->interrupt()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    goto :goto_0

    .line 456
    .end local v4    # "stopVideoChannelThread":Z
    :cond_3
    sput-object v0, LuTools/uBlocker;->openVideoChannelThread:Ljava/lang/Thread;

    .line 457
    nop

    .line 458
    return-void

    .line 456
    :catchall_0
    move-exception v1

    sput-object v0, LuTools/uBlocker;->openVideoChannelThread:Ljava/lang/Thread;

    .line 457
    throw v1
.end method

.method static synthetic lambda$OpenVideoResolutionsFlyout$3(Landroid/support/v7/widget/RecyclerView;)V
    .locals 3
    .param p0, "recyclerView"    # Landroid/support/v7/widget/RecyclerView;

    .line 472
    :try_start_0
    sget-boolean v0, LuTools/uBlocker;->quickQualityBottomSheet:Z

    if-eqz v0, :cond_0

    .line 473
    const/4 v0, 0x0

    sput-boolean v0, LuTools/uBlocker;->quickQualityBottomSheet:Z

    .line 475
    invoke-virtual {p0}, Landroid/support/v7/widget/RecyclerView;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    invoke-interface {v1}, Landroid/view/ViewParent;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    invoke-interface {v1}, Landroid/view/ViewParent;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    check-cast v1, Landroid/view/ViewGroup;

    const/16 v2, 0x8

    invoke-virtual {v1, v2}, Landroid/view/ViewGroup;->setVisibility(I)V

    .line 476
    invoke-virtual {p0, v0}, Landroid/support/v7/widget/RecyclerView;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/view/ViewGroup;

    const/4 v1, 0x3

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/View;->performClick()Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 478
    :catch_0
    move-exception v0

    :cond_0
    :goto_0
    nop

    .line 479
    return-void
.end method
