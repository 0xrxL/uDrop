.class LuTools/uUtils$2;
.super Ljava/util/HashMap;
.source "uUtils.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LuTools/uUtils;->InitializeNewBlockList(Ljava/util/AbstractMap$SimpleEntry;)Ljava/util/AbstractMap$SimpleEntry;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/util/HashMap<",
        "Ljava/lang/String;",
        "Ljava/lang/String;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic val$blockList:Ljava/util/AbstractMap$SimpleEntry;


# direct methods
.method constructor <init>(Ljava/util/AbstractMap$SimpleEntry;)V
    .locals 1

    .line 213
    iput-object p1, p0, LuTools/uUtils$2;->val$blockList:Ljava/util/AbstractMap$SimpleEntry;

    invoke-direct {p0}, Ljava/util/HashMap;-><init>()V

    .line 214
    iget-object p1, p0, LuTools/uUtils$2;->val$blockList:Ljava/util/AbstractMap$SimpleEntry;

    invoke-virtual {p1}, Ljava/util/AbstractMap$SimpleEntry;->getKey()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/Set;

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    .line 215
    .local v0, "filter":Ljava/lang/String;
    invoke-virtual {p0, v0, v0}, LuTools/uUtils$2;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 216
    .end local v0    # "filter":Ljava/lang/String;
    goto :goto_0

    .line 213
    :cond_0
    return-void
.end method
