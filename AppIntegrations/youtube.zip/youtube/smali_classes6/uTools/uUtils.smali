.class public LuTools/uUtils;
.super Ljava/lang/Object;
.source "uUtils.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LuTools/uUtils$entries;,
        LuTools/uUtils$EnumInitialization;
    }
.end annotation


# static fields
.field public static final BackgroundThreadPool:Ljava/util/concurrent/ThreadPoolExecutor;

.field public static appContext:Landroid/content/Context;

.field public static isCommentsOrLiveChatPanelOpen:Z

.field private static isDarkTheme:Z

.field public static lithoActionDownDuration:J

.field private static lithoActionDownStartTime:J

.field private static mainActivity:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Landroid/app/Activity;",
            ">;"
        }
    .end annotation
.end field

.field public static playerType:Ljava/lang/Enum;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Enum<",
            "*>;"
        }
    .end annotation
.end field

.field private static statsForNerdsClientName:Ljava/lang/String;


# direct methods
.method public static synthetic $r8$lambda$yKRGTDwFHgOlK-w-W5TPtJhLgqE(Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;Ljava/lang/String;)Z
    .locals 0

    invoke-virtual {p0, p1}, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->matches(Ljava/lang/String;)Z

    move-result p0

    return p0
.end method

.method static constructor <clinit>()V
    .locals 9

    .line 92
    const-wide/16 v0, 0x0

    sput-wide v0, LuTools/uUtils;->lithoActionDownStartTime:J

    .line 93
    sput-wide v0, LuTools/uUtils;->lithoActionDownDuration:J

    .line 130
    sget-object v0, LuTools/uUtils$EnumInitialization;->NONE:LuTools/uUtils$EnumInitialization;

    sput-object v0, LuTools/uUtils;->playerType:Ljava/lang/Enum;

    .line 141
    const/4 v0, 0x0

    sput-boolean v0, LuTools/uUtils;->isCommentsOrLiveChatPanelOpen:Z

    .line 282
    sput-boolean v0, LuTools/uUtils;->isDarkTheme:Z

    .line 308
    new-instance v1, Ljava/util/concurrent/ThreadPoolExecutor;

    sget-object v6, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    new-instance v7, Ljava/util/concurrent/SynchronousQueue;

    invoke-direct {v7}, Ljava/util/concurrent/SynchronousQueue;-><init>()V

    new-instance v8, LuTools/uUtils$$ExternalSyntheticLambda3;

    invoke-direct {v8}, LuTools/uUtils$$ExternalSyntheticLambda3;-><init>()V

    const/4 v2, 0x1

    const/4 v3, 0x1

    const-wide/16 v4, 0x4e20

    invoke-direct/range {v1 .. v8}, Ljava/util/concurrent/ThreadPoolExecutor;-><init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;Ljava/util/concurrent/ThreadFactory;)V

    sput-object v1, LuTools/uUtils;->BackgroundThreadPool:Ljava/util/concurrent/ThreadPoolExecutor;

    .line 321
    const-string v0, ""

    sput-object v0, LuTools/uUtils;->statsForNerdsClientName:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 39
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static ByteBufferContainsString(Ljava/nio/ByteBuffer;Ljava/util/Set;LuTools/uUtils$entries;)Z
    .locals 11
    .param p0, "bArrSource"    # Ljava/nio/ByteBuffer;
    .param p2, "entriesEnum"    # LuTools/uUtils$entries;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/nio/ByteBuffer;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;",
            "LuTools/uUtils$entries;",
            ")Z"
        }
    .end annotation

    .line 46
    .local p1, "blockList":Ljava/util/Set;, "Ljava/util/Set<Ljava/lang/String;>;"
    const/4 v0, 0x0

    .line 47
    .local v0, "entriesFound":I
    invoke-virtual {p0}, Ljava/nio/ByteBuffer;->limit()I

    move-result v1

    .line 49
    .local v1, "bArrSourceLimit":I
    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v4, 0x0

    if-eqz v3, :cond_3

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    .line 50
    .local v3, "filter":Ljava/lang/String;
    invoke-virtual {v3}, Ljava/lang/String;->getBytes()[B

    move-result-object v5

    .line 51
    .local v5, "bArrTarget":[B
    array-length v6, v5

    .line 53
    .local v6, "bArrTargetLength":I
    const/4 v7, 0x0

    .local v7, "i":I
    :goto_1
    sub-int v8, v1, v6

    if-gt v7, v8, :cond_2

    .line 54
    invoke-virtual {p0, v7}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v8

    aget-byte v9, v5, v4

    if-ne v8, v9, :cond_1

    .line 55
    const/4 v8, 0x0

    .line 57
    .local v8, "j":I
    :goto_2
    if-ge v8, v6, :cond_0

    add-int v9, v7, v8

    invoke-virtual {p0, v9}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v9

    aget-byte v10, v5, v8

    if-ne v9, v10, :cond_0

    .line 58
    add-int/lit8 v8, v8, 0x1

    goto :goto_2

    .line 61
    :cond_0
    if-ne v8, v6, :cond_1

    .line 62
    add-int/lit8 v0, v0, 0x1

    .line 64
    goto :goto_3

    .line 53
    .end local v8    # "j":I
    :cond_1
    add-int/lit8 v7, v7, 0x1

    goto :goto_1

    .line 68
    .end local v3    # "filter":Ljava/lang/String;
    .end local v5    # "bArrTarget":[B
    .end local v6    # "bArrTargetLength":I
    .end local v7    # "i":I
    :cond_2
    :goto_3
    goto :goto_0

    .line 70
    :cond_3
    invoke-virtual {p2}, LuTools/uUtils$entries;->name()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v3

    const/4 v5, 0x1

    sparse-switch v3, :sswitch_data_0

    :cond_4
    goto :goto_4

    :sswitch_0
    const-string v3, "ANY"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_4

    move v2, v4

    goto :goto_5

    :sswitch_1
    const-string v3, "ALL"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_4

    move v2, v5

    goto :goto_5

    :goto_4
    const/4 v2, -0x1

    :goto_5
    packed-switch v2, :pswitch_data_0

    .line 73
    goto :goto_6

    .line 72
    :pswitch_0
    invoke-interface {p1}, Ljava/util/Set;->size()I

    move-result v2

    if-ne v0, v2, :cond_5

    move v4, v5

    goto :goto_6

    .line 71
    :pswitch_1
    if-lez v0, :cond_5

    move v4, v5

    .line 70
    :cond_5
    :goto_6
    return v4

    nop

    :sswitch_data_0
    .sparse-switch
        0xfd81 -> :sswitch_1
        0xfdcc -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public static CheckDarkTheme()Z
    .locals 1

    .line 284
    sget-boolean v0, LuTools/uUtils;->isDarkTheme:Z

    return v0
.end method

.method public static GetAppContext()Landroid/content/Context;
    .locals 2

    .line 79
    sget-object v0, LuTools/uUtils;->appContext:Landroid/content/Context;

    if-nez v0, :cond_0

    .line 80
    const-string v0, "uContext"

    const-string v1, "App Context is null"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 82
    const/4 v0, 0x0

    return-object v0

    .line 84
    :cond_0
    sget-object v0, LuTools/uUtils;->appContext:Landroid/content/Context;

    return-object v0
.end method

.method public static GetMainActivity()Landroid/app/Activity;
    .locals 2

    .line 106
    sget-object v0, LuTools/uUtils;->mainActivity:Ljava/lang/ref/WeakReference;

    if-nez v0, :cond_0

    .line 107
    const-string v0, "uActivity"

    const-string v1, "Main Activity is null"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 109
    const/4 v0, 0x0

    return-object v0

    .line 111
    :cond_0
    sget-object v0, LuTools/uUtils;->mainActivity:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/Activity;

    return-object v0
.end method

.method public static GetMainActivityContext()Landroid/content/Context;
    .locals 3

    .line 118
    sget-object v0, LuTools/uUtils;->mainActivity:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/content/Context;

    .line 120
    .local v0, "mainActivityContext":Landroid/content/Context;
    if-nez v0, :cond_0

    .line 121
    const-string v1, "uContext"

    const-string v2, "Main Activity Context is null"

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 123
    const/4 v1, 0x0

    return-object v1

    .line 125
    :cond_0
    return-object v0
.end method

.method public static GetNewToast(Ljava/lang/String;)Landroid/widget/Toast;
    .locals 2
    .param p0, "messageToToast"    # Ljava/lang/String;

    .line 303
    invoke-static {p0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 305
    invoke-static {}, LuTools/uUtils;->GetAppContext()Landroid/content/Context;

    move-result-object v0

    const/4 v1, 0x1

    invoke-static {v0, p0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    return-object v0
.end method

.method public static GetPlayerType()Ljava/lang/Enum;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/lang/Enum<",
            "*>;"
        }
    .end annotation

    .line 132
    sget-object v0, LuTools/uUtils;->playerType:Ljava/lang/Enum;

    if-nez v0, :cond_0

    .line 133
    const-string v0, "uPlayerType"

    const-string v1, "Player Type is null"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 135
    const/4 v0, 0x0

    return-object v0

    .line 137
    :cond_0
    sget-object v0, LuTools/uUtils;->playerType:Ljava/lang/Enum;

    return-object v0
.end method

.method public static GetStatsForNerdsClientName()Ljava/lang/String;
    .locals 1

    .line 323
    sget-object v0, LuTools/uUtils;->statsForNerdsClientName:Ljava/lang/String;

    return-object v0
.end method

.method private static GetuUtilsClassName()Ljava/lang/String;
    .locals 1

    .line 89
    const-class v0, LuTools/uUtils;

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public static HideImageView(Landroid/widget/ImageView;)V
    .locals 1
    .param p0, "imageView"    # Landroid/widget/ImageView;

    .line 144
    const/16 v0, 0x8

    invoke-virtual {p0, v0}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 145
    return-void
.end method

.method public static HideInstanceViewByLayoutParams(Landroid/view/View;)V
    .locals 2
    .param p0, "view"    # Landroid/view/View;

    .line 148
    instance-of v0, p0, Landroid/view/ViewGroup;

    if-eqz v0, :cond_0

    .line 149
    new-instance v0, Landroid/view/ViewGroup$LayoutParams;

    const/4 v1, 0x1

    invoke-direct {v0, v1, v1}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    invoke-virtual {p0, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 151
    :cond_0
    return-void
.end method

.method public static HideView(Landroid/view/View;)V
    .locals 1
    .param p0, "view"    # Landroid/view/View;

    .line 154
    const/16 v0, 0x8

    invoke-virtual {p0, v0}, Landroid/view/View;->setVisibility(I)V

    .line 155
    return-void
.end method

.method public static HideViewByLinearLayoutParams(Landroid/view/View;)V
    .locals 2
    .param p0, "view"    # Landroid/view/View;

    .line 158
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v1, 0x0

    invoke-direct {v0, v1, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {p0, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 159
    return-void
.end method

.method public static HideViewGroupByLayoutParams(Landroid/view/ViewGroup;)V
    .locals 2
    .param p0, "viewGroup"    # Landroid/view/ViewGroup;

    .line 162
    new-instance v0, Landroid/view/ViewGroup$LayoutParams;

    const/4 v1, 0x0

    invoke-direct {v0, v1, v1}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 163
    return-void
.end method

.method public static HideViewGroupByMarginLayout(Landroid/view/ViewGroup;)V
    .locals 1
    .param p0, "viewGroup"    # Landroid/view/ViewGroup;

    .line 166
    const/16 v0, 0x8

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->setVisibility(I)V

    .line 167
    return-void
.end method

.method public static InitializeCache()Ljava/util/LinkedHashMap;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">()",
            "Ljava/util/LinkedHashMap<",
            "Ljava/lang/String;",
            "TT;>;"
        }
    .end annotation

    .line 170
    new-instance v0, LuTools/uUtils$1;

    invoke-direct {v0}, LuTools/uUtils$1;-><init>()V

    return-object v0
.end method

.method public static InitializeNewBlockList(Ljava/util/AbstractMap$SimpleEntry;)Ljava/util/AbstractMap$SimpleEntry;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/AbstractMap$SimpleEntry<",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/util/AbstractMap$SimpleEntry<",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .line 179
    .local p0, "blockList":Ljava/util/AbstractMap$SimpleEntry;, "Ljava/util/AbstractMap$SimpleEntry<Ljava/util/Set<Ljava/lang/String;>;Ljava/lang/String;>;"
    new-instance v0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;

    invoke-direct {v0}, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;-><init>()V

    .line 181
    .local v0, "corasickObject":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<Ljava/lang/String;>;"
    new-instance v1, Ljava/io/File;

    sget-object v2, LuTools/uUtils;->appContext:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v2

    invoke-virtual {p0}, Ljava/util/AbstractMap$SimpleEntry;->getValue()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-direct {v1, v2, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 183
    .local v1, "file":Ljava/io/File;
    const/4 v2, 0x0

    .line 186
    .local v2, "generateAutomatonData":Z
    :try_start_0
    new-instance v3, Ljava/io/FileInputStream;

    invoke-direct {v3, v1}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 187
    .local v3, "fis":Ljava/io/FileInputStream;
    :try_start_1
    new-instance v4, Ljava/io/ObjectInputStream;

    invoke-direct {v4, v3}, Ljava/io/ObjectInputStream;-><init>(Ljava/io/InputStream;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    .line 189
    .local v4, "ois":Ljava/io/ObjectInputStream;
    :try_start_2
    invoke-virtual {v0, v4}, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->load(Ljava/io/ObjectInputStream;)V

    .line 191
    invoke-virtual {v4}, Ljava/io/ObjectInputStream;->close()V

    .line 193
    nop

    .line 194
    invoke-virtual {p0}, Ljava/util/AbstractMap$SimpleEntry;->getKey()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/Set;

    .line 195
    invoke-interface {v5}, Ljava/util/Set;->stream()Ljava/util/stream/Stream;

    move-result-object v5

    .line 196
    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v6, LuTools/uUtils$$ExternalSyntheticLambda0;

    invoke-direct {v6, v0}, LuTools/uUtils$$ExternalSyntheticLambda0;-><init>(Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;)V

    invoke-interface {v5, v6}, Ljava/util/stream/Stream;->filter(Ljava/util/function/Predicate;)Ljava/util/stream/Stream;

    move-result-object v5

    .line 197
    invoke-interface {v5}, Ljava/util/stream/Stream;->count()J

    move-result-wide v5

    .line 200
    invoke-virtual {p0}, Ljava/util/AbstractMap$SimpleEntry;->getKey()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/util/Set;

    .line 201
    invoke-interface {v7}, Ljava/util/Set;->size()I

    move-result v7

    int-to-long v7, v7

    cmp-long v5, v5, v7

    if-nez v5, :cond_0

    .line 204
    invoke-static {}, LuTools/uUtils;->GetuUtilsClassName()Ljava/lang/String;

    move-result-object v5

    const-string v6, "%s Aho-Corasick file succesfully loaded!"

    .line 206
    invoke-virtual {v1}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v7

    filled-new-array {v7}, [Ljava/lang/Object;

    move-result-object v7

    invoke-static {v6, v7}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v6

    .line 203
    invoke-static {v5, v6}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    goto :goto_0

    .line 209
    :cond_0
    const/4 v2, 0x1

    .line 211
    :goto_0
    :try_start_3
    invoke-virtual {v4}, Ljava/io/ObjectInputStream;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    .end local v4    # "ois":Ljava/io/ObjectInputStream;
    :try_start_4
    invoke-virtual {v3}, Ljava/io/FileInputStream;->close()V
    :try_end_4
    .catch Ljava/lang/ClassNotFoundException; {:try_start_4 .. :try_end_4} :catch_0
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_0

    .line 219
    .end local v3    # "fis":Ljava/io/FileInputStream;
    goto :goto_3

    .line 185
    .restart local v3    # "fis":Ljava/io/FileInputStream;
    .restart local v4    # "ois":Ljava/io/ObjectInputStream;
    :catchall_0
    move-exception v5

    :try_start_5
    invoke-virtual {v4}, Ljava/io/ObjectInputStream;->close()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    goto :goto_1

    :catchall_1
    move-exception v6

    :try_start_6
    invoke-virtual {v5, v6}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .end local v0    # "corasickObject":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<Ljava/lang/String;>;"
    .end local v1    # "file":Ljava/io/File;
    .end local v2    # "generateAutomatonData":Z
    .end local v3    # "fis":Ljava/io/FileInputStream;
    .end local p0    # "blockList":Ljava/util/AbstractMap$SimpleEntry;, "Ljava/util/AbstractMap$SimpleEntry<Ljava/util/Set<Ljava/lang/String;>;Ljava/lang/String;>;"
    :goto_1
    throw v5
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    .end local v4    # "ois":Ljava/io/ObjectInputStream;
    .restart local v0    # "corasickObject":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<Ljava/lang/String;>;"
    .restart local v1    # "file":Ljava/io/File;
    .restart local v2    # "generateAutomatonData":Z
    .restart local v3    # "fis":Ljava/io/FileInputStream;
    .restart local p0    # "blockList":Ljava/util/AbstractMap$SimpleEntry;, "Ljava/util/AbstractMap$SimpleEntry<Ljava/util/Set<Ljava/lang/String;>;Ljava/lang/String;>;"
    :catchall_2
    move-exception v4

    :try_start_7
    invoke-virtual {v3}, Ljava/io/FileInputStream;->close()V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_3

    goto :goto_2

    :catchall_3
    move-exception v5

    :try_start_8
    invoke-virtual {v4, v5}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .end local v0    # "corasickObject":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<Ljava/lang/String;>;"
    .end local v1    # "file":Ljava/io/File;
    .end local v2    # "generateAutomatonData":Z
    .end local p0    # "blockList":Ljava/util/AbstractMap$SimpleEntry;, "Ljava/util/AbstractMap$SimpleEntry<Ljava/util/Set<Ljava/lang/String;>;Ljava/lang/String;>;"
    :goto_2
    throw v4
    :try_end_8
    .catch Ljava/lang/ClassNotFoundException; {:try_start_8 .. :try_end_8} :catch_0
    .catch Ljava/io/IOException; {:try_start_8 .. :try_end_8} :catch_0

    .line 211
    .end local v3    # "fis":Ljava/io/FileInputStream;
    .restart local v0    # "corasickObject":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<Ljava/lang/String;>;"
    .restart local v1    # "file":Ljava/io/File;
    .restart local v2    # "generateAutomatonData":Z
    .restart local p0    # "blockList":Ljava/util/AbstractMap$SimpleEntry;, "Ljava/util/AbstractMap$SimpleEntry<Ljava/util/Set<Ljava/lang/String;>;Ljava/lang/String;>;"
    :catch_0
    move-exception v3

    .line 213
    .local v3, "e":Ljava/lang/Exception;
    invoke-static {}, LuTools/uUtils;->GetuUtilsClassName()Ljava/lang/String;

    move-result-object v4

    .line 215
    invoke-virtual {v3}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v5

    .line 212
    invoke-static {v4, v5}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 218
    const/4 v2, 0x1

    .line 221
    .end local v3    # "e":Ljava/lang/Exception;
    :goto_3
    if-eqz v2, :cond_1

    .line 222
    nop

    .line 225
    invoke-virtual {p0}, Ljava/util/AbstractMap$SimpleEntry;->getKey()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/util/Set;

    .line 226
    invoke-interface {v3}, Ljava/util/Set;->stream()Ljava/util/stream/Stream;

    move-result-object v3

    new-instance v4, LuTools/uUtils$$ExternalSyntheticLambda1;

    invoke-direct {v4}, LuTools/uUtils$$ExternalSyntheticLambda1;-><init>()V

    new-instance v5, LuTools/uUtils$$ExternalSyntheticLambda2;

    invoke-direct {v5}, LuTools/uUtils$$ExternalSyntheticLambda2;-><init>()V

    .line 229
    invoke-static {v4, v5}, Ljava/util/stream/Collectors;->toMap(Ljava/util/function/Function;Ljava/util/function/Function;)Ljava/util/stream/Collector;

    move-result-object v4

    .line 227
    invoke-interface {v3, v4}, Ljava/util/stream/Stream;->collect(Ljava/util/stream/Collector;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/util/Map;

    .line 223
    invoke-virtual {v0, v3}, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->build(Ljava/util/Map;)V

    .line 238
    :try_start_9
    new-instance v3, Ljava/io/FileOutputStream;

    invoke-direct {v3, v1}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    :try_end_9
    .catch Ljava/io/IOException; {:try_start_9 .. :try_end_9} :catch_1

    .line 239
    .local v3, "fos":Ljava/io/FileOutputStream;
    :try_start_a
    new-instance v4, Ljava/io/ObjectOutputStream;

    invoke-direct {v4, v3}, Ljava/io/ObjectOutputStream;-><init>(Ljava/io/OutputStream;)V
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_6

    .line 241
    .local v4, "oos":Ljava/io/ObjectOutputStream;
    :try_start_b
    invoke-virtual {v0, v4}, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->save(Ljava/io/ObjectOutputStream;)V

    .line 243
    invoke-virtual {v4}, Ljava/io/ObjectOutputStream;->flush()V

    .line 244
    invoke-virtual {v4}, Ljava/io/ObjectOutputStream;->close()V

    .line 247
    invoke-static {}, LuTools/uUtils;->GetuUtilsClassName()Ljava/lang/String;

    move-result-object v5

    const-string v6, "%s Aho-Corasick file succesfully saved!"

    .line 249
    invoke-virtual {v1}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v7

    filled-new-array {v7}, [Ljava/lang/Object;

    move-result-object v7

    invoke-static {v6, v7}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v6

    .line 246
    invoke-static {v5, v6}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_4

    .line 251
    :try_start_c
    invoke-virtual {v4}, Ljava/io/ObjectOutputStream;->close()V
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_6

    .end local v4    # "oos":Ljava/io/ObjectOutputStream;
    :try_start_d
    invoke-virtual {v3}, Ljava/io/FileOutputStream;->close()V
    :try_end_d
    .catch Ljava/io/IOException; {:try_start_d .. :try_end_d} :catch_1

    .line 257
    .end local v3    # "fos":Ljava/io/FileOutputStream;
    goto :goto_6

    .line 237
    .restart local v3    # "fos":Ljava/io/FileOutputStream;
    .restart local v4    # "oos":Ljava/io/ObjectOutputStream;
    :catchall_4
    move-exception v5

    :try_start_e
    invoke-virtual {v4}, Ljava/io/ObjectOutputStream;->close()V
    :try_end_e
    .catchall {:try_start_e .. :try_end_e} :catchall_5

    goto :goto_4

    :catchall_5
    move-exception v6

    :try_start_f
    invoke-virtual {v5, v6}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .end local v0    # "corasickObject":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<Ljava/lang/String;>;"
    .end local v1    # "file":Ljava/io/File;
    .end local v2    # "generateAutomatonData":Z
    .end local v3    # "fos":Ljava/io/FileOutputStream;
    .end local p0    # "blockList":Ljava/util/AbstractMap$SimpleEntry;, "Ljava/util/AbstractMap$SimpleEntry<Ljava/util/Set<Ljava/lang/String;>;Ljava/lang/String;>;"
    :goto_4
    throw v5
    :try_end_f
    .catchall {:try_start_f .. :try_end_f} :catchall_6

    .end local v4    # "oos":Ljava/io/ObjectOutputStream;
    .restart local v0    # "corasickObject":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<Ljava/lang/String;>;"
    .restart local v1    # "file":Ljava/io/File;
    .restart local v2    # "generateAutomatonData":Z
    .restart local v3    # "fos":Ljava/io/FileOutputStream;
    .restart local p0    # "blockList":Ljava/util/AbstractMap$SimpleEntry;, "Ljava/util/AbstractMap$SimpleEntry<Ljava/util/Set<Ljava/lang/String;>;Ljava/lang/String;>;"
    :catchall_6
    move-exception v4

    :try_start_10
    invoke-virtual {v3}, Ljava/io/FileOutputStream;->close()V
    :try_end_10
    .catchall {:try_start_10 .. :try_end_10} :catchall_7

    goto :goto_5

    :catchall_7
    move-exception v5

    :try_start_11
    invoke-virtual {v4, v5}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .end local v0    # "corasickObject":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<Ljava/lang/String;>;"
    .end local v1    # "file":Ljava/io/File;
    .end local v2    # "generateAutomatonData":Z
    .end local p0    # "blockList":Ljava/util/AbstractMap$SimpleEntry;, "Ljava/util/AbstractMap$SimpleEntry<Ljava/util/Set<Ljava/lang/String;>;Ljava/lang/String;>;"
    :goto_5
    throw v4
    :try_end_11
    .catch Ljava/io/IOException; {:try_start_11 .. :try_end_11} :catch_1

    .line 251
    .end local v3    # "fos":Ljava/io/FileOutputStream;
    .restart local v0    # "corasickObject":Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;, "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<Ljava/lang/String;>;"
    .restart local v1    # "file":Ljava/io/File;
    .restart local v2    # "generateAutomatonData":Z
    .restart local p0    # "blockList":Ljava/util/AbstractMap$SimpleEntry;, "Ljava/util/AbstractMap$SimpleEntry<Ljava/util/Set<Ljava/lang/String;>;Ljava/lang/String;>;"
    :catch_1
    move-exception v3

    .line 253
    .local v3, "e":Ljava/io/IOException;
    invoke-static {}, LuTools/uUtils;->GetuUtilsClassName()Ljava/lang/String;

    move-result-object v4

    .line 255
    invoke-virtual {v3}, Ljava/io/IOException;->toString()Ljava/lang/String;

    move-result-object v5

    .line 252
    invoke-static {v4, v5}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 260
    .end local v3    # "e":Ljava/io/IOException;
    :cond_1
    :goto_6
    new-instance v3, Ljava/util/AbstractMap$SimpleEntry;

    invoke-virtual {p0}, Ljava/util/AbstractMap$SimpleEntry;->getKey()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/util/Set;

    invoke-interface {v4}, Ljava/util/Set;->size()I

    move-result v4

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-direct {v3, v0, v4}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    return-object v3
.end method

.method public static SearchInSetCorasick(Ljava/lang/String;Ljava/util/AbstractMap$SimpleEntry;LuTools/uUtils$entries;)Z
    .locals 5
    .param p0, "value"    # Ljava/lang/String;
    .param p2, "entriesEnum"    # LuTools/uUtils$entries;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/AbstractMap$SimpleEntry<",
            "Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/Integer;",
            ">;",
            "LuTools/uUtils$entries;",
            ")Z"
        }
    .end annotation

    .line 263
    .local p1, "corasickObject":Ljava/util/AbstractMap$SimpleEntry;, "Ljava/util/AbstractMap$SimpleEntry<Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie<Ljava/lang/String;>;Ljava/lang/Integer;>;"
    nop

    .line 264
    invoke-virtual {p1}, Ljava/util/AbstractMap$SimpleEntry;->getKey()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;

    invoke-virtual {v0, p0}, Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie;->parseText(Ljava/lang/CharSequence;)Ljava/util/List;

    move-result-object v0

    .line 266
    .local v0, "foundResults":Ljava/util/List;, "Ljava/util/List<Lcom/hankcs/algorithm/AhoCorasickDoubleArrayTrie$Hit<Ljava/lang/String;>;>;"
    invoke-virtual {p2}, LuTools/uUtils$entries;->name()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    sparse-switch v2, :sswitch_data_0

    :cond_0
    goto :goto_0

    :sswitch_0
    const-string v2, "ANY"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    move v1, v4

    goto :goto_1

    :sswitch_1
    const-string v2, "ALL"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    move v1, v3

    goto :goto_1

    :goto_0
    const/4 v1, -0x1

    :goto_1
    packed-switch v1, :pswitch_data_0

    .line 278
    move v3, v4

    goto :goto_2

    .line 270
    :pswitch_0
    new-instance v1, LuTools/uUtils$2;

    invoke-direct {v1, v0}, LuTools/uUtils$2;-><init>(Ljava/util/List;)V

    .line 274
    invoke-virtual {v1}, LuTools/uUtils$2;->size()I

    move-result v1

    .line 276
    invoke-virtual {p1}, Ljava/util/AbstractMap$SimpleEntry;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    if-ne v1, v2, :cond_1

    goto :goto_2

    :cond_1
    move v3, v4

    goto :goto_2

    .line 268
    :pswitch_1
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_2

    goto :goto_2

    :cond_2
    move v3, v4

    .line 266
    :goto_2
    return v3

    :sswitch_data_0
    .sparse-switch
        0xfd81 -> :sswitch_1
        0xfdcc -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public static SetAppTheme(Z)V
    .locals 0
    .param p0, "value"    # Z

    .line 290
    sput-boolean p0, LuTools/uUtils;->isDarkTheme:Z

    .line 291
    return-void
.end method

.method public static SetLithoActionDownDuration(Landroid/view/MotionEvent;)V
    .locals 4
    .param p0, "motionEvent"    # Landroid/view/MotionEvent;

    .line 95
    invoke-virtual {p0}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    packed-switch v0, :pswitch_data_0

    goto :goto_0

    .line 100
    :pswitch_0
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    sget-wide v2, LuTools/uUtils;->lithoActionDownStartTime:J

    sub-long/2addr v0, v2

    sput-wide v0, LuTools/uUtils;->lithoActionDownDuration:J

    goto :goto_0

    .line 97
    :pswitch_1
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    sput-wide v0, LuTools/uUtils;->lithoActionDownStartTime:J

    .line 102
    :goto_0
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public static SetMainActivity(Landroid/app/Activity;)V
    .locals 1
    .param p0, "activity"    # Landroid/app/Activity;

    .line 115
    new-instance v0, Ljava/lang/ref/WeakReference;

    invoke-direct {v0, p0}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    sput-object v0, LuTools/uUtils;->mainActivity:Ljava/lang/ref/WeakReference;

    .line 116
    return-void
.end method

.method public static SetNavBarIndexByMainActivity()V
    .locals 6

    .line 294
    invoke-static {}, LuTools/uUtils;->GetMainActivity()Landroid/app/Activity;

    move-result-object v0

    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v5, -0x1

    sparse-switch v1, :sswitch_data_0

    :cond_0
    goto :goto_0

    :sswitch_0
    const-string v1, "com.google.android.youtube.action.open.subscriptions"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    move v0, v3

    goto :goto_1

    :sswitch_1
    const-string v1, "com.google.android.youtube.action.open.shorts"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    move v0, v4

    goto :goto_1

    :sswitch_2
    const-string v1, "com.google.android.youtube.action.open.search"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    move v0, v2

    goto :goto_1

    :goto_0
    move v0, v5

    :goto_1
    packed-switch v0, :pswitch_data_0

    .line 298
    goto :goto_2

    .line 297
    :pswitch_0
    move v2, v3

    goto :goto_2

    .line 296
    :pswitch_1
    move v2, v4

    goto :goto_2

    .line 295
    :pswitch_2
    move v2, v5

    .line 298
    :goto_2
    sput v2, LuTools/uBlocker;->currentNavBarIndex:I

    .line 300
    return-void

    nop

    :sswitch_data_0
    .sparse-switch
        -0xf94baba -> :sswitch_2
        -0xf6414eb -> :sswitch_1
        0x7514bd98 -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public static SetStatsForNerdsClientName(Ljava/lang/String;)V
    .locals 0
    .param p0, "value"    # Ljava/lang/String;

    .line 326
    sput-object p0, LuTools/uUtils;->statsForNerdsClientName:Ljava/lang/String;

    .line 327
    return-void
.end method

.method public static SetSystemTheme(Ljava/lang/Enum;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Enum<",
            "*>;)V"
        }
    .end annotation

    .line 287
    .local p0, "value":Ljava/lang/Enum;, "Ljava/lang/Enum<*>;"
    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    sput-boolean v1, LuTools/uUtils;->isDarkTheme:Z

    .line 288
    return-void
.end method

.method static synthetic lambda$InitializeNewBlockList$0(Ljava/lang/String;)Ljava/lang/String;
    .locals 0
    .param p0, "filter"    # Ljava/lang/String;

    .line 230
    return-object p0
.end method

.method static synthetic lambda$InitializeNewBlockList$1(Ljava/lang/String;)Ljava/lang/String;
    .locals 0
    .param p0, "filter"    # Ljava/lang/String;

    .line 232
    return-object p0
.end method

.method static synthetic lambda$static$2(Ljava/lang/Runnable;)Ljava/lang/Thread;
    .locals 2
    .param p0, "r"    # Ljava/lang/Runnable;

    .line 315
    new-instance v0, Ljava/lang/Thread;

    invoke-direct {v0, p0}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 316
    .local v0, "t":Ljava/lang/Thread;
    const/16 v1, 0xa

    invoke-virtual {v0, v1}, Ljava/lang/Thread;->setPriority(I)V

    .line 317
    return-object v0
.end method
